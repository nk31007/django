#!/data/py38env/bin/python3

"""
Exposes metrics collected from different gunicorn process and expose over http for Prometheus server to scrap.
"""

from prometheus_client.exposition import make_wsgi_app
from wsgiref.simple_server import make_server

from prometheus_client.core import CollectorRegistry
from prometheus_client.multiprocess import MultiProcessCollector

import logging
import sys

# Logging
logger = logging.getLogger("config")
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
logger.addHandler(ch)


def start_metrics_exporter(port):
    """
    Exposes metrics over http
    :param port: Port where the metrics will be made available. ex: http://localhost:9000/metrics
    """
    registry = CollectorRegistry()
    collector = MultiProcessCollector(registry, '/data/metrics')
    app = make_wsgi_app(registry)
    httpd = make_server('', port, app)
    logger.info('starting metric exporter @ %d' % port)
    httpd.serve_forever()


if __name__ == "__main__":
    # if port is passed, then the metrics will be available in that port else will be available in default 9000 port
    port = int(sys.argv[1]) if len(sys.argv) >= 2 else 9000
    start_metrics_exporter(port)
