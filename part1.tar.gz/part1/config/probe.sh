#!/bin/bash
# This is hugly but looks like we can't trust http probe in Kube
# Args are either `test` or `status`
curl "localhost:8000/nmsys/api/$1/"

