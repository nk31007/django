# nmSys Server

nmSys is an alerting system, integrated with Epic. It handles tens of millions of unique alerts that update every minute, and sends tens of thousands of notifications every day.

nmSys’s features include:

Filtered based escalation with multi-criteria pattern matching
Threshold alert creation for any Epic metric
Subscription based escalation
Default monitoring for all hosts running nmSys-client/epic-client
Escalation paths supported: CentralStation, Espresso, PagerDuty, Pager, Email
Export formats: JSON, HTML, CSV, XML, PNG
Per event escalation triage
Modular client supporting: default alerting, user plugins, scheduling, method to publish stats to Epic
Endpoints
Production: https://nmsys.isg.apple.com

QA (UAT): https://nmsys.qa.isg.apple.com


Docs : https://epic.isg.apple.com/docs/alerting/
RIO : https://rio.apple.com/projects/iso-nmsys-server
 

