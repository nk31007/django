curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{
  "source": {
    "index": "epic",
    "type": "filter"
  },
  "dest": {
    "index": "nmsys-filter",
    "type": "_doc"
  }
}
'



curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "epic",
    "type": "alert"
  },
  "dest": {
    "index": "nmsys-alert",
    "type": "_doc"
  }
}
'


curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "epic",
    "type": "ack"
  },
  "dest": {
    "index": "nmsys-ack",
    "type": "_doc"
  }
}
'


curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "epic",
    "type": "node"
  },
  "dest": {
    "index": "nmsys-node",
    "type": "_doc"
  }
}
'

curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "epic",
    "type": "plugin"
  },
  "dest": {
    "index": "nmsys-plugin",
    "type": "_doc"
  }
}
'


curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "epic",
    "type": "maintenance"
  },
  "dest": {
    "index": "nmsys-maintenance",
    "type": "_doc"
  }
}
'

curl -X POST -H 'Content-Type: application/json' "17.142.128.161:9210/_reindex" -d '
{ 
  "source": {
    "index": "notification",
    "type": "notification"
  },
  "dest": {
    "index": "nmsys-notification",
    "type": "_doc"
  }
}
'








