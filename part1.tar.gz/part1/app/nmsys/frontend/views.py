


# Create your views here.

from django.shortcuts import render
from django.template import RequestContext
from django.shortcuts import HttpResponse
from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from django.views.decorators.csrf import csrf_exempt

from contrib.explode import explode_epic, explode_nmsys, explode_nmsys_plugin, build_filter
from backend.models import Filter, Plugin, Maintenance

from contrib.get_filter import extract_parameters

from provider.oauth2.models import Client
from django.contrib.auth.models import User, Group
from provider.oauth2.models import AccessToken
from datetime import datetime, timedelta

from elasticsearch import Elasticsearch

import ujson as json
import logging
import os
logger = logging.getLogger("django")

from django.views.generic import TemplateView


class ExtraContextTemplateView(TemplateView):
    extra_context = None

    def get_context_data(self, *args, **kwargs):
        context = super(ExtraContextTemplateView, self).get_context_data(*args, **kwargs)
        if self.extra_context:
            context.update(self.extra_context)
        if self.request:
            context.update(
                {
                    'get': extract_parameters(self.request), 
                    'stats_instance': settings.STATS_INSTANCE, 
                    'stats_locale': settings.STATS_LOCALE, 
                    'stats_node': settings.STATS_NODE,
                    'stats_epic': settings.EPIC_URL
                }
            )
        context.update(self.kwargs)
        return context

def wizard_create(request, action=None, resource=None):
    extra = request.GET.get('url', None)
    template = 'frontend/wizard_main.html'
    if extra or resource != "epic":
        template = 'frontend/wizard_create.html'
    return render(
        request, 
        template,
        {
            'action': action,
            'resource': resource,
            'apz': settings.APZ, 
            'get': extract_parameters(request, page='main')
        }
    )

def wizard_modify(request, action=None, resource=None, name=None):
    template = 'update'
    owner = ''
    try:
        if resource == 'filter':
            content = Filter.get(id=name)
            owner = content.information.username
        elif resource == 'plugin':
            content = Plugin.get(id=name)
            owner = content.deployment.owner
        elif resource == 'group':
            content = Group.get(id=name)
            owner = content.name
        elif resource == 'maintenance':
            content = Maintenance.get(id=name)
            owner = content.schedule.owner
        else:
            return HttpResponse(json.dumps({'success': False}))

        if action in ['subscribe', 'unsubscribe', 'disable', 'enable']:
            template = 'subscribe'
        elif action == 'delete':
            template = 'delete'

        return render(
            request,
            'frontend/wizard_%s.html' % template,
            {
                'action': action,
                'me': request.user.username,
                'name': name,
                'resource': resource,
                'owner': owner,
                'apz': settings.APZ, 
                'application': content.application if action in ['update', 'duplicate', 'rename'] else name,
                'content': json.dumps(content.to_dict())
            }
        )
    except:
        return render(
            request,
            'frontend/wizard_nofound.html',
            {
                'action': action,
                'resource': resource,
                'apz': settings.APZ, 
                'me': request.user.username,
                'name': name,
            }
        )

### Wizards helpers
@csrf_exempt
def wizard_validate(request, action):
    result = {}
    try:
        data = json.loads(request.body)
    except ValueError:
        logger.critical('[ wizard_validate ]  You just tried to save non json data %s' % request.body)
        return HttpResponse(json.dumps(result))
    logger.debug('[ wizard_validate ] User %s is trying to validate %s |> Data : %s' % (request.user.username, action, data))

    return HttpResponse(json.dumps(result))

@csrf_exempt
def builder(request, type_call):
    result = {}
    try:
        data = json.loads(request.body)
    except ValueError:
        logger.critical('[ builder ]  You just tried to save non json data %s' % request.body)
        return HttpResponse(json.dumps(result))
    logger.debug('[ builder ] User %s is trying to build %s |> Data : %s' % (request.user.username, type_call, data))

    if type_call == 'filter':
        logger.debug('[ builder nmsys ] %s' % data)
        result = explode_nmsys(data)
        logger.debug('[ builder ] %s' % result)
    elif type_call == 'epic':
        result = explode_epic(data)
        logger.debug('[ builder ] %s' % result)
    elif type_call == 'nmsysclient':
        logger.debug('[ builder nmsys ] %s' % data)
        result = explode_nmsys_plugin(data)
        logger.debug('[ builder ] %s' % result)

    return HttpResponse(json.dumps(result))

#############
# Session Context Switching
@csrf_exempt
def context_switch(request):
    try:
        data = json.loads(request.body)
    except:
        logger.critical('[ context_switch ]  You just tried to save non json data %s' % request.body)
        return HttpResponse(json.dumps({'success': True}))
    logger.debug("[ context_switch ] New Request %s %s" % (data, request.user.groups.all()))
    group_list = request.user.groups.values_list('name', flat=True)
    if data['contextSwitch'] in group_list or 'epic-admin' in group_list or data['contextSwitch'] == request.user.username:
        request.session['contextSwitch'] = data['contextSwitch']
    else:
        HttpResponse(json.dumps({'success': False}))
    return HttpResponse(json.dumps({'success': True}))


def docs(request, filename='README.md'):
    logger.debug("[ docs ] New Request %s" % filename)
    arr_file = []
    for file in os.listdir(settings.DOC_ROOT):
        if file.endswith(".md"):
            arr_file.append(file)
    if filename not in arr_file:
        if filename.endswith('.png'):
            with open(settings.DOC_ROOT + filename, "rb") as f:
                return HttpResponse(f.read(), mimetype="image/jpeg")
        if filename.endswith('.mov'):
            return render(request, 'frontend/video.html', {
                    'content': filename,
                    'list': sorted(arr_file),
                    'get': extract_parameters(request, page='main')
            }, context_instance=RequestContext(request))
        filename = 'README.md'
    markD = open(settings.DOC_ROOT + filename).read()
    return render(
        request, 
        'frontend/docs.html', 
        {
            'content': markD, 
            'list': sorted(arr_file), 
            'get': extract_parameters(request, page='main')
        },
    )

def monitoring(request, name):

    hosts = []
    for server in getattr(settings, "ES_HOST").split(","):
        host, port = server.strip().split(":")
        hosts.append({"host": host, "port": port})
    es = Elasticsearch(hosts)
    if name == 'cluster':
        return HttpResponse(json.dumps(es.cluster.health()))
    else:
        return HttpResponse({})

def maintenance(request):
    content = build_filter()
    return render(
        request, 
        'frontend/maintenance.html', 
        {
            'content': content,
            'get': extract_parameters(request, page='main')
        }
    )

def nmsys_cli(request):
    filename = 'nmsys-cli.py'
    user = User.objects.get(id=request.user.id)
    oauth_client, cr = Client.objects.get_or_create(user=user,
                                                name="NmsysClient account", client_type=1,
                                                url="http://nmsysapi.isg.apple.com")
    token, cr = AccessToken.objects.get_or_create(user=user, client=oauth_client, scope=6)
    token.expires = datetime.now() + timedelta(days=5*365)
    token.save()
    content = open(settings.DOC_ROOT + filename).read()
    content = content.replace('__KEY_ACCESS_NUMBER__', token.token)
    content = content.replace('__ENDPOINT__', settings.FRONTENDPOINT)
    content = content.replace('__VERSION__', settings.CLI_VERSION)
    return HttpResponse(content, content_type='text/plain')



def export(request, type):
    pass
