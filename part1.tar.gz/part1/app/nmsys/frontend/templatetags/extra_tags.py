from django import template
from django.conf import settings
import datetime
import pytz
register = template.Library()


@register.simple_tag()
def workday():
    date_today = datetime.datetime.utcnow().replace(hour=10, minute=0, second=0).replace(tzinfo=pytz.timezone('US/Pacific'))

    shift = 1 + ((date_today.weekday()//4)*(6-date_today.weekday()))
    return (date_today + datetime.timedelta(shift)).isoformat()


@register.simple_tag()
def centralstation_config_items():
    result = []
    for key, value in sorted(settings.CENTRALSTATION_CONFIG_ITEMS.items()):
        result.append(
            """
            <li class="selected">
                <a tabindex="1" class="">
                    <span class="text">%s</span>
                </a>
            </li>
            """ % value
        )
    return '\n'.join(result)


@register.simple_tag()
def aipo_config_items():
    result = []
    for key, value in sorted(settings.AIPO_CONFIG_ITEMS.items()):
        result.append(
            """
            <li class="selected">
                <a tabindex="1" class="">
                    <span class="text">%s</span>
                </a>
            </li>
            """ % value
        )
    return '\n'.join(result)


@register.simple_tag()
def build_status_list():
    color_paint = {
        'OK': '39b54a',
        'WARNING': 'FAFF7E',
        'INFO': 'A4A8DB',
        'CRITICAL': 'e01806',
        'UNKNOWN': 'E7A65F',
        'Acknowledged': 'cccccc'
    }
    result = []
    for key, value in color_paint.items():
        result.append("status_"+key+":title="+key+":color="+value)
    return '!'.join(result)
