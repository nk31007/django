__author__ = 'rfoucher'


def is_owner(registered_alert, request):
    creator, name = registered_alert.registered_alert_name.split('@', 1)
    user = request.user.username
    groups = request.user.groups.values_list('name', flat=True)
    if creator == user or creator in groups:
        return 1
    else:
        return 0


def is_template(registered_alert):
    creator, name = registered_alert.registered_alert_name.split('@', 1)
    if creator in ['nmsys', 'common', 'default', 'epic']:
        return 0
    else:
        return 1
