from django.conf.urls import url
from frontend.views import ExtraContextTemplateView
from django.http import HttpResponse
from django.contrib import admin
from frontend import views
admin.autodiscover()


urlpatterns = [
    url(
        r'main/(?P<info>[^/]+)/$', ExtraContextTemplateView.as_view(
            template_name='frontend/main.html',
        ),
        name='home'
    ),
    url(
        r'^test$', lambda request: HttpResponse("Hello World", content_type="text/plain"),
    ),
    url(
        r'search/(?P<info>[^/]+)/$', ExtraContextTemplateView.as_view(template_name='frontend/search.html'),
        name='search'
    ),
    url(
        r'^plugin/$',
        ExtraContextTemplateView.as_view(template_name='frontend/plugin.html'),
        name='plugin'
    ),
    url(
        r'^plugin/(?P<name>[^/]+)/$',
        ExtraContextTemplateView.as_view(template_name='frontend/plugin.html'),
        name='plugin'
    ),
    url(
        r'^maintenance/(?P<name>[^/]+)/$',
        ExtraContextTemplateView.as_view(template_name='frontend/maintenance.html'),
        name='plugin'
    ),
    url(
        r'^node/(?P<info>[^/]+)/(?P<name>.*)$',
        ExtraContextTemplateView.as_view(template_name='frontend/node.html'),
    ),
    url(
        r'^monitoring/(?P<info>[^/]+)/$',
        ExtraContextTemplateView.as_view(template_name='frontend/monitoring.html'),
    ),
    url(
        r'^monitoring/(?P<info>[^/]+)/(?P<name>[^/]+)/$', views.monitoring
    ),
    url(
        r'^maintenance/$', views.maintenance,
    ),
    url(
        r'^filter/(?P<info>[^/]+)/(?P<name>[^/]+)/$',
        ExtraContextTemplateView.as_view(template_name='frontend/filter.html'),
    ),
    url(
        r'^alert/(?P<info>[^/]+)/(?P<name>[^/]+)/(?P<locale>[^/]+)/(?P<instance>[^/]+)/$',
        ExtraContextTemplateView.as_view(template_name='frontend/alert.html'),
    ),
    url(
        r'^alert/(?P<name>[^/]+)/$$',
        ExtraContextTemplateView.as_view(template_name='frontend/alert.html'),
        name='alert'
    ),

    url(
        r'^rename/$',
        ExtraContextTemplateView.as_view(template_name='frontend/wizard_rename.html'),
        name='rename'
    ),
    url(
        r'^group/$',
        ExtraContextTemplateView.as_view(template_name='frontend/group.html'),
        name='group'
    ),
    url(
        r'^preferences/$',
        ExtraContextTemplateView.as_view(template_name='frontend/preferences.html'),
        name='preferences'
    ),
    url(
        r'^contacts/$',
        ExtraContextTemplateView.as_view(template_name='frontend/contacts.html'),
        name='contacts'
    ),

    # Path for creation
    url(r'^wizard/(?P<action>[^/]+)/(?P<resource>[^/]+)/(\?.*)?$', views.wizard_create),
    url(r'^wizard/(?P<action>[^/]+)/(?P<resource>[^/]+)/(?P<name>[^/]+)/', views.wizard_modify),
    url(r'^wizard_validate/(?P<action>[^/]+)/(\?.*)?$', views.wizard_validate),

    url(r'^builder/(?P<type_call>[^/]+)/', views.builder),

    url(r'^docs/$', views.docs),
    url(r'^docs/(?P<filename>[^/]+)/', views.docs),

    url(r'^context_switch/', views.context_switch),

    url(r'^nmsys-cli.py$', views.nmsys_cli),
]


handler404 = 'contrib.custom_error.page_not_found'
handler500 = 'contrib.custom_error.server_error'
