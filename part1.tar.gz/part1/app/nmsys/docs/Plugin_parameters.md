[HaproxyPlugin]
source = http://127.0.0.1
auth = 
user = 
password = 
proxy = 
ignore = 
all = 
type = 

[JenkinsPlugin]
source = http://127.0.0.1

[MemcachedPlugin]
host = 127.0.0.1
port = 11211

[MongodbPlugin]
host = 127.0.0.1
port = 27018
username = 
password = 
database = 

[MysqlPlugin]
username = 
password = 
host = 127.0.0.1
port = 3306
type = 
extra = 

[NginxPlugin]
source = http://127.0.0.1:8000/nginx_status


[ElasticsearchPlugin]
source = http://es-server.apple.com:9200

[PostgresqlPlugin]
host: 127.0.0.1
port: 5432
username:
password:

[NmsysServerPlugin]
host = 127.0.0.1
port = 6000
database = 

[PuppetPlugin]
puppetrun_file = /var/lib/puppet/state/last_run_summary.yaml

[RabbitmqPlugin]
rabbitmqstatusurl = http://127.0.0.1:9000/status
exclude_queue = 
rabbitmquser = 
rabbitmqpass = 

[RedisPlugin]
host = 127.0.0.1
port = 6379

[NmsysPlugin]
node = 
run = 60
servicename = 
params = 
path =
occurrence =
action = apps,common,database,hardware,isg,nmsys,openstack,test,lib,reports
command = check_http_vip.py,check_mysql.py,check_uptime.py,check_mailq.pl,check_swap.ksh,check_load.py,check_user_limits.pl,check_hardware.py,check_filesystem.py,check_memory_utilization.py,check_running_process.py,check_mounts.py,check_harddrive.py,check_minimal.py,check_disk_local.py,check_puppet_run.py,check_network.py,check_fusionIO,check_local_dns.py,check_privatenetwork.ksh,check_basic_hardware.sh,check_hardware.py,check_harddrive.py,check_smart.py,check_ipmi.py,check_ldap.py,check_puppet.py,thisIsCritical.py,thisIsOK.py,thisIsRandom.py,check_dt_service,check_glance1,check_keystone,check_novaapi,check_rabbitmq,check_swift,criticalbutFine.py,everythingFine.py,long_runningCheck.py,subprocessfork.py,warningandfine.py,wrongOutputCheck.py,wrongReturnCheck.py,raid_report.py,cpu_report.py

