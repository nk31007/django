#!/usr/bin/env python
"""usage: %prog <command> [command-options]

This client uses the HTTP nmSys API to issue commands and retrieve information.

Warning it will only work with the nmSys server version 4 !

Usage:

    %prog <command> [command-options]


    For any command please check --help if you need more details :
        %prog <command> --help

General

    %prog list-command

Status Viewing

    %prog status

Acknowledgment Management

    %prog ack [filter] --comment|-c=TEXT

    %prog cancel-ack [filter]

Downtime Management

    %prog silence [filter]s --duration [d] --comment|-c=TEXT

    %prog cancel-silence [filter]

Maintenance

    %prog maintenance [filter]s --duration [d] --comment|-c=TEXT

    %prog cancel-maintenance [filter]s 

    %prog list-maintenance [filter]s

"""

__author__ = 'rfoucher'
__version__ = '__VERSION__'

import re
import logging
import sys
root = logging.getLogger()
root.setLevel(logging.DEBUG)

if int(sys.version_info[1]) <= 4:
    print('Outdated version of Python.')
    sys.exit(1)


from json import loads, dumps
from optparse import OptionParser

try:
    from urllib.parse import urlparse, urlencode
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError, URLError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
    from urllib2 import urlopen, Request, HTTPError, URLError

import datetime
import time
import ssl

whatever = '__KEY_ACCESS_NUMBER__'


def query_formater(dic_format):
    result_keys = ['a', 'n', 'd']
    result = {
        'search_q': []
    }
    for (key, val) in dic_format.items():
        if key in result_keys:
            result['search_q'].append("%s:%s" % (key, val))
        else:
            result[key] = val
    result['search_q'] = ' AND '.join(result['search_q'])
    return result


def time_to_datetime(c_input, reference=int(time.time())):
    """ Convert 2days, 2d to time in seconds"""
    match = re.match(r'^[e-]?(\d+)(h|d|w|mo|m|y|s)', c_input)
    if match is not None:
        val, denom = match.groups()
        multiplier = {
            'y': datetime.timedelta(days=365*int(val)),
            'mo': datetime.timedelta(days=30*int(val)),
            'w': datetime.timedelta(days=7*int(val)),
            'd': datetime.timedelta(days=int(val)),
            'h': datetime.timedelta(hours=int(val)),
            'm': datetime.timedelta(minutes=int(val)),
            's': datetime.timedelta(seconds=int(val)),
        }
        return int(reference + (multiplier[denom]).total_seconds())
    try:
        date_date = datetime.datetime.strptime(c_input, "%Y-%m-%d %H:%M:%S.%f").strftime("%s")
        return int(date_date)
    except Exception as e:
        raise('Incorrect input value for duration')
    try:
        return int(reference - int(c_input))
    except:
        return int(reference)


def create_full_uri(data):
    return '%s%s' % (URL, data)


def transmit(url):
    req = Request(url)
    log.debug('Transmit %s' % url)
    req.add_header('Accept', 'application/json')
    req.add_header("Content-type", "application/x-www-form-urlencoded")
    req.get_method = lambda: 'GET'
    context = ssl._create_unverified_context()

    try:
        response = urlopen(req, context=context)
        result = response.read()
        log.debug(response.getcode())
        log.debug(response.info())
        log.debug(response.msg)
        return loads(result)
    except HTTPError as he:
        if he.getcode() == 401:
            try:
                print(he.readlines()[0])
            except:
                log.critical(url)
                log.critical(he.getcode())
                log.critical(he.info())
                log.critical(he.msg)
            return {'meta': {'next': False, 'error': True}, 'objects': []}
        else:
            log.critical(url)
            log.critical(he.getcode())
            log.critical(he.info())
            log.critical(he.msg)
            return {'meta': {'next': False}, 'objects': []}
    except URLError as ue:
        log.critical('Major URLError %s' % ue)
        return {'meta': {'next': False}, 'objects': []}


def iterator_api(result):
    yield result
    while result['meta']['next']:
        url = create_full_uri(result['meta']['next'])
        result = transmit(url)
        yield result


def init_get(type_rest, consumer_key, q_search):
    params = {
        'oauth_consumer_key': consumer_key,
        'format': 'json',
        'limit': 100,
    }
    params.update(query_formater(q_search))
    return {
        'meta': {
            'next': '/nmsys/api/rest/v2/%s/?%s' % (type_rest, urlencode(params))
        }
    }


def data_patch(url, type_rest, consumer_key, data):
    params = {
        'oauth_consumer_key': consumer_key,
        'format': 'json',
    }
    req = Request('%s/nmsys/api/rest/v2/%s/?%s' % (url, type_rest, urlencode(params)))
    req.add_header('Accept', 'application/json')
    req.add_header("Content-type", "application/json")
    req.get_method = lambda: 'PATCH'
    context = ssl._create_unverified_context()

    try:
        response = urlopen(req, dumps(data), context=context)
        result = response.read()
        return result
    except HTTPError as he:
        log.critical(url)
        log.critical(he.getcode())
        log.critical(he.info())
        log.critical(he.msg)
        return {'meta': {'next': False}, 'objects': []}
    except URLError as ue:
        log.critical('Major URLError %s' % ue)
        return {'meta': {'next': False}, 'objects': []}


def data_post(url, type_rest, consumer_key, data):
    params = {
        'oauth_consumer_key': consumer_key,
        'format': 'json'
    }
    req = Request('%s/nmsys/api/rest/v2/%s/?%s' % (url, type_rest, urlencode(params)))
    req.add_header('Content-Type', 'application/json')
    req.get_method = lambda: 'POST'
    req.add_header('Accept', 'application/json')
    context = ssl._create_unverified_context()
    try:
        response = urlopen(req, dumps(data), context=context)
        result = response.read()
        return result
    except HTTPError as he:
        log.critical(url)
        log.critical(he.getcode())
        log.critical(he.info())
        log.critical(he.msg)
        return {'meta': {'next': False}, 'objects': []}
    except URLError as ue:
        log.critical('Major URLError %s' % ue)
        return {'meta': {'next': False}, 'objects': []}

def data_delete(url, type_rest, consumer_key, resourceid):
    params = {
        'oauth_consumer_key': consumer_key,
        'format': 'json'
    }
    req = Request('%s/nmsys/api/rest/v2/%s/%s/?%s' % (url, type_rest, resourceid, urlencode(params)))
    req.add_header('Content-Type', 'application/json')
    req.get_method = lambda: 'DELETE'
    req.add_header('Accept', 'application/json')
    context = ssl._create_unverified_context()
    try:
        response = urlopen(req, context=context)
        result = response.read()
        return result
    except HTTPError as he:
        log.critical(url)
        log.critical(he.getcode())
        log.critical(he.info())
        log.critical(he.msg)
        return {'meta': {'next': False}, 'objects': []}
    except URLError as ue:
        log.critical('Major URLError %s' % ue)
        return {'meta': {'next': False}, 'objects': []}

def critical(msg, retval=1):
    """Print a message to STDERR and return a failure code.

    """
    sys.stderr.write(msg)
    return retval


def query_details(cmd, args, opts):
    url_init = init_get('user', whatever, {'oauth': whatever, 'version': __version__})
    result = {}
    for item in iterator_api(url_init):
        result = item
    if 'objects' in result and len(result['objects']) == 1:
        return {'user': result['objects'][0]['username']}
    return {}


def query_yes_no(question, default="no"):
    """Ask a yes/no question via raw_input() and return their answer.

    "question" is a string that is presented to the user.
    "default" is the presumed answer if the user just hits <Enter>.
        It must be "yes" (the default), "no" or None (meaning
        an answer is required of the user).

    The "answer" return value is True for "yes" or False for "no".
    """
    valid = {"yes": True, "y": True, "ye": True,
             "no": False, "n": False}
    if default is None:
        prompt = " [y/n] "
    elif default == "yes":
        prompt = " [Y/n] "
    elif default == "no":
        prompt = " [y/N] "
    else:
        raise ValueError("invalid default answer: '%s'" % default)

    while True:
        sys.stdout.write(question + prompt)
        try:
            choice = raw_input().lower()
        except:
            choice = input().lower()
        if default is not None and choice == '':
            return valid[default]
        elif choice in valid:
            return valid[choice]
        else:
            sys.stdout.write("Please respond with 'yes' or 'no' "
                             "(or 'y' or 'n').\n")

def prettyPrint(dictionary, indent='', braces=1):
    for key, value in dictionary.items():
        if isinstance(value, dict):
            print('%s%s%s%s' % (indent, braces*'[', key, braces*']'))
            prettyPrint(value, indent+'  ', braces+1)
        elif isinstance(value, list):
            ndict=0
            for v in value:
                if isinstance(v, dict):
                    ndict += 1
            if ndict:
                print('%s%s' % (indent, key))
                for e in value:
                    print('#' * 60)
                    if isinstance(e, dict):
                        prettyPrint(e, indent+'  ', braces+1)
                    else:
                         print(indent+'%s : %s' % (key, e))
            else:
                print(indent+'%s : %s' % (key, value))
        elif isinstance(value, datetime.date):
            print(indent + '%s : %s' % (key, str(value)))
        else:
            print(indent+'%s : %s' % (key, value))


def trim(docstring):
    """This is taken from PEP 257 for docstring usage. I'm duplicating
    it here so I can use it to preparse docstrings before sending them
    to OptionParser. Otherwise, I can either not indent my docstrings
    (in violation of the PEP) or I can have the usage outputs be
    indented.

    """
    if not docstring:
        return ''
    # Convert tabs to spaces (following the normal Python rules)
    # and split into a list of lines:
    lines = docstring.expandtabs().splitlines()
    # Determine minimum indentation (first line doesn't count):
    indent = sys.maxsize
    for line in lines[1:]:
        stripped = line.lstrip()
        if stripped:
            indent = min(indent, len(line) - len(stripped))
    # Remove indentation (first line is special):
    trimmed = [lines[0].strip()]
    if indent < sys.maxsize:
        for line in lines[1:]:
            trimmed.append(line[indent:].rstrip())
    # Strip off trailing and leading blank lines:
    while trimmed and not trimmed[-1]:
        trimmed.pop()
    while trimmed and not trimmed[0]:
        trimmed.pop(0)
    # Return a single string:
    return '\n'.join(trimmed)


def do_list_command(cmd, args, opts):
    for key in dispatch:
        print(key)
    return 0


def do_version(cmd, args, opts):
    print(__version__)
    return 0


def do_status(cmd, args, opts):
    """Status for a host or services based one filters. Usage:

        %prog status [opts]

    By default no opts will return the status for ALL Hosts and Services (with a limit of 10 000)
    Build the filter based on what you are really looking for using options :

    Available options:

        -n   (--node)           Node
        -e   (--alert)          Alert
        -t   (--tag)            Verdad Tag ~ Epic nodegroup
        -l   (--list-ids)       List of alerts IDs
        -S   (--status)         Status (CRITICAL, WARNING, OK, UNKNOWN)
        -u   (--user)           Filter on last user ack/silence
        -o   (--locale)   Locale
        -i   (--instance)       Instance
        -r   (--definition)     definition ID
        -a   (--acknowledged)   Already Acknowledged alerts

        -F                      format output (can be plain or json)
        -V                      verbose
    Example:

        %prog status --node nk11a00is-noname001.isg.apple.com
            # check status of all services for nk11a00is-noname001.isg.apple.com

        %prog status --node nk11a00is-noname001.isg.apple.com --alert "Standard Services"
            # check status for Standard Services on nk11a00is-noname001.isg.apple.com

        %prog status --node nk11a00is.* -S CRITICAL,WARNING
            # list status for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

         %prog status -r 1901 -S CRITICAL,WARNING -a 1
            # list all alert for the Alert 1901 that are CRITICAL or WARNING AND already acknowledged

    """
    p = OptionParser(usage=trim(do_status.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-e', '--alert', dest='alert',
                 help='Service to search for')
    p.add_option('-t', '--tag', dest='tag',
                 help='Tag to search for')
    p.add_option('-l', '--list-ids', dest='ids',
                 help='list of ids of alerts comma separted e.g. 10221,112444,1221333')

    p.add_option('-S', '--status', dest='status',
                 help='Comma Separated List of State/Status to search for e.g. CRITICAL,WARNING,OK')

    p.add_option('-o', '--locale', dest='locale',
                 help='Locale to filter on')
    p.add_option('-i', '--instance', dest='instance',
                 help='Instance to filter on')
    p.add_option('-u', '--user', dest='user',
                 help='Instance to filter on')

    p.add_option('-r', '--definition', dest='definition',
                 help='Definition Filter id to search for')
    p.add_option('-a', '--acknowledged', type="int", dest='acknowledged',
                 help='Alerts already acknowledged')

    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')

    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.set_defaults(host=None, regex=None, service=None, tag=None,
                   locale=None, instance=None,
                   limit=0, format='plain', verbose=False)

    (options, args) = p.parse_args(opts)
    get_par = {}
    if options.node is not None:
        get_par['n'] = options.node
    if options.alert is not None:
        get_par['a'] = options.alert
    if options.tag is not None:
        get_par['tag'] = options.tag
    if options.ids is not None:
        get_par['alert_id'] = options.ids

    if options.status is not None:
        get_par['status'] = options.status
    if options.user is not None:
        get_par['user'] = options.user
    if options.locale is not None:
        get_par['locale'] = options.locale
    if options.instance is not None:
        get_par['instance'] = options.instance

    if options.definition is not None:
        get_par['definition'] = options.definition
    if options.acknowledged is not None:
        if options.acknowledged in [0, 1, 2]:
            get_par['acknowledged'] = int(options.acknowledged)
        else:
            return critical("Ack value can only be 1 (see only acknowledged) or 0 (see only non-acknowledged)")
    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    if get_par == {}:
        p.error('You are required to filter on an item to proceed')
        return critical("You are required to filter on an item to proceed")
    url_init = init_get('alert', whatever, get_par)
    validate = query_details(cmd, args, opts)
    if validate == {}:
        return

    for item in iterator_api(url_init):
        if options.format == 'plain':
            prettyPrint({'alerts': item})
        else:
            print(dumps(item))


def do_acknowledge(cmd, args, opts):
    """Acknowledge a host or services based one filters. Usage:

        %prog ack [opts]

    By default no opts will return the status for ALL Hosts and Services (with a limit of 10 000)
    Build the filter based on what you are really looking for using options :

    Available options:

        -n   (--node)           Node
        -e   (--alert)          Alert
        -t   (--tag)            Verdad Tag ~ Epic nodegroup
        -l   (--list-ids)       List of Alerts IDs
        -S   (--status)         Status (CRITICAL, WARNING, OK, UNKNOWN)
        -u   (--user)           Filter on last user ack/silence
        -o   (--locale)         Locale
        -i   (--instance)       Instance
        -r   (--definition)     definition ID

        -c --comment=STR        Comment for the acknowledgement

        -F                      format output (can be plain or json)
        -V                      verbose
        -q --quiet              Non interactive mode - (!use with caution)
    Example:

        %prog ack --node nk11a00is-noname001.isg.apple.com --comment="Disaster recovery on all services."
            # ack alerts of all services for nk11a00is-noname001.isg.apple.com

        %prog ack --node nk11a00is-noname001.isg.apple.com --alert "Standard Services"
            # ack alerts for Standard Services on nk11a00is-noname001.isg.apple.com

        %prog ack --node nk11a00is.* -S CRITICAL,WARNING
            # ack alerts for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

         %prog ack -r 1901 -S CRITICAL,WARNING
            # ack all alerts for the Alert 1901 that are CRITICAL or WARNING

    """
    p = OptionParser(usage=trim(do_acknowledge.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-e', '--alert', dest='alert',
                 help='Service to search for')
    p.add_option('-t', '--tag', dest='tag',
                 help='Tag to search for')
    p.add_option('-l', '--list-ids', dest='ids',
                 help='list of ids of alerts comma separted e.g. 10221,112444,1221333')

    p.add_option('-S', '--status', dest='status',
                 help='Comma Separated List of State/Status to search for e.g. CRITICAL,WARNING,OK')

    p.add_option('-u', '--user', dest='user',
                 help='User last silence')
    p.add_option('-o', '--locale', dest='locale',
                 help='Locale to filter on')
    p.add_option('-i', '--instance', dest='instance',
                 help='Instance to filter on')

    p.add_option('-r', '--definition', dest='definition',
                 help='Definition Filter id to search for')
    p.add_option('-a', '--acknowledged', type="int", dest='acknowledged',
                 help='Alerts already acknowledged')

    p.add_option('-c', '--comment', dest='comment', action='store',
                 help="Comment on the acknowledged problem.")
    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')

    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.add_option('-q', '--quiet', action='store_true', dest='quiet',
            help='Quiet creation')
    p.set_defaults(host=None, regex=None, service=None, tag=None,
                   locale=None, instance=None, quiet=False,
                   limit=0, format='plain', verbose=False)

    (options, args) = p.parse_args(opts)
    get_par = {}
    if options.node is not None:
        get_par['n'] = options.node
    if options.alert is not None:
        get_par['a'] = options.alert
    if options.tag is not None:
        get_par['tag'] = options.tag
    if options.ids is not None:
        get_par['alert_id'] = options.ids
    if options.status is not None:
        get_par['status'] = options.status

    if options.locale is not None:
        get_par['locale'] = options.locale
    if options.instance is not None:
        get_par['instance'] = options.instance
    if options.user is not None:
        get_par['user'] = options.user

    if options.definition is not None:
        get_par['definition'] = options.definition
    if get_par == {}:
        return critical("You are required to filter on an item to proceed")

    if cmd == 'cancel-ack':
        cancel = 0
        get_par['acknowledged'] = 1
    else:
        cancel = 1

    if options.comment is not None:
        new_comment = options.comment
    else:
        new_comment = "No Specific Message - contact user"

    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)

    url_init = init_get('alert', whatever, get_par)
    content = {'objects': []}
    validate = query_details(cmd, args, opts)

    if validate == {}:
        return

    arr_alert = []
    now = int(time.time())
    for item in iterator_api(url_init):
        if 'objects' not in item:
            continue
        for obj in item['objects']:
            ret = {
                'resource_uri': obj['resource_uri'],
                'ack': cancel,
                'comment': new_comment,
                'time_ack': now
            }
            ret.update(validate)
            content['objects'].append(ret)
            arr_alert.append(obj['resource_uri'].split('/')[-2])
    try:
        if len(arr_alert) == 0:
            print("No matching alert, make sure you got the filter right, the alerts might be already acknowledged")
            return
        if query_yes_no("Would you like to list the %s alerts you are about to modify "
                        "(you will have one more chance to abort)?" % len(arr_alert)):
            for alert in arr_alert:
                print(alert)
        if query_yes_no("You are about to modify %s alerts, do you want to proceed (final call)?" % len(arr_alert)):
            print(data_patch(URL, 'alert', whatever, content))
            ret = {
                'alert_id': arr_alert,
                'comment': new_comment,
                'time_ack': int(time.time()),
                'modification': 'ack',
                'modification_value': 'Ack Set'
            }
            ret.update(validate)
            data_post(URL, 'ack', whatever, ret)
            print("You have successfully modified acknowledged %s alerts" % len(arr_alert))
        else:
            print("Aborting")
    except Exception as e:
        print(e)


def do_silence(cmd, args, opts):
    """Status for a host or services based one filters. Usage:

        %prog (cancel-)silence [opts]

    By default no opts will return the status for ALL Hosts and Services (with a limit of 10 000)
    Build the filter based on what you are really looking for using options :

    Available options:

        -n   (--node)           Node
        -e   (--alert)          Alert
        -t   (--tag)            Verdad Tag ~ Epic nodegroup
        -l   (--list-ids)       List of alerts IDs
        -S   (--status)         Status (CRITICAL, WARNING, OK, UNKNOWN)
        -o   (--locale)         Locale
        -i   (--instance)       Instance
        -r   (--definition)     definition ID
        -u   (--user)           User last silence/ack
        -a   (--acknowledged)   Already Acknowledged alerts

        -d --duration           Duration for Acknowledgement Until
        -c --comment=STR        Comment for the acknowledgement

        -F                      format output (can be plain or json)
        -V                      verbose
        -q --quiet              Non interactive mode - (!use with caution)
    Example:

        %prog silence --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
            # silence for 2 days for  all services for nk11a00is-noname001.isg.apple.com

        %prog silence --node nk11a00is-noname001.isg.apple.com --alert "Standard Services" -d 1h
            # silence for 1 hour for Standard Services on nk11a00is-noname001.isg.apple.com

        %prog silence --node nk11a00is.* -S CRITICAL,WARNING -d 1h
            # silence for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING and ack them

         %prog silence --tag ~verdad.tag=.*nmsys -S CRITICAL,WARNING -d 1h
            # silence for 1h for all hosts matching tag .*nmsys with status CRITICAL OR WARNING and ack them

         %prog silence -r 1901 -S CRITICAL,WARNING -d 1d
            # silence for 1 day on all alerts for the Alert 1901 that are CRITICAL or WARNING

    """
    p = OptionParser(usage=trim(do_silence.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-e', '--alert', dest='alert',
                 help='Service to search for')
    p.add_option('-t', '--tag', dest='tag',
                 help='Tag to search for')
    p.add_option('-l', '--list-ids', dest='ids',
                 help='list of ids of alerts comma separted e.g. 10221,112444,1221333')
    p.add_option('-S', '--status', dest='status',
                 help='Comma Separated List of State/Status to search for e.g. CRITICAL,WARNING,OK')

    p.add_option('-o', '--locale', dest='locale',
                 help='Locale to filter on')
    p.add_option('-i', '--instance', dest='instance',
                 help='Instance to filter on')
    p.add_option('-u', '--user', dest='user',
                 help='User last silence')
    p.add_option('-r', '--definition', dest='definition',
                 help='Definition Filter id to search for')
    p.add_option('-a', '--acknowledged', type="int", dest='acknowledged',
                 help='alerts already acknowledged')

    if cmd == 'silence':
        p.add_option('-d', '--duration', dest='duration', action='store',
                     help="Duration to acknowledge until the problem.")
    p.add_option('-c', '--comment', dest='comment', action='store',
                 help="Comment on the acknowledged problem.")
    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')

    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.add_option('-q', '--quiet', action='store_true', dest='quiet',
                help='Quiet creation')
    p.set_defaults(host=None, regex=None, service=None, tag=None,
                   locale=None, instance=None, quiet=False,
                   limit=0, format='plain', verbose=False)

    (options, args) = p.parse_args(opts)
    get_par = {}
    now = int(time.time())
    if options.node is not None:
        get_par['n'] = options.node
    if options.alert is not None:
        get_par['a'] = options.alert
    if options.tag is not None:
        get_par['tag'] = options.tag
    if options.ids is not None:
        get_par['alert_id'] = options.ids
    if options.status is not None:
        get_par['status'] = options.status
    if options.user is not None:
        get_par['user'] = options.user

    if options.locale is not None:
        get_par['locale'] = options.locale
    if options.instance is not None:
        get_par['instance'] = options.instance

    if options.definition is not None:
        get_par['definition'] = options.definition
    if get_par == {}:
        return critical("You are required to filter on an item to proceed")
    if cmd == 'cancel-silence':
        get_par['acknowledged'] = 1
        new_downtime = now
    else:
        if options.duration is not None:
            new_downtime = time_to_datetime(options.duration)
        else:
            return critical("You have to specify a duration for this Acknowledgment until")
    if options.comment is not None:
        new_comment = options.comment
    else:
        new_comment = "No Specific Message - contact user"
    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    url_init = init_get('alert', whatever, get_par)

    content = {'objects': []}
    validate = query_details(cmd, args, opts)
    if validate == {}:
        return
    arr_alert = []
    for item in iterator_api(url_init):
        if 'objects' not in item:
            continue
        for obj in item['objects']:
            ret = {
                'resource_uri': obj['resource_uri'],
                'silence': new_downtime,
                'comment': new_comment,
                'time_ack': now
            }
            ret.update(validate)
            content['objects'].append(ret)
            arr_alert.append(obj['resource_uri'].split('/')[-2])
    try:
        if len(arr_alert) == 0:
            print("No matching alert, make sure you got the filter right, the alerts might be already acknowledged")
            return
        if options.quiet or query_yes_no("Would you like to list the %s alerts you are about to modify "
                        "(you will have one more chance to abort)?" % len(arr_alert)):
            for alert in arr_alert:
                print(alert)
        if options.quiet or query_yes_no("You are about to modify %s alerts, do you want to proceed (final call)?" % len(arr_alert)):
            result = data_patch(URL, 'alert', whatever, content)
            if not options.quiet:
                print(result)
            ret = {
                'alert_id': arr_alert,
                'comment': new_comment,
                'time_ack': now,
                'date_set': new_downtime,
                'modification': 'silence',
                'modification_value': 'Downtime : %s' % new_downtime
            }
            ret.update(validate)
            data_post(URL, 'ack', whatever, ret)
            if not options.quiet:
                print("You have successfully modified silence %s on alerts %s" % (new_downtime, arr_alert))
        else:
            print("Aborting")
    except Exception as e:
        print(e)

def do_maintenance(cmd, args, opts):
    """Maintenance for a host or services based one filters. Usage:

        %prog maintenance [opts]

    Available options:

        -n   (--node)           Node
        -e   (--alert)          Alert (default no filter -> all)

        -s --start              Start time of the maintenance (default now)
        -d --duration           Duration for Acknowledgement Until (default 2d)
        -c --comment=STR        Comment for the maintenance

        -F                      format output (can be plain or json)
        -V                      verbose
        -q --quiet              Non interactive mode - (!use with caution)
    Example:

        %prog maintenance --node nk11a00is-noname001.isg.apple.com -s 1d -d 2d --comment="Disaster recovery on all services."
            # Maintenance starting in 1 day, duration 2 days for all alerts on the node nk11a00is-noname001.isg.apple.com

        %prog maintenance --node nk11a00is-noname001.isg.apple.com --alert 'nmsys.*' -d 1h
            # Maintenance starting now, duration 1 hour for all nmsys.* alerts on the node nk11a00is-noname001.isg.apple.com

         %prog maintenance --node ~verdad.tag=.*nmsys -d 1h
            # Maintenance for 1h for all hosts matching tag .*nmsys for 1 hour

    """
    p = OptionParser(usage=trim(do_maintenance.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-a', '--alert', dest='alert',
                 help='Service to search for')

    p.add_option('-s', '--start', dest='start',
                 help="Start of the maintenance")
    p.add_option('-d', '--duration', dest='duration',
                 help="Duration for the maintenance.")
    p.add_option('-c', '--comment', dest='comment',
                 help="Comment on the acknowledged problem.")
    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')
    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.add_option('-q', '--quiet', action='store_true', dest='quiet',
                 help='Quiet creation')
    p.set_defaults(host=None, alert=None, start='0m', duration=None,
                   limit=0, format='plain', quiet=False, verbose=False)

    (options, args) = p.parse_args(opts)
    create_time = int(time.time())
    get_par = {
        "application": "maintenance",
        "schedule": {
            "dependencies": '0',
            "dependents": '0',
            "description": "No Specific Message - maintenance",
            "endmaintenance": create_time,
            "node": "",
            "owner": "nmsyscli",
            "startmaintenance": create_time
        },
        "status": "PENDING",
        "timestamp": create_time,
        "u_ctime": create_time
    }

    if options.node is None:
        return critical("You are required to filter on a node - option --node")
    else:
        get_par['schedule']['node'] = options.node

    if options.alert is not None:
        get_par['schedule']['alert'] = options.alert

    if options.start is not None:
        get_par['schedule']['startmaintenance'] = time_to_datetime(options.start)
    else:
        return critical("You have to specify a start time for this Maintenance")

    if options.duration is not None:
        get_par['schedule']['endmaintenance'] = time_to_datetime(options.duration, get_par['schedule']['startmaintenance'])
    else:
        return critical("You have to specify a duration for this Maintenance")


    if options.comment is not None:
        get_par['schedule']['description'] = options.comment

    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)

    create_time = int(time.time())

    try:
        if options.quiet or query_yes_no(
            "You are about to put the node %s in maintenance from %s until %s, continue (Y/N)" % (
            get_par['schedule']['node'],
            time.strftime("%a, %d %b %Y %H:%M:%S %Z", time.localtime(get_par['schedule']['startmaintenance'])),
            time.strftime("%a, %d %b %Y %H:%M:%S %Z", time.localtime(get_par['schedule']['endmaintenance'])))):

            data_post(URL, 'maintenance', whatever, get_par)
            print("You have successfully created the maintenance")
    except Exception as e:
        print(e)


def do_cancel_maintenance(cmd, args, opts):
    """Cancel Maintenance for a host or services based one filters. Usage:

        %prog cancel-maintenance [opts]

    Available options:

        -n   (--node)           Node
        -o   (--owner)           Owner
        -e   (--alert)          Alert (default no filter -> all)
        -s   (--status)         Status of the maintenance (default: lists only active) Valid are PENDING or ACTIVE
        -F                      format output (can be plain or json)
        -V                      verbose
        -q --quiet              Non interactive mode - (!use with caution)
    Example:

        %prog cancel-maintenance --node nk11a00is-noname001.isg.apple.com --owner ISO_SSC"
            # Cancel maintenance on node nk11a00is-noname001.isg.apple.com created by owner ISO_SSC


    """
    p = OptionParser(usage=trim(do_cancel_maintenance.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-a', '--alert', dest='alert',
                 help='Service to search for')
    p.add_option('-o', '--owner', dest='owner',
                 help='Owner to search for')
    p.add_option('-s', '--status', dest='status',
                 help='Status of the maintenance - default only ACTIVE maintenance')

    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')
    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.add_option('-q', '--quiet', action='store_true', dest='quiet',
                 help='Quiet creation')
    p.set_defaults(host=None, alert=None, start='0m', duration=None,
                   limit=0, format='plain', quiet=False, verbose=False)

    (options, args) = p.parse_args(opts)
    create_time = int(time.time())
    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    get_par = {
        'status': 'ACTIVE'
    }
    now = int(time.time())
    if options.node is not None:
        get_par['n'] = options.node
    if options.alert is not None:
        get_par['a'] = options.alert
    if options.owner is not None:
        get_par['schedule.owner'] = options.owner
    if options.status is not None:
        if options.status not in ['PENDING', 'ACTIVE', 'COMPLETED']:
            return critical("You have to specify a valid status ('PENDING', 'ACTIVE', 'COMPLETED')")
        get_par['status'] = options.status

    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    url_init = init_get('maintenance', whatever, get_par)
    arr_delete = []
    for item in iterator_api(url_init):
        if 'objects' not in item:
            continue
        for obj in item['objects']:
            prettyPrint(obj)
            if query_yes_no("Do you want to delete this maintenances (Y/N) ?"):
                arr_delete.append(obj['resource_uri'].split('/')[-2])
    if len(arr_delete) > 0 and query_yes_no("We have %s maintenances ready for deletion, should we proceed? (Y/N) ?" % len(arr_delete)):
        for i in arr_delete:
            data_delete(URL, 'maintenance', whatever, i)
            print("You have successfully deleted the maintenance %s" % i)


def do_list_maintenance(cmd, args, opts):
    """List Maintenances based one filters. Usage:

        %prog list-maintenance [opts]

    Available options:

        -n   (--node)           Node
        -o   (--owner)           Owner
        -e   (--alert)          Alert (default no filter -> all)
        -s   (--status)         Status of the maintenance (default: lists only active) Valid are PENDING or ACTIVE
        -F                      format output (can be plain or json)
        -V                      verbose
        -q --quiet              Non interactive mode - (!use with caution)
    Example:

        %prog list-maintenance --node nk11a00is-noname001.isg.apple.com --owner ISO_SSC"
            # List maintenances on node nk11a00is-noname001.isg.apple.com created by owner ISO_SSC


    """
    p = OptionParser(usage=trim(do_list_maintenance.__doc__))
    p.disable_interspersed_args()

    p.add_option('-n', '--node', dest='node',
                 help='Node to search for')
    p.add_option('-a', '--alert', dest='alert',
                 help='Service to search for')
    p.add_option('-o', '--owner', dest='owner',
                 help='Owner to search for')
    p.add_option('-s', '--status', dest='status',
                 help='Status of the maintenance - default only ACTIVE maintenance')

    p.add_option('-F', '--format', dest='format',
                 help='Format output can be plain or json (default plain)')
    p.add_option('-V', '--verbose', action="store_true", dest='verbose',
                 help='Print Debug statements')
    p.add_option('-q', '--quiet', action='store_true', dest='quiet',
                 help='Quiet creation')
    p.set_defaults(host=None, alert=None, start='0m', duration=None,
                   limit=0, format='plain', quiet=False, verbose=False)

    (options, args) = p.parse_args(opts)
    create_time = int(time.time())
    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    get_par = {
        'status': 'ACTIVE'
    }
    now = int(time.time())
    if options.node is not None:
        get_par['n'] = options.node
    if options.alert is not None:
        get_par['a'] = options.alert
    if options.owner is not None:
        get_par['schedule.owner'] = options.owner
    if options.status is not None:
        if options.status not in ['PENDING', 'ACTIVE', 'COMPLETED']:
            return critical("You have to specify a valid status ('PENDING', 'ACTIVE', 'COMPLETED')")
        get_par['status'] = options.status

    if options.verbose:
        log.setLevel(logging.DEBUG)
        out_hdlr.setLevel(logging.DEBUG)
    url_init = init_get('maintenance', whatever, get_par)
    arr_delete = []
    for item in iterator_api(url_init):
        if 'objects' not in item:
            continue
        for obj in item['objects']:
            prettyPrint(obj)



configuration = '__ENDPOINT__'



dispatch = {
    'list-command': do_list_command,
    'version': do_version,
    'status': do_status,
    'silence': do_silence,
    'cancel-silence': do_silence,
    'ack': do_acknowledge,
    'cancel-ack': do_acknowledge,
    'query_details': query_details,
    'maintenance': do_maintenance,
    'cancel-maintenance': do_cancel_maintenance,
    'list-maintenance': do_list_maintenance,
}

arr_fetch = ['list-cluster', 'list-command', 'version']


def main(argv):
    """Void Main Void
    """
    global URL
    global log
    global out_hdlr

    log = logging.getLogger("django")

    out_hdlr = logging.StreamHandler(sys.stdout)
    out_hdlr.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    out_hdlr.setLevel(logging.INFO)

    log.addHandler(out_hdlr)
    log.setLevel(logging.DEBUG)

    # Parse out command line options
    p = OptionParser(usage=trim(__doc__))
    p.disable_interspersed_args()
    (opts, args) = p.parse_args(argv[1:])

    # args will now contain the subcommand, some positional arguments,
    # and then the dashed options. Split them.
    if len(args) <= 0:
        p.error('No command specified')
    if whatever[0] == '_':
        return critical('Your key is not valid, please request one from nmSys UI '
                        '(user preference - API key) or download the script again')
    URL = 'https://%s' % configuration

    command, posargs, otherargs = args[0], [], []

    for arg in args[1:]:
        if len(otherargs) > 0:
            otherargs.append(arg)
            continue
        if arg[0] == '-':
            otherargs.append(arg)
        else:
            posargs.append(arg)

    for cmd in dispatch:
        if re.match(r'^%s$' % command, cmd):
            return dispatch[cmd](command, posargs, otherargs)
    p.error('Command not found, see the usage')


if __name__ == '__main__':
    sys.exit(main(sys.argv[0:]))


