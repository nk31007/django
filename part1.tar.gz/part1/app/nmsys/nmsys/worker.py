from __future__ import absolute_import

import os

from celery import Celery
from celery import signals

# set the default Django settings module for the 'celery' program.
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'nmsys.settings')

from django.conf import settings
from kombu import Queue

app = Celery('nmsys')
app.config_from_object('django.conf:settings')

if settings.SENTINEL_KUBE:
    app.conf.broker_url = ';'.join(['sentinel://:%s@%s:%s/%s' % (settings.SENTINEL_PASS, pp[0], pp[1], 1) for pp in settings.SENTINEL_NODE])
    app.conf.broker_transport_options = {'master_name': settings.SENTINEL_MASTER, 'password': settings.SENTINEL_PASS, "sentinel_kwargs": {"password":  settings.SENTINEL_PASS, "socket_connect_timeout":20,  "socket_timeout": 480, "retry_on_timeout": True}}

elif settings.SENTINEL_FLAG:
    app.conf.broker_url = ';'.join(['sentinel://:%s@%s:%s/%s' % (settings.SENTINEL_PASS, pp[0], pp[1], 0)
                                    for pp in settings.SENTINEL_INSTANCE['nmsys_celery-redis-cluster']])
    app.conf.broker_transport_options = {'master_name': 'nmsys_celery-redis-cluster', 'password': settings.SENTINEL_PASS, }
else:
    app.conf.broker_url = "redis://%s:%s/%s" % (
        os.environ.get('REDIS_CELERY_HOST', ''),
        os.environ.get('REDIS_CELERY_PORT', ''),
        0
    )

if settings.REDBEAT:
    app.conf.broker_transport_options.update(
        {
            "sentinels": settings.SENTINEL_NODE,
            'password': settings.SENTINEL_PASS,
            'service_name': settings.SENTINEL_MASTER,
            'socket_timeout': 0.1,
            'sentinel_kwargs': {'password': settings.SENTINEL_PASS},
            'retry_period': 60,
        }
    )

app.conf.task_default_queue = 'default'
app.conf.task_queues = (
    Queue('default', routing_key='task.#'),
)

app.autodiscover_tasks(['tasks'])


@signals.setup_logging.connect
def on_celery_setup_logging(**kwargs):
    pass

@app.task(bind=True)
def debug_task(self):
    print('Request: {0!r}'.format(self.request))
