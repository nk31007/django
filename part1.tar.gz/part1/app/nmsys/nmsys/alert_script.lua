-- list of types
-- if redis.call("EXISTS", KEYS[1]) ~= 1 then
--    return nil;
-- end

redis.replicate_commands()

local tencoded = KEYS[1];
if tencoded == '' or tencoded == '{}' then
    return nil;
end
local tDecoded = cjson.decode(tencoded);
local key_change = KEYS[2];
local organization = KEYS[3];
local instance = KEYS[4];

local list_alert = tDecoded['alert']['list'];

local arr_result = {};

ARGV = {};
for i=1, #list_alert
do
    -- test if array is not empty
    local newObj = list_alert[i];
    if newObj then
        local server = '';
        if newObj['node'] == '' then
            newObj['node'] = newObj['ng']
        end
        -- look for the key
        local my_key = 'Alert' ..
                '::' .. organization ..
                '::' .. instance ..
                '::' .. newObj['alert'] ..
                '::' .. newObj['node']

        local new_status = tonumber(newObj['state'])
        local old_status =  tonumber(redis.pcall('get', my_key))
        if old_status ~= nil then
            if old_status ~= new_status then
                redis.pcall('set', my_key, new_status )
                -- redis.call('expire', my_key, 21600)
                newObj['u_ptime'] = tonumber(redis.pcall('time')[1])
                table.insert(arr_result, newObj)
            -- else
            --     redis.call('expire', my_key, 10800)
            end
        else
            redis.pcall('set', my_key, new_status )
            -- redis.call('expire', my_key, 21600)
            newObj['u_ptime'] = tonumber(redis.pcall('time')[1])
            table.insert(arr_result, newObj)
        end
    end
end
redis.call('set', key_change, cjson.encode(arr_result))
