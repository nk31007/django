"""
    This file contains all the existing tasks registered for nmsys
"""
from celery import shared_task
from celery.decorators import periodic_task
from celery.schedules import crontab
from elasticsearch_dsl import Q
from elasticsearch.exceptions import NotFoundError
from datetime import timedelta, datetime
from contrib.kin import Kin
from backend.models import Filter, Plugin, Maintenance, Alert, Notification, Node
from contrib.resource.redisrouter import RedisRouter
from contrib.epic import EpicKVStats
from contrib.bulk import chunk_bulk
from contrib.utils import chunks
from contrib.history import History
from django.conf import settings
import json
import ast
import shutil
import pathlib
import os
import recertifi
import glob


from time import time
from datetime import timedelta
from celery.utils.log import get_task_logger
from git import Repo, Actor

logger = get_task_logger("django")


from contrib import metrics


task_monitor = metrics.InvocationMonitor('task_process_latency_seconds',
                                         'Histogram of latencies while ingesting bulk events',
                                         ['task'], metric_type=metrics.MetricType.Histogram).monitor_invocation



############################################
# nmSys Bulk task
############################################
# Ingest
@shared_task(name="bulk_parser")
@task_monitor('bulk_parser_task')
def bulk_parser_task(locale, instance, content):
    Alert().bulk_epic_content(locale, instance, content)


@periodic_task(run_every=crontab())
@task_monitor('aging_epic_alert')
def aging_epic_alert():
    Alert().aging()


################################################
# bulk NMsys status
@periodic_task(run_every=timedelta(seconds=15))
@task_monitor('nmsys_queue_go')
def nmsys_queue_go():
    r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
    if not r_base.get('maintenance'):
        logger.info('[nmsys_queue_go::maintenance] Cluster is in maintenance mode, alert ingestion will be delayed')
        return False
    metrics = []
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    for redis_key in r_stream_stream.smembers('JSON_INCR_LIST'):
        redis_key = str(redis_key)
        try:
            size = r_stream_stream.scard(redis_key)
            try:
                _, _, application, locale, instance, _ = redis_key.split('::')
            except:
                _, _, application, locale, instance = redis_key.split('::')
            metrics.append({
                'node': '/type=queue/app=%s/locale=%s/instance=%s' % (application, locale, instance),
                'count': ('GAUGE', size)
            })
            if size > 0:
                logger.debug("[nmsys_queue_go] running %s size is %s" % (redis_key, size))
                queue_run.apply_async(
                    args=[redis_key]
                )
        except Exception as e:
            logger.critical("[nmsys_queue_go] %s %s" % (e, redis_key))
    try:
        obj = EpicKVStats('queue', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except:
        pass


@shared_task
@task_monitor('nmsys_queue')
def queue_run(redis_key):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    content = r_stream_stream.spop(redis_key, 20000)
    logger.info("[queue_run::ingest] %s" % redis_key)
    result = []
    try:
        _, incr, application, locale, instance, _ = redis_key.split('::')
    except:
        _, incr, application, locale, instance = redis_key.split('::')
    for check in content:
        try:
            try:
                alert = ast.literal_eval(check)
            except ValueError:
                alert = ast.literal_eval(check.decode('utf8'))
            if 'u_ctime' not in alert:
                continue
            labels = {
                'locale': locale,
                'instance': instance,
            }
            if alert['node'].startswith('/'):
                labels.update(dict(i.split('=') for i in alert['node'].split('/') if '=' in i))
            else:
                labels['host'] = alert['node']
            if 'labels' in alert:
                labels.update(alert['labels'])
            alert['labels'] =  labels 
            result.append(alert)
        except Exception as e:
            print(e)
            logger.critical("[queue_run] Application %s, Type %s key %s content %s Error on reformat %s" % (
                application, incr, redis_key, check, e
            ))
    try:
        result.sort(key=lambda x: x['u_ctime'], reverse=False)
    except Exception as e:
        logger.critical("[queue_run::sort] Application %s, Type %s content %s Error on reformat %s" % (
            application, incr, result, e
        ))
    data = Alert().bulk(
        application,
        locale,
        instance,
        json.dumps({
            "alert": {
                "list": result
                }
        }),
        cache=application == 'dsemond'
    )
    logger.debug("[queue_run::bulkresult] Application %s, Type %s %s insert in es %s" % (application, instance, locale, data))


@periodic_task(run_every=timedelta(seconds=120))
@task_monitor('full_run')
def full_run():
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    for i in r_stream_stream.spop('JSON_FULL_LIST', 10000):
        full_unpack.apply_async(
            args=[str(i)],
        )

########
# Goal is just to refresh the objects if they need to be
#
@shared_task
@task_monitor('full_unpack')
def full_unpack(key_redis):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    _, _, application, locale, instance, _ = key_redis.split('::')

    raw = r_stream_stream.get(key_redis)
    r_stream_stream.delete(key_redis)

    content = json.loads(raw)['alert']['list']

    length_list = len(content)

    chunk_bulk(application, locale, instance, 'reinsert', content)
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    r_base.incrby('unpack_count::%s::%s::%s::%s' % (application, 'unpack', locale, instance), length_list)


@periodic_task(run_every=timedelta(seconds=600))
@task_monitor('delay_run')
def delay_run():
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    for i in r_stream_stream.smembers('JSON_DELAY', 10000):
        delay_unpack.apply_async(
            args=[str(i)],
        )

########
# Goal is just to refresh the objects if they need to be
#
@shared_task
@task_monitor('delay_unpack')
def delay_unpack(key_redis):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    func, incr, application, locale, instance, _ = key_redis.split('::')

    raw = r_stream_stream.get(key_redis)
    r_stream_stream.delete(key_redis)

    content = json.loads(raw)['alert']['list']

    length_list = len(content)
    Alert().fetch_existing(application, locale, instance, content)
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    r_base.incrby('unpack_count::%s::%s::%s::%s' % (application, 'unpack', locale, instance), length_list)



################################################
# Node insert

@periodic_task(run_every=timedelta(seconds=240))
@task_monitor('node_queue_go')
def node_queue_go():
    r_stream_stream = RedisRouter().retrieve_redis_connection('nmsysclient', 'bulk')
    queue = 'queue::node'
    content = r_stream_stream.spop(queue, 200000)
    Node().bulk(content)


#################################################################################
################################################
# Notifier spawner
@periodic_task(run_every=crontab())
@task_monitor('notify_active_loop')
def notify_active_loop():
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
    if not r_base.get('maintenance'):
        logger.info('[notify_active_loop::maintenance] Cluster is in maintenance mode, no notification will be sent')
        return False
    try:
        start = time()

        search = Filter.search().extra(from_=0, size=30000)
        result = search.execute()
        spawned = 0
        trySpawn = 0
        failed = 0
        for kk in chunks(result, 1020):
            trySpawn += 1
            try:

                klist = [i.meta.id for i in kk]
                notify_active.apply_async(
                    args=[klist]
                )
                stats_active.apply_async(
                    args=[klist]
                )
            except Exception as e:
                failed += 1
                print(e)
            spawned += 1
        print('Spawner took %s seconds and launched %s tasks out of %s, failure %s' % (time()-start, spawned, trySpawn, failed))
    except Exception as e:
            print('Major problem spawning notifier %s' % e)


# Active notifier handler
@shared_task
@task_monitor('notify_active')
def notify_active(filter_ids):
    start = time()
    for i in filter_ids:
        try:
            i = Filter.get(id=i).notify()
        except NotFoundError:
            pass
        except Exception as e:
            print(e)
    print('notify_active took %s seconds and processed %s filters' % (time()-start, len(filter_ids)))


################################################
# Stats
@periodic_task(run_every=crontab(hour="*", minute="5"))
@task_monitor('plugin_loop')
def plugin_loop():
    Plugin().flush_db()
    for i in Plugin.search().extra(from_=0, size=20000):
        try:
            i.update_plugin()
            i.update(status='ACTIVE')
        except Exception as e:
            i.update(status='ERROR')


# Stats active handler
@shared_task
@task_monitor('stats_active')
def stats_active(filter_ids):
    start = time()
    for i in filter_ids:
        try:
            i = Filter.get(id=i).set_stats()
        except NotFoundError:
            pass
        except Exception as e:
            print('[stats_active] Error with %s %s' % (i, e))

    print('stats_active took %s seconds and processed %s filters' % (time()-start, len(filter_ids)))



@periodic_task(run_every=crontab())
@task_monitor('epic_publish_stats')
def epic_publish_stats():
    metrics = []
    for i in Filter.search().extra(from_=0, size=20000):
        if 'details' in i:
            for status, value in i.details.to_dict().items():
                metrics.append({
                    'node': '/type=filter/filter=%s' % (i.meta.id),  #' % i._id,  # /name=%s' % (i.pk, i.name), For now no name since @ is not whitelisted
                    '%s' % status: ('GAUGE', value)
                })
    try:
        obj = EpicKVStats('status', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except Exception as e:
        print(e)


@periodic_task(run_every=timedelta(seconds=30))
@task_monitor('stats_queues')
def stats_queues():
    metrics = []
    r_bulk_bulk = RedisRouter().retrieve_redis_connection('celery', 'task', 'main_queue')
    for queue in settings.CELERY_QUEUES:
        length = r_bulk_bulk.llen(queue)
        metrics.append({
            'node': '/type=celery/app=%s' % queue,
            'count': ('GAUGE', length)
        })
    try:
        obj = EpicKVStats('queue', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except:
        pass


@periodic_task(run_every=crontab())
@task_monitor('stats_updates')
def stats_updates():
    metrics = Alert().updated_stats()
    try:
        obj = EpicKVStats('alert', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except:
        pass


@periodic_task(run_every=crontab())
@task_monitor('stats_refreshes')
def stats_refreshes():
    metrics = Alert().refreshed_stats()
    try:
        obj = EpicKVStats('alert', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except:
        pass


@periodic_task(run_every=crontab())
@task_monitor('aging_stats')
def aging_stats():
    metrics = Alert().aging_stats()
    try:
        obj = EpicKVStats('alert', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics)
    except:
        pass


@periodic_task(run_every=crontab())
@task_monitor('stats_notification')
def stats_notification():
    metrics = Notification().notification_stats()
    obj = EpicKVStats('notification', settings.EPIC_STATS_HOST, 60)
    obj.publish(metrics)


@periodic_task(run_every=crontab())
@task_monitor('stats_bulk_count')
def stats_bulk_count():
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    metrics_bulk = []
    for bulk_count in r_base.keys('bulk::*::stats'):
        try:
            length = int(r_base.get(bulk_count))
            nothin, type_action, app, locale, instance, _ = bulk_count.split('::')

            metrics_bulk.append({
                'node': '/type=bulk/action=%s/application=%s/locale=%s/instance=%s' % (type_action, app, locale, instance),
                'count': ('COUNTER', length)
            })
        except:
            logger.critical('[stats_bulk_count] is malformed %s' % bulk_count)
    try:
        obj = EpicKVStats('bulk', settings.EPIC_STATS_HOST, 60)
        obj.publish(metrics_bulk)
    except:
        pass

@periodic_task(run_every=crontab())
@task_monitor('stats_notifier_status')
def stats_notifier_status():
    logger.debug('[stats_notifier_status] starting')
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    metrics_bulk = []
    for bulk_count in r_base.keys('notifier::*'):
        try:
            length = r_base.get(bulk_count)
            nothin, route, action, status = bulk_count.split('::')
            metrics_bulk.append({
                'node': '/class=%s/route=%s/action=%s/status=%s' % (nothin, route, action, status),
                'count': ('COUNTER', length)
            })
        except:
            logger.critical('[stats_notifier_status] is malformed %s' % bulk_count)
    obj = EpicKVStats('notifier', settings.EPIC_STATS_HOST, 60)
    obj.publish(metrics_bulk)
    
#################################################################################
################################################
# Maintenance spawner
@periodic_task(run_every=timedelta(seconds=60))
@task_monitor('maintenance_active_loop')
def maintenance_active_loop():
    try:
        start = time()

        search = Maintenance.search().query(
            Q('match', status='ACTIVE')
        ).extra(from_=0, size=30000)
        
        result = search.execute()
        spawned = 0
        trySpawn = 0
        failed = 0
        for kk in chunks(result, 1020):
            trySpawn += 1 
            try:

                klist = [i.meta.id for i in kk]
                maintenance_active.apply_async(
                    args=[klist]
                )
            except Exception as e:
                failed += 1
                print(e)
            spawned += 1
        print('Spawner took %s seconds and launched %s tasks out of %s, failure %s' % (time()-start, spawned, trySpawn, failed))
    except Exception as e:   
            print('Major problem spawning maintenance %s' % e)
    

# Active maintenance handler
@shared_task
@task_monitor('maintenance_active')
def maintenance_active(maintenance_ids):
    start = time()
    for i in maintenance_ids:
        try:
            i = Maintenance.get(id=i)
            i.execute(True)
            i.save()
        except Exception as e:
            print(e)
            i.status='ERROR'
            i.save()
    print('maintenance_active took %s seconds and processed %s maintenances' % (time()-start, len(maintenance_ids)))


# Stats
@periodic_task(run_every=timedelta(seconds=60))
@task_monitor('maintenance_completed_loop')
def maintenance_completed_loop():
    try:
        search = Maintenance.search().query(
            Q(
                'bool',
                must=[
                    Q(
                        "nested",
                        path='schedule',
                        query=Q('range', schedule__endmaintenance={"lte": int(time())})
                    ),
                    Q('match', status='ACTIVE')
                ]
            )
        )[0:10000]
        for i in search.execute():
            try:
                i.status = 'COMPLETED'
                i.save()
            except Exception as e:
                print(e)
    except Exception as e:
        print(e)


@periodic_task(run_every=timedelta(seconds=60))
@task_monitor('maintenance_starting_loop')
def maintenance_starting_loop():
    try:
        search = Maintenance.search().query(
            Q(
                'bool',
                must=[
                    Q(
                        "nested",
                        path='schedule',
                        query=Q('range', schedule__startmaintenance={"lte": int(time())})
                    ),
                    Q('match', status='PENDING')
                ]
            )
        )[0:10000]
        for i in search.execute():
            try:
                i.execute(False)
                i.status='ACTIVE'
                i.save()
            except:
                i.status='ERROR'
                i.save()
    except Exception as e:
        print(e)

@shared_task
@task_monitor('maintenance_cleanup_execute')
def maintenance_cleanup_execute(idP, user):
    try:
        Maintenance().cleanup_execute(idP, user)
    except Exception as e:
        print("Error cleaning maintenance %s : %s" % (idP, e))
        
#@periodic_task(run_every=timedelta(seconds=60))
#@task_monitor('kin_publish')
#def kin_publish():
#    if not settings.KIN_ENABLE:
#        return
#    try:
#        Kin().task()
#    except Exception as e:
#        print(e)



#@periodic_task(run_every=timedelta(seconds=3))
#@task_monitor('history_task')
#def history_task():
#    r_stream_stream = RedisRouter().retrieve_redis_connection('history', 'default')
#    for application in r_stream_stream.keys('bulk::INCRE::*'):
#        history_run.apply_async(
#            args=[str(application)]
#        )

#@shared_task
#@task_monitor('history_run')
#def history_run(application):
#    History().task_epic(application)

########################################################################################
#@periodic_task(run_every=timedelta(seconds=30))
#@task_monitor('history_other')
#def history_other():
#    r_stream_stream = RedisRouter().retrieve_redis_connection('history', 'default')
#    for application in r_stream_stream.keys("bulk::OTHER::*"):
#        history_other_run.apply_async(
#            args=[str(application)]
#        )

#@shared_task
#@task_monitor('history_other_run')
#def history_other_run(application):
#    History().task_other(application)




#########################################################################################
@periodic_task(run_every=crontab(hour="23", minute="0", day_of_week="saturday"))
@task_monitor('create_incremental_index')
def create_incremental_index():
    append_date = (datetime.today()-timedelta(((datetime.today().weekday() + 1) % 7))).strftime('%Y_%m_%d')
    History().create_index(append_date)



#########################################################################################
@periodic_task(run_every=crontab(hour="23", minute="0"))
@task_monitor('backup_all')
def backup_all():
    r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
    if not r_base.get('maintenance'):
        logger.info('[backup_all::maintenance] Cluster is in maintenance mode, no notification will be sent')
        return False

    try:
        path = settings.ALERT_BACKUP
        if os.path.exists(path):
            shutil.rmtree(path)

        pathlib.Path(path).mkdir(parents=True, exist_ok=True)

        Repo.clone_from(
            settings.ALERT_REPO % (
                os.environ.get('GIT_ID', ''),
                os.environ.get('GIT_TOKEN', ''),
                os.environ.get('GIT_ALERT_REPO', '')
            ), 
            path, 
            depth=1,
            config="http.sslVerify=false"
        )
        repo = Repo(
            path
        )
        # Cleanup content
        for dir in glob.glob(path+'*', recursive=True):
            try:
                shutil.rmtree(dir)
            except OSError as e:
                print("Error: %s : %s" % (dir, e.strerror))

        # Backup filters
        for i in Filter.search().extra(from_=0, size=10000):
            try:
                i.backup()
            except Exception as e:
                print("%s error" % e)

        repo.git.add(A=True)
        repo.index.commit("Automatic backup %s" % int(time()))
        repo.remote('origin').push()
    except Exception as e:
        print(e)
    finally:
        # Cleanup
        shutil.rmtree(path)
