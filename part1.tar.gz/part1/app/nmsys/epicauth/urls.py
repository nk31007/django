__author__ = 'rfoucher'
from django.conf.urls import url
from epicauth import views

urlpatterns = [
    url(r'^login/$', views.login_view),
    url(r'^logout/$', views.logout_view),
]
