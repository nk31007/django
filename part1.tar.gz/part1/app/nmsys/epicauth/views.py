from django.contrib import auth
from epicauth.unauthorized import Http403
from epicauth.models import AppleDSSessionError, AppleDSGroupError

from django.http import HttpResponseRedirect, HttpResponse, HttpResponseForbidden

from django.contrib.auth import logout
from django.conf import settings
import logging
import ujson as json

logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


def check(request):
    return HttpResponse(json.dumps({"success": True}), status=200)


def login_view(request):
    request.session.set_test_cookie()

    if not request.COOKIES.get(settings.COOKIE_NAME, False) and request.user.is_authenticated:
        logger.info(
            '[ login_view ] Idmsauth cookie %s is not set - but user %s is authenticated Logging out now' % (
                settings.COOKIE_NAME,
                request.user
            )
        )
        return logout_view(request)
    if not request.COOKIES.get(settings.COOKIE_NAME, False):
        logger.info("[ login_view ] Idmsauth cookie %s is not set redirecting to idmsauth URL" %
                        settings.COOKIE_NAME
                        )
        response = HttpResponseRedirect('%s&path=%s' % (settings.DS_URL, settings.SHORT_LOGIN_URL))
        return response
    else:
        logger.debug("[ login_view ] Idmsauth cookie is set - looking up now")
        resp = request.COOKIES.get(settings.COOKIE_NAME)
        try:
            ipsource = request.META['X-Forwarded-For'].split(',')[0]
        except:
            ipsource = request.META['REMOTE_ADDR']
        if ipsource == '172.17.0.1':
            ipsource = '17.228.4.140'
        try:
            user = auth.authenticate(mecookie=resp, ip=ipsource)
            logger.info("User is authenticated %s" % user)
        except AppleDSSessionError:
            logger.info(
                '[ login_view ] Idmsauth - Token is too old removing and go to Idmsauth %s %s' %
                (request.META['REMOTE_ADDR'], request.META['X-Forwarded-For'])
            )
            response = HttpResponseRedirect('%s&path=%s' % (settings.DS_URL, settings.SHORT_LOGIN_URL))
            response.delete_cookie(settings.COOKIE_NAME, domain=".apple.com")
            return response
        except AppleDSGroupError:
            raise Http403

        if user:
            if user.is_active:
                auth.login(request, user)
                logger.debug("user %s is : %s" % (user, user.is_authenticated))
                next_page = request.COOKIES.get("go")
                if next_page == settings.LOGIN_URL:
                    logger.info("[ login_view ] next cookie is set to auth go to /alerting/")
                    next_page = '/alerting/'

                logger.info("[ login_view ] User is logged in now going to %s" % next_page)
                response = HttpResponseRedirect(next_page)
                response.delete_cookie('count')
                response.delete_cookie('go')
                response.set_cookie('user', request.user.username, secure=True, httponly=True)
                return response
    raise Http403


def logout_view(request):
    logger.debug("[ logout ] Cleanup since we shouldnt' need all this")
    auth.logout(request)
    response = HttpResponseRedirect('/')
    response.delete_cookie(settings.COOKIE_NAME, domain=".apple.com")
    response.delete_cookie('count')
    response.delete_cookie('go')
    response.delete_cookie('user')
    return response
