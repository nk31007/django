from django.contrib.auth import models as auth_models
from django.conf import settings
from django.core.exceptions import ObjectDoesNotExist
from epicauth import models

import logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class AppleDSBackend:

    def match_groups(self, user=None, groups=None):
        logger.debug("checking groups")
        if groups is not None:
            user.groups.clear()
            logger.debug("clearing user groups")
            for group in groups.split(';'):
                if len(group) > 0:
                    try:
                        group_ = auth_models.Group.objects.get(pk=int(group))
                        user.groups.add(group_.id)
                        logger.debug("adding group %s to %s", group_.name,
                                     user.username)
                    except ObjectDoesNotExist:
                        pass

    def authenticate(self, mecookie=None, ip=None):
        applds_session, crea = models.AppleDSSession.objects.get_or_create(access_token=mecookie, ipaddress=ip)

        profile = applds_session.query()
        if settings.DSAUTH_USER_KEY in profile and profile[settings.DSAUTH_USER_KEY] != '':
            username = profile[settings.DSAUTH_USER_KEY]
        else:
            username = profile['emailAddress'].split('@')[0]

        try:
            user, cr = auth_models.User.objects.get_or_create(username=username)
        except auth_models.User.DoesNotExist:
            user = auth_models.User(username=username)

        self.match_groups(user, profile['allGroups'])
        user.set_unusable_password()
        user.email = profile['emailAddress']
        user.first_name = profile['firstName']
        user.last_name = profile['lastName']
        user.save()

        try:
            models.AppleDSSession.objects.get(user=user).delete()
        except models.AppleDSSession.DoesNotExist:
            pass

        applds_session.nickname = profile['nickName']
        applds_session.email = profile['emailAddress']
        applds_session.officenumber = profile['phoneOfficeNumber']
        applds_session.phonenumber = profile['phoneHomeNumber']
        applds_session.employeeid = profile['employeeId']
        applds_session.groups = profile['allGroups']
        applds_session.user = user
        applds_session.save()

        return user

    def get_user(self, user_id):

        try:
            return auth_models.User.objects.get(pk=user_id)
        except auth_models.User.DoesNotExist:
            return None
