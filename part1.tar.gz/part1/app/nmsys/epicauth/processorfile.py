from django.http import HttpResponsePermanentRedirect
from django.http import HttpResponseRedirect
from django.conf import settings
from django.core.exceptions import PermissionDenied
try:
    from django.utils.deprecation import MiddlewareMixin
except ImportError:
    MiddlewareMixin = object

from re import compile
import logging
logger = logging.getLogger("django")


def user(request):
    if hasattr(request, 'user'):
        return {'user': request.user}
    return {}

EXEMPT_URLS = [compile(settings.LOGIN_URL.lstrip('/'))]
if hasattr(settings, 'LOGIN_EXEMPT_URLS'):
    EXEMPT_URLS += [compile(expr) for expr in settings.LOGIN_EXEMPT_URLS]


class LoginRequiredMiddleware(MiddlewareMixin):
    def process_request(self, request):
        assert hasattr(request, 'user'), (
            'The LoginRequiredMiddleware requires authentication middleware '
            'to be installed. Edit your MIDDLEWARE setting to insert before '
            "'django.contrib.auth.middleware.AuthenticationMiddleware'."
        )
        if not request.user.is_authenticated:
            path = request.path_info.lstrip('/')
            if not any(m.match(path) for m in EXEMPT_URLS):
                response = HttpResponseRedirect('%s' % settings.LOGIN_URL)
                counter = int(request.COOKIES.get("count", 0))
                logger.debug("[ process_request ] counter %s" % counter)
                if counter == 10:
                    raise PermissionDenied 
                else:
                    counter += 1
                temp_next = request.get_full_path()
                logger.debug("[ process_request ] next request %s" % temp_next)
                response.set_cookie('go', temp_next, secure=True, httponly=True)
                response.set_cookie('count', counter, secure=True, httponly=True)
                return response

class SecureRequiredMiddleware(MiddlewareMixin):

    def process_request(self, request):
        paths = getattr(settings, 'SECURE_NOREQUIRED_PATHS')
        enabled = paths and getattr(settings, 'HTTPS_SUPPORT')
        if enabled:
            if 'X_FORWARDED_PROTO' in request.META and request.META['X_FORWARDED_PROTO'] == 'https':
                return None
            if request.is_secure():
                return None
            for path in paths:
                if not request.get_full_path().startswith(path):
                    request_url = request.build_absolute_uri(request.get_full_path())
                    secure_url = request_url.replace('http://', 'https://')
                    return HttpResponsePermanentRedirect(secure_url)
        return None
