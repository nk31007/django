from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

import logging
import requests
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class AppleDSSessionError(Exception):
    def __init__(self, error_type, message):
        self.message = message
        self.type = error_type

    def get_message(self):
        return self.message

    def get_type(self):
        return self.type

    def __unicode__(self):
        return u'%s: "%s"' % (self.type, self.message)


class AppleDSGroupError(Exception):
    def __init__(self, error_type, message):
        self.message = message
        self.type = error_type

    def get_message(self):
        return self.message

    def get_type(self):
        return self.type

    def __unicode__(self):
        return u'%s: "%s"' % (self.type, self.message)


class AppleDSSession(models.Model):

    access_token = models.CharField(max_length=1000)
    ipaddress = models.CharField(max_length=50, null=True)
    nickname = models.CharField(max_length=40, null=True)
    email = models.CharField(max_length=40, null=True)
    officenumber = models.CharField(max_length=40, null=True)
    phonenumber = models.CharField(max_length=40, null=True)
    employeeid = models.CharField(max_length=40, null=True)
    groups = models.CharField(max_length=10000, null=True)
    user = models.ForeignKey(User, null=True, on_delete=models.PROTECT)

    def query(self):
        result = {}
        url = settings.DSAUTH_URL_DISPATCH['validateCookie']
        params = {
            'cookie': self.access_token,
            'ip': self.ipaddress,
            'appId': settings.DSAUTH_AUTH_PROD['appId'],
            'appAdminPassword': settings.DSAUTH_AUTH_PROD['appAdminPassword'],
            'func': settings.DSAUTH_AUTH_PROD['info'],
        }

        response = requests.post(url, data=params)
        lines = response.text.split("\n")
        for line in lines:
            if line.strip() == "":
                continue
            fields = line.split("=")
            result[fields[0]] = fields[1]
        logger.debug('DEBUG FROM DS: %s' % result)
        logger.debug('DEBUG PARAMETERS %s' % params)
        logger.debug('DEBUG URL VALIDATE %s' % url)

        if result['status'] == '12':
            logger.debug('Status result Issue with Unauthorized user - missing from Group: %s' % result)
            error = result['reason']
            raise AppleDSGroupError(result['status'], error)

        if result['status'] != '0':
            error = result['reason']
            raise AppleDSSessionError(result['status'], error)
        return result
