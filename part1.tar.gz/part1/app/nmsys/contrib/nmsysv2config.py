__author__ = 'nmsys'
import requests
import ujson as json
import time
import pytz
from dateutil.parser import parse
from datetime import datetime
from backend.models import Filter, Alert, Plugin

from elasticsearch_dsl import Q
from django.conf import settings
from contrib.stream import Stream
from contrib.utils import retry
from django.contrib.auth.models import Group, Permission

import uuid
import pprint

class NmsysV2Config(object):

    def __init__(self):
        self.endpoint = settings.BACKENDPOINT
        self.path = '/api/rest/v1/'
        self.arguments = {
            'format': 'json',
            'oauth_consumer_key': settings.OAUTH
        }

    @retry(Exception, tries=4, delay=3, backoff=2)
    def fetch_config(self, url, **params):
        response = requests.get(url, params=params)
        return json.loads(response.content)

    def _iterate(self, resource, **params):
        params.update(self.arguments)
        content = []
        result = self.fetch_config("http://%s%s%s" % (self.endpoint, self.path, resource), **params)
        content += result['objects']
        while "next" in result['meta'] and result['meta']['next']:
            result = self.fetch_config("http://%s%s" % (self.endpoint, result['meta']['next']))
            content += result['objects']
        return content

    def build_threshold(self, subscription):
        glb = {}
        final = {}
        for i_type in ['critical', 'warning', 'ok']:
            try:
                stat = json.loads(subscription.get("register_alert_%s_limit" % i_type))
                glb[i_type.upper()] = stat
            except Exception as e:
                print(e)
                print(subscription['registered_alert_name'])
                print(i_type)
                print(subscription.get("register_alert_%s_limit" % i_type))
        for status in glb:
            for id, definition in glb[status].items():
                if id not in final:
                    final[id] = {}
                    final[id]['status'] = status
                final[id]['definition'] = definition
        return final

    def build_definition(self, subscription):
        final = {}
        if subscription['registered_alert_application'] == "epic":
            ng, n = subscription['registered_alert_hostregex'].split('::', 1)
            if ng != '%':
                final['node'] = '~%s' % ng
            if n != '%':
                final['node'] = n
            final['mode'] = subscription['registered_alert_specific']
            final['datasource'] = subscription['registered_alert_outputregex']
        else:
            final['alert'] = subscription['registered_alert_serviceregex']
            if subscription['registered_alert_hostregex'] != '%::%':
                final['node'] = subscription['registered_alert_hostregex']
        organization = ['.*']
        instance = ['.*']
        if subscription['registered_alert_restriction_organization'] != '*':
            organization = subscription['registered_alert_restriction_organization'].split(',')

        if subscription['registered_alert_restriction_instance'] != '*':
            instance = subscription['registered_alert_restriction_instance'].split(',')

        final['instance'] = ','.join(['%s%s' % (org, inst) for org in organization for inst in instance])
        if final['instance'] == '.*.*':
            final.pop('instance')
        return final

    def build_subscription(self, subscription):
        final = {
            "subscriber": subscription['user_name'],
            "resend-after": subscription['notification_resend_after'],
            "select-duration": subscription['notification_maxtime'],
            "notification_type": subscription['notification_type'],
        }
        if final['notification_type'] == 'espresso_api':
            final['notification_type'] = 'espresso'
        # Default contact to alert for everything
        if 'contact_email' in subscription['contact'] and subscription['contact']['contact_email'] != '':
            final['email-contact'] = subscription['contact']['contact_email']

        # Digesting
        if 'digest' in subscription and subscription['digest'] == 1:
            final["notif-ifdigest"] = "on"

        # Notification for specific status
        if 'notification_critical_enable' in subscription and subscription['notification_critical_enable']:
            final['notif-ifcritical'] = "on"
        if 'notification_warning_enable' in subscription and subscription['notification_warning_enable']:
            final['notif-ifwarning'] = "on"

        # Multiple Contacts
        if 'multiif-email' in subscription and subscription['multiif-email'] == "on":
            final['multiif-email'] = "on"
            final["input-contact-warning"] = \
                subscription['contact']['contact_warning'] \
                    if subscription['contact']['contact_warning'] != '' \
                    else subscription['contact']['contact_email']
            final["input-contact-critical"] = \
                subscription['contact']['contact_critical'] \
                    if subscription['contact']['contact_critical'] != '' \
                    else subscription['contact']['contact_email']
        # Ratio
        if 'multiif-ratio' in subscription and subscription['multiif-ratio'] == "on":
            final['multiif-ratio'] = "on"
            final['ratio'] = subscription['ratio']
        # Callback
        if 'callback' in subscription and subscription['callback'] != "":
            final["callback-myself"] = "on"
            final["callback-my-url"] = subscription['callback']
        # Recovery (Notify per unique event)
        if 'recovery' in subscription and subscription['recovery'] == 1:
            final["recovery"] = "on"

        if final['notification_type'] == 'email':
            pass
        elif final['notification_type'] == 'centralstation' or final['notification_type'] == 'espresso':
            final.update({
                "priority-critical": subscription['contact']['contact_priority_critical'],
                "priority": subscription['contact']['contact_priority'],
                "priority-warning": subscription['contact']['contact_priority_warning'],
            })

        if 'notification_enable' in subscription and subscription['notification_enable'] == 0:
            final['disable'] = "on"
        if 'notification_downtime' in subscription:
            now = datetime.utcnow().replace(tzinfo=pytz.utc)
            downtime = parse(subscription['notification_downtime'])
            if downtime > now:
                final['downtime'] = downtime.strftime('%s')
        return final

    def massage_data(self, data):
        '''

        :param data:
        :return: New Formated list of alerts with subscription
        '''
        alert = {}
        for subscription in data:
            name = subscription['alert']['registered_alert_name']
            if name == 'ISO_SSC@cpu_utilization':
                continue
            if 'ISO_SSC' in name:
                if 'registered_alert_restriction_organization' != '*':
                    name = "%s_%s" % (subscription['alert']['registered_alert_name'], subscription['alert']['registered_alert_restriction_organization'])
            if name not in alert:
                username, shortname = name.split('@', 1)
                if shortname == '':
                    shortname = 'missing_name_%s' % int(time.time())
                shortname = shortname.replace('@', '')
                shortname = shortname.replace('/', '')
                definition = {
                    "status": "PENDING",
                    "name": '%s@%s' % (username, shortname),
                    "information": {
                        "username": username,
                        "description": subscription['alert']['register_alert_description'],
                        "name": shortname,
                        "gitlink": subscription['alert']['register_alert_wiki']
                    },
                    "u_ctime": int(time.time()),
                    "definition": {},
                    "application": subscription['alert']['registered_alert_application'],
                    "subscription": []
                }
                if subscription['alert']['registered_alert_application'] == "epic":
                    definition['threshold'] = self.build_threshold(subscription['alert'])
                definition['definition'] = self.build_definition(subscription['alert'])

                alert[name] = definition

            alert[name]['subscription'].append(self.build_subscription(subscription))
        return alert

    def massage_plugin(self, plugin):
        data = {
            "application": "plugin",
            "status": "PENDING",
            "plugin": {
                "class": plugin.get("plugin")
            },
            "configuration": plugin.get("parameters"),
            "name": plugin.get("name"),
            "deployment": {
                "owner": plugin.get("owner"),
                "name": plugin.get("name"),
                "tag": plugin.get("tag")
            },
            "timestamp": int(time.time()),
        }
        return data

    def import_nmsys_plugin(self):
        import ast
        data = self._iterate('plugin', limit=200)
        for plugin in data:
            result = Plugin.search().query(
                Q('match', name=plugin.get('name'))
            ).execute()
            # plugin['timestamp'] = int(parse(plugin.get('modified')).strftime('%s'))
            plugin.pop('modified')
            plugin.pop('resource_uri')
            plugin = ast.literal_eval(json.dumps(plugin))
            plugin = self.massage_plugin(plugin)
            if result.hits.total == 1:
                s = result[0]
                if 'pk' not in s:
                    plugin['pk'] = s._id
                s.update(**plugin)
            else:
                s = Plugin(**plugin)
                if 'pk' in plugin:
                    s._id = plugin['pk']
                else:
                    s._id = s.pk = str(uuid.uuid4())
            try:
                s.save()
            except Exception as e:
                print(plugin.get('name'))
                pprint.pprint(plugin)
                print(e)

    def import_nmsys_groups(self):
        data = self._iterate('group', limit=200)
        for group in data:
            try:
                new_group, created = Group.objects.get_or_create(id=group['id'], name=group['name'])
            except Exception as e:
                print(e)
                print(group)

    def import_nmsys_ack(self, status):
        data = self._iterate('alert', status=status, limit=200, ack=1, search_q='o:admin')   # , search_q='n:mr11a00is-nmsys001.isg.apple.com'
        arr_stream = {}
        for alert in data:
            obj = {}
            silence = parse(alert.get('alert_downtime'))
            now = datetime.utcnow().replace(tzinfo=pytz.utc)
            if silence > now or alert['alert_ack'] == 1:
                try:
                    kiki = self._iterate('ack', alert_id=alert['alert_id'], order_by="-date_modified", limit=1)[0]
                    if 'comment' in kiki:
                        obj['comment'] = kiki['comment']
                    else:
                        obj['comment'] = 'Unable to find a comment during migration'
                    if 'user' in kiki:
                        obj['user'] = kiki['user']
                    else:
                        obj['user'] = 'nmsys-import'
                    obj['time_ack'] = int(parse(kiki.get('date_modified', time.time())).strftime('%s'))
                except Exception as e:
                    print(e)
                if silence > now:
                    obj['silence'] = int(silence.strftime('%s'))
                if alert['alert_ack'] == 1:
                    obj["ack"] = 1
            else:
                continue

            result = Alert.search().query(
                Q('match', node=alert.get('alert_server')) & Q('match', alert=alert.get('alert_service'))
            ).execute()
            if len(result) == 0:
                continue
            for o in result:
                print(o)
                if 'silence' in obj:
                    o["silence"] = obj['silence']
                if 'ack' in obj:
                    o['ack'] = obj["ack"]
                if 'comment' in obj:
                    o['comment'] = obj['comment']
                else:
                    o['comment'] = 'Unable to find user for import'
                if 'user' in obj:
                    o['user'] = obj['user']
                else:
                    o['user'] = 'auto-migration'
                o['time_ack'] = int(time.time())
                o.save()

    def import_auth_keys(self):
        data = self._iterate('subscription', limit=20, search_q="o:admin")
        alerts = self.massage_data(data)
        for alert, definition in alerts.items():
            self.save_filter(definition)

    def import_old(self):
        data = self._iterate('subscription', limit=20, search_q="o:admin")
        alerts = self.massage_data(data)
        for alert, definition in alerts.items():
            self.save_filter(definition)

    def save_alert(self, definition):
        result = Alert.search().query(
            Q('match', node=definition['alert_server'])
        ).execute()
        if result.hits.total == 1:
            s = result[0]
            if 'pk' not in definition:
                definition['pk'] = s._id
            s.update(**definition)
        else:
            s = Filter(**definition)
            if 'pk' in definition:
                s._id = definition['pk']
            else:
                s._id = s.pk = str(uuid.uuid4())
        try:
            s.save()
        except Exception as e:
            print(definition['information']['name'])
            pprint.pprint(definition)
            print(e)

    def save_filter(self, definition):
        #if 'ISO_SSC' in definition['name']:
        #    return
        if definition['name'].startswith('nmsys@') or definition['name'].startswith('common@') or definition['name'].startswith('default@'):
            return
        result = Filter.search().query(
            Q('match', name=definition['name'])
        ).execute()
        if result.hits.total == 1:
            s = result[0]
            if 'pk' not in definition:
                definition['pk'] = s._id
            s.update(**definition)
        else:
            s = Filter(**definition)
            if 'pk' in definition:
                s._id = definition['pk']
            else:
                s._id = s.pk = str(uuid.uuid4())
        try:
            s.save()
        except Exception as e:
            pprint.pprint(definition)

    def delete_all(self):
        result = Filter.search().extra(from_=0, size=10000)
        for r in result:
            r.delete()

    def ack_ssc(self):
        data = self._iterate('subscription', limit=20, search_q="a:.*ISO_SSC.*")
        for filtr in data:
            content = self._iterate('alert', limit=200, registered_alert=filtr['alert']['alert_id'], status='CRITICAL,WARNING')
            for alert in content:
                result = Alert.search().query(
                    Q('match', node=alert.get('alert_server')) & Q('match', alert=alert.get('alert_service'))
                ).execute()
                if len(result) > 0:
                    for o in result:
                        o["silence"] = int(time.time()) + 60 * 60 * 24 * 7
                        o['comment'] = "Auto ACK FOR SSC migration to the new nmSys"
                        o['user'] = "rfoucher"
                        o['time_ack'] = int(time.time())
                        o.save()
