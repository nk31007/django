__author__ = 'rfoucher'

import ujson as json
import logging
import urllib
from django.conf import settings
from time import time
import requests
import uuid
import os
from contrib.pager import email_me
import socket
from random import randint
from urllib.parse import urlencode
from contrib.resource.redisrouter import RedisRouter
import re
import recertifi

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class EpicSearch:
    def __init__(self, endpoint=settings.EPIC_URL, version='v2'):
        self.endpoint = endpoint
        self.params = {
            'format': 'json',
            'limit': 10000,
            'source': 'nmsys'
        }
        self.version = version
        self.r_base = RedisRouter().retrieve_redis_connection('stats', 'nodes')

        if not self.r_base:
            self.r_base = RedisRouter().retrieve_redis_connection('stats', 'nodes')
 
    def get_node_name(self, result):
        yield result
        while 'meta' in result and result['meta']['next']:
            req = requests.get(
                "%s%s" % (self.endpoint, result['meta']['next']),
                timeout=20,
            )
            result = req.json()
            yield result

    def validate(self):
        try:
            re.compile(self.params['search_q'])
            return True
        except re.error:
            return False

    def find_exact(self, node_name, version='v2'):
        params = {
            'format': 'json',
            'node': node_name
        }
        result = requests.get("%s/api/search/rest/%s/node/?%s" % (self.endpoint, version, urlencode(params))).json()
        if len(result['objects']) > 0:
            return {
                'locale': result['objects'][0]['locale'],
                'instance': result['objects'][0]['instance'],
                'node': result['objects'][0]['node'],
            }
        else:
            return {}

    def find_list(self, node_filter, expand=False, cache=True, version='v2'):
        result = []
        self.params['search_q'] = node_filter
        pre_cached = []
        if cache and not expand:
            cached = self.r_base.get('EpicSearch::%s' % self.params['search_q'])
            if cached:
                return json.loads(cached)
            else:
                pre_cached = self.r_base.get('EpicSearch::Precache::%s' % self.params['search_q'])
        try:
            for item in self.get_node_name(
                    {
                        'meta':
                            {
                                'next':  '/api/search/rest/%s/node/?%s' % (
                                    version,
                                    urlencode(self.params)
                                )
                            }
                    }
                ):
                if 'error_message' in item:
                    raise ValueError(item['error_message'])
                elif 'objects' not in item:
                    continue
                elif 'meta' in item and 'total_count' in item['meta'] and item['meta']['total_count'] > 350000:
                    logger.critical('Epic search issue too many in filter %s' % socket.gethostname(), 'count %s, filter %s' % (item['meta']['total_count'], self.params['search_q']))
                    raise NameError('Too many items in your node filter (limit is 350 000)')
                for obj in item['objects']:
                    if expand:
                        result.append({
                            'node': obj['node'],
                            'locale': obj['locale'],
                            'instance': obj['instance']
                        })
                    else:
                        result.append(obj['node'])
        except (
                requests.exceptions.HTTPError,
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout,
                requests.exceptions.ReadTimeout,
            ) as e:
            logger.critical('EpicSearch::find_list Epic endpoint %s raised an error %s for request %s' % (self.endpoint, e, node_filter))
            if pre_cached and len(pre_cached) > 0:
                return pre_cached
            else:
                raise ValueError('Epic Search service is unresponsive and cannot find any cached results - try again later')

        self.r_base = RedisRouter().retrieve_redis_connection('stats', 'nodes')
        if not expand:
            self.r_base.set('EpicSearch::%s' % self.params['search_q'], json.dumps(result))
            self.r_base.expire('EpicSearch::%s' % self.params['search_q'], 60*60*4 + randint(20, 6000))
            self.r_base.set('EpicSearch::Precache::%s' % self.params['search_q'], json.dumps(result))

        return result


class EpicStats:
    def __init__(self, plugin, hostname=socket.gethostname(), schedule=60):
        self.epic_path = settings.EPIC_PATH
        self.hostname = hostname
        self.schedule = schedule
        self.plugin = plugin

    def build_data_stats(self, data):
        result = []
        timestamp = int(time())
        for row in data:
            k = row.keys()[0]
            t, value = row[k]
            result.append("O:%s:%s:%s:%s:%s:%s" % (
                              k,
                              timestamp,
                              value,
                              self.hostname,
                              t,
                              self.schedule))
#            except Exception as e:
#                logger.critical('Epic unable to stream data for Epic dropping %s reason %s' % (row, e))
        return result

    def insert_data(self, data, content):
        file_name = '%s.%s.%s' % (self.plugin, int(time()), uuid.uuid4())

        ff = open('%s.%s' % (self.epic_path, file_name), 'wt')
        ff.write('\n'.join(data) + '\n')
        ff.close()
        os.chmod('%s.%s' % (self.epic_path, file_name), 0o644)
        os.rename('%s.%s' % (self.epic_path, file_name), '%s%s' % (self.epic_path, file_name))

    def publish(self, data):
        """
            Epic publish stats
        """
        result = self.build_data_stats(data)
        self.insert_data(result, data)


class EpicKVStats:
    def __init__(self, plugin, hostname=socket.gethostname(), schedule=60):
        self.epic_path = settings.EPIC_PATH
        self.hostname = hostname
        self.schedule = schedule
        self.plugin = plugin

    # Get Array of data with timestamp return array of RRD data
    def build_data_stats(self, data):
        result = []
        now = int(time())
        for row in data:
            try:
                tmp_name = row.pop("node", None)
                tmp_name += '/api=%s' % self.hostname
                keyK = list(row.keys())[0]
                tt, value = row[keyK]
                result.append("O:%s:%s:%s:%s:%s:%s" % (
                              keyK,
                              now,
                              value,
                              tmp_name,
                              tt,
                              self.schedule))
            except Exception as e:
                logger.critical('Epic unable to stream data for Epic dropping %s reason %s' % (row, e))
        return result

    def insert_data(self, data):
        file_name = '%s.%s.%s' % (self.plugin, int(time()), uuid.uuid4())

        ff = open('%s.%s' % (self.epic_path, file_name), 'wt')
        ff.write('\n'.join(data) + '\n')
        ff.close()
        os.chmod('%s.%s' % (self.epic_path, file_name), 0o644)
        os.rename('%s.%s' % (self.epic_path, file_name), '%s%s' % (self.epic_path, file_name))

    def publish(self, data):
        """
            Epic publish stats
        """
        result = self.build_data_stats(data)
        self.insert_data(result)
