#!/usr/bin/env python

import logging
import re
import urllib
from json import loads
import urllib.request as urllib2
from urllib.parse import urlencode

logger = logging.getLogger("django")

def transmit(url):
    req = urllib2.Request(url)
    req.add_header('Accept', 'application/json')
    req.add_header("Content-type", "application/x-www-form-urlencoded")
    req.get_method = lambda: 'GET'
    try:
        response = urllib2.urlopen(req)
        result = response.read()
        return loads(result)
    except Exception as he:
        print(he)
        print(url)


class Lint(object):
    def __init__(self, epic=False):
        self.pks = {}
        self.names = {}
        self.epic = epic
        self.array_definition = []
        self.errors = []

    def validate_schema(self, definition):
        required = ['application', 'definition', 'information']
        found_errors = []
        for k in required:
            if k not in definition:
                self.errors.append('[SCHEMA](missing key):'
                                             '\n\t\t\t%s key is required ' % (k.upper()))
        if len(found_errors) > 0:
            self.errors += found_errors
            return False

        if definition['application'] not in ['epic', 'filter']:
            self.errors.append('[SCHEMA](invalid value):\n\t\t\tApplication value can only '
                                         'be either "filter" or "epic" not %s' % definition['application'])
            return False
        if definition['application'] == 'epic':
            if 'threshold' not in definition:
                self.errors.append('[SCHEMA](missing key):,'
                                             '\n\t\t\tWhen application is Epic, threshold is required ')
                return False
        return True

    def call_epic_search(self, filter_node):
        params = {
            'search_q': filter_node,
            'format': 'json',
            'limit': 1,
        }
        result = transmit('https://epic.isg.apple.com/api/search/rest/v3/node/?%s' % urlencode(params))
        if 'meta' in result:
            if 'total_count' in result['meta']:
                return result['meta']['total_count']
        return 0

    def validate_information(self, information):
        required = ['description', 'name', 'username']
        found_errors = []
        for k in required:
            if k not in information:
                found_errors.append('[INFORMATION] (missing key):'
                                    '\n\t\t\t%s key is required ' % (k.upper()))
        if len(found_errors) > 0:
            self.errors += found_errors
            return False
        if re.search("[@\$%\^&\*\[\]\\\; /{}:~\'\"\(\)<>\,\+\!\?]+", information['name']):
            self.errors.append(
                '[INFORMATION] illegal character use in name %s'
                '\n\t\t\t you must not use any of these chars @ $ %% ^ & * [] () \ ; / {} : , +  ~ \'\" < > ? !'
                'and space' % (information['name']))
            return False
        if re.search("[@\$%\^&\*\[\]\\\; /{}:~\'\"\(\)<>\,\+\!\?]+", information['username']):
            self.errors.append(
                'INFORMATION illegal character use in username  %s'
                '\n\t\t\t you must not use any of these chars @ $ %% ^ & * [] () \ ; / {} : , + ~ \'\" < > ? !'
                'and space' % (information['username']))
            return False
        return True

    def validate_definition(self, definition, application):
        if application == 'epic':
            required = ['mode', 'datasource', 'node', 'instance']
            found_errors = []
            for k in required:
                if k not in definition.keys():
                    found_errors.append(
                        '[DEFINITION] (missing key):'
                        '\n\t\t\t For Epic threshold %s key is required ' % k.upper())
            if len(found_errors) > 0:
                self.errors += found_errors
                return False
            if definition['mode'] not in ['average', 'expand', 'sum']:
                self.errors.append(
                    '[DEFINITION] (incorrect mode):'
                    '\n\t\t\t %s is not one of the following average, '
                    'expand, sum ' % definition['mode'])
                return False
        else:
            for key, value in definition.items():
                if key not in ['alert', 'node', 'instance', 'locale']:
                    self.errors.append(
                        '[DEFINITION] (incorrect filter key):'
                        '\n\t\t\t %s is not one of the following filter:  '
                        'alert, node, instance, locale' % definition['mode'])
                    return False
                try:
                    re.compile(value)
                except Exception as e:
                    self.errors.append(
                        '[DEFINITION] (Invalid filter):'
                        '\n\t\t\t %s is not a valid regex.' % value
                    )
                    return False
        if 'node' in definition:
            try:
                definition['node']
            except UnicodeDecodeError:
                self.errors.append(
                    '[DEFINITION] (Node filter):'
                    '\n\t\t\t You cannot use non ascii chars in node filter')
                return False
            try:
                re.compile(definition['node'])
            except Exception as e:
                # Edge case, for Epic keyword * is allowed as a wildcard for all instances
                if 'application' == 'epic' and definition['node'] == '*':
                    pass
                else:
                    self.errors.append(
                        '[DEFINITION] (Node filter):'
                        '\n\t\t\t Your Node regex is not valid Reason %s, '
                        'value %s' % (e, definition['node']))
                    return False
            if ' ' in definition['node']:
                self.errors.append(
                    '[DEFINITION] (Node filter):'
                    '\n\t\t\t You cannot use space in the node filter')
                return False
            if application == 'epic':
                if len(definition['node']) > 1024:
                    self.errors.append(
                        '[DEFINITION] (Node filter),'
                        '\n\t\t\t When application is Epic, the max length'
                        ' of the node or node list is 1024 characters')
                    return False
            if self.epic:
                if '/' in definition['node']:
                    pass
                all_exclude = re.findall('([a-zA-Z0-9]+),?', definition['node'])
                all_filters = re.findall('!([a-zA-Z0-9]+),?', definition['node'])
                if len(all_exclude) == len(all_filters):
                    pass
                count = self.call_epic_search(definition['node'])
                if count > 200000:
                    self.errors.append(
                        '[DEFINITION] (Node filter):'
                        '\n\t\t\t Your filter is too large, matching more than 200 000 entries,\n '
                        'please reduce the scope of your filter')
                    return False
                elif count == 0:
                    self.errors.append(
                        '[DEFINITION] (Node filter):'
                        '\n\t\t\t Your filter is not matching any node,\n '
                        'please verify your filter')
                    return False

        return True

    def validate_threshold(self, threshold):
        list_status = ['', 'ok', 'unknown', 'info', 'warning', 'critical']
        for aggr, info in sorted(threshold.items()):
            for nest in info['definition']:
                if len(nest) != 3:
                    self.errors.append(
                        '[THRESHOLD] (Threshold syntax):'
                        '\n\t\t\t Syntax %s is not in the form of '
                        '{a} {comparison} {b}' % nest)
                    return False
                if nest[1] not in ['>', '<', '<=', '>=', '!', '=']:
                    self.errors.append(
                        '[THRESHOLD] (Threshold syntax):'
                        '\n\t\t\t %s is not  a valid comparison.'
                        'We only allow >, <, <=, >=, !, =' % nest[1])
                    return False
                try:
                    if '(?<' in nest[0]:
                        re.compile(nest[0].replace('(?<', '(?P<'))
                    else:
                        re.compile(nest[0])
                except Exception as e:
                    self.errors.append(
                        '[THRESHOLD] (Threshold syntax):'
                        '\n\t\t\t %s is not  a valid regex.' % nest[0])
                    return False
                try:
                    if '(?<' in nest[2]:
                        re.compile(nest[2].replace('(?<', '(?P<'))
                    else:
                        re.compile(nest[2])
                except Exception as e:
                    self.errors.append(
                        '[THRESHOLD] (Threshold syntax):'
                        '\n\t\t\t %s is not  a valid regex.' % nest[0])
                    return False
                if 'status' not in info:
                    self.errors.append(
                        '[THRESHOLD] (Threshold status):'
                        '\n\t\t\t Status %s is missing' % info)
                    return False
                elif info['status'].lower() not in list_status:
                    self.errors.append(
                        '[THRESHOLD] (Threshold status):'
                        '\n\t\t\t Status %s is not valid, '
                        'must be in %s' % (info['status'], ', '.join(list_status)))
                    return False
        return True

    def validate_subscription(self, subscription):
        list_escalation = ['email', 'http', 'slack', 'centralstation', 'radar', 'cst', 'servicenow',
                           'hipchat', 'pager', 'espresso',  'debug', 'pagerduty', 'syslog', 'aipo']
        if 'notification_type' not in subscription:
            self.errors.append(
                '[SUBSCRIPTION] (Notification type missing):'
                '\n\t\t\t Type is required'
                'must be in %s' % (', '.join(list_escalation)))
        elif subscription['notification_type'] not in list_escalation:
            self.errors.append(
                '[SUBSCRIPTION] (Notification type):'
                '\n\t\t\t Type %s is not valid'
                'must be in %s' % (subscription['notification_type'], ', '.join(list_escalation)))
            return False
        elif subscription['notification_type'] == "cst":
            required_cst = ['priority', 'jobname', 'subscriber', 'select-duration', 'resend-after',]
            list_status = ['ok', 'unknown', 'info', 'warning', 'critical']
            list_cst = ['1 - High', '2 - Medium', '3 - Low']
            found_errors = []
            for k in required_cst:
                if k not in subscription.keys():
                    found_errors.append(
                        '[SUBSCRIPTION] TYPE CST (missing key):'
                        '\n\t\t\t For Subscription %s key is required ' % k.upper())
                if k == 'priority':
                    for p, content in subscription['priority']:
                        if p not in list_status:
                            found_errors.append(
                                '[SUBSCRIPTION] TYPE CST (invalid status):'
                                '\n\t\t\t For Subscription %s allowed values ' % (k.upper(), ))

        else:
            required_email = ['email-contact', 'select-duration', 'resend-after', 'subscriber']
            found_errors = []
            for k in required_email:
                if k not in subscription.keys():
                    found_errors.append(
                        '[SUBSCRIPTION] (missing key):'
                        '\n\t\t\t For Subscription %s key is required ' % k.upper())
        if len(found_errors) > 0:
            self.errors += found_errors
            return False
        return True

    def duplicate_name(self):
        for key, value in self.names.items():
            if len(value) > 1:
                self.errors.append(
                    "[DUPLICATE_NAME] Name: found %s in %s files"
                    "\n\t\t\t%s" % (key, len(value), '\n\t\t\t'.join(value)))

    def duplicate_pk(self):
        for key, value in self.pks.items():
            if len(value) > 1:
                self.errors.append(
                    "[DUPLICATE_PK] PK: found %s in %s files"
                    "\n\t\t\t%s" % (key, len(value), '\n\t\t\t'.join(value)))

    def validate(self, definition):
        self.validate_schema(definition)
        self.validate_information(definition['information'])
        self.validate_definition(definition['definition'], definition['application'])

        if definition['application'] == 'epic':
            self.validate_threshold(definition['threshold'])
        if 'subscription' in definition:
            for i in definition['subscription']:
                self.validate_subscription(i)
        return self.errors


