__author__ = 'rfoucher'

import logging
import redis

from django.conf import settings
logger = logging.getLogger("django")


class RedisRouter:
    def __init__(self, action, organization, retry=10):
        self.organization = organization
        self.action = action.upper()
        self.retry = retry

    def connect(self, host='127.0.0.1', port=11211, db=0, attempt=0):
        r_base = None
        if attempt < self.retry:
            r_base = redis.Redis(
                host=host,
                port=port,
                db=db,
                retry_on_timeout=True,
                socket_timeout=480
            )
            self.test_connection(r_base)
        if not self.test_connection(r_base):
            if attempt < 20:
                self.connect(host, port, db, attempt+1)
            else:
                logger.critical('Unable to connect to Redis config : %s %s (%s)' % (host, port, db))
        return r_base

    def retrieve_redis_connection(self):
        r_base = None
        if self.action not in settings.REDIS_INSTANCES:
            return False
        if self.organization in settings.REDIS_INSTANCES[self.action]:
            conf = settings.REDIS_INSTANCES[self.action][self.organization]
            logger.debug('Found the organization SETTINGS %s' % conf)
            r_base = self.connect(host=conf['HOST'], port=int(conf['PORT']), db=conf['DB'])
        else:
            logger.critical('[RedisRouter missing route ] unable to find organization SETTINGS %s' % self.organization)
            conf = settings.REDIS_INSTANCES[self.action]['default']
            r_base = self.connect(host=conf['HOST'], port=int(conf['PORT']), db=conf['DB'])
        return r_base

    def test_connection(self, r_base):
        try:
            r_base.ping()
            return True
        except:
            return False
