__author__ = 'rfoucher'

import ujson as json
import logging
from django.conf import settings
import requests
from contrib.resource.redisrouter import RedisRouter
from backend.models import Alert

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)



class Kin:
    def __init__(self):
        self.endpoint = settings.KIN_URL
        self.version = settings.KIN_VERSION

    @staticmethod
    def set_last_publish(location):
        # UUID is the marker for the last update
        # Update the last UUID after the push to Kin
        RedisRouter().retrieve_redis_connection('stats', 'nodes').set('kin_last', location)

    @staticmethod
    def get_last_publish():
        # Used for the Notification process to correlate with last pushed alert to Kin
        # UUID is the marker for the last update
        return RedisRouter().retrieve_redis_connection('stats', 'nodes').get('kin_last')

    def fetch_topology(self, node, locale, instance, dependents=0, dependencies=0, expand=False):
        resource = 'nodes'
        data = {
            'dependents': dependents,
            'dependencies': dependencies,
            'expand': expand
        }
        content = requests.get('%s/api/kin/%s/%s/%s@%s/%s/' % (
            self.endpoint,
            self.version,
            resource,
            instance, locale, node
            ),
            params=data, verify=False
        )
        return content.json()

    def fetch_related_alerts(self, node, locale, instance):
        result = []
        topology = self.fetch_topology(node, locale, instance)
        topology = topology['nodes'][0]

        nodes = [topology['properties']['node']]
        nodes += []
        keep = ['alert', 'instance', 'node', 'locale']
        for i in Alert().kin_fetch({'node': nodes}):
            result.append(
                {key: i['_source'][key] for key in i['_source'] if key in keep}
            )
        return result

    def fetch_correlation(self, location, data):
        resource = 'correlate'
        # On fetch reuse cached UUID
        logger.debug('%s%s%s/' % (self.endpoint, location, resource))
        logger.debug('Count of alert to correlate: %s' % len(data))
        logger.debug(data)
        content = requests.post('%s%s%s/' % (self.endpoint, location, resource), json=data, verify=False, timeout=240)
        try:
            return content.json()
        except Exception as e:
            logger.critical('[Kin::fetch_correlation] Error while fetching Kin %s : %s' % (e, content.text))
        return {'simple': [], 'causal': []}

    def publish_alerts(self, data):
        resource = 'alert-state'
        # On publish - store UUID
        logger.debug('Publish alert %s/api/kin/%s/%s/' % (self.endpoint, self.version, resource))
        logger.debug('Count of alerts %sq' % len(data))
        logger.debug('Alerts %s' % json.dumps(data))
        try:
            content = requests.post('%s/api/kin/%s/%s/' % (self.endpoint, self.version, resource),
                                    json=data, verify=False, timeout=240)
            logger.critical(content.text)
            result = content.json()
        except Exception as e:
            logger.critical(e)
            raise ValueError
        if 'location' in result:
            return result
        else:
            raise ValueError

    def find_causal(self, alerts):
        location = self.get_last_publish()
        return self.fetch_correlation(location, alerts)

    def task(self):
        all_alerts = Alert().kin_fetch({'status': 'CRITICAL', 'instance': 'gnsnet'})
        location = self.publish_alerts(all_alerts)
        self.set_last_publish(location['location'])
