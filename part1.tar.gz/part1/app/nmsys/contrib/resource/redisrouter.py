__author__ = 'rfoucher'

import logging
import redis
import random
from redis.sentinel import Sentinel
from redis.sentinel import MasterNotFoundError
from django.conf import settings
logger = logging.getLogger()



class RedisRouter:
    def __init__(self):
        self.retry = 10

    def connect_sentinel(self, routing_key='picky', db=0):
        return Sentinel(settings.SENTINEL_INSTANCE[routing_key], password=settings.SENTINEL_PASS, decode_responses=True).master_for(routing_key, socket_timeout=480, retry_on_timeout=False)

    # Allow fallback to old Redis router from settings when sentinel is unavailable
    def retrieve_redis_connection(self, action, application):
        action = action.upper()
        logger.debug('[retrieve_redis_connection ] SETTINGS %s %s' % (action, application))
        if settings.SENTINEL_KUBE:
            return Sentinel(settings.SENTINEL_NODE, password=settings.SENTINEL_PASS, decode_responses=True, sentinel_kwargs={'password': settings.SENTINEL_PASS}).master_for(settings.SENTINEL_MASTER, socket_timeout=480, retry_on_timeout=False)
        elif settings.SENTINEL_FLAG:
            if action == 'COMMON' or action == 'TASK':
                routing_key = 'nmsys_celery-redis-cluster'
                try:
                    db = settings.REDIS_INSTANCES[action][application]['DB']
                except:
                    db = 0
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'SCRIPT':
                routing_key = 'nmsys_script-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'STATS':
                routing_key = 'nmsys_stats-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'SEMAPHORE':
                routing_key = 'nmsys_semaphore-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'HISTORY':
                routing_key = 'nmsys_history-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'ID_CACHE':
                routing_key = 'nmsys_idcache-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
            elif action == 'NMSYSCLIENT':
                routing_key = 'nmsys_alert-redis-cluster'
                db = settings.REDIS_INSTANCES[action][application]['DB']
                return self.connect_sentinel(routing_key, db=db)
        else:
            return self.connect_redis(action, application)

    def connect(self, host='127.0.0.1', port=11211, db=0, attempt=0):
        r_base = None
        if attempt < self.retry:
            r_base = redis.Redis(
                host=host,
                port=port,
                db=db,
                retry_on_timeout=True,
                socket_timeout=480,
                decode_responses=True
            )
            self.test_connection(r_base)
        if not self.test_connection(r_base):
            if attempt < 20:
                self.connect(host, port, db, attempt+1)
            else:
                logger.critical('Unable to connect to Redis config : %s %s (%s)' % (host, port, db))
        return r_base

    def connect_redis(self, action, application):
        r_base = None
        if action not in settings.REDIS_INSTANCES:
            return False
        if application in settings.REDIS_INSTANCES[action]:
            conf = settings.REDIS_INSTANCES[action][application]
            logger.debug('Found the organization SETTINGS %s' % conf)
            r_base = self.connect(host=conf['HOST'], port=int(conf['PORT']), db=conf['DB'])
        else:
            logger.critical('[RedisRouter missing route ] unable to find organization SETTINGS %s' % application)
            conf = settings.REDIS_INSTANCES[action]['default']
            r_base = self.connect(host=conf['HOST'], port=int(conf['PORT']), db=conf['DB'])
        return r_base

    def test_connection(self, r_base):
        try:
            r_base.ping()
            return True
        except:
            return False
