from django.db.backends.mysql.base  import (
    DatabaseWrapper as XtradbWrapper,
    DatabaseFeatures,
    DatabaseOperations,
    django_conversions,
    Database,
    CLIENT
)
from django.db.utils import IntegrityError, DatabaseError
from django.conf import settings
import logging
from django.core.exceptions import ImproperlyConfigured

logger = logging.getLogger("django")
ch = logging.StreamHandler()
logger.addHandler(ch)


__all__ = ['DatabaseWrapper', 'DatabaseError', 'IntegrityError',
           'DatabaseFeatures', 'DatabaseOperations']

class DatabaseWrapper(XtradbWrapper):
    isolation_levels = {
        'read uncommitted',
        'read committed',
        'repeatable read',
        'serializable',
    }
    def get_connection_params(self):
        kwargs = {
            'conv': django_conversions,
            'charset': 'utf8',
        }
        settings_dict = self.settings_dict
        if settings_dict['USER']:
            kwargs['user'] = settings_dict['USER']
        if settings_dict['NAME']:
            kwargs['db'] = settings_dict['NAME']
        if settings_dict['PASSWORD']:
            kwargs['passwd'] = settings_dict['PASSWORD']
        if settings_dict['HOST']:
            kwargs['host'] = settings_dict['HOST']
        if settings_dict['PORT']:
            kwargs['port'] = int(settings_dict['PORT'])
        # We need the number of potentially affected rows after an
        # "UPDATE", not the number of changed rows.
        kwargs['client_flag'] = CLIENT.FOUND_ROWS
        # Validate the transaction isolation level, if specified.
        options = settings_dict['OPTIONS'].copy()
        isolation_level = options.pop('isolation_level', 'read committed')
        if isolation_level:
            isolation_level = isolation_level.lower()
            if isolation_level not in self.isolation_levels:
                raise ImproperlyConfigured(
                    "Invalid transaction isolation level '%s' specified.\n"
                    "Use one of %s, or None." % (
                        isolation_level,
                        ', '.join("'%s'" % s for s in sorted(self.isolation_levels))
                    ))
        self.isolation_level = isolation_level
        kwargs.update(options)
        return kwargs

    def get_new_connection(self, conn_params):
        index = 0
        hostlist = conn_params.pop('host')
        conn_params['connect_timeout'] = 1
        while True:
            try:
                conn_params['host'] = hostlist[index]
                connect = Database.connect(**conn_params)
                connect.ping()
                return connect
            except Exception as e:
                logger.critical('[DatabaseWrapper::get_new_connection]Error %s %s' % (hostlist, e))
                if index > len(hostlist):
                    break
                index += 1

    def is_usable(self):
        if self.connection is not None:
            try:
                self.connection.ping()
                return True
            except Database.Error as e:
                logger.critical('[DatabaseWrapper::is_usable]Error %s' % e)
                self.connection.close()
                self.connection = None
        return False
