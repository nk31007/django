import logging
import operator
import re
from elasticsearch_dsl import Q
from elasticsearch_dsl import Search
from ply import lex, yacc
from contrib.resource.translate_deprecated_n_exp import Translator
import itertools
from elasticsearch_dsl import A
from ply.lex import TOKEN
from contrib.epic import EpicSearch
from backend.models import connections
# Logging
logger = logging.getLogger('django')

__author__ = 'nikita'

# ------------------------------------------------------------
# parser_search.py
#
# tokenizer for a  node-expression evaluator
# ------------------------------------------------------------

# List of token names. This is always required

class LexerNmsysSearch(object):

    tokens = [
        'COMMA',
        'TILDE',
        'PARAM',
        'LP',
        'RP',
        'SQ_REGEX_PARAM',
        'DQ_REGEX_PARAM',
        'INTERSECTION_OPERATOR',
        'UNION_OPERATOR',
        'DIFFERENCE_OPERATOR',
        'ANY',
        'ALL',
        'EXPAND',
        'FUNC_NAME',
        'NODE'
    ]

    # Regular expression rules for simple tokens
    t_COMMA = r'\,'
    t_TILDE = r'\~'
    t_PARAM = r'[^\s\(\),&:\"\'~]+'

    def __init__(self, dict_obj):
        t_FUNC_NAME = dict_obj

    def t_LP(self, t):
        r'\('
        return t

    def t_RP(self, t):
        r'\)'
        return t

    def t_SQ_REGEX_PARAM(self, t):
        r'\'([^\s:\"\']*?)\''
        t.type = 'PARAM'
        t.value = t.value[1:-1]
        return t

    def t_DQ_REGEX_PARAM(self, t):
        r'\"([^\s:\"\']*?)\"'
        t.type = 'PARAM'
        t.value = t.value[1:-1]
        return t

    def t_INTERSECTION_OPERATOR(self, t):
        r'(?i)INTERSECT|&'
        return t

    def t_UNION_OPERATOR(self, t):
        r'(?i)UNION'
        return t

    def t_DIFFERENCE_OPERATOR(self, t):
        r'(?i)MINUS|-'
        return t

    def t_ANY(self, t):
        r'(?i)ANY'
        return t

    def t_ALL(self, t):
        r'(?i)ALL'
        return t

    def t_EXPAND(self, t):
        '(?i)EXPAND'
        return t

    def t_NODE(self, t):
        r'(?i)NODE'
        return t

    # Define a rule so we can track line numbers
    def t_newline(self, t):
        r'\n+'
        t.lexer.lineno += len(t.value)

    # A string containing ignored characters (spaces and tabs)
    t_ignore = ' \t'

    # Error handling rule
    def t_error(self, t):
        logger.debug("Illegal character '%s' on line %d, column %d" % (t.value[0], t.lexer.lineno, t.lexer.lexpos))
        t.lexer.skip(1)

    # Build the lexer
    def build_lexer(self, **kwargs):
        self.lexer = lex.lex(module=self, **kwargs)
        return self.lexer

class ParserNmsysSearch(object):

    tokens = LexerNmsysSearch.tokens

    def __init__(self, **kwargs):
        self.lexer = None
        self._model_map = None
        # if dot is followed by any regex meta characters
        # then it will be counted as regex character else it will considered literally
        self.dot_check = re.compile('\.[\^$*+?{}\[\]|()]')
        # check if its a valid kv node
        self.regex_valid_kv_node = re.compile(r'^[\w\-.]+!?=.')
        # checking double .*.*in string"
        self.double_dot_star_check = re.compile('(?:\.\*){2,}')
        self.error = ""
        self.es_query = ""
        self.parser = yacc.yacc(module=self, **kwargs)

    @property
    def model_map(self):
        return self._model_map

    @model_map.setter
    def model_map(self, model_map):
        self._model_map = model_map
        r_pattern = re.compile('|'.join('{}'.format(k) for k in self._model_map), re.IGNORECASE)
        r_pattern = r_pattern.pattern
        self.lexer = LexerNmsysSearch(r_pattern).build_lexer()

    # dummy method : needs to be replaced with EpicSearch().findlist()
    def get_nodes_from_search(self, node_expression):
        list_node = ["fakenode0.apple.com", "fakenode1.apple.com"]
        return list_node

    def get_es_alert_query(self, node_expression):
        try:
            #list_node = self.get_nodes_from_search(node_expression)
            list_node = EpicSearch().find_list(node_expression, version='v3')
            if len(list_node) == 0:
                raise ValueError('Invalid node, please make sure %s exists in Epic' % node_expression)
        except NameError:
            raise NameError('Too many entries to fetch for %s (limit is 200 000)' % node_expression)
        except Exception as e:
            raise ValueError('There\' s a problem with your request %s : %s' % (node_expression, e))
        query = []
        if len(list_node) > 1024:
            mini_query = []
            for buk in [list_node[i:i + 1000] for i in list(range(0, len(list_node), 1000))]:
                mini_query.append(Q(
                    'terms',
                    node=buk
                ))
            return Q(
                'bool',
                should=mini_query,
            )
        else:
            return Q(
                'terms',
                node=list_node
            )

    def get_nodes_query(self, param):

        # check if its a regex or kv node
        node_pattern = re.compile("[\^\/!*\[({%?$]")

        # if dot is followed by any regex meta characters
        # then it will be counted as regex character else it will considered literally
        # dot_check = re.compile('\.[\^$*+?{}\[\]|()]')

        if node_pattern.search(param):
            iskvnode = False

            # check if kv nodes are anchored ^$ or ^ or $
            full_kv_match_1 = re.match('\^/(.*)\$', param)
            full_kv_match_2 = re.match('/(.*)\/\?', param)
            start_kv_match = re.match('\^/(.*)', param)
            end_kv_match = re.match('/(.*)\$', param)

            if full_kv_match_1 or full_kv_match_2 or start_kv_match or end_kv_match or param.startswith("/"):
                iskvnode = True

            # input node-pattern is a kv node
            if iskvnode:
                # full anchored kv node ^$
                if full_kv_match_1 or full_kv_match_2:
                    if full_kv_match_1:
                        param = "/" + full_kv_match_1.group(1)
                    if full_kv_match_2:
                        param = "/" + full_kv_match_2.group(1)
                    param = param.replace("(.*)", ".*")

                    sub_kv_nodes_list = filter(None, param.split("/"))

                    # check every part of kv node is valid
                    valid_sub_kv_nodes_list = [sub_node if self.regex_valid_kv_node.match(sub_node) else ""
                                               for sub_node in sub_kv_nodes_list]

                    # kv node is valid
                    # for eg:  ^/k1=v1/k2=.*$
                    # 1.) form list like : /k1=v1/k2=.*, /k2=.*/k1=v1
                    #   (list generated after making all permutation combinations)
                    # 2.) check if any item in the list ends with .*, if yes then make that item as => /k1=v1/k2=.*?
                    # 3.) Now list looks like : /k1=v1/k2=.*?, /k2=.*/k1=v1
                    # 4.) now get all the items using es qyery which matches above items ->
                    # Q('bool', should = [/k1=v1/k2=.*?, /k2=.*/k1=v1])
                    # Lets say the results are :
                    #   1.) /k2=v3/k1=v1
                    #   2.) /k1=v1/k2=v4/k3=v3
                    # Now, filter this results list using python code
                    #   such that every item contains key as k1 and k2 only.
                    # So, now final list will look like : [/k2=v3/k1=v1]
                    # Now form es query with the final list :  Q('bool', should = [/k2=v3/k1=v1])

                    # if '!=' is in any part of kv node for eg: ^/k1=v1/k2=.*/k3!=v3$,
                    # then add k3=.*?, k1=v1, k2=.*  in must_list of es query and k3=v3 in must_not list of es query.

                    if set(sub_kv_nodes_list) == set(valid_sub_kv_nodes_list):
                        sub_kv_nodes_list = [sub_node
                                             if self.dot_check.search(sub_node)
                                             else sub_node.replace(".", "\.")
                                             for sub_node in sub_kv_nodes_list]
                        must_not_list = []
                        expected_keys = [sub_node.split('=', 1)[0] for sub_node in sub_kv_nodes_list]
                        kv_list = ["/" + kvnode
                                   for kvnode in ['/'.join(node)
                                                  for node in list(itertools.permutations(sub_kv_nodes_list))]]
                        kv_list = [node.replace('.*', '.*?') if node.endswith(".*") else node for node in kv_list]

                        for index, kv_node in enumerate(kv_list):
                            if "!=" in kv_node:
                                kv_node = kv_node.replace('!',"")
                                must_not_list.append(kv_node)
                                kv_list[index] = kv_node.split("=")[0] + "=.*?"

                        query = Q('bool',
                                  should=[Q('regexp', node=kv_node) for kv_node in kv_list],
                                  must_not=[Q('regexp', node=kv_node) for kv_node in must_not_list])

                        # Stream = Alert resource _meta.index
                        # _meta.doc_type
                        if any(node.endswith(".*?") for node in kv_list):
                            search_obj = Search(
                                using=connections.get_connection(),
                                index='epic',
                                doc_type='alert'
                            ).query(query)
                            agg_obj = A('terms', field='node', size=99999)
                            search_obj.aggs.bucket('nodes', agg_obj)
                            nodes_list = [b.key for b in search_obj.execute().aggregations.nodes.buckets]
                            final_kv_list = []

                            # filter nodes_list
                            for node in nodes_list:
                                sub_node_kv_list = filter(None, node.split("/"))
                                result_keys = [sub_node.split('=', 1)[0] for sub_node in sub_node_kv_list]
                                if set(expected_keys) == set(result_keys):
                                    final_kv_list.append(node)

                            if final_kv_list:
                                query = Q('bool', should=[Q('regexp', node=kv_node) for kv_node in final_kv_list])
                            else:
                                query = ""
                    else:
                        query = ""

                # kv node is either ^ or $ or non-anchored
                else:
                    if start_kv_match:
                        param = "/" + start_kv_match.group(1)
                    elif end_kv_match:
                        param = "/" + end_kv_match.group(1)

                    # check if its a kv node
                    must_list = []
                    must_list2 = []
                    must_not_list = []
                    should_list = []
                    dot_star_end_list = []

                    # split the list
                    param = param.replace("(.*)", ".*")
                    nodelist = filter(None, param.split("/"))

                    # check if its a valid kv node
                    # loop inside list
                    # eg : /k1=v1/k2!=v2/k3=.*/k4=v4[12]
                    # 1.) split above list on '/' and check if every part of kv node is valid
                    # 2.) form ES query like Q('bool', must=must_list, should=should_list, must_not=must_not_list)
                    # 3.) how to create must, should, must_not_list ?
                    # 4.) if some item ends with .*; put that in dot_star_emd_list [] like:
                    # dot_star_end_list = [*/k3=.*?]
                    # else add in must_list and must_list2 like :
                    # must_list = [.*/k1=v1/.*? , .*/k4=v4[12]/.*?]
                    #   (for all the nodes that contains /k1=v1/ and /k4=v4[12]/ in it)
                    # must_list2 = [.*/k1=v1 , .*/k4=v4[12]]
                    #   (because we dont want to miss any nodes which ends with /k1=v1 or /k4=v4[12])
                    # 5.) if some item contains != in it, then add that item in dot_star_end_list and must_not_list as:
                    # dot_star_end_list = [*/k3=.*? , .*/k2=.*?]
                    # must_not_list = [.*/k2=v2/.*?, .*/k2=v2]

                    # Final lists:
                    # must_list = [.*/k1=v1/.*? , .*/k4=v4[12]/.*?]
                    # must_list2 = [.*/k1=v1 , .*/k4=v4[12]]
                    # dot_star_end_list = [*/k3=.*? , .*/k2=.*?]
                    # must_not_list = [.*/k2=v2/.*?, .*/k2=v2]

                    # form a query like below:
                    # final query =
                    #   Q('bool', should=[Q('bool', must=[.*/k1=v1/.*?, .*/k4=v4[12], */k3=.*?, .*/k2=.*?]),
                    #                        Q('bool', must=[.*/k4=v4[12]/.*?, .*/k1=v1, */k3=.*?, .*/k2=.*?])],
                    #             must_not=[.*/k2=v2/.*?, .*/k2=v2])

                    for node in nodelist:
                        if self.regex_valid_kv_node.search(node):
                            node = node if self.dot_check.search(node) else node.replace(".", "\.")
                            # check regex and !
                            if node.endswith(".*"):
                                if '!=' in node:
                                    kvnode = node.replace('!',"")
                                    splitkv = kvnode.split("=")
                                    must_not_list.append(".*/" + kvnode + "?")
                                    dot_star_end_list.append(".*/" + splitkv[0] + "=.*?")
                                else:
                                    dot_star_end_list.append(".*/" + node + "?")
                            else:
                                if '!=' in node:
                                    kvnode = node.replace('!',"")
                                    splitkv = kvnode.split("=")
                                    must_not_list.append(".*/" + kvnode + "/.*?")
                                    must_not_list.append(".*/" + kvnode)
                                    dot_star_end_list.append(".*/" + splitkv[0] + "=.*?")
                                else:
                                    must_list.append(".*/" + node + "/.*?")
                                    must_list2.append(".*/" + node)

                        # invalid kv node-pattern; return empty list
                        else:
                            must_list = []
                            must_list2 = []
                            must_not_list = []
                            should_list = []
                            dot_star_end_list = []
                            break

                    # if both must and must_not list's are empty (which means invalid input kv node pattern)
                    if not must_list and not must_not_list and not dot_star_end_list:
                        query = ""
                    else:
                        if len(must_list) > 1:
                            for index, node in enumerate(must_list):
                                new_list = must_list
                                if len(must_list) == len(must_list2):
                                    new_list = list(must_list)
                                    new_list[index] = must_list2[index]
                                new_list = new_list + dot_star_end_list
                                sub_query = Q('bool', must=[Q('regexp', node=test_node) for test_node in new_list])
                                should_list.append(sub_query)
                            should_list.append(Q('bool', must=[Q('regexp', node=must_node)
                                                               for must_node in must_list]))
                            query = Q('bool', should=should_list, must_not=[Q('regexp', node=must_not_node)
                                                                            for must_not_node in must_not_list])
                        elif len(must_list) == 1:
                            for count in range(2):
                                if count == 0:
                                    new_list = must_list
                                else:
                                    new_list = must_list2
                                new_list = new_list + dot_star_end_list
                                sub_query = Q('bool', must=[Q('regexp', node=test_node) for test_node in new_list])
                                should_list.append(sub_query)
                            query = Q('bool', should=should_list, must_not=[Q('regexp', node=must_not_node)
                                                                            for must_not_node in must_not_list])
                        else:
                            if dot_star_end_list:
                                must_list = dot_star_end_list
                            query = Q(
                                'bool',
                                must=[Q('regexp', node=must_node) for must_node in must_list],
                                must_not=[Q('regexp', node=must_not_node) for must_not_node in must_not_list]
                            )

            # simple regex non kv node pattern
            else:
                param = param if self.dot_check.search(param) else param.replace(".", "\.")
                full_match = re.match('\^(.*)\$', param)
                start_match = re.match('\^(.*)', param)
                end_match = re.match('(.*)\$', param)

                if full_match:
                    node_pattern = full_match.group(1)
                elif start_match:
                    node_pattern = start_match.group(1) + ".*"
                elif end_match:
                    node_pattern = ".*" + end_match.group(1)
                else:
                    node_pattern = ".*" + param + ".*"

                node_pattern = re.sub(self.double_dot_star_check, '.*', node_pattern)
                query = Q('regexp', node=node_pattern)

        # its a scalar node
        else:
            param = param if self.dot_check.search(param) else param.replace(".", "\.")
            node_pattern = re.sub(self.double_dot_star_check, '.*', ".*" + param + ".*")
            query = Q('regexp', node=node_pattern)
        return query

    # Handles LP expression RP
    def p_expression(self, p):
        """
        expression : LP expression RP
        """
        p[0] = p[2]
        return p[0]

    # Handles TILDE PARAM - call search
    def p_tilde_param(self, p):
        """
        expression : TILDE PARAM
        """
        p[0] = p[1] + p[2]
        p[0] = self.get_es_alert_query(p[0])
        return p[0]

    # Handles ANY LP PARAM RP - call search
    def p_expression_any(self, p):
        """
        expression : ANY LP PARAM RP
        """
        p[0] = p[1] + p[2] + p[3] + p[4]
        p[0] = self.get_es_alert_query(p[0])
        return p[0]

    # Handles ALL LP PARAM RP - call search
    def p_expression_all(self, p):
        """
        expression : ALL LP PARAM RP
        """
        p[0] = p[1] + p[2] + p[3] + p[4]
        p[0] = self.get_es_alert_query(p[0])
        return p[0]

    # Handles EXPAND LP PARAM COMMA expression RP
    # expression with expand if only for getting nodes from search
    def p_expression_expand(self, p):
        """
        expression : EXPAND LP PARAM COMMA expression RP
        """
        p[0] = p[1] + p[2] + p[3] + p[4] + p[5] + p[6]
        p[0] = self.get_es_alert_query(p[0])
        return p[0]

    def p_expression_func(self, p):
        """
        expression : FUNC_NAME LP PARAM RP
        """
        p[3] = p[3] if self.dot_check.search(p[3]) else p[3].replace(".", "\.")
        param = re.sub(self.double_dot_star_check, '.*', p[3])
        p[0] = Q('regexp', ** { self.model_map[p[1].upper()]:param })
        return p[0]

    def p_expression_func2(self, p):
        """
        expression : PARAM LP PARAM RP
        """
        p[3] = p[3] if self.dot_check.search(p[3]) else p[3].replace(".", "\.")
        param = re.sub(self.double_dot_star_check, '.*', p[3])

        if '.' in p[1]:
            path, short_query = p[1].split('.', 1)
            p[0] = Q("nested", path = path, query = Q("regexp", **{p[1].lower():param}))
        else:
            if p[1].upper() in self.model_map.keys():
                p[0] = Q('regexp', **{ self.model_map[p[1].upper()]:param })
            else:
                p[0] = "INVALID KEY"
        return p[0]

    # Handles expression INTERSECTION_OPERATOR expression
    def p_expression_intersection(self, p):
        """
        expression : expression INTERSECTION_OPERATOR expression
        """
        if isinstance(p[1], basestring) or isinstance(p[3], basestring):
            p[0] = "ERROR: " + (p[1] if isinstance(p[1], basestring) else '') + \
                   " " + (p[3] if isinstance(p[3], basestring) else '')
        else:
            p[0] = Q('bool', must=[p[1], p[3]])
        return p[0]

    # Handles expression UNION_OPERATOR expression | expression COMMA expression
    def p_expression_union(self, p):
        """
        expression : expression UNION_OPERATOR expression
                   | expression COMMA expression
        """
        if isinstance(p[1], basestring) or isinstance(p[3], basestring):
            p[0] = "ERROR: " + (p[1] if isinstance(p[1], basestring) else '') + \
                   " " + (p[3] if isinstance(p[3], basestring) else '')
        else:
            p[0] = Q('bool', should=[p[1], p[3]])
        return p[0]

    # Handles expression DIFFERENCE_OPERATOR expression
    def p_expression_difference(self, p):
        """
        expression : expression DIFFERENCE_OPERATOR expression
        """
        if isinstance(p[1], basestring) or isinstance(p[3], basestring):
            p[0] = "ERROR: " + (p[1] if isinstance(p[1], basestring) else '') + \
                   " " + (p[3] if isinstance(p[3], basestring) else '')
        else:
            p[0] = Q('bool', must=[p[1]], must_not=[p[3]])
        return p[0]


    # Handles NODE PARAM
    def p_expression_node(self, p):
        """
        expression : NODE LP expression2 RP
        """
        p[0] = p[3]
        if isinstance(p[0], basestring):
            if re.search(r'(:?\W|^)(:?ANY|ALL|INSTANCE|LOCALE|EXPAND)\(', p[0], re.IGNORECASE):
                p[0] = self.get_es_alert_query(p[0])
            elif re.search(r'\W(:?UNION|MINUS|INTERSECT)\W', p[0], re.IGNORECASE):
                p[0] = self.get_es_alert_query(p[0])
        return p[0]

    def p_expression_node1(self, p):
        """
        expression2 : LP expression2 RP
        """
        p[0] = p[1] + p[2] + p[3]
        return p[0]

    def p_expression_node2(self, p):
        """
        expression2 : TILDE PARAM
                    | ANY LP PARAM RP
                    | ALL LP PARAM RP
                    | FUNC_NAME LP PARAM RP
                    | PARAM LP PARAM RP
        """
        if p[1] == "~":
            p[0] = "ANY(\"" + p[2] + "\")"
        else:
            p[0] = p[1] + p[2] + p[3] + p[4]
        return p[0]

    def p_expression_node3(self, p):
        """
        expression2 : EXPAND LP PARAM COMMA expression2 RP
        """
        p[0] = p[1] + p[2] + p[3] + p[4]+ p[5]+ p[6]
        return p[0]

    def p_expression_node4(self, p):
        """
        expression2 : expression2 INTERSECTION_OPERATOR expression2
                    | expression2 UNION_OPERATOR expression2
                    | expression2 COMMA expression2
                    | expression2 DIFFERENCE_OPERATOR expression2
        """
        p[0] = p[1] + " " + p[2] + " " + p[3]
        return p[0]

    # Handles PARAM
    def p_expression_node5(self, p):
        """
        expression2 : PARAM
        """
        query = self.get_nodes_query(p[1])
        if query:
            p[0] = query
        else:
            p[0] = "INVALID KV NODE"
        return p[0]

    # Error handling rule
    def p_error(self, p):
        if p:
            stack_state_str = " ".join([symbol.type for symbol in self.parser.symstack[1:]])
            self.error = "Syntax error at %s, type %s, on line %d, Parser state: %s %s . %s" % (
                p.value, p.type, p.lineno, self.parser.state, stack_state_str, p
            )
        else:
            self.error = "SYNTAX ERROR IN INPUT"
        logger.debug(self.error)

    
    # checking if n-expression is in new syntax or old syntax
    def get_expression_version(self, node_expression):

        # contains " or ' , call translator v3
        v3_pattern_1 = 'ANY' + '|' + 'ALL' + '|' + 'EXPAND' + '|' + 'INSTANCE' + '|' + 'LOCALE' + '|' + 'NODE' + '|' + '|'.join(re.escape(k) for k in self.model_map.values())
        if node_expression.find("'") != -1 or node_expression.find("\"") != -1:
            return "v3"
        
        # contains ANY/ALL/EXPAND etc() | _ANY/ALL/EXPAND etc(), call translator v3

        elif re.search(r'(:?\W|^)(:?' + v3_pattern_1 + r')\(', node_expression , re.IGNORECASE):
            return "v3"
        
        # contains :intersect, call translator v1
        elif node_expression.find(":intersect") != -1:
            return "v1"
        
        # contains _UNION_/_INTERSECT_/_MINUS_ , call translator v3
        elif re.search(r'\W(:?UNION|MINUS|INTERSECT)\W', node_expression, re.IGNORECASE):
            return "v3"
        
        # contains _-_|_&_ , call translator v3
        elif node_expression.find(" & ") != -1 or node_expression.find(" - ") != -1:
            return "v3"

        # contains first letter : of any model map keys or full key name 
        # contains i:, instance:, locale:, l:, node:, n: , call translator v2

        elif any(val + ":" in node_expression  or val[0] + ':' in node_expression for val in self.model_map.values()):
            return "v2"

        # if expression consists of _AND_/_OR_, call translator v2
        elif re.search(r'\W(:?AND|OR)\W', node_expression):
            return "v2"

        # sub - expressions are separated only by spaces, call translator v2
        elif node_expression.strip().find(" ") != -1:
            return "v2"

        elif ":" in node_expression.strip():
            return "v2"

        # sub - expressions are separated only by , call translator v3
        # split expression on comma and enclose in double quotes
        elif re.search(r',\s*(?![^{}]*\})', node_expression):
            return "v3_comma_syntax"

        else:
            return "v3_none"

    def get_es_query(self, node_expression):
        node_expression = node_expression.strip()
        if node_expression:
            version = self.get_expression_version(node_expression)
            if version == "v1":
                node_expression = Translator().translate_v1_to_v3(node_expression)
                logger.debug("Translated Expression V1: " + node_expression)
            if version == "v2":
                node_expression = Translator().translate_v2_to_v3(self.model_map, node_expression)
                logger.debug("Translated Expression V2: " + node_expression)
            if version == "v3_comma_syntax":
                node_exp_list = re.split(r',\s*(?![^{}]*\})', node_expression)
                for index, item in enumerate(node_exp_list):
                    if re.match('~"(.*)"$', item):
                        node_exp_list[index] = "ANY(\""+re.match('~"(.*)"$', item).group(1)+"\")"
                    elif re.match('~(.*)$', item):
                        node_exp_list[index] = "ANY(\""+re.match('~(.*)$', item).group(1)+"\")"
                node_expression = ','.join([item if item.find("'") != -1 or item.find("\"")
                                            != -1 else "\""+item+"\"" for item in node_exp_list])
                logger.debug("Translated Expression V3_comma_syntax: " + node_expression)
            if version == "v3_none":
                if re.match('~"(.*)"$', node_expression):
                    node_expression = "ANY(\""+re.match('~"(.*)"$', node_expression).group(1)+"\")"
                elif re.match('~(.*)$', node_expression):
                    node_expression = "ANY(\""+re.match('~(.*)$', node_expression).group(1)+"\")"
                logger.debug("Translated Expression V3_none_syntax: " + node_expression)
        
            logger.debug("Node Expression for Parser: " + node_expression)
            self.es_query = self.parser.parse(node_expression, lexer=self.lexer)      
            if self.error:
                logger.debug("parse result -> %s" % self.error)
                raise ValueError(self.error)
            elif self.es_query:
                logger.debug("parse result -> %s" % self.es_query)
                if isinstance(self.es_query, basestring):
                    raise ValueError(self.es_query)
                else:
                    return self.es_query
            else:
                logger.debug("parse result -> %s" % "ERROR")
                raise ValueError("ERROR")
        else:
            logger.debug("parse result -> %s" % "EMPTY EXPRESSION ERROR")
            raise ValueError("EMPTY EXPRESSION ERROR")

# Parse input node - expression and returns ES Query
def parser(node_expression):
    logger.debug("IN NEW PARSER")
    par_obj = ParserNmsysSearch()
    par_obj.model_map = {
      'INSTANCE' : 'instance',
      'LOCALE'   : 'locale',
      'ALERT'    : 'alert',
      'STATUS'   : 'status',
      'DESCRIPTION' : 'description',
      'STATE' : 'state',
      'MTIME' : 'mtime',
      'i':'instance',
      'l':'locale',
      'instance':'instance',
      'locale':'locale',
      'n': 'node'
    }
    return par_obj.get_es_query(node_expression)


