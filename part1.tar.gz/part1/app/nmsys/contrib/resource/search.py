__author__ = 'rfoucher'

# python
from dateutil.parser import parse
import logging
import operator
import re
from elasticsearch_dsl import Search, Q
from contrib.epic import EpicSearch
from functools import reduce

import pytz
# django

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)

class SearchFilter:
    term_regex = '(?P<exlude>!)?(?P<tag>[\w]+):' \
                 '(?P<quantifier>(?:[>|<]=?)|\*)?(?P<group>~)?(?P<value>[\^\,\$\[\]\w\s\/\\*.\-@=\(\)|]+)'
    notag_regex = '(?P<exlude>!)?(?P<quantifier>(?:[>|<]=?)|\*)?(?P<group>~)?(?P<value>[\^\$\,\w\s\/\\*.\-@=\(\)|]+)'
    real_match_regex = "\^(.*)\$"
    quantifier_to_lookup = {
        '>=': 'gte',
        '>': 'gt',
        '<=': 'lte',
        '<': 'lt',
        '*': 'contains',
    }

    def __init__(self, query):
        self.query = query
        self._compile_re = re.compile(self.term_regex)
        self._compile_notag = re.compile(self.notag_regex)
        self._real_match = re.compile(self.real_match_regex)
        self._model_map = {}
        self.tz = pytz.timezone("US/Pacific")

    @property
    def model_map(self):
        return self._model_map

    @model_map.setter
    def model_map(self, value):
        if value and type(value) is dict:
            self._model_map = value

    def surcharge_tag(self, tag, query):
        if tag == 'mtime':
            return query
        full = self._real_match.search(query)
        if full:
            return full.group(1)
        return '.*%s.*' % query

    def _extract_query(self, exclude, group, model_field, tag, quantifier, query):
        logger.debug('[ SearchFilter ] Creating Q raw data with %s %s %s %s %s %s' % (exclude, group, model_field, tag, quantifier, query))
        if re.match("[\w_]+?time|date", tag):
            query = parse(query)  # This will be treated as a date
            if not query.tzinfo:
                query = query.replace(tzinfo=self.tz)
        else:  # Can be a basic string or int or bool
            try:
                int(query)
            except ValueError:  # Is a string not a number leave as it is
                pass
        if group:
            return self.special_parsing(query)
        query = self.surcharge_tag(tag, query)
        if tag == 'default':
            logging.debug('[ SearchFilter _extract_query] Name %s ' % self.model_map)
            model_field = self.model_map.get('default', 'node')

        if '.' in model_field:
            path, short_query = model_field.split('.', 1)
            # Add quantifier stuff here
            # if quantifier and self.quantifier_to_lookup.get(quantifier):
            #    q_object = Q("range", **{model_field: {self.quantifier_to_lookup.get(quantifier): query}})
            #        model_field = ('%s__%s' %
            #                       (model_field,
            #                        self.quantifier_to_lookup.get(quantifier)))
            if not exclude:
                q_object = Q("nested", path=path, query=Q("regexp", **{model_field: query}))
            else:

                q_object = ~Q("nested", path=path, query=Q("regexp", **{model_field: query}))
        else:
            if not exclude:
                q_object = Q("regexp", **{model_field: query})
            else:
                q_object = ~Q("regexp", **{model_field: query})

        logger.debug('[ SearchFilter ] Creating Q object with %s : %s' % (model_field, query))
        return q_object

    def special_parsing(self, query):
        logger.debug('special_parsing %s' % query)
        if query[0] != '~':
            query = '~%s' % query
        try:
            list_node = EpicSearch().find_list(query)
            if len(list_node) == 0:
                raise ValueError('Invalid node, please make sure %s exists in Epic' % query)
        except NameError:
            raise NameError('Too many entries to fetch for %s (limit is 200 000)' % query)
        except Exception as e:
            raise ValueError('There\' s a problem with your request %s : %s' % (query, e))
        query = []
        if len(list_node) > 1024:
            mini_query = []
            for buk in [list_node[i:i + 1000] for i in list(range(0, len(list_node), 1000))]:
                mini_query.append(Q(
                    'terms',
                    node=buk
                ))
            return Q(
                'bool',
                should=mini_query,
            )
        else:
            return Q(
                'terms',
                node=list_node
            )

    def _parse(self, query):
        q_object = None

        exclude = None
        tag = 'default'
        quantifier = '='
        group = None
        value = query

        if query:
            # Here we create the predicate
            if ":intersect" in query:
                logger.debug('intersect %s' % query)
                return self.special_parsing(query)

            search_match = self._compile_re.search(query)
            search_notag = self._compile_notag.search(query)
            if search_match:
                (exclude, tag, quantifier, group, value) = search_match.groups()
            elif search_notag:
                (exclude, quantifier, group, value) = search_notag.groups()

            model_field = None
            if self.model_map:
                if tag and tag in self.model_map:
                    model_field = self.model_map.get(tag)
                else:
                    raise ValueError('Incorrect tag specified in search query.' +
                                     ' Valid tags are: %s' % ', '.join(self.model_map.keys()))
            if not model_field:
                model_field = tag

            q_object = self._extract_query(exclude, group, model_field, tag, quantifier, value.strip())

        return q_object

    def _and(self, query):
        ands = re.split("AND| ", query)
        parsed_ands = []
        for s in ands:
            parsed_and = self._parse(s)
            if parsed_and:
                parsed_ands.append(parsed_and)
        return reduce(operator.and_, parsed_ands)

    def _or(self, query):
        logging.debug('[ SearchFilter ] Query %s ' % query)
        ors = query.split(' OR ')
        parsed_ors = []
        for o in ors:
            processed_and = self._and(o)
            if processed_and:
                parsed_ors.append(processed_and)
        return reduce(operator.or_, parsed_ors)

    def filter(self):
        logging.debug('[ SearchFilter ] Name %s ' % __name__)
        if self.query == "":  # When filter is empty, accept it and return everything
            logging.debug('[ SearchFilter ] Empty filter in search query ')
            return Q()

        return self._or(self.query)
