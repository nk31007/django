import logging

from django.contrib.auth.models import AnonymousUser
from django.utils import timezone

from epicauth.models import AppleDSSession
from tastypie.authentication import Authentication
from django.contrib.sessions.models import Session
from django.contrib.auth.models import User
from provider.oauth2.models import AccessToken
from contrib.resource.redisrouter import RedisRouter


# stolen from piston
class OAuthError(RuntimeError):
    """Generic exception class."""
    def __init__(self, message='OAuth error occured.'):
        self.message = message


class OAuth20Authentication(Authentication):
    """
    OAuth authenticator.

    This Authentication method checks for a provided HTTP_AUTHORIZATION
    and looks up to see if this is a valid OAuth Access Token
    """
    def __init__(self, realm='API'):
        self.realm = realm

    def is_authenticated(self, request, **kwargs):
        """
        Verify 2-legged oauth request. Parameters accepted as
        values in "Authorization" header, or as a GET request
        or in a POST body.
        """
        logging.info("OAuth20Authentication")

        try:
            key = request.GET.get('oauth_consumer_key')
            if not key:
                key = request.POST.get('oauth_consumer_key')
            if not key:
                auth_header_value = request.META.get('HTTP_AUTHORIZATION')
                if auth_header_value:
                    key = auth_header_value.split(' ')[1]
            if not key:
                logging.error('OAuth20Authentication. No consumer_key found.')
                return None

            # If verify_access_token() does not pass, it will raise an error

            token = verify_access_token(key)

            # If OAuth authentication is successful, set the request user to the token user for authorization
            request.user = token.user
            # If OAuth authentication is successful, set oauth_consumer_key on request in case we need it later
            request.META['oauth_consumer_key'] = key
            return True
        except KeyError:
            logging.exception("Error in OAuth20Authentication.")
            request.user = AnonymousUser()
            return False
        except Exception:
            logging.exception("Error in OAuth20Authentication.")
            return False


def verify_access_token(key):
    # Check if key is in AccessToken key
    try:
        token = AccessToken.objects.get(token=key)

        # Check if token has expired
        if token.expires < timezone.now():
            raise OAuthError('AccessToken has expired.')
    except AccessToken.DoesNotExist:
        raise OAuthError("AccessToken not found at all.")

    logging.info('Valid access')
    return token


def verify_nmsys_token(key):
    try:
        token = AppleDSSession.objects.get(access_token=key)
    except AppleDSSession.DoesNotExist:
        try:
            token = Session.objects.get(pk=key)
            uid = token.get_decoded().get('_auth_user_id')
            token.user = User.objects.get(pk=uid)
        except Session.DoesNotExist:
            raise OAuthError("AccessToken not found at all.")

    logging.info('Valid access')
    return token


def verify_jwt_tokent(key):
    pass


class NmSysSessionAuthentication(Authentication):
    """
    nmSys authenticator.

    """
    def __init__(self, realm='API'):
        self.realm = realm

    def is_authenticated(self, request, **kwargs):
        """
        Verify 2-legged oauth request. Parameters accepted as
        values in "Authorization" header, or as a GET request
        or in a POST body.
        """
        logging.info("NmSysAuthentication")

        try:
            key = request.GET.get('nmsys_key')
            if not key:
                key = request.POST.get('nmsys_key')
            if not key:
                auth_header_value = request.META.get('HTTP_AUTHORIZATION')
                if auth_header_value:
                    key = auth_header_value.split(' ')[1]
            if not key:
                logging.error('NmSysAuthentication. No nmsys_key found.')
            key = request.GET.get('session_key')
            if not key:
                key = request.POST.get('session_key')
            if not key:
                logging.error('NmSysAuthentication. No nmsys_key nor session Id found.')
                return None

            # If verify_access_token() does not pass, it will raise an error

            token = verify_nmsys_token(key)

            # If OAuth authentication is successful, set the request user to the token user for authorization
            request.user = token.user
            # If OAuth authentication is successful, set oauth_consumer_key on request in case we need it later
            request.META['nmsys_key'] = key
            return True
        except KeyError:
            logging.exception("Error in NmSysAuthentication.")
            request.user = AnonymousUser()
            return False
        except Exception:
            logging.exception("Error in NmSysAuthentication.")
            return False
