__author__ = 'rfoucher'
from django.shortcuts import render
from django.utils.timezone import is_naive
from tastypie.serializers import Serializer, _STR, _DICT, _LIST, _BUNDLE, _DATETIME, _DATE, _TIME, _SIMPLETYPES, _NUM
from django.utils.encoding import force_text
import pytz
import datetime
import six
import logging
import cgi
from io import StringIO
from urllib.parse import parse_qs
from django.core.serializers import json as djangojson
from tastypie.exceptions import BadRequest

logger = logging.getLogger("django")

import yaml
import csv
import ujson as json


def flatten(self, data, odict={}):
    if isinstance(data, list):
        for value in data:
            flatten(value, odict)
    elif isinstance(data, dict):
        for (key, value) in data.items():
            if not isinstance(value, (dict, list)):
                odict[key] = value
            else:
                flatten(value, odict)
    return odict


class TemplateSerializer(Serializer):
    formats = Serializer.formats + ['html', 'urlencode']

    content_types = {
        'json': 'application/json',
        'jsonp': 'text/javascript',
        'xml': 'application/xml',
        'yaml': 'text/yaml',
        'epic': 'text/plain',
        'csv': 'text/csv',
        'html': 'text/html',
        'plist': 'application/x-plist',
        'image': 'image/png',
        'urlencode': 'application/x-www-form-urlencoded',
    }

    def to_json(self, data, options=None):
        options = options or {}
        data = self.to_simple(data, options)
        return json.dumps(data, sort_keys=True)

    def from_json(self, content):
        try:
            return json.loads(content)
        except ValueError:
            raise BadRequest('Request is not valid JSON.')

    def from_urlencode(self, data, options=None):
        """ handles basic formencoded url posts """
        qs = dict((k, v if len(v) > 1 else v[0])
                  for k, v in parse_qs(data).items())
        return qs

    def to_urlencode(self, content):
        pass
    def export_data_epic(self, data):
        threshold = []
        list_status = ['', 'ok', 'unknown', 'info', 'warning', 'critical']
        for aggr, info in sorted(data['threshold'].items()):
            for nest in info['definition']:
                threshold.append('alert = %s; state = %s;   alert_dep = %s;  expr = %s;   description = ;' % (
                    data['name'],
                    list_status.index(info['status'].lower()),
                    aggr,
                    ' '.join(nest)))
        if data['definition']['mode'] == 'average':
            mode = 'avg'
        elif data['definition']['mode'] == 'sum':
            mode = ''
        else:
            mode = data['definition']['mode']
        if 'epicimg' in data['information'] and data['information']['epicimg'] != '':
            description = "%s <epicimg>%s</epicimg>" % (data['information']['description'], data['information']['epicimg'])
        else:
            description = data['information']['description']
        definition = 'alert_node = %s; ng = %s; n = %s; m = %s; description =%s' % (
            data['name'],
            '',
            data['definition']['node'],
            mode,
            description
        )
        return definition, threshold

    def to_epic(self, content, options=None):
        options = options or {}
        data = self.to_simple(content, options)
        definition = []
        application = []
        if "objects" in data:
            for o in data.get("objects"):
                appl, threshold = self.export_data_epic(o)
                definition += threshold
                application.append(appl)
        else:
            appl, threshold = self.export_data_epic(data)
            definition += threshold
            application.append(appl)
        return render_to_string('epic/definition.html', {'definitions': definition, 'applications': application})


    def to_html(self, data, options=None):
        options = options or {}
        data = self.to_simple(data, options)
        if 'objects' in data:
            template_name = 'api/api_list.html'
        else:
            template_name = 'api/api_detail.html'
        return render(None, 'index.html', {'objects': data}) 

    def from_html(self, content):
        form = cgi.FieldStorage(fp=StringIO(content))
        data = {}
        for key in form:
            data[key] = form[key].value
        return data

    def to_csv(self, data, options=None):
        options = options or {}
        data = self.to_simple(data, options)
        raw_data = StringIO()
        writer = False
        if "objects" in data:
            objects = data.get("objects")
            for value in objects:
                if not writer:
                    writer = csv.DictWriter(raw_data, value.keys(), quotechar="'", quoting=csv.QUOTE_ALL)
                    writer.writerow(dict(zip(writer.fieldnames, writer.fieldnames)))
                    writer.writerow(value)
                else:
                    writer.writerow(value)
        else:
            writer = csv.DictWriter(raw_data, data.keys(), quotechar="'", quoting=csv.QUOTE_ALL)
            writer.writerow(dict(zip(writer.fieldnames, writer.fieldnames)))
            writer.writerow(data)
        return raw_data.getvalue()

    def to_yaml(self, data, options=None):
        options = options or {}
        if isinstance(data, dict) and "objects" in data.keys():
            objects = data.get("objects")
            return yaml.safe_dump(self.to_simple(objects, options), indent=4, encoding='utf-8', allow_unicode=True, default_flow_style=False)
        else:
            return yaml.safe_dump(self.to_simple(data, options), indent=4, encoding='utf-8', allow_unicode=True, default_flow_style=False)

    def to_formatdate(self, data):
        try:
            d = datetime.datetime.utcfromtimestamp(data)
        except:
            d = datetime.datetime.utcfromtimestamp(data/1000.0)
        d = pytz.UTC.localize(d)
        return d.isoformat()

    def format_datetime(self, data):
        # If naive or rfc-2822, default behavior...
        if is_naive(data) or self.datetime_formatting == 'rfc-2822':
            return super(TemplateSerializer, self).format_datetime(data)

        return data.isoformat()

    def to_simple(self, data, options):
        """
        Rewriting the to_simple to support UNIX timestamp to isoformat
        """
        if data is None:
            return None

        data_type = type(data)

        stype = _STR

        for dt in data_type.__mro__:
            try:
                stype = _SIMPLETYPES[dt]
                break
            except KeyError:
                pass
        if stype == _NUM:
            return data
        if stype == _DICT:
            to_simple = self.to_simple
            return {key: to_simple(val, options)
			if not key.endswith('_at') and not key.endswith('_time') # and key != 'timestamp'
			else self.to_formatdate(val) for key, val in six.iteritems(data)}
        if stype == _STR:
            return force_text(data)
        if stype == _LIST:
            to_simple = self.to_simple
            return [to_simple(item, options) for item in data]
        if stype == _BUNDLE:
            to_simple = self.to_simple
            return {key: to_simple(val, options)
			        if not key.endswith('_at') and not key.endswith('_time') # and key != 'timestamp'
			        else self.to_formatdate(val) for key, val in six.iteritems(data.data)
            }
        if stype == _DATETIME:
            return self.format_datetime(data)
        if stype == _DATE:
            return self.format_date(data)
        if stype == _TIME:
            return self.format_time(data)
