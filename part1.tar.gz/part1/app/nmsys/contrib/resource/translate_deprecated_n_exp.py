__author__ = 'nikita'
import re


class Translator:
    def __init__(self):

        # matches **group patterns** with mandatory enum at the end eg: ~foo{enum}
        self.group_enum = re.compile('~(.*):enum$')

        # matches **node patterns** with mandatory enum at the end eg: foo{enum}
        self.node_enum = re.compile('(.*):enum$')

        # matches **group patterns** eg: ~foo
        self.group_pattern = re.compile('~(.*)$')

        # matches **group patterns** with exlusion '!' in front eg: !~foo
        self.group_exclude = re.compile('!~(.*)$')

        # matches **node patterns/instance/locale patterns** with exlusion '!' in front eg: !foo
        self.exclude = re.compile('!(.*)$')

    def get_v1_to_v3_sub_exp(self, sub_exp, is_intersect):

        # split expression on comma
        sub_exp_list = re.split(r',\s*(?![^{}]*\})', sub_exp)
        include_elements = []
        exclude_elements = []

        for sub_exp in sub_exp_list:
            if self.group_enum.match(sub_exp):
                if is_intersect:
                    include_elements.append("ALL(\"" + self.group_enum.match(sub_exp).group(1) + "\")")
                else:
                    include_elements.append("ANY(\"" + self.group_enum.match(sub_exp).group(1) + "\")")

            elif self.node_enum.match(sub_exp):
                include_elements.append("\"" + self.node_enum.match(sub_exp).group(1) + "\"")

            elif self.group_pattern.match(sub_exp):
                include_elements.append("ANY(\"" + self.group_pattern.match(sub_exp).group(1) + "\")")

            elif self.group_exclude.match(sub_exp):
                exclude_elements.append("ANY(\"" + self.group_exclude.match(sub_exp).group(1) + "\")")
 
            elif self.exclude.match(sub_exp):
                exclude_elements.append("\"" + self.exclude.match(sub_exp).group(1) + "\"")

            else:
                include_elements.append("\"" + sub_exp + "\"")
        return include_elements, exclude_elements

    # converts old exp - Version 1 into new Version 3 format
    # If intersect is to be done in old-expressions, keyword :intersect should be present at last of the expression.
    # In V1 expression, sub-expressions are separated by comma and have :intersect keyword at the end for intersection

    def translate_v1_to_v3(self, old_exp):

        # separating intersect and union elements in two lists
        # eg : a,b,c,d:intersect,e,f:intersect,g,h
        # intersect = ['a,b,c,d','e,f']
        # union = ['g,h']
        old_exp_list = [elem.strip(",") for elem in old_exp.split(':intersect')]
        intersect, union = old_exp_list[:-1], old_exp_list[-1:]
        intersect = filter(None, intersect)
        union = filter(None, union)

        if intersect:
            for index, elem in enumerate(intersect):

                include_elements, exclude_elements = self.get_v1_to_v3_sub_exp(elem, True)
                include_expression = '(' + ' INTERSECT '.join(include_elements) + ')'

                translated_expression = '(' + include_expression + ') MINUS (' + \
                    ' UNION '.join(exclude_elements) + ')' if exclude_elements else include_expression

                intersect[index] = translated_expression

        if union:
            for index, elem in enumerate(union):

                include_elements, exclude_elements = self.get_v1_to_v3_sub_exp(elem, False)
                include_expression = '(' + ' UNION '.join(include_elements) + ')'

                translated_expression = '(' + include_expression + ') MINUS (' + \
                    ' UNION '.join(exclude_elements) + ')' if exclude_elements else include_expression

                union[index] = translated_expression

        intersect_translated_exp = ''
        union_translated_exp = ''

        if intersect:
            intersect_translated_exp = '(' + ' UNION '.join(intersect) + ')'

        if union:
            union_translated_exp = '(' + ' UNION '.join(union) + ')'

        translated_expression = ''
        if intersect_translated_exp and union_translated_exp:
            translated_expression = intersect_translated_exp + ' UNION ' + union_translated_exp
        elif intersect_translated_exp:
            translated_expression = intersect_translated_exp
        elif union_translated_exp:
            translated_expression = union_translated_exp

        return translated_expression

    # converts old exp - Version 2 into new Version 3 format
    # In V2 expression, sub-expressions are separated by comma, space, AND, OR

    def translate_v2_to_v3(self, modelmap, old_exp):
        # split expression on comma|OR & on AND|" " such that:
        # Eg : r = "a b,c AND d f OR g,h"
        # [ a b,c AND d f ] [ g,h ]
        # 1 - [ a b,c ]   AND [  d f ]
        # 2 - [g,h]
        # 1 -> [ n:a AND n:(B OR C) AND n:d AND n:f]
        # sublists indicate that AND is to be performed on these items first and then OR is to be done on the items of the big list
        # So, finally forming an expression like : (a AND b) OR (c AND d AND f) OR (g) OR (h)
        
        modelmap_keys = modelmap.keys()
        modelmap_values = list(set(modelmap.values()))

        sub_exp_list = [[item for item in re.split(" |AND", sub_exp) if item]
                        for sub_exp in re.split("OR", old_exp)]
        for index, elem in enumerate(sub_exp_list):
            sub_exp_dict = {}
            for key,val in modelmap.items():
                if val not in sub_exp_dict:
                    sub_exp_dict[val] = {}
                    sub_exp_dict[val]['include'] = []
            sub_exp_dict['include'] = []
            sub_exp_dict['exclude'] = []

            for sub_elem in elem:
                if  any(sub_elem.startswith(key + ":") for key in modelmap_keys):
                    sub_elem_kv = sub_elem.split(":")
                    sub_elem_key = modelmap[sub_elem_kv[0]]
                    sub_elem_value = re.split(r',\s*(?![^{}]*\})', sub_elem_kv[1])

                    exclude_items = [val for val in sub_elem_value if self.exclude.match(val)]
                    include_items = [val for val in sub_elem_value if val not in exclude_items]

                    if include_items:
                        sub_exp_dict[sub_elem_key]['include'].append([sub_elem_key + "(\""+ item + "\")" for item in include_items])
                    if exclude_items:
                        sub_exp_dict['exclude'].extend(
                            [sub_elem_key + "(\""+ self.exclude.match(item).group(1)+"\")" for item in exclude_items])

                elif self.group_pattern.match(sub_elem):
                    sub_exp_dict['include'].append("ANY(\"" + self.group_pattern.match(sub_elem).group(1) + "\")")

                elif self.group_exclude.match(sub_elem):
                    sub_exp_dict['exclude'].extend("ANY(\"" + self.group_exclude.match(sub_elem).group(1) + "\")")

                elif "." in sub_elem.split(":")[0]:
                    key = sub_elem.split(":")[0]
                    value = sub_elem.split(":")[1]
                    if self.exclude.match(value):
                        sub_exp_dict['exclude'].extend(key + "(\"" + value + "\")")
                    else:
                        sub_exp_dict['include'].append(key + "(\"" + value + "\")")

            sub_exp_list[index] = sub_exp_dict

        # updating sub_dictionary items
        for elem in sub_exp_list:
            for val in modelmap_values:
                if elem[val]["include"]:
                    elem['include'].extend(elem[val]['include'])
                del elem[val]
            if not elem['include']:
                del elem['include']
            if not elem['exclude']:
                del elem['exclude']

        exclude_elements = []
        include_elements = []

        for index, elem in enumerate(sub_exp_list):
            if set(['include', 'exclude']).issubset(elem.keys()):
                for index, item in enumerate(elem['include']):
                    if isinstance(item, list):
                        elem['include'][index] = '(' + ' UNION '.join(item) + ')'

                intersect = ' INTERSECT '.join(elem['include'])
                minus = '(' + ' UNION '.join(elem['exclude']) + ')'
                exp = '(' + intersect + ' MINUS ' + minus + ')'
                include_elements.append(exp)

            elif set(['include']).issubset(elem.keys()):
                for index, item in enumerate(elem['include']):
                    if isinstance(item, list):
                        elem['include'][index] = '(' + ' UNION '.join(item) + ')'
                exp = '(' + ' INTERSECT '.join(elem['include']) + ')'
                include_elements.append(exp)
            else:
                exclude_elements.extend(elem['exclude'])

        exclude_expression = '(' + ' UNION '.join(exclude_elements) + ')' if exclude_elements else ""
        translated_expression = '(' + ' UNION '.join(include_elements) + ') MINUS (' + exclude_expression + \
            ')' if exclude_expression else '(' + ' UNION '.join(include_elements) + ')'
        return translated_expression
