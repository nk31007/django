# -*- coding: utf-8 -*-
"""
tastypie.Resource definitions for Elasticsearch

"""

import logging
from django.conf import settings
from django.conf.urls import url
from tastypie import http
from tastypie.bundle import Bundle
from tastypie.resources import Resource, DeclarativeMetaclass, convert_post_to_patch
from tastypie.exceptions import ImmediateHttpResponse, NotFound, Unauthorized
import socket
from tastypie.utils import trailing_slash, dict_strip_unicode_keys
from django.core.exceptions import MultipleObjectsReturned
import uuid
from elasticsearch.helpers import bulk, BulkIndexError
import elasticsearch
import time
import elasticsearch.exceptions
from elasticsearch.connection import Urllib3HttpConnection
from elasticsearch_dsl import Search, Q
from contrib.pager import pager
from contrib.resource.paginator import ElasticsearchResult, ElasticsearchPaginator

# Logging
logger = logging.getLogger('django')


class ESObject(object):
    def __init__(self, uuid=None, initial=None):
        self.__dict__['_data'] = {}
        self.__dict__['_data']['_id'] = uuid
        self.__dict__['_data'] = initial

    def __getattr__(self, name):
        return self._data.get(name, None)

    def __setattr__(self, name, value):
        self.__dict__['_data'][name] = value

    def to_dict(self):
        return self._data


class ElasticsearchDeclarativeMetaclass(DeclarativeMetaclass):
    """
    This class has the same functionality as its supper ``ModelDeclarativeMetaclass``.
    Changing only some Elasticsearch intrinsics
    """

    def __new__(self, name, bases, attrs):
        meta = attrs.get('Meta')

        new_class = super(ElasticsearchDeclarativeMetaclass,
            self).__new__(self, name, bases, attrs)

        override = {
            'object_class': dict,
            'include_mapping_fields': True,
            'paginator_class': ElasticsearchPaginator,
        }
        defaults = {
            'es_server': getattr(settings, "ES_SERVER", "127.0.0.1:9200"),
            'es_connection_class': Urllib3HttpConnection,
            'es_timeout': 40,
            'create_if_missing': False,
            'index_settings': {},
            'write_index': None,
        }
        for k, v in override.items():
            setattr(new_class._meta, k, v)

        for k, v in defaults.items():
            if not hasattr(new_class._meta, k):
                setattr(new_class._meta, k, v)

        return new_class

class ElasticsearchResource(Resource, metaclass=ElasticsearchDeclarativeMetaclass):
    """
    Elasticsearch Base Resource

    """


    def __init__(self, api_name=None):
        super(ElasticsearchResource, self).__init__(api_name)
        if self._meta.write_index is None:
            self._meta.write_index = self._meta.index

        if self._meta.create_if_missing:
            # create the index if missing and create_if_missing
            if not self.client.indices.exists(self._meta.write_index):
                self.client.indices.create(self._meta.write_index, body=self._meta.index_settings)

            # create the alias if missing and create_if_missing
            if (self._meta.write_index != self._meta.index and
                    not self.client.indices.exists_alias(self._meta.index,
                                                         self._meta.write_index)):
                self.client.indices.put_alias(self._meta.write_index, self._meta.index)
        self._meta.collection_name = 'objects'
    
    _es = None

    def es__get(self):
        if self._es is None:
            self._es = elasticsearch.Elasticsearch(
                **settings.ES_CONFIG, 
                connection_class=self._meta.es_connection_class
            )
        return self._es

    client = property(es__get)

    def prepend_urls(self):
        """Override Resource url map to fit search Id syntax"""
        resource_name = self._meta.resource_name
        tr = trailing_slash()
        return [
            # default implementation
            url(r"^(?P<resource_name>%s)%s$" % (resource_name, tr),
                self.wrap_view('dispatch_list'), name="api_dispatch_list"),
            url(r"^(?P<resource_name>%s)/schema%s$" % (resource_name, tr),
                self.wrap_view('get_schema'), name="build_schema"),
            url(r"^(?P<resource_name>%s)/set/(?P<%s_list>.*?)%s$" % (resource_name,
                self._meta.detail_uri_name, tr), self.wrap_view('get_multiple'),
                name="api_get_multiple"),
            url(r"^(?P<resource_name>%s)/(?P<%s>.*?)%s$" % (resource_name,
                self._meta.detail_uri_name, tr), self.wrap_view('dispatch_detail'),
                name="api_dispatch_detail"),
        ]

    def build_schema(self):
        schema = super(ElasticsearchResource, self).build_schema()

        if self._meta.include_mapping_fields:
            mapping = self.client.indices.get_mapping(self._meta.index, self._meta.doc_type)
            mapping_fields = mapping[self._meta.doc_type]["properties"]

            fields = schema["fields"]

            for key, v in mapping_fields.items():
                if key not in fields:
                    fields[key] = {
                        "blank": v.get("default", True),
                        "default": v.get("default", None),
                        "help_text": v.get("help_text", key),
                        "nullable": v.get("nullable", "unknown"),
                        "readonly": v.get("readonly", True),
                        "unique": v.get("unique", key in ["id"]),
                        "type": v.get("type", "unknown"),
                    }
            schema["fields"] = fields

        return schema

    def full_dehydrate(self, bundle, for_list=False):
        try:
            bundle.data = dict(bundle.obj.get("_source"))
        except:
            pass
        bundle = super(ElasticsearchResource, self).full_dehydrate(bundle, for_list)
        kwargs = dict(resource_name=self._meta.resource_name, pk=bundle.obj.get("_id", bundle.data.get('_id')))
        
        if self._meta.api_name is not None:
            kwargs['api_name'] = self._meta.api_name
        bundle.data["resource_uri"] = self._build_reverse_url('api_dispatch_detail', kwargs=kwargs)
        bundle.data = self.clean_es_object(bundle.data)
        #if "highlight" in bundle.obj:
        #    bundle.obj.get("_source").update(bundle.obj.get('highlight'))
        return bundle

    def full_hydrate(self, bundle):
        bundle = super(ElasticsearchResource, self).full_hydrate(bundle)
        bundle.obj.update(bundle.data)
        return bundle

    def get_resource_uri(self, bundle_or_obj=None, url_name='api_dispatch_list'):
        if bundle_or_obj is None:
            result = super(ElasticsearchResource, self).get_resource_uri(bundle_or_obj)
            return result

        obj = (bundle_or_obj.obj if
               isinstance(bundle_or_obj, Bundle) else bundle_or_obj)

        kwargs = {
            'resource_name': self._meta.resource_name,
            'pk': obj.get('_id'),
        }
        if self._meta.api_name is not None:
            kwargs['api_name'] = self._meta.api_name

        return self._build_reverse_url("api_dispatch_detail", kwargs=kwargs)

    def get_sorting(self, request, key="sort_by"):
        order_by = request.GET.get(key, self._meta.default_sorting)
        if order_by:
            l = {}
            items = [i.strip() for i in order_by.split(",")]
            for item in items:
                order = "asc"
                if item.startswith("-"):
                    item = item[1:]
                    order = "desc"
                l[item] = {"order": order}
                if '.' in item:
                    l[item].update({"nested_path": "%s" % item.split('.')[0]})
            return l
        return None

    def ensure_format(self, request):
        format_q = request.GET.get('format', None)
        if format_q == 'csv' and self._meta.private_fields is not None:
            return self._meta.private_fields
        else:
            return None

    def clean_es_object(self, content):
        for kk in list(content):
            if kk.startswith('_'):
                content.pop(kk)
            if kk in ['forced_refresh', 'result']:
                content.pop(kk)
        return content

    def ensure_exclude(self):
        return self._meta.excludes

    def parse_query(self, filters):
        query = []
        for key, value in filters.items():
            if value == "":
                continue
            if key not in ["offset", "aggr", "limit", "query_type", "format", "sort_by", "session_key", "oauth_consumer_key"]:
                value = value.split(',')
                t_query = []
                if '__' in key:
                    key, quantifier = key.split('__', 1)
                    if quantifier in ['gte', 'gt', 'lte', 'lt']:
                        t_query = [Q(
                            'bool',
                            should=[
                                Q("exists", field=key),
                                Q('range', **{key: {quantifier: int(value[0])}}),
                            ],
                            minimum_should_match=2
                        )]
                    else:
                        for i in value:
                            t_query.append(Q("match", **{key+'.'+quantifier: i}))
                else:
                    for i in value:
                        if '.' in key:
                            t_query.append(Q("nested", path=key.split('.')[0], query=Q("match", **{key: i})))
                        else:
                            t_query.append(Q("match", **{key: i}))

                query.append(Q('bool', should=t_query, minimum_should_match=1))

        return Q('bool', must=query)

    def build_query(self, filters=None):
        if filters is None:
            return None
        query = self.parse_query(filters)
        return query

    def lookup(self, **kwargs):
        query = self.build_query(kwargs)
        search = Search().query(query)
        result = search.using(self.client).index(self._meta.index).doc_type(self._meta.doc_type).execute()
        return ElasticsearchResult(result.to_dict())

    def obj_get_list(self, bundle, **kwargs):
        filters = {}
        if hasattr(bundle.request, 'GET'):
            filters = bundle.request.GET.copy()
        filters.update(kwargs)

        sort = self.get_sorting(bundle.request)
        format_fields = self.ensure_format(bundle.request)
        excludes = self.ensure_exclude()
        lmin = int(bundle.request.GET.get("offset", 0))
        lmax = int(bundle.request.GET.get("limit", self._meta.limit)) + lmin
        aggr = int(bundle.request.GET.get("aggr", 1))

        if lmin > settings.MAX_ES_PAGINATION:
            response = http.HttpBadRequest("You are reaching the maximum allowed pagination arguments please reduce the set of your filter", content_type="text/plain")
            raise ImmediateHttpResponse(response)
        if lmax > settings.MAX_ES_LIMIT:
            response = http.HttpBadRequest("You are reaching the maximum allowed pagination arguments please reduce the set of your filter", content_type="text/plain")
            raise ImmediateHttpResponse(response)
        
        query = self.build_query(filters)
        if query:
            search = Search().query(query).sort(sort)
        else:
            search = Search().sort(sort)
        
        if format_fields:
            search = search.extra(_source={'includes': format_fields})
        if excludes:
            search = search.extra(_source={'excludes': excludes})
        
        if hasattr(self._meta, 'bucket') and self._meta.bucket and aggr == 1:
            search.aggs.bucket('bucket', 'terms', field=self._meta.bucket, size=settings.ES_AGGREGATION_SIZE)
        
        search = search[lmin:lmax]
        result = search.using(self.client).index(self._meta.index).doc_type(self._meta.doc_type).execute()
        return ElasticsearchResult(result.to_dict())

    def obj_get(self, bundle, **kwargs):
        pk = kwargs.get("pk")
        format_fields = self.ensure_format(bundle.request)
        if format_fields:
            return self.client.get(index=self._meta.index, id=pk, doc_type=self._meta.doc_type, _source=format_fields)
        else:
            return self.client.get(index=self._meta.index, id=pk, doc_type=self._meta.doc_type)

    def obj_create(self, bundle, **kwargs):
        obj = self.full_hydrate(bundle).obj
        params = dict(kwargs)
        pk = params.get('pk', obj.get('pk', obj.get('id')))
        if not pk:
            pk = uuid.uuid4()
        now = int(time.time())
        content = {
            'timestamp': now,
            'created_at': now
        }
        content.update(obj)
        try:
            result = self.client.index(index=self._meta.index, doc_type=self._meta.doc_type, body=content, id=pk, refresh=True)
        except Exception as e:
            logger.critical(
                "[Resource::obj_create] Index Error %s %s %s %s" % (
                    e, self._meta.index, self._meta.doc_type, content
                )
            )
            raise e
        result.update(content)
        bundle.data = result
        return bundle 

    def obj_update(self, bundle, **kwargs):
        obj = self.full_hydrate(bundle)
        params = dict(kwargs)
        pk = params.get('pk')
        now = int(time.time())
        content = {
            'timestamp': now,
            'updated_at': now
        }
        content.update(obj.obj)
        try:
            result = self.client.index(index=self._meta.index, doc_type=self._meta.doc_type, body=content, id=pk, refresh=True)
        except Exception as e:
            logger.critical("[Resource::obj_update] Index Error %s %s" % (e, content))
            raise e
        result.update(content)
        bundle.data = result
        return bundle 

    def obj_delete(self, bundle, **kwargs):
        pk = kwargs.get('pk')
        data = {
            '_id': pk,
            '_index': self._meta.index,
            '_type': self._meta.doc_type,
            '_op_type': 'delete',
        }
        try:
            bulk(self.client, [data], raise_on_error=True, raise_on_exception=True)
            self.client.indices.flush(self._meta.index)
        except BulkIndexError as e:
            logger.critical("[Resource::obj_delete]Index Error %s" % e)
            raise NotFound("The object %s does not exist." % pk)
        except Exception as exc:
            msg = "%s(%s)" % (exc.__class__.__name__, exc)
            logger.critical("[Resource::obj_delete]Index Error %s" % msg)
            response = http.HttpApplicationError(msg, content_type="text/plain")
            raise ImmediateHttpResponse(response)
        return http.HttpNoContent("The object %s is deleted." % pk)

    def patch_list(self, request, **kwargs):
        request = convert_post_to_patch(request)
        deserialized = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))

        torun = []
        for key, content in deserialized.items():
            for data in content:
                try:
                    url_str = data.pop('resource_uri')
                    pk = url_str.split('/')[-2:-1][0]
                except:
                    continue
                if key == 'deleted_objects':
                    result = {
                        '_id': pk,
                        '_index': self._meta.index,
                        '_type': self._meta.doc_type,
                        '_op_type': 'delete'
                    }
                else:
                    data.update({'timestamp': int(time.time()), 'created_at': int(time.time())})
                    result = {
                        '_id': pk,
                        '_index': self._meta.index,
                        '_type': self._meta.doc_type,
                        'doc': data,
                        '_op_type': 'update',
                        'doc_as_upsert': True
                    }
                torun.append(result)

        if len(torun):
            try:
                bulk(self.client, torun, raise_on_error=True, raise_on_exception=True)
                self.client.indices.flush(self._meta.index)
            except Exception as exc:
                msg = "%s(%s)" % (exc.__class__.__name__, exc)
                response = http.HttpApplicationError(msg, content_type="text/plain")
                raise ImmediateHttpResponse(response)
            else:
                return http.HttpNoContent("The Patch was applied properly")
        else:
            return http.HttpBadRequest()

    def rollback(self, bundles):
        pass

    def put_detail(self, request, **kwargs):
        """
        Overwriting this since my bundles don't do prefetching which break updates
        """
        deserialized = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        deserialized = self.alter_deserialized_detail_data(request, deserialized)
        bundle = self.build_bundle(data=dict_strip_unicode_keys(deserialized), request=request)

        try:
            updated_bundle = self.obj_update(bundle=bundle, **self.remove_api_resource_names(kwargs))

            if not self._meta.always_return_data:
                return http.HttpNoContent()
            else:
                # Invalidate prefetched_objects_cache for bundled object
                # because we might have changed a prefetched field
                # HERE Remove this shit : updated_bundle.obj._prefetched_objects_cache = {}
                updated_bundle = self.full_dehydrate(updated_bundle)
                updated_bundle = self.alter_detail_data_to_serialize(request, updated_bundle)
                return self.create_response(request, updated_bundle)
        except (NotFound, MultipleObjectsReturned):
            updated_bundle = self.obj_create(bundle=bundle, **self.remove_api_resource_names(kwargs))
            location = self.get_resource_uri(updated_bundle)

            if not self._meta.always_return_data:
                return http.HttpCreated(location=location)
            else:
                updated_bundle = self.full_dehydrate(updated_bundle)
                updated_bundle = self.alter_detail_data_to_serialize(request, updated_bundle)
                return self.create_response(request, updated_bundle, response_class=http.HttpCreated, location=location)

    def _handle_500(self, request, exception):
        import traceback
        import sys
        the_trace = '\n'.join(traceback.format_exception(*(sys.exc_info())))


        if isinstance(exception, elasticsearch.exceptions.ConnectionError):
            data = {
                'error_message': 'Error while connecting to the Elasticsearch Instance '
                                 '(Connection Error), Epic admin Team has been notified.',
                'error_code': '1'
            }
            try:
                pager('Unable to connect to the ES instance %s on %s' % (
                    self._es, socket.gethostname()
                ), "%s : %s" % (self._es, str(exception)))
            except:
                pass
            logger.critical('[error500 - resource] %s %s' % (exception, the_trace))
            return self.error_response(
                request,
                data,
                response_class=http.HttpApplicationError
            )
        elif isinstance(exception, elasticsearch.exceptions.NotFoundError):
            data = {
                'error_message': 'Not Found.',
                'error_code': '2'
            }
            return self.error_response(
                request,
                data,
                response_class=http.HttpNotFound
            )
        elif isinstance(exception, elasticsearch.exceptions.RequestError):
            data = {
                'error_message': 'Problem in your filter, please validate the syntax.',
                'error_code': '3'
            }
            logger.warning('Elasticsearch : user filter is incorrect %s' % data['error_message'])
            return self.error_response(
                request,
                data,
                response_class=http.HttpBadRequest
            )
        elif isinstance(exception, ValueError):
            data = {
                'error_message': 'Problem in your filter, %s.' % str(exception),
                'error_code': '4'
            }

            return self.error_response(
                request,
                data,
                response_class=http.HttpUnprocessableEntity
            )
        elif isinstance(exception, NameError):
            data = {
                'error_message': 'Problem in your filter, %s.' % str(exception),
                'error_code': '5'
            }

            return self.error_response(
                request,
                data,
                response_class=http.HttpBadRequest
            )
        elif isinstance(exception, Unauthorized):
            data = {
                'error_message': 'Unauthorized access, %s.' % str(exception),
                'error_code': '4'
            }
            logger.warning('Unauthorized : user access %s' % data['error_message'])
            return self.error_response(
                request,
                data,
                response_class=http.HttpBadRequest
            )
        else:
            return super(ElasticsearchResource, self)._handle_500(request, exception)
