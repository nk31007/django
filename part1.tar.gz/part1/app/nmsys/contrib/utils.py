from functools import wraps
from json import dumps
from time import time, sleep
import socket
import http.client as http
import sys
import os
import re
import time
import inspect
import logging
import datetime
import requests
import base64

logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)

def retry(ExceptionToCheck, tries=4, delay=3, backoff=2, logger=None):
    """Retry calling the decorated function using an exponential backoff.
    http://www.saltycrane.com/blog/2009/11/trying-out-retry-decorator-python/
    original from: http://wiki.python.org/moin/PythonDecoratorLibrary#Retry
    :param ExceptionToCheck: the exception to check. may be a tuple of
        exceptions to check
    :type ExceptionToCheck: Exception or tuple
    :param tries: number of times to try (not retry) before giving up
    :type tries: int
    :param delay: initial delay between retries in seconds
    :type delay: int
    :param backoff: backoff multiplier e.g. value of 2 will double the delay
        each retry
    :type backoff: int
    :param logger: logger to use. If None, print
    :type logger: logging.Logger instance
    """
    def deco_retry(f):

        @wraps(f)
        def f_retry(*args, **kwargs):
            mtries, mdelay = tries, delay
            while mtries > 1:
                try:
                    return f(*args, **kwargs)
                except ExceptionToCheck as e:
                    msg = "%s, Retrying in %d seconds..." % (str(e), mdelay)
                    if logger:
                        logger.warning(msg)
                    else:
                        print(msg)
                    sleep(mdelay)
                    mtries -= 1
                    mdelay *= backoff
            return f(*args, **kwargs)

        return f_retry  # true decorator

    return deco_retry

level = {
    'ok': 1,
    'unknown': 2,
    'info': 3,
    'warning': 4,
    'critical': 5,
    'maintenance': 12,
    'admin': 10,
}

def send_alert(host=socket.gethostname(), desc="This is just testing",
               state="info", alert="nmsys-admin@nmsys_internal"):
    host = "" + str(host)
    desc = "" + str(desc)
    alert = "" + str(alert)
    state = "" + str(state)

    if state not in level:
        logger.critical("Attempted to send alert with invalid level %s" % state)
        return 1

    if host[:2] == 'vp':
        api = 'vp21-nmsysapi.isg.apple.com'
    elif host[:2] == 'lo':
        api = 'localhost:6623'
    else:
        api = 'nmsysapi.isg.apple.com'

    uri_alert = '/alerting/api_alert/epic/admin/sys/'

    now = int(time.time())

    try:
        obj = {
            'alert': {
                'list': []
            }
        }
        tmp_dict = {
            'alert': alert,
            'description': desc,
            'node': host,
            'state': level[state],
            'u_ctime': now,
        }
        obj['alert']['list'].append(tmp_dict)
        dmp = dumps(obj)
    except Exception as ex:
        logger.critical("Unable to create JSON object: %s" % str(ex))
        return 1

    try:
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json; charset=UTF-8'}
        connection = http.HTTPConnection(api)
        connection.request(method="POST", url=uri_alert, body=dmp, headers=headers)
        response = connection.getresponse()
        data = response.read()
        connection.close()
    except Exception as ex:
        logger.critical("Unable to open HTTP connection to nmSys host %s: %s" % (api, str(ex)))
        return 1
    logger.debug("Sent nmSys alert http://%s%s\ndata %s\nResponse %s" % (api, uri_alert, str(dmp), str(data)))
    logger.debug("Server Response: %s" % str(response.status))
    return 0



def load_class_from_name(module_path):
    paths = module_path.split('.')
    modulename = '.'.join(paths[:-1])
    classname = paths[-1]

    __import__(modulename, globals(), locals(), ['*'])

    Pmod = getattr(sys.modules[modulename], classname)
    if not inspect.isclass(Pmod):
        raise TypeError("%s is not a class" % module_path)
    return Pmod


def get_secret(secret_name, result='empty'):
    try:
        with open('/run/secrets/{0}'.format(secret_name), 'r') as secret_file:
            return secret_file.read()
    except IOError:
        return os.environ.get(secret_name, result)

def get_version():
    try:
        with open('/version', 'r') as version_file:
            return version_file.read()
    except Exception:
        return os.environ.get("VERSION", "0.0.0")

def chunks(l, n):
    """Yield successive n-sized chunks from l."""
    for i in list(range(0, len(l), n)):
        yield l[i:i + n]


def time_to_datetime(c_input, reference=int(time.time())):
    """ Convert 2days, 2d to time in seconds"""
    match = re.match(r'^[e-]?(\d+)(h|d|w|mo|m|y|s)', str(c_input))
    if match is not None:
        val, denom = match.groups()
        multiplier = {
            'y': datetime.timedelta(days=365*int(val)),
            'mo': datetime.timedelta(days=30*int(val)),
            'w': datetime.timedelta(days=7*int(val)),
            'd': datetime.timedelta(days=int(val)),
            'h': datetime.timedelta(hours=int(val)),
            'm': datetime.timedelta(minutes=int(val)),
            's': datetime.timedelta(seconds=int(val)),
        }
        return int(reference - (multiplier[denom]).total_seconds())
    try:
        date_date = datetime.datetime.strptime(c_input, "%Y-%m-%d %H:%M:%S.%f").strftime("%s")
        return int(date_date)
    except Exception as e:
        pass
    try:
        return int(reference - int(c_input))
    except:
        return int(reference)


def epic_generator(locale_filter=None, instance_filter=None):
    content = requests.get(
        'https://epic.isg.apple.com/api/search/rest/v2/node/'
        '?format=json&search_q=GLOBAL&limit=300&deprecated=1'
    )
    endpoints = []
    for i in content.json()['objects']:
        if not locale_filter or i['locale'] in locale_filter:
            if not instance_filter or i['instance'] in instance_filter:
                if '_qa' in i['locale']:
                    i['locale'] = i['locale'].replace('_', '-')
                endpoints.append({
                    'instance': i['instance'],
                    'locale': i['locale'],
                    'url': 'https://%s-epic.isg.apple.com/%s' % (i['locale'], i['instance'])
                })
    return endpoints


def encode_to_base64(bytes_or_string_to_encode):
    """A python-major-version-agnostic function to encode a string to base64.
    Works with both python2 and python3.
    :param bytes_or_string_to_encode: A bytes (python3) or string (python2)
        literal to encode
    """

    python_major_version = sys.version_info[0]

    if python_major_version >= 3 and isinstance(bytes_or_string_to_encode,
                                                str):
        input_bytes = bytes_or_string_to_encode.encode('utf-8')
    else:
        input_bytes = bytes_or_string_to_encode

    output_bytes = base64.b64encode(input_bytes)

    if python_major_version >= 3:
        output = output_bytes.decode('utf-8')
    else:
        output = output_bytes

    return output

