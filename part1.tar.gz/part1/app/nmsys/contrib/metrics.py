#!/usr/bin/env python

"""
APIs to create / update time-series metrics. This can be used by application to report custom metrics or monitor method invocations.
"""

import logging
import time
from enum import Enum

from prometheus_client import Gauge, Counter, Summary, Histogram
from prometheus_client.context_managers import Timer


# Logging
logger = logging.getLogger("django")

default_timer = time.perf_counter


def create_metric(metric_type, application, description, tag_names):
    metric_name = format_name(application)
    if metric_type.lower() == 'counter':
        metric = Counter(metric_name, description, tag_names)
    elif metric_type.lower() == 'summary':
        metric = Summary(metric_name, description, tag_names)
    elif metric_type.lower() == 'histogram':
        metric = Histogram(metric_name, description, tag_names)
    else:
        metric = Gauge(metric_name, description, tag_names)

    return metric


def apply_value(metric, metric_type, val):
    v = float(val)
    if metric_type == 'gauge':
        metric.set(v)
    elif metric_type == 'counter':
        metric.inc(v)


def format_name(name):
    if '/' in name:
        name = name.replace('/', '_')
    if ' ' in name:
        name = name.replace(' ', '_')
    return name


class MetricType(Enum):
    Summary = 1
    Histogram = 2


class InvocationMonitor:
    """
    Invocation Monitor supports monitoring the method calls.
    It collects two metrics for each method call decorated with this functionality
    a. count  - Number of times the method is invoked
    b. sum - total time taken by the method cumulative of all invocation
    """

    def __init__(self, name, description, tags,  metric_type=Summary, optional_args={}):
        if metric_type == MetricType.Histogram:
            if 'buckets' in optional_args:
                self.metrics = Histogram(name, description, labelnames=tags, buckets=optional_args['buckets'])
            else:
                self.metrics = Histogram(name, description, labelnames=tags)
        else:
            self.metrics = Summary(name, description, tags)

    def monitor_invocation(self, tag_values):
        s = self.metrics.labels(tag_values)
        return Timer(s.observe)


class InvocationMonitorWithArgParser:
    """
    InvocationMonitorWithArgParser supports using arguments passed to the monitored method as labels for metrics.
    It collects two metrics for each method call decorated with this functionality
    a. count  - Number of times the method is invoked
    b. sum - total time taken by the method cumulative of all invocation

    """

    def __init__(self, name, description, tags, func, metric_type=Summary, optional_args={}):
        self.tag_func = func
        if metric_type == MetricType.Histogram:
            if 'buckets' in optional_args:
                self.metrics = Histogram(name, description, labelnames=tags, buckets=optional_args['buckets'])
            else:
                self.metrics = Histogram(name, description, labelnames=tags)
        else:
            self.metrics = Summary(name, description, tags)

    def monitor_invocation(self, func):

        def apply_tags(*args, **kwargs):
            tag_values = self.tag_func(*args, **kwargs)
            s = self.metrics.labels(*tag_values)
            with CustomTimer(s.observe):
                return func(*args, **kwargs)

        return apply_tags


class CustomTimer(object):
    """
    CustomTimer is a decorator for measuring time taken for method invocation
    """
    def __init__(self, func):
        self._callback = func

    def __enter__(self):
        self._start = default_timer()

    def __exit__(self, typ, value, traceback):
        duration = max(default_timer() - self._start, 0)
        self._callback(duration)