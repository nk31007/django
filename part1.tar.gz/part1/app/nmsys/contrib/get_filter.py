__author__ = 'rfoucher'

# Restarting the search feature from scratch since I can't even remember what I was doing


# python
import logging
import ujson as json
import hashlib
from django.core.cache import cache

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)

"""
{
    "ack": 0,
    "dep": 1,
    "search_q": "a:.*ping.* OR n:.*ping.*",
    "type": " Alert",
    "status": "CRITICAL",
}
"""


def extract_parameters(request, page=None):
    search = dict()
    # Not a GET go away
    if request.method != 'GET':
        return {}

    real_filter = dict(request.GET)
    # No filter keep going
    if real_filter == {}:
        return {}

    logger.debug("Get parameter Filter - start ensuring everything is there %s" % real_filter)

    if 'search_md5' in real_filter:
        search_cache = cache.get(real_filter['search_md5'])
        if search_cache:
            return json.dumps(search_cache)
        else:
            return {}

    if 'status' in real_filter:
        search['status'] = real_filter['status'][0].lower().split(',')
        real_filter.pop('status')
    if 'acknowledged' in real_filter:
        search['acknowledged'] = real_filter['acknowledged'][0]
        real_filter.pop('acknowledged')
    if 'query' in real_filter:
        search['query'] = real_filter['query'][0]
        real_filter.pop('query')
    if 'toggle' in real_filter:
        search['toggle'] = real_filter['toggle'][0]
        real_filter.pop('toggle')
    if 'url' in real_filter:
        search['url'] = real_filter['url'][0]
        real_filter.pop('url')
    if 'silencing' in real_filter:
        search['silencing'] = real_filter['silencing'][0]
        real_filter.pop('silencing')
    logger.debug("Get parameter Filter - here is the result %s" % search)
    return json.dumps(search)

def cache_search(object):
    if object:
        opw = hashlib.new(object).hexdigest()
        cache.set(opw, object)
        return opw
    else:
        return False
