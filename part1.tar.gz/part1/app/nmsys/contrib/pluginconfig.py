import os
import shutil
import logging
import time
import yaml
from git import Repo, Actor
from django.conf import settings
from backend.models import Plugin
from elasticsearch_dsl import Q, Search
import uuid


logger = logging.getLogger("django")

class PluginConfig(object):

    def __init__(self):
        self.repo_url = settings.PLUGIN_REPO % (os.environ.get('GIT_ID', ''), os.environ.get('GIT_TOKEN', ''))

        self.path = settings.Plugin_BACKUP
        if not os.path.exists(self.path):
            self.clone_repo()
        self.repo = Repo(self.path)

    def backup(self, alert_id, username, email, create=False):
        filename = Plugin.get(id=alert_id).backup()
        self.repo.index.add([filename])
        committer = Actor(username, email)
        self.repo.index.commit("Plugin modifier on %s" % int(time.time()), author=committer, committer=committer)

        self.repo.remote('origin').push()

    def delete(self, alert_id, username, email):
        filename = Plugin.get(id=alert_id).backup()
        self.repo.index.remove([filename])
        committer = Actor(username, email)
        self.repo.index.commit("Plugin modifier on %s" % int(time.time()), author=committer, committer=committer)

        self.repo.remote('origin').push()

    def backup_all(self):
        for i in Plugin.search().extra(from_=0, size=10000):
            i.backup()
        self.repo.index.add('*')
        self.repo.index.commit("Automatic backup %s" % int(time.time()))
        self.repo.remote('origin').push()

    def load(self):
        for subdir, dirs, files in os.walk(self.path):
            for config in files:
                if not config.endswith('.yaml'):
                    continue
                with open(os.path.join(subdir, config), 'r') as stream:
                    try:
                        definition = yaml.load(stream)
                        result = Plugin.search().query(
                            Q('match', name=definition['name'])
                        ).execute()
                        if result.hits.total == 1:
                            s = result[0]
                            if 'pk' not in definition:
                                definition['pk'] = s._id
                            s.update(**definition)
                        else:
                            s = Plugin(**definition)
                            if 'pk' in definition:
                                s._id = definition['pk']
                            else:
                                s._id = s.pk = str(uuid.uuid4())
                        s.save()
                    except yaml.YAMLError as exc:
                        print(exc)
        self.backup_all()

    def update_local(self):
        if not os.path.exists(self.path):
            self.clone_repo()
        for i in Plugin.search():
            i.load()

    def update_remote(self):
        if os.path.exists(self.path):
            self.clone_repo()
        self.backup_all()

    def cleanup_local(self):
        if os.path.exists(self.path):
            shutil.rmtree(self.path)
        os.mkdir(self.path)

    def git_check_head(self):
        self.repo.remote('origin').fetch()
        commits_behind = self.repo.iter_commits('master..origin/master')
        return sum(1 for c in commits_behind)

    def remote_update(self):
        if self.git_check_head():
            self.repo.remote('origin').pull()
            self.load()

    def clone_repo(self):
        self.cleanup_local()
        Repo.clone_from(self.repo_url, self.path, depth=1)
