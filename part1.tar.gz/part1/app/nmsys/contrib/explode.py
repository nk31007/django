__author__ = 'rfoucher'

import re
import logging
import urllib.parse as urlparse
import urllib
import ujson as json
from django.conf import settings
from copy import deepcopy
from backend.models import Alert
import requests
from backend.models import connections
from elasticsearch_dsl import Search, Q
from urllib.parse import urlencode, unquote

logger = logging.getLogger("django")


def explode_epic(content):
    params, url, instance = epic_url_parser(content['data'])
    epic_expanded = epic_call(url, instance, params)
    epic_expanded['instance'] = sorted(epic_expanded['instance'], reverse=True)
    epic_expanded['instance'].append(instance)
    epic_expanded['instance'].reverse()
    return epic_expanded


def build_filter(t_filter=True):
    search = Alert.search().query(Q("regexp", alert="default@.*|nmsys@.*|common@.*"))
    summary = {}
    if t_filter:
        search.aggs.bucket('alert', 'terms', field='alert', size=settings.ES_AGGREGATION_SIZE)
    else:
        summary['mode'] = ['expand', 'average', 'sum']
    search.aggs.bucket('instance', 'terms', field='instance', size=settings.ES_AGGREGATION_SIZE)
    search.aggs.bucket('locale', 'terms', field='locale', size=settings.ES_AGGREGATION_SIZE)
    result = search.execute()

    for key, value in result.to_dict()['aggregations'].items():
        summary[key] = [val['key'] for val in value['buckets']]
        summary[key] = sorted(summary[key])
    return summary


def epic_call(url, instance, params):
    req = {
        'graph': 0,
        'a': 'json',
        'no_intervals': 1,
        'v': 2,
        'expand': 0
    }
    pp = re.compile(r'((:no_graph|:legend_only|:_expn)(=.)?)+|((:color|:n)=([0-9a-zA-Z\-\._]+)?)')
    nn = re.compile(r'(?P<node>[^/]+)/(?P<datasource>[^/]+)')

    req.update(params)

    content = deepcopy(params)
    content.update(build_filter(False))

    result = requests.get('%s/%s?%s' % (url, instance, urlencode(req)), verify=False)
    logger.debug('[ epic_call ] ::Epic URL %s' % '%s/%s?%s' % (url, instance, urlencode(req)))

    try:
        result = result.json()
        content['datasource'] = [pp.sub('',  i) for i in result['meta']['ds']['name']]
        logger.debug('[ FQDS ] :: %s' % content)
        if 'n' in content:
            logger.debug('[ N IN  CONTENT] :: %s' % content)
            content['node'] = content['n']
        elif 'ng' in content:
            logger.debug('[ NG IN CONTENT ] :: %s' % content)
            content['node'] = '~%s' % content['ng']
        else:
            
            if 'n' in result['meta'] and result['meta']['n']:
                logger.debug('[ N IN result] :: %s' % result['meta']['n'])
                content['node'] = result['meta']['n']
            else:
                logger.debug('[ N NOT IN result] :: %s' % result['meta']['n'])
                node = []
                datasource = []
                # FQDS worst nightmare
                logger.debug('[ FQDS ] ::')
                for i in content['datasource']:
                    try:
                        n, ds = nn.findall(i)[0]
                        node.append(n)
                        datasource.append(ds)
                    except Exception as e:
                        logger.critical('[ epic_call ] :: FQDS fail %s' % e)
                if len(node) > 0:
                    content['node'] = node
                else:
                    content['node'] = ''
                if len(datasource) > 0:
                    content['datasource'] = datasource

        content.pop('ds', None)
        req.update({'a': 'graph', 'w': '200', 'h': '90', 'no_legend': '1', 'expand': '0'})
        content['url'] = '%s/%s?%s&ignore=1' % (url, instance, urlencode(req))
        return epic_cleanup(content, False)
    except Exception as e:
        logger.critical('[ epic_call ] ::epic_call fail %s' % e)
        return content

def build_url(scheme, locale):
    if '_qa' in locale:
        locale, d = locale.split('_')
        return '%s://%s-epic.%s.isg.apple.com' % (scheme, locale, d) 
    else:
        return '%s://%s-epic.isg.apple.com' % (scheme, locale)

def epic_url_parser(url):
    logger.debug('[ epic_url_parser ] ::Epic URL %s' % url)
    url_query = unquote(url)
    # Giant-ass hack to work around ty51 epic instances in APZ being
    # incorrectly marked (by epic) as ty51-epic.services.silu.net
    url_query = url_query.replace('ty51-epic.services.silu.net',
                                  'ty51-epic.isg.apzones.com')
    parsed_query = urlparse.urlparse(url_query)
    params = dict(urlparse.parse_qsl(parsed_query.query))

    if parsed_query.netloc == 'epic.isg.apple.com':
        if parsed_query.path.startswith('/i/'):
            instance, locale = parsed_query.path.split('/')[2].split('@')
            params = epic_cleanup(params)
            return params, build_url(parsed_query.scheme, locale), instance
        elif parsed_query.path.startswith('/api/'):
            instance, locale = parsed_query.path.split('/')[3].split('@')
            params = epic_cleanup(params)
            return params, build_url(parsed_query.scheme, locale), instance
        else:
            locale, instance = parsed_query.path.split('/')[2:4]
            url_export = '%s://%s-epic.isg.apple.com' % (parsed_query.scheme, locale)
            params = epic_cleanup(params)
            return params, build_url(parsed_query.scheme, locale), instance
    elif parsed_query.netloc == 'epic.isg.apzones.com':
        if parsed_query.path.startswith('/i/'):
            instance, locale = parsed_query.path.split('/')[2].split('@')
            url_export = '%s://%s-epic.isg.apzones.com' % (parsed_query.scheme, locale)
            params = epic_cleanup(params)
            return params, url_export, instance
        elif parsed_query.path.startswith('/api/'):
            instance, locale = parsed_query.path.split('/')[3].split('@')
            url_export = '%s://%s-epic.isg.apzones.com' % (parsed_query.scheme, locale)
            params = epic_cleanup(params)
            return params, url_export, instance
        else:
            locale, instance = parsed_query.path.split('/')[2:4]
            url_export = '%s://%s-epic.isg.apple.com' % (parsed_query.scheme, locale)
            params = epic_cleanup(params)
            return params, url_export, instance
    else:
        try:
            instance = parsed_query.path.split('/')[1].split('-', 1)[1]
        except:
            instance = parsed_query.path.split('/')[1]
        url_export = '%s://%s' % (parsed_query.scheme, parsed_query.netloc)
        if "_qa" in parsed_query.netloc:
            locale = parsed_query.netloc.split('-')[0].split('_')[0]
            url_export = '%s://%s-epic.qa.isg.apple.com' % (parsed_query.scheme, locale)
        params = epic_cleanup(params)
        return params, url_export, instance


def epic_cleanup(dic, all_i=True):
    exP = ['instance', 'org', 'datasource', 'node', 'group', 'mode', 'url']
    if all_i:
        exP += ['ds', 'n', 'gr', 'md5', 'ng']
    params = dict((k, v) for (k, v) in dic.items() if k in exP)
    return params


def explode_nmsys(definition):
    logger.debug('[ explode_nmsys ] ::Nmsys Object %s' % definition)
    definition.update(build_filter())
    if 'node' not in definition:
        definition['node'] = '~specifyyourgroup'
    return definition


def explode_nmsys_plugin(data):
    logger.debug('[ explode_nmsysclient ] ::Nmsys Client Object %s' % data)
    import configparser
    config = configparser.RawConfigParser()
    config.readfp(open(settings.DOC_ROOT+'/Plugin_parameters.md'))
    try:
        params = dict(config.items(data['plugin']['class']))
    except:
        params = {
            'run': '60',
            'params': ''
        }
    for key, value in params.items():
        if ',' in value:
            params[key] = value.split(',')
    return params
