__author__ = 'rfoucher'

from contrib.resource.redisrouter import RedisRouter
from contrib.history import History
from backend.models import Node
from redis._compat import unicode
import ujson as json
import time
from dateutil.parser import parse as date_parse
import calendar
from django.conf import settings
import socket

# Logging
import logging
from contrib.metrics import create_metric
from contrib import metrics

logger = logging.getLogger("django")
ch = logging.StreamHandler()
logger.addHandler(ch)


def single_bulk(application, locale, instance, upload_type, content):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    queue = 'bulk::JSON_FULL::%s::%s::%s::content' % (application, locale, instance)
    r_stream_stream.set(queue, content)
    r_stream_stream.sadd('JSON_FULL_LIST', queue)
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    r_base.incr('bulk::FULL::%s::%s::%s::stats' % (application, locale, instance), 1)


def delay_bulk(application, locale, instance, upload_type, content):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    queue = 'bulk::JSON_DELAY::%s::%s::%s::content' % (application, locale, instance)
    r_stream_stream.set(queue, content)
    r_stream_stream.sadd('JSON_DELAY_LIST', queue)
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    r_base.incr('bulk::DELAY::%s::%s::%s::stats' % (application, locale, instance), 1)


def chunk_bulk(application, locale, instance, upload_type, events):
    r_stream_stream = RedisRouter().retrieve_redis_connection('common', 'default')
    queue = 'bulk::INCRE::%s::%s::%s::content' % (application, locale, instance)
    size = r_stream_stream.scard(queue)
    c = [str(e) for e in events]
    if len(c) == 0:
        return queue
    try:
        r_stream_stream.sadd(queue, *c)
        r_stream_stream.sadd('JSON_INCR_LIST', queue)
    except Exception as e:
        logger.critical('[default_bulk] Unable to queue %s, [%s]' % (c, e))
        raise e
    r_base = RedisRouter().retrieve_redis_connection('stats', 'default')
    r_base.incrby('bulk::INCRE::%s::%s::%s::stats' % (application, locale, instance), size)
    return queue



def status_bulk(node_name, data):
    res = {}
    arr_status = [1, 4, 5, 2]  # Nagios to Epic state conversion
    j_obj = json.loads(data)
    now = int(time.time())

    for check in j_obj:
        try:
            if check['run'] is False and check['error'] is False:
                continue
            if 'node' not in check:
                check['node'] = node_name
            if 'alert' not in check and 'servicename' not in check:
                continue
            if 'servicename' in check:
                check['alert'] = check['servicename']
            if 'ctime' in check:
                timestamp = calendar.timegm(date_parse(check['ctime']).timetuple())
            else:
                timestamp = now
            if 'locale' not in check:
                check['locale'] = 'locale'
            if 'organization' in check:
                check['instance'] = '%s%s' % (check['organization'], check['instance'])
            queue = 'queue::%s::%s' % (check['locale'], check['instance'])

            if queue not in res:
                res[queue] = []

            res[queue].append({
                "alert": "nmsys@%s" % check['alert'],
                "description": check['description'],
                "node": check['node'],
                "ng": "",
                "state": arr_status[int(check['state'])],
                "u_ctime": timestamp
            })
        except Exception as e:
            logger.critical('Bulk insert issue on alert insertion, server %s' % socket.gethostname(),
                  'reason %s, content %s' % (e, check))

    for queue, events in res.items():
        ig, locale, instance = queue.split('::')
        chunk_bulk('nmsys', locale, instance, 'bulk', events)


def node_stream(node_name, content):
    r_stream_stream = RedisRouter().retrieve_redis_connection('nmsysclient', 'bulk')
    queue = 'queue::node'
    size = r_stream_stream.scard(queue)
    if int(size) > settings.QUEUE_MAX_SIZE:
        pass
    r_stream_stream.sadd(queue, str(content))

