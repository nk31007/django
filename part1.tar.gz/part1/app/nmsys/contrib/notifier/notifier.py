# Parent class for notificafion
# Takes care of formating the text for the variour notification routes
# Logging the content, and few other little things


import threading
from django.conf import settings
import os
import re
import sys
import time
import uuid
import traceback
import socket
import requests
import urllib.parse as urlparse
from urllib.request import urlopen, urlretrieve
from copy import deepcopy
from backend.models import Notification
from contrib.resource.redisrouter import RedisRouter
from contrib.history import History
from contrib.kin import Kin
from dictor import dictor
from prometheus_client import Histogram, Counter
from contrib import metrics

import recertifi


import ujson as json

def fetch_label(x):
    return [x.content['route']]

class Notifier(object):
    notification_latency_histo = metrics.InvocationMonitorWithArgParser('notification_latency_seconds',
                                                                        'Histogram of notification latency', ['route'],
                                                                        fetch_label,
                                                                        metric_type=metrics.MetricType.Histogram).monitor_invocation
    notification_error_count = Counter('notification_errors', 'Count of error while processing notifications', ['route'])

    def __init__(self, subscription, alert, data, stats, logger):
        """
            :param subscription: Subscription
            :type subscription: Alert
            :param alert: Alert definition
            :type alert: Alert
            :param data: Array of alerts to send
            :type data: dict
            :param logger: Main logger
            :type logger
        """
        self.subscription = subscription
        self.alert = alert
        self.data = data
        self.mainLogger = logger
        self.current_pid = os.getpid()
        self.hostname = socket.gethostname()
        self.lock = threading.Lock()
        self.digested = False
        self.expire = 0
        self.force_digest = False
        self.content = {
            'subscriber': subscription['subscriber'],
            'route': subscription['notification_type'],
            'id': alert['pk'],
            'application': alert['application'],
            'name': '%s@%s' % (alert['information']['username'], alert['information']['name']),
            'stats': stats,
            'u_ctime': int(time.time()) * 1000,
            'content': [],
            'notification': []
        }
        if alert['application'] == 'filter' and 'description' in alert['information']:
            self.content['description'] = alert['information']['description']

        self.r_base = RedisRouter().retrieve_redis_connection('id_cache', 'default')
        if not self.r_base:
            raise
        self.r_stats = RedisRouter().retrieve_redis_connection('stats', 'default')
        self.escalation = {}
        
        for al in self.data['hits']['hits']:
            doc = al['_source']
            doc['uri'] = '/nmsys/api/rest/v2/alert/%s/' % al['_id']
            self.content['content'].append(doc)
        self.caching_key = "%s_%s_%s" % (self.content['id'], self.content['subscriber'], self.content['route'])
        self.max_digest = int(self.subscription['notif-maxdigest']) if 'notif-maxdigest' in self.subscription else 200
        if self.max_digest > 200:
            self.max_digest = 200
        if 'notif-ifdigest' in self.subscription and self.subscription['notif-ifdigest'] == 'on':
            self.digested = True
        elif len(self.content['content']) > self.max_digest:
            self.force_digest = True
        if 'correlation'  in self.subscription and self.subscription['correlation'] == 'on':
            self.detect_correlated()
        if 'resend-create-new-incident' in self.subscription and self.subscription['resend-create-new-incident'] == 'on':
            self.expire = int(self.subscription['resend-after']) * 60

        self.alert_special = re.compile(r'^([a-zA-Z\]+)@([a-zA-Z_0-9]+)_([a-zA-Z\.\-0-9]+)_([a-zA-Z\-0-9_]+)$')
        self.error_count = self.notification_error_count.labels(self.content['route'])

    @notification_latency_histo
    def publish(self):
        try:
            self.lock.acquire()
            try:
                self._publish()
            except Exception as ex:
                self.error_count.inc()
                tra = ''.join(traceback.format_stack())
                self.mainLogger.critical(str(ex))
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                self.mainLogger.critical(
                    'Notifier issue during publish reason %s, %s, %s, %s, %s, content %s' % (
                        tra, str(ex), exc_type, fname, exc_tb.tb_lineno, self.content)
                )
            self._callback()
            try:
                self._log_notification()
            except Exception as ex:
                self.error_count.inc()
                self.mainLogger.critical('reason %s, content %s' % (ex, self.content['notification']))
        finally:
            if self.lock.locked():
                self.lock.release()

    def _callback(self):
        if 'callback-my-url' in self.subscription and 'callback-myself' in self.subscription and self.subscription['callback-myself'] == 'on':
            try:
                self.content['stats'] = self.content['stats'].to_dict()
            except:
                self.content.pop('stats', None)
            try:
                requests.post(self.subscription['callback-my-url'], json=self.content, timeout=10)
            except Exception as ex:
                self.mainLogger.critical(
                    "Callback ISSUE %s : Unable to open HTTP connection to nmSys host %s: %s" % (
                        self.subscription,
                        self.subscription['callback-my-url'],
                        str(ex)
                    )
                )

    def get_id(self, olduuid, newuuid):
        result = self.r_base.get('%s_%s' % (self.caching_key, newuuid))
        if not result:
            # Starting the process of deprecation of the old IDs
            # <rdar://problem/65667242> Duplicate Alerts - Digested alerts state is not tracked.
            if self.r_base.exists('%s_%s' % (self.caching_key, olduuid)):
                result = self.r_base.get('%s_%s' % (self.caching_key, olduuid))
                self.r_base.set('%s_%s' % (self.caching_key, newuuid), result)
                self.r_base.expire('%s_%s' % (self.caching_key, olduuid), 60)
        # Depending on the Redis version, might return bytes force str
        try:
           return result.decode('utf8')
        except:
            return result

    # Eventually need to find a cleaner way to do that (redis won't allow a 0 value)
    def set_id(self, uuid, ticket, force=True):
        if force:
            # rdar://64760386 (NmSYS to create new CST after defined mins if the alerts still exists)
            if self.expire > 0:
                self.r_base.set('%s_%s' % (self.caching_key, uuid), ticket, self.expire)
            else:
                self.r_base.set('%s_%s' % (self.caching_key, uuid), ticket)
        # check if we already have a key and set the TTL accordingly
        elif self.r_base.ttl('%s_%s' % (self.caching_key, uuid)) < 0:
            if self.expire > 0:
                self.r_base.set('%s_%s' % (self.caching_key, uuid), ticket, self.expire)
            else:
                self.r_base.set('%s_%s' % (self.caching_key, uuid), ticket)

    def purge_id(self, olduuid, uuid):
        self.r_base.delete('%s_%s' % (self.caching_key, olduuid))
        self.r_base.delete('%s_%s' % (self.caching_key, uuid))

    @staticmethod
    def _graph_epic(full_url):
        """
        :param full_url: Epic URL
        :return: formatted url
        """
        try:
            url = urlparse(full_url)
            return 'https://epic.isg.apple.com/i/%s@%s/element?a=graph&%s' % (
                url[2].split('/')[1], url.netloc.split('-')[0], url.query.replace('a=g', '').replace('%20', ' ')
            )
        except:
            return full_url

    def _epicimg_format(self, description):
        """
        Common method to cleanup the description from PNG definition
        Return properly formatted description as well as list of PNGs to be downloaded from Epic
        :param description: Alert description
        :type description: string
        :return: formatted description. list of PGNs
        """
        regex = re.compile(r'<epicimg>(.*?)</epicimg>', re.DOTALL)
        replace_re = re.compile(r'(<epicimg>.*?)</epicimg>', re.DOTALL)
        clean_html = re.compile(r'</epicimg>')
        list_pics = []
        for png in regex.findall(description):
            tmp_name = "pic_%s.png" % uuid.uuid4()
            pic_name = ' <cid="%s" link="%s"> ' % (tmp_name, self._graph_epic(png))
            list_pics.append({'url': png, 'name': tmp_name})
            description = replace_re.sub('', description)
            description = clean_html.sub('', description)
            description += pic_name
        return description, list_pics

    def detect_correlated(self):
        p = [{'node': alert['node'], 'alert': alert['alert'], 'locale': alert['locale'], 'instance': alert['instance']}
             for alert in self.content['content']]
        content = Kin().find_causal(p)
        self.mainLogger.critical('Detect correlated %s' % content)

    def _epic_img_store(self, list_image):
        """
            Common method to retrieve raw PNGs, store them to disk if mime is False
            otherwise build mime objects list.
            Returns either list of path to disk, or raw mime objects to be attached.
        """
        image = []
        if list_image and len(list_image) > 0:
            for pic in list_image:
                try:
                    urlretrieve(pic['url'], '/var/tmp/%s' % pic['name'])
                except Exception as e:
                    self.mainLogger.critical('unable to get Epic PNG URL %s : %s' % (pic['url'], e))

    def gnsalert(self, alert):
        if alert.startswith('gns') and '@gns' in alert:
            cc = self.alert_special.findall(alert)
            if len(cc) > 0:
                alert_root = ' '.join(cc[0][0].split('_')[3:])
                node = cc[0][1]
                interface = cc[0][2].replace('_', '/')
                return "%s : %s %s" % (alert_root.capitalize(), node, interface)
        return alert

    def build_subject(self, status, content, digested):
        # rdar://problem/64544862
        if 'title' in self.subscription:
            title = self.subscription['title']
            if not digested:
                title = title.replace('{alert}', content[0]['alert'])
                title = title.replace('{node}', content[0]['node'])
                title = title.replace('{filter}', self.content['name'])
                title = title.replace('{state}', content[0]['status'])
                title = title.replace('{alertgns}', self.gnsalert(content[0]['alert']))
            else:
                title = self.subscription['title']
                title = title.replace('{alert}', '')
                title = title.replace('{node}', '')
                title = title.replace('{alertgns}', '')
                title = title.replace('{filter}', self.content['name'])
                title = title.replace('{state}', status)
            return title

        # Automated title generation :
        # Force Digested : minimum service the Name and the count of spam
        if self.force_digest:
            return '%s: %s - forcing digestion for %s alerts' % (status, len(content), self.content['name'])
        # Digested:
        if digested:
            return "%s : %s" % (content[0]['status'], self.content['name'])
        
        # Non digested :
        if self.content['name'] == content[0]['alert']:
            return "%s : %s %s" % (content[0]['status'], content[0]['alert'], content[0]['node'])
        
        # Default behavior
        title = "%s %s: %s %s" % (content[0]['status'], self.content['name'], content[0]['alert'], content[0]['node'])
        if len(title) > 240:
            return "%s : %s %s" % (content[0]['status'], content[0]['alert'], content[0]['node'])
        return title
    
    # Take a status, checks if we have mutliple escalation paths 
    # a custom severity or a basic Priorities like in the old day
    # Returns esclation group impact and urgency for esclation based on alert status and subscription
    def find_severity(self, status):
        # Defaults
        priority = ''
        impact = '3 - Low'
        urgency = '3 - Low'
        contact = 'nmsys-users'

        # The split [0] is just a hack - we cant escalate to multiple groups in CST
        if 'input-contact-%s' % status in self.subscription and \
            self.subscription['input-contact-%s' % status] != '':
            contact = self.subscription['input-contact-%s' % status]
        elif 'email-contact' in self.subscription and \
            self.subscription['email-contact'] != '':
            contact = self.subscription['email-contact']
        else:
            self.mainLogger.critical("[Cst improperly configured contact defaults to nmsys-users]")
 
        if 'priority-%s' % status in self.subscription and \
            self.subscription['priority-%s' % status] != '':
            priority = self.subscription['priority-%s' % status]
        elif 'priority' in self.subscription and \
            self.subscription['priority'] != '':
            priority = self.subscription['priority']
        else:
            self.mainLogger.info("[Cst improperly configured priority defaults to empty or uses the new version]")


        if priority == '':
            try:
                if 'impact-%s' % status in self.subscription and \
                    self.subscription['impact-%s' % status] != '':
                    impact = self.subscription['impact-%s' % status]
                elif 'impact' in self.subscription and \
                    self.subscription['impact'] != '':
                    impact = self.subscription['impact']
                else:
                    self.mainLogger.info("[impact : Cst improperly configured impact defaults Low]")
            except:
                self.mainLogger.critical("[impact : Cst improperly configured skipping impact setting defaulting to low]")
            try:
                if 'urgency-%s' % status in self.subscription and \
                    self.subscription['urgency-%s' % status] != '':
                    urgency = self.subscription['urgency-%s' % status]
                elif 'urgency' in self.subscription and \
                    self.subscription['urgency'] != '':
                    urgency = self.subscription['urgency']
                else:
                    self.mainLogger.info("[urgency : Cst improperly configured impact defaults Low+]")
            except:
                self.mainLogger.critical("[urgency : Cst improperly configured skipping urgency setting defaulting to low]")
        elif priority.lower() == 'p1c':
            impact = self.escalation['map'][0]['Impact']
            urgency = self.escalation['map'][0]['Urgency']
        else:
            try:
                impact = self.escalation['map'][int(priority.replace("P", ""))]['Impact']
                urgency = self.escalation['map'][int(priority.replace("P", ""))]['Urgency']
            except Exception as e:
                self.mainLogger.critical("[Cst improperly configured skipping impact/urgencency setting defaulting to low] %s" % e)

        return contact.split(',')[0], impact, urgency

    def regroup(self, keys, content):
        raw = {}
        s_keys = [k.strip() for k in keys.split(',')]
        for alert in content:
            main_k = []
            for k in s_keys:
                keyfound =  dictor(alert, k)
                if keyfound:
                    main_k.append(keyfound)
            main_k = ' '.join(main_k)
            raw.setdefault(main_k, {"alert": [], "picture": []})
            if 'description' in alert:
                alert['description'], list_pics = self._epicimg_format(alert['description'])
                alert['description'] = alert['description'].replace('\\n', '<br />').replace('\t', '&nbsp;')
            else:
                alert['description'] = ''
                list_pics = []
            raw[main_k]['alert'].append(alert)
            raw[main_k]['picture'] += list_pics

        return raw 

    def _epic_img_unlink(self, list_image):
        if list_image and len(list_image) > 0:
            for pic in list_image:
                try:
                    os.unlink('/var/tmp/%s' % pic['name'])
                except Exception as e:
                    self.mainLogger.critical('unable to get Epic PNG URL %s : %s' % (pic['url'], e))

    def _add_epic_tags(self, nodename, description):
        r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'export')
        content = r_base.get(nodename)
        if content:
            content = json.loads(content)
            description += '<p>Tag = %s</p>' % content
        return description

    def api_stats(self, r_key):
        try:
            self.r_stats.incr('notifier::%s' % r_key, 1)
        except Exception as e:
            self.mainLogger.critical('[notifier::api_stats] Unable to incr counter of use for %s, reason %s' % (r_key, e))

    def _log_notification(self):
        """
            Common method to store the notification in ES
        :return:
        """
        try:
            history = []
            for notification in self.content['notification']:
                try:
                    cc = deepcopy(self.content)
                    if 'content' in notification:
                        cc['content'] = notification['content']
                    cc['notification'] = notification
                    cc['timestamp'] = cc['u_ctime'] = int(time.time()) * 1000
                    cc['hostname'] = self.hostname
                    cc['pid'] = self.current_pid
                    Notification(**cc).save()
                    try:
                        try:
                            cc['stats'] = cc['stats'].to_dict()
                        except:
                            pass
                        history.append(json.dumps(cc))
                    except Exception as e:
                        self.mainLogger.critical('Unable to encode %s' % cc)
                        self.mainLogger.critical('error %s' % e)
                except Exception as e:
                    self.mainLogger.critical('Log notification content error: %s' % e)
                if settings.HISTORICAL:
                    History().stream_other('notification', history)
        except Exception as e:
            self.mainLogger.critical('[Notifier::Log notification} : %s' % e)

    def _publish(self):
        """
            Override this
        """
        raise NotImplementedError
