__author__ = 'nmsys'

from contrib.notifier.notifier import Notifier


class Debug(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Debug, self).__init__(subscription, alert, data, stats, logger)
        self.digested = True \
            if 'notif-ifdigest' in self.subscription and self.subscription['notif-ifdigest'] == 'on' \
            else False
        self.msg = None

    def _format(self):
        for alert in self.data:
            print(alert)
        return []

    def _publish(self):
        print("Notifier debug")
        print(self.subscription)
        print(self.alert)
        print(self.data)
        print(self.content)
