__author__ = 'rfoucher'

import logging
import re
from contrib.notifier.handler.aipo.auth import AipoAuthenticationService
from contrib.notifier.handler.aipo.aipo import Aipo as AipoG
from contrib.notifier.notifier import Notifier
from django.template.loader import render_to_string
from django.conf import settings

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class Aipo(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Aipo, self).__init__(subscription, alert, data, stats, logger)
        self.mapper = {
            '': {
                'map': [
                    {"Impact": "1 - High", "Urgency": "1 - High"},
                    {"Impact": "2 - Medium", "Urgency": "1 - High"},
                    {"Impact": "2 - Medium", "Urgency": "2 - Medium"},
                    {"Impact": "3 - Low", "Urgency": "3 - Low"}
                ]
            }
        }
        self.configuration_item_mapper = settings.AIPO_CONFIG_ITEMS

        ibj = AipoAuthenticationService(
            settings.AIPO_ENDPOINT,
            settings.AIPO_CLIENTID,
            settings.AIPO_CLIENTSECRET,
            settings.AIPO_USER,
            settings.AIPO_PAS
        )
        token = ibj.token()
        self.auth_status, self.token = ibj.token()
        if self.auth_status:
            self.api_stats('aipo::auth::success')
            self.aipo = AipoG(
                settings.AIPO_ENDPOINT,
                settings.AIPO_APPID,
                token
            )
        else:
            self.api_stats('aipo::auth::failure')
    
        self.attachment = False

        if 'aipo_configuration_item' not in self.subscription or self.subscription['aipo_configuration_item'].replace('_', ' ').lower() not in self.configuration_item_mapper:
            self.subscription['aipo_configuration_item'] = 'default'

    def build_payload(self, status, impact, urgency, name, content):
        description = render_to_string(
            'mail/aipo_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )
        if len(description) > 4000:
            self.attachment = description
        description = description.replace('\n', '\\n').replace('\t', '\\t').replace('<br />', '\\n').replace('</BR>', '\\n')
        description = description[:3997] + (description[3997:] and '..')
        
        return {
            'title': name,
            'description': description,
            'environment': 'Production',
            'Impact': impact,
            'Urgency': urgency,
            'configurationItem': self.configuration_item_mapper.get(
                getattr(self.subscription, 'aipo_configuration_item', 'default').replace('_', ' ').lower(),
                ''
            )
        }

    def create_ticket(self, uu_pk, create_payload, contact, list_pics):
        try:
            aipo_ticket = self.aipo.create(create_payload)
            self.mainLogger.debug('[ aipo ] result %s' % aipo_ticket)
            if 'status' not in aipo_ticket or aipo_ticket['status'] != 'OK':
                self.api_stats('aipo::create::systemfailure')
                return "-1", {'status': 'failure', 'details': 'System Error : %s' % aipo_ticket}
            elif aipo_ticket['number'] == '-1':
                self.api_stats('cst::create::failure')
                aipo_ticket.update({'status': 'failure', 'details': aipo_ticket['errorMessage']})
                return "-1", aipo_ticket
            else:
                self.api_stats('aipo::create::success')
                self.set_id(uu_pk, aipo_ticket['number'])

            if len(list_pics) > 0:
                for pic in list_pics:
                    try:
                        self.aipo.attach(aipo_ticket['number'], '/var/tmp/%s' % pic['name'])
                    except Exception:
                        pass
            try:
                if len(self.attachment):
                    self.aipo.attach(aipo_ticket['number'], self.attachment)
            except Exception:
                pass

            ticket = self.aipo.status(aipo_ticket['number'])

            result = {
                'status': 'OK',
                'details': 'aipo ticket <a href=\'%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.AIPO_ENDPOINT, aipo_ticket['number'], aipo_ticket['number']),
                'result': ticket,
                'ticket': aipo_ticket['number'],
                'recipient': contact
            }
            return result
        except Exception as e:
            self.mainLogger.critical('[ aipo ] Problem %s' % e)
            return {'status': 'failure', 'details': 'System Error : %s' % str(e)}

 
    def _publish(self):
        if not self.auth_status:
            self.content['notification'].append({'status': 'failure', 'details': 'Authentication Error : %s' % self.token})
            return

        if self.digested or self.force_digest:
            raw = {}
            for alert in self.content['content']:
                raw.setdefault(alert['status'], {"alert": [], "picture": []})
                alert['description'], list_pics = self._epicimg_format(alert['description'])
                raw[alert['status']]['alert'].append(alert)
                if not self.force_digest:
                    raw[alert['status']]['picture'] += list_pics

            for key, value in raw.items():
                olduuid = '%s: %s' % (key.upper(), self.content['name'])
                if self.force_digest:
                    olduuid = 'Forcing digestion for %s alerts: %s' % (len(self.content['content']), olduuid)

                uuid = '%s: %s' % (key.upper(), self.content['name'])
                content = {}
                ticket = None
                ticket_id = self.get_id(olduuid, uuid)

                if not ticket_id or ticket_id == '-1':
                    content = {
                        'debug': "No ticket found, creating a new one"
                    }
                    if 'picture' in value:
                        self._epic_img_store(value['picture'])
                    else:
                        value['picture'] = None

                    contact, impact, urgency = self.find_severity(key.lower())

                    subject = self.build_subject(key.upper(), value['alert'], digested=True)
                    payload = self.build_payload(key, impact, urgency, subject, value['alert'])
                    ticket, data = self.create_ticket(uuid, payload, contact, value['picture'])
                    content.update(data)
                elif self.aipo.isclosed(ticket_id):
                    content = {
                        'debug': "An older ticket was found but was closed <a href=\'%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a> , creating a new one" % (settings.AIPO_ENDPOINT, ticket_id, ticket_id)
                    }
                    self.purge_id(olduuid, uuid)
                    if 'picture' in value:
                        self._epic_img_store(value['picture'])
                    else:
                        value['picture'] = None

                    contact, impact, urgency = self.find_severity(key.lower())

                    subject = self.build_subject(key.upper(), value['alert'], digested=True)
                    payload = self.build_payload(key, impact, urgency, subject, value['alert'])
                    ticket, data = self.create_ticket(uuid, payload, contact, value['picture'])
                    content.update(data)
                else:
                    ticket = self.aipo.status(ticket_id)
                    self.api_stats('aipo::status::success')
                    # Transition to the NewID
                    self.set_id(uuid, ticket_id, False)
                    content = {
                        'status': 'OK',
                        'result': ticket,
                        'details': 'Found a ticket openned for this issue, not creating a new one <a href=\'%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.AIPO_ENDPOINT, ticket_id, ticket_id),
                        'ticket': ticket_id,
                    }
                    if self.attachment and len(self.attachment):
                        try:
                            self.aipo.attach(ticket_id, str(self.attachment), 'alerts_list.txt')
                            self.api_stats('aipo::attach::success')
                        except Exception as e:
                            self.api_stats('aipo::attach::failure')
                            self.mainLogger.critical('[ GRANDPRIX::aipo ] attache dump list alert error  %s' % e)
                # rdar://problem/60856653
                try:
                    content.update(self.validate_ticket(ticket))
                except Exception as e:
                    self.mainLogger.critical("Validate problem %s %s" % (ticket, e))
                # Log
                self.content['notification'].append(content)
                # Cleanup             
                self._epic_img_unlink(value['picture'])
        else:
            for alert in self.content['content']:
                try:
                    # Cache Key
                    olduuid = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
                    if len(olduuid) > 240:
                        olduuid = "%s : %s %s" % (alert['status'], self.content['name'], alert['node'])

                    uuid = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
                    content = {}
                    ticket = None

                    list_pics = []
                    # Check if we have a ticket already
                    ticket_id = self.get_id(olduuid, uuid)
                    if not ticket_id or ticket_id == '-1':
                        content = {
                            'content': alert,
                            'debug': "No ticket found, creating a new one"
                        }
                        # Picture Stuff first
                        alert['description'], list_pics = self._epicimg_format(alert['description'])
                        self._epic_img_store(list_pics)
                        contact, impact, urgency = self.find_severity(alert['status'].lower())

                        subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                        payload = self.build_payload(alert['status'], impact, urgency, subject, [alert])

                        ticket, data = self.create_ticket(uuid, payload, contact, list_pics)
                        content.update(data)
                        # Cleanup             
                        self._epic_img_unlink(list_pics)
                    elif self.aipo.isclosed(ticket_id):
                        content = {
                            'content': alert,
                            'debug': "An older ticket was found but was closed "
                                     "<a href=\'%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a> , "
                                     "creating a new one" % (settings.AIPO_ENDPOINT, ticket_id, ticket_id)
                        }
                        self.purge_id(olduuid, uuid)
                        alert['description'], list_pics = self._epicimg_format(alert['description'])
                        self._epic_img_store(list_pics)
                        contact, impact, urgency = self.find_severity(alert['status'].lower())

                        subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                        payload = self.build_payload(alert['status'], impact, urgency, subject, [alert])

                        ticket, data = self.create_ticket(uuid, payload, contact, list_pics)
                        content.update(data)
                        # Cleanup             
                        self._epic_img_unlink(list_pics)
                    else:
                        ticket = self.aipo.status(ticket_id)
                        self.api_stats('aipo::status::success')
                        # Transition to the NewID
                        self.set_id(uuid, ticket_id, False)
                        content = {
                            'status': 'OK',
                            'content': alert,
                            'details': 'Found a ticket opened for this issue, not creating a new one <a href=\'%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.AIPO_ENDPOINT, ticket_id, ticket_id),
                            'ticket': ticket_id,
                            'result': ticket
                        }
                    # rdar://problem/60856653
                    try:
                        content.update(self.validate_ticket(ticket))
                    except Exception as e:
                        self.mainLogger.critical("Validate problem %s %s" % (ticket, e))
                    # Log
                    self.content['notification'].append(content)
                except Exception as e:
                    self.mainLogger.critical('[ aipo ] Main loop issue %s : %s' % (alert, e))
