__author__ = 'nmsys'

import requests

from contrib.notifier.handler.grandprix.lib.cstlib import merge
from contrib.notifier.handler.grandprix.lib.cstlib import cstlib


class SSPAuthenticationService:
    def __init__(self, uri, environment, app, token):
        self.uri = uri
        self.environment = environment
        self.app = app
        self.password = token

    def token(self):

        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "AuthenticationService",
                    "operationName": "authenticate",
                },
                "espRequestPayload": {
                    "header": {
                    },
                    "zbody": {
                        "request": {
                            "authenticationRequest": {
                                "data": {
                                    "authenticationRequestData": {
                                        "applicationId": self.app,
                                        "applicationPassword": self.password
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        params = merge(cstlib(client="1.5"), params)
        del params['EspServiceRequest']['espRequestPayload']['body']
        try:
            r = requests.post(
                self.uri,
                json=params,
                headers={'Content-Type': 'application/json', 'Accept': 'application/json'},
                verify=True
            )
            data = r.json()
        except requests.exceptions.Timeout:
            print("Request timeout URI %s" % self.uri)
            return ""
        except requests.exceptions.RequestException as e:
            print(e)
            return ""
        if data['EspServiceResponse']['espResponsePayload']['body']['authenticateReturn']['header']['authenticated'] == 'false':
            return False, "[SSPAuthenticationService] Error %s" % data['EspServiceResponse']['espResponsePayload']['body']['authenticateReturn']['header']
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            return True, data['EspServiceResponse']['espResponsePayload']['body']['authenticateReturn']['data']['tokens']['EspToken']['token']
        else:
            return False, "[SSPAuthenticationService] Error %s" % data['EspServiceResponse']['espResponseHeader']
