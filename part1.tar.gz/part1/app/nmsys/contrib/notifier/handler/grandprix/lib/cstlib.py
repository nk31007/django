__author__ = 'nmsys'
import socket
from time import gmtime, strftime


def cstlib(version="2.0", client="2.0"):
    return {
        "EspServiceRequest": {
            "espRequestHeader": {
                "consumerAppId": '',
                "consumerPersonId": '',
                "serviceName": '',
                "operationName": '',
                "consumerIP": socket.gethostbyname(socket.gethostname()),
                "requestTimeStamp": strftime("%Y/%m/%d %H:%M:%S : GMT", gmtime()),
                "versionNumber": version,
                "espEnvironment": '',
                "espGuid": '',
                "transactID": '',
                "isAsync": 'false',
                "espPassThroughToken": '',
                "espToken": {},
                "filter": '',
                "encoding": 'UTF-8',
                "consumerAppSeqNo": '',
                "sendToAddress": '',
                "deliverToAddress": '',
                "inputDataFormat": 'ESP_JSON',
                "outputDataFormat": 'ESP_JSON',
                "espClientVersion": client,
                "espNameValueString": {},
                "lbOveride": '',
                "hostnamePort": '',
                "bizKey01": '',
                "bizValue01": '',
                "bizKey02": '',
                "bizValue02": ''
            },
            "espRequestPayload": {
              "header": {},
              "body": {}
            }
        }
    }


def merge(a, b, path=None):
    if path is None: path = []
    for key in b:
        if key in a:
            if isinstance(a[key], dict) and isinstance(b[key], dict):
                merge(a[key], b[key], path + [str(key)])
            elif a[key] == b[key]:
                pass # same leaf value
            elif a[key] == '':
                a[key] = b[key]
            else:
                a[key] = b[key]
                #raise Exception('Conflict at %s' % '.'.join(path + [str(key)]))
        else:
            a[key] = b[key]
    return a
