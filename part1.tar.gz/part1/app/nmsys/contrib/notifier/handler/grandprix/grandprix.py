__author__ = 'nmsys'

import requests
import time
import logging
import base64
from contrib.notifier.handler.grandprix.lib.cstlib import merge
from contrib.notifier.handler.grandprix.lib.cstlib import cstlib
from contrib.utils import encode_to_base64
# Logging
logger = logging.getLogger("django")

class Grandprix:
    def __init__(self, uri, environment, app, token):
        self.uri = uri
        self.environment = environment
        self.app = app
        self.token = token
        self.version = '3.0'
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'HTTP_HEADER_SSP_SERVICE_NAME': 'GrandPrix',
            'HTTP_HEADER_SSP_SERVICE_VER': self.version,
            'HTTP_HEADER_SSP_CONSUMER_ID': self.app,
            'HTTP_HEADER_SSP_CONSUMER_APP_SEQ_NO': '2',
            'HTTP_HEADER_SSP_ESP_CLIENT_VERSION': '2.0',
            'HTTP_HEADER_SSP_INPUT_DATA_FORMAT': 'ESP_JSON',
            'HTTP_HEADER_SSP_OUTPUT_DATA_FORMAT': 'ESP_JSON',
            'HTTP_HEADER_SSP_ESP_ENVIRONMENT': self.environment
        }

    def create(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "CreateTicket",
                    "espToken":{
                        "EspToken":{
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "createTicketRequest": {
                            "createTicketRequestType": {
                                "callerId": "298",
                                "configuration": '',
                                "configurationItem": option.get('configurationItem', ''),
                                "description": option.get('description', 'See title...'),
                                "environment": option.get('environment', ''),
                                "failType": option.get('failType', 'F'),
                                "impactedGeo": "",
                                "jobName": option.get('jobName', ''),
                                "jobType": option.get('jobType', 'P'),
                                "logFileData": "",
                                "logFileName": "",
                                "masterIncident": "",
                                "timeLag": "dasd",
                                "title": option.get('title', 'Nmsys Alert'),
                                "impact": option.get('Impact', ''),
                                "urgency": option.get('Urgency', ''),
                                "callingApp": "%s-Nmsys" % self.app
                            }
                        }
                    }
                }
            }
        }
        params = merge(cstlib(version=self.version), params)

        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'CreateTicket'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::creation ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::creation ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}

        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            result = data['EspServiceResponse']['espResponsePayload']['body']['createTicketResponse']['createTicketResponseType']
            result.update({'status': 'OK'})
            return result
        else:
            logger.critical("[ Grandprix::creation ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::creation ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def update(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "UpdateTicket",
                    "espToken": {
                        "EspToken": {
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "updateTicketRequest": {
                            "updateTicketRequestType": {
                                "ticketId": option.get('id', ''),
                                "assignedPersonId": option.get('assignedPersonId', ''),
                                "ticketOwnerId": "",
                                "ticketStatus": option.get('ticketStatus', ''),
                                "configurationItem": option.get('configurationItem', ''),
                                "category": "",
                                "subcategoryName": "",
                                "affectedGroups": "",
                                "sapModuleName": "",
                                "escalatedWorkgroupName": option.get('escalatedWorkgroupName', 'escalatedWorkgroupName'),
                                "cause": option.get('cause', ''),
                                "resolutionSummary": option.get('resolutionSummary', ''),
                                "resolution": option.get('resolution', ''),
                                "affectedCi": "",
                                "title": "",
                                "description": option.get('description', 'See title...'),
                                "workLog": "",
                                "dsPrsId": "2650259001",
                                "type": "",
                                "espressoCR": "",
                                "espressoSR": "",
                                "espressoTT": "",
                                "radar": "",
                                "relatedRecords": "",
                                "subCause": ""
                            }
                        }
                    }
                }
            }
        }
        params = merge(cstlib(version=self.version), params)
        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'UpdateTicket'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::update ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::update ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            result = data['EspServiceResponse']['espResponsePayload']['body']['updateTicketResponse']['updateTicketResponseType']
            result.update({'status': 'OK'})
            return result
        else:
            logger.critical("[ Grandprix::update ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::update ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def _attach(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "AttachFile",
                    "espToken": {
                        "EspToken": {
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "attachFileRequest": {
                            "attachFileRequestType": {
                                "ticketId": option.get('id', ''),
                                "action": option.get('action', 'UPLOAD'),
                                "fileName": option.get('name', 'attachment.txt'),
                                "fileData": option.get('data', 'No content Provided'),
                                "dsPrsId": ''
                            }
                        }
                    }
                }
            }
        }
        params = merge(cstlib(version=self.version), params)
        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'AttachFile'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::attach ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::attach ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            return data['EspServiceResponse']['espResponsePayload']['body']['attachFileResponse']['attachFileResponseType']['status']
        else:
            logger.critical("[ Grandprix::attach ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::attach ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def search(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "QueryTicket",
                    "espToken": {
                        "EspToken": {
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "queryTicketRequest": {
                            "queryTicketRequestType": {
                                "query": option.get('query', ''),
                                "showCompliance": "",
                                "affectedLocationsRequired": "",
                                "fromIncident": ""
                            }
                        }
                    }
                }
            }
        }

        params = merge(cstlib(version=self.version), params)
        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'QueryTicket'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::search ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::search ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            return data['EspServiceResponse']['espResponsePayload']['body']['queryTicketResponse']['queryTicketResponseType'] # ['queryList']
        else:
            logger.critical("[ Grandprix::search ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::search ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def ping(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "Ping",
                    "espToken": {
                        "EspToken": {
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "pingRequest": {
                            "pingRequestType": {
                                'message': 'OK'
                            }
                        }
                    }
                }
            }
        }

        params = merge(cstlib(version=self.version), params)
        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'Ping'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::ping ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::ping ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            return data['EspServiceResponse']['espResponsePayload']['body']['pingResponse']['pingResponseType']['statusMsg']
        else:
            logger.critical("[ Grandprix::ping ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::ping ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def configuration(self, option):
        params = {
            "EspServiceRequest": {
                "espRequestHeader": {
                    "consumerAppId": self.app,
                    "espEnvironment": self.environment,
                    "serviceName": "GrandPrix",
                    "operationName": "GetConfig",
                    "espToken": {
                        "EspToken": {
                            "message": "",
                            "token": self.token,
                            "tokenType": "APPLICATION"
                        }
                    }
                },
                "espRequestPayload": {
                    "body": {
                        "getConfigRequest": {
                            "getConfigRequestType": {
                                'jobName': option.get('name', 'espresso_p_c_WS_monitor'),
                                "jobType": "P"
                            }
                        }
                    }
                }
            }
        }

        params = merge(cstlib(version=self.version), params)
        try:
            r = requests.post(self.uri, json=params, headers=merge(self.headers, {'HTTP_HEADER_SSP_SERVICE_OPR': 'GetConfig'}), verify=True)
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Grandprix::configuration ] Request timeout URI %s" % self.uri)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Grandprix::configuration ] Request exception URI %s: %s" % (self.uri, e))
            return {'status': 'critical', 'error': str(e)}
        if data['EspServiceResponse']['espResponseHeader']['statusCD'] == 'OK':
            return data['EspServiceResponse']['espResponsePayload']['body']['getConfigResponse']['getConfigResponseType']
        else:
            logger.critical("[ Grandprix::configuration ] Something is wrong %s" % data['EspServiceResponse']['espResponseHeader'])
            logger.critical("[ Grandprix::configuration ] Content %s" % params)
            return {'status': 'critical', 'error': str(data)}

    def status(self, ticket_id):
        return self.search({'query': 'number=%s' % ticket_id})

    def attach(self, ticket_id, content, name='attachment.txt'):
        self._attach({
            'id': ticket_id,
            'name': name,
            'data': encode_to_base64(content)
        })

    def attach_image(self, ticket_id, image):
        self._attach({
            'id': ticket_id,
            'name': image,
            'data': encode_to_base64(open(image, 'rb').read())
        })

    def isclosed(self, ticket_id):
        try:
            status = self.search({'query': 'number=%s' % ticket_id})['queryList'][0]['queryTicketListType']
            if 'state' in status and status['state'] in ['Resolved', 'Closed']:
                return True
        except:
            pass
        return False

    def escalate(self, ticket_id, group, content):
        content.update({
            'id': ticket_id,
            'escalatedWorkgroupName': group,
         })

        return self.update(content)

    def update_details(self, ticket_id, description):
        return self.update({'id': ticket_id, 'description': description})

    def close(self, ticket_id, resolver_user_id):
        print(self.update({'id': ticket_id, 'ticketStatus': 'Work in Progress',
                           'Impact': '3 - Low', 'Urgency': '3 - Low',
                           'escalatedWorkgroupName': 'nmsys-users', 'assignedPersonId': resolver_user_id}))
        time.sleep(0.5)
        print(self.update(
            {
                'id': ticket_id,
                'assignedPersonId': resolver_user_id,
                "resolutionSummary": "Auto-closed",
                "resolution": "Cannot Reproduce",
                'escalatedWorkgroupName': 'nmsys-users',
                "cause": "Monitoring Error / False Alarm",
                "ticketStatus": "Resolved"
             }
        ))
        time.sleep(0.5)
        print(self.update(
            {
                'id': ticket_id,
                'assignedPersonId': resolver_user_id,
                "resolutionSummary": "Auto-closed",
                "resolution": "Cannot Reproduce",
                'escalatedWorkgroupName': 'nmsys-users',
                "cause": "Monitoring Error / False Alarm",
                "ticketStatus": "Closed"
             }
        ))

