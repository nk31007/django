#!/usr/bin/env python

import ujson as json
import requests
import datetime
import logging
logger = logging.getLogger("django")

class Pagerduty:
    def __init__(self, rest_token, service_esc, proxies=None):
        self.rest_token = rest_token
        self.service_esc = service_esc
        self.proxies = proxies

    def trigger_incident(self, uu_pk, alert):
        dt = datetime.datetime.utcfromtimestamp(alert['u_ptime']) 
        payload = { 
            "routing_key": self.service_esc,
            "event_action": "trigger",
            "payload": {
                "class": alert['alert'],
                "source": alert['node'],
                "timestamp":  dt.isoformat(),
                "summary": '%s: %s %s' % (alert['status'], alert['alert'], alert['node']),
                "severity": alert['status'].lower(),
                "custom_details": alert['description'],
            }
        }
        response = requests.post('https://events.pagerduty.com/v2/enqueue', json=payload, proxies=self.proxies)
        return response.json()

    def isclosed(self, uu_pk):
        url = 'https://api.pagerduty.com/incidents'
        headers = {
            'Accept': 'application/vnd.pagerduty+json;version=2',
            'Authorization': 'Token token={token}'.format(token=self.rest_token)
        }

        r = requests.get(url, headers=headers, params={'incident_key': uu_pk, 'statuses[]': ['triggered', 'acknowledged']}, proxies=self.proxies)
        result = r.json()
        logger.debug('[Pagerduty::icslosed] %s' % result)
        if len(result['incidents']) > 0:
            return False
        else:
            return True

    def isackd(self, uu_pk):
        url = 'https://api.pagerduty.com/incidents'
        headers = {
            'Accept': 'application/vnd.pagerduty+json;version=2',
            'Authorization': 'Token token={token}'.format(token=self.rest_token)
        }

        r = requests.get(url, headers=headers, params={'incident_key': uu_pk, 'statuses[]': ['acknowledged']}, proxies=self.proxies)
        result = r.json()
        logger.debug('[Pagerduty::isackd] %s' % result)
        if len(result['incidents']) > 0:
            return False
        else:
            return True

    def ack_incident(self, uu_pk):
        payload = {
            "routing_key": self.service_esc,
            "event_action": "acknowledge",
            "dedup_key": uu_pk
        }

        response = requests.post('https://events.pagerduty.com/v2/enqueue',
                                json=json.dumps(payload), proxies=self.proxies)

        if response.json()["status"] == "success":
            print('Incident Resolved')
        else:
            print(response.text)

        return response

    def resolve_incident(self, uu_pk):
        payload = {
            "routing_key": self.rest_token,
            "event_action": "resolve",
            "dedup_key": uu_pk
        }

        response = requests.post('https://events.pagerduty.com/v2/enqueue',
                                json=json.dumps(payload), proxies=self.proxies)

        if response.json()["status"] == "success":
            print('Incident Resolved')
        else:
            print(response.text)

        return response
