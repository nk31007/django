__author__ = 'rfoucher'

import logging
import re
from contrib.notifier.notifier import Notifier
from radarclient import RadarClient, AuthenticationStrategyWebCookie, ClientSystemIdentifier

from django.template.loader import render_to_string
from django.conf import settings

import copy

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class Radar(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Radar, self).__init__(subscription, alert, data, stats, logger)
        system_identifier = ClientSystemIdentifier('nmSys', '1.0')
        self.radarclient = RadarClient(
            AuthenticationStrategyWebCookie(settings.APPLECONNECTNAME, settings.APPLECONNECTPASSWORD),
            system_identifier
        )

    def build_payload(self, status, name, component, content):
        description = render_to_string(
            'mail/centralstation_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )

        if len(description) > 4000:
            self.attachment = copy.deepcopy(description)
        description = description[:3997] + (description[3997:] and '..')
        description = description.replace('<br />', '\n').replace('</BR>', '\n')
        try:
            com, version = component.split('|')
        except:
            com = component
            version = '1.0'
        return {
            'title': name,
            'component': {'name': com.strip(), 'version': version.strip()},
            'classification': 'Task',
            'reproducible': 'Not Applicable',
            'description': description,
        }

    def create_ticket(self, uu_pk, create_payload):
        data = {}
        try:
            radar = self.radarclient.create_radar(create_payload)
            if not radar.id:
                self.api_stats('radar::create::systemfailure')
                return {'status': 'failure', 'details': 'System Error : %s' % radar}

            self.api_stats('radar::create::success')
            self.set_id(uu_pk, radar.id)

            result = {
                'status': 'OK',
                'details': 'Radar ticket <a href=\'rdar://problem/%s\' target=\'_blank\'>rdar://problem/%s</a>' % (radar.id, radar.id),
                'ticket': radar.id,
                'result': create_payload
            }
            data.update(result)
            return data
        except Exception as e:
            self.mainLogger.critical('[ radar ] Problem %s' % e)
            return {'status': 'failure', 'details': 'Radar error user {} : {}'.format(settings.APPLECONNECTNAME, e)}

    def isclosed(self, radarid):
        radar = self.radarclient.radar_for_id(radarid)
        if radar.state == 'Verify' or radar.state == 'Closed':
            return True
        return False

    def _publish(self):
        for alert in self.content['content']:
            uu_pk = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
            try:
                dedup_id = self.get_id(uu_pk, uu_pk)
                if not dedup_id or dedup_id == '-1':
                    subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                    payload = self.build_payload(alert['status'], subject, self.subscription['email-contact'], [alert])
                    content = self.create_ticket(uu_pk, payload)
                    content.update({'content': alert})
                    self.content['notification'].append(content)
                elif self.isclosed(dedup_id):
                    self.purge_id(uu_pk, uu_pk)
                    subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                    payload = self.build_payload(alert['status'], subject, self.subscription['email-contact'], [alert])
                    content = self.create_ticket(uu_pk, payload)
                    content.update({
                        'content': alert,
                        'debug': "An older Radar was found but is closed"
                    })
                    self.content['notification'].append(content)
                else:
                    self.content['notification'].append({
                        'status': 'OK',
                        'content': alert,
                        'details': 'Found a Radar <a href=\'rdar://problem/%s\' target=\'_blank\'>rdar://problem/%s</a>' % (dedup_id, dedup_id),
                        'ticket': dedup_id
                    })
            except Exception as e:
                self.mainLogger.critical('[ radar ] Major %s, %s' % (self.subscription['email-contact'], e))
