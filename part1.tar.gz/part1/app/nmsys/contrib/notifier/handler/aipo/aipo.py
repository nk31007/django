__author__ = 'nmsys'

import requests
import time
import logging
import socket
# Logging
logger = logging.getLogger("django")

class Aipo:
    def __init__(self, endpoint, app, token):
        self.endpoint = endpoint
        self.token = token
        self.app = app
        self.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization' : 'Bearer %s' % token,
            'AppID': app,
            'RequestID': '',
            'SourceIP': ''
        }

    def ping(self):
        try:
            r = requests.get(
                '%s/api/global/ping' % self.endpoint,
                headers=self.headers,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::ping ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::ping ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::ping ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

    def create(self, option):
        payload = {
            "module" : "incident",
                "data" : {
                    "configurationitem" : option.get('configurationItem', ''),
                    "environment" : option.get('environment', ''),
                    "assignmentgroup" : option.get('assignmentgroup', 'assignmentgroup'),
                    "title" : option.get('title', 'Nmsys Alert'),
                    "description" : option.get('description', 'See title...'),
                    "impact": option.get('Impact', ''),
                    "urgency": option.get('Urgency', ''),
                    "ownedby" : "",
                    "parentincident" : ""
                }
        }
        try:
            r = requests.post(
                '%s/api/global/createrecord' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::create ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::create ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::create ] Something is wrong %s %s" % (data, payload))
            return {'status': 'critical', 'error': str(data)}

    def update(self, option):
        payload = {
            "module" : "incident",
            "action": "save",
                "data" : {
                    "ticketid" : option.get('id', ''),
                    "configurationitem" : option.get('configurationItem', ''),
                    "environment" : option.get('environment', ''),
                    "assignmentgroup" : option.get('assignmentgroup', 'assignmentgroup'),
                    "title" : option.get('title', 'Nmsys Alert'),
                    "description" : option.get('description', 'See title...'),
                    "impact": option.get('Impact', ''),
                    "urgency": option.get('Urgency', '')
                }
        }
        try:
            r = requests.post(
                '%s/api/global/updaterecord' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::update ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::update ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::update ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

    def resolve(self, option):
        payload = {
            "module" : "incident",
            "action" : "resolve",
            "data" :
            {
                "ticketid" : option.get('id', ''),
                "resolutioncode" : option.get('resolutioncode', "Cannot Reproduce"),
                "cause" : option.get('cause', "Process Failure"),
                "closenotes" : option.get('closenotes', 'Monitoring Error / False Alarm')
            }
        }
        self.assignto(option.get('id', ''))
        try:
            r = requests.post(
                '%s/api/global/updaterecord' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::resolve ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::resolve ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::resolve ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

    def _attach(self, option):
        payload = {
            "data" : {
                "ticketid": option.get('id', ''),
                "action": option.get('action', 'UPLOAD'),
                "filename": option.get('name', 'attachment.txt'),
                "filedata": option.get('data', 'No content Provided'),
                "uploadedby": ""
            }
        }
        try:
            r = requests.post(
                '%s/api/global/attach_file' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::_attach ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::_attach ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'Success':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::_attach ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

    def search(self, option):
        payload = {
            "module" : "incident",
            "querystring": option.get('query', ''),
        }
        try:
            r = requests.get(
                '%s/api/global/querytaskrecord' % self.endpoint,
                headers=self.headers,
                params=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::search ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::search ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}
        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::search ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}


    def status(self, ticket_id):
        return self.search({'query': 'number=%s' % ticket_id})

    def attach(self, ticket_id, image):
        f = open(image, 'rb')
        self._attach({
            'id': ticket_id,
            'name': image,
            'data': f.read()
        })

    def isclosed(self, ticket_id):
        try:
            status = self.search({'query': 'number=%s' % ticket_id})['data'][0]
            if 'state' in status and status['state'] in ['Resolved', 'Closed']:
                return True
        except:
            pass
        return False

    def escalate(self, ticket_id, group, content):
        content.update({
            'id': ticket_id,
            'assignmentgroup': group,
         })

        return self.update(content)

    def update_details(self, ticket_id, description):
        return self.update({'id': ticket_id, 'description': description})

    def assignto(self, ticket_id, user_id='2319677863'):
        payload = {
            "module" : "incident",
            "action": "save",
                "data" : {
                    "ticketid" : ticket_id,
                    "assignedto":  {"type" : "uidnumber" , "number" : user_id},
                }
        }
        try:
            r = requests.post(
                '%s/api/global/updaterecord' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::escalateto ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::escalateto ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::escalateto ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

    def close(self, option):
        payload = {
            "module" : "incident",
            "action" : "close",
            "data" :
            {
                "ticketid" : option.get('id', ''),
                "resolutioncode" : option.get('resolutioncode', "Cannot Reproduce"),
                "cause" : option.get('cause', "Process Failure"),
                "closenotes" : option.get('closenotes', 'Monitoring Error / False Alarm')
            }
        }
        try:
            r = requests.post(
                '%s/api/global/updaterecord' % self.endpoint,
                headers=self.headers,
                json=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical("[ Aipo::resolve ] Request timeout URI %s" % self.endpoint)
            return {'status': 'critical', 'error': 'Request timeout'}
        except requests.exceptions.RequestException as e:
            logger.critical("[ Aipo::resolve ] Request exception URI %s: %s" % (self.endpoint, e))
            return {'status': 'critical', 'error': str(e)}

        if data['status'] == 'SUCCESS':
            data.update({'status': 'OK'})
            return data
        else:
            logger.critical("[ Aipo::resolve ] Something is wrong %s" % data)
            return {'status': 'critical', 'error': str(data)}

