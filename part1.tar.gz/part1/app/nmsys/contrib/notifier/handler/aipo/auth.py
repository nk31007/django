__author__ = 'nmsys'

import requests
import time
import logging
from contrib.resource.redisrouter import RedisRouter
# Logging
logger = logging.getLogger("django")

class AipoAuthenticationService:
    def __init__(self, endpoint, client_id, client_secret, username, password):
        self.endpoint = endpoint
        self.client_id = client_id
        self.client_secret = client_secret
        self.username = username
        self.password = password
        self.expire_access =  18000  # 5*60*60 = 5 hours
        self.expire_refresh =  1728000  # 20*24*60*60 = 20 days
        self.aipocache = RedisRouter().retrieve_redis_connection('COMMON', 'default')

    def authentication(self):
        payload = {
            "grant_type" : "password",  
            "client_id" :self.client_id,  
            "client_secret" : self.client_secret,  
            "username" : self.username,  
            "password" : self.password
        }
        try:
            r = requests.post(
                '%s/oauth_token.do' % self.endpoint,
                headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
                data=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical('[AipoAuthenticationService::authentication] TimeOut from API %s, you shall retry' % self.endpoint)
            return False, "TimeOut from API %s" % self.endpoint
        except requests.exceptions.RequestException as e:
            logger.critical('[AipoAuthenticationService::authentication] UnHanbdled error from %s, %s' % (self.endpoint, e))
            return False, "[AipoAuthenticationService::authentication] UnHanbdled Error from API %s" % self.endpoint
        if 'error' in data:
            return False, "[AipoAuthenticationService::authentication] Error returned from API %s" % data['error_description']
 
        return True, data

    def refresh(self, token):
        payload = {
            "grant_type" : "refresh_token",  
            "client_id" :self.client_id,  
            "client_secret" : self.client_secret,  
            "refresh_token" : token
        }
        try:
            r = requests.post(
                '%s/oauth_token.do' % self.endpoint,
                headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
                data=payload,
                verify=False
            )
            data = r.json()
        except requests.exceptions.Timeout:
            logger.critical('[AipoAuthenticationService::refresh] TimeOut from API %s, you shall retry' % self.endpoint)
            return False, "TimeOut from API %s" % self.endpoint
        except requests.exceptions.RequestException as e:
            logger.critical('[AipoAuthenticationService::refresh] UnHanbdled error from %s, %s' % (self.endpoint, e))
            return False, "[AipoAuthenticationService::refresh] UnHanbdled Error from API %s" % self.endpoint
        if 'error' in data:
            return False, "[AipoAuthenticationService::refresh] Error returned from API %s" % data['error_description']
 
        return True, data

    def token(self, force=False):
        # Fetch access token from cache        
        if not force:
            access_token = self.aipocache.get('aipo_access_token')
            if access_token:
                return access_token

            # Fetch refresh token from cache        
            refresh_token = self.aipocache.get('aipo_refresh_token')
            if refresh_token:
                completed, data = self.refresh(refresh_token)
                if completed:
                    self.aipocache.set('access_token', data['access_token'], ex=self.expire_access)
                return data['access_token']


        completed, data = self.authentication()
        if completed:
            self.aipocache.set('access_token', data['access_token'], ex=self.expire_access)
            self.aipocache.set('refresh_token', data['refresh_token'], ex=self.expire_refresh)
            return True, data['access_token']

        return False, "[AipoAuthenticationService] Error %s" % data
