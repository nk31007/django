__author__ = 'nmsys'

from contrib.notifier.notifier import Notifier
from contrib.notifier.handler.pagerduty.pagerduty import Pagerduty as pd

from django.template.loader import render_to_string
from django.conf import settings


class Pagerduty(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Pagerduty, self).__init__(subscription, alert, data, stats, logger)
        self.service_esc = self.subscription['email-contact']
        self.rest_token = self.subscription['extra']

    def build_message(self, status, content):
        return render_to_string(
            'mail/pagerduty_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )

    def create_ticket(self, uu_pk, alert):
        alert['description'] = self.build_message(alert['status'], [alert])

        subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
        obj = pd(self.rest_token, self.service_esc, settings.DPS_HTTP_PROXY)
        result = obj.trigger_incident(
            subject,
            alert
        )
        self.set_id(uu_pk, result['dedup_key'])
        return result

    def _publish(self):
        for alert in self.content['content']:
            uu_pk = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
            try:
                dedup_id = self.get_id(uu_pk, uu_pk)
                if not dedup_id or dedup_id == '-1':
                    content = self.create_ticket(uu_pk, alert)
                    content.update({'content': alert})
                    self.content['notification'].append(content)
                elif pd(self.rest_token, self.service_esc, settings.DPS_HTTP_PROXY).isclosed(dedup_id):
                    self.purge_id(uu_pk)
                    content = self.create_ticket(uu_pk, alert)
                    content.update({
                        'content': alert,
                        'debug': "An older PD incident was found but is closed "
                    })
                    self.content['notification'].append(content)
                else:
                    self.content['notification'].append({
                        'status': 'OK',
                        'content': alert,
                        'details': 'Found a incident in PD',
                        'ticket': dedup_id
                    })
            except Exception as e:
                self.mainLogger.critical('[ send_pagerduty ] Major %s, %s' % (self.subscription['email-contact'], e))
                return {'status': 'failure', 'details': 'System Error : %s ' % str(e)}
