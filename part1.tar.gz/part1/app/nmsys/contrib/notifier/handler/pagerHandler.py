__author__ = 'nmsys'

from contrib.notifier.notifier import Notifier
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from email.mime.image import MIMEImage
from django.conf import settings
import smtplib


class Pager(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Pager, self).__init__(subscription, alert, data, stats, logger)
        self.array_email = None

    def image_mime(self, msg, pictures):
        for pic in pictures:
            image = MIMEImage(open('/var/tmp/%s' % pic['name'], "rb").read())
            image.add_header('Content-ID', '<%s>' % pic['name'])
            msg.attach(image)

    def _send_email(self, _subject, _to, text_content, pictures):
        try:
            msg = EmailMultiAlternatives(
                _subject,
                text_content,
                settings.NOTIF_INFO['from'],
                _to
            )
            self.image_mime(msg, pictures)
            info = msg.send()
            return {'status': 'OK', 'details': "Email %s sent to %s" % (_subject, _to), 'recipient': _to}
        except smtplib.SMTPException as e:
            self.mainLogger.critical('[ send_email ] Unable to send the email to %s, %s' % (_to, e))
            return {'status': 'critical', 'details': 'SMTP Error : %s ' % str(e), 'recipient': _to}
        except Exception as e:
            self.mainLogger.critical('[ send_email ] Damn it %s, %s' % (_to, e))
            return {'status': 'failure', 'details': 'System Error : %s ' % str(e), 'recipient': _to}

    def build_email(self, status, content):
        text_content = render_to_string(
            'mail/pager_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )
        return text_content

    def _build_escalation(self):
        for alert in self.content['content']:
            alert['description'], list_pics = self._epicimg_format(alert['description'])
            self._epic_img_store(list_pics)
            text_content = self.build_email(alert['status'], [alert])
            _to = getattr(self.subscription, 'input-contact-%s' % alert['status'].lower(), '').split(',')
            if _to[0] == '':
                _to = self.subscription['email-contact'].split(',')
            subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
            result = self._send_email(
                subject,
                _to, 
                text_content, 
                list_pics
            )
            result['content'] = alert
            self.content['notification'].append(result)
            self._epic_img_unlink(list_pics)

    def _publish(self):
        self._build_escalation()

