__author__ = 'rfoucher'

import logging
import re
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from contrib.notifier.notifier import Notifier
from django.template.loader import render_to_string
from django.conf import settings

import copy

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class Centralstation(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Centralstation, self).__init__(subscription, alert, data, stats, logger)
        self.mapper = {
            '': {
                'jobName': 'nmSys_event_notification',
                'map': [
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "2 - Medium", "Urgency": "1 - High"},
                    {"Impact": "2 - Medium", "Urgency": "2 - Medium"},
                    {"Impact": "3 - Low", "Urgency": "3 - Low"}
                ]
            },
            'IS&T': {
                'jobName': 'nmSys_event_notification',
                'map': [
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "2 - Medium", "Urgency": "1 - High"},
                    {"Impact": "2 - Medium", "Urgency": "2 - Medium"},
                    {"Impact": "3 - Low", "Urgency": "3 - Low"}
                ]
            },
            'ISO': {
                'jobName': 'nmSys Service product map1',
                'map': [
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "2 - Medium", "Urgency": "2 - Medium"},
                    {"Impact": "3 - Low", "Urgency": "3 - Low"}
                ]
            },
            'IS&S': {
                'jobName': 'nmSys Service product map1',
                'map': [
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "1 - High", "Urgency": "2 - Medium"},
                    {"Impact": "2 - Medium", "Urgency": "2 - Medium"},
                    {"Impact": "3 - Low", "Urgency": "3 - Low"}
                ]
            }
        }
        self.configuration_item_mapper = settings.CENTRALSTATION_CONFIG_ITEMS

        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        self.auth_status, self.token = ibj.token()
        if self.auth_status:
            self.api_stats('centralstation::auth::success')
            self.centralstation = Grandprix(
                settings.CENTRALSTATION_URL,
                settings.CENTRALSTATION_ENV,
                settings.CENTRALSTATION_ID,
                self.token
            )
        else:
            self.api_stats('centralstation::auth::failure')

        self.attachment = False
        if 'centralstation_template' not in self.subscription or self.subscription['centralstation_template'] not in self.mapper:
            self.subscription['centralstation_template'] = ''
        if 'centralstation_configuration_item' not in self.subscription or self.subscription['centralstation_configuration_item'].replace('_', ' ').lower() not in self.configuration_item_mapper:
            self.subscription['centralstation_configuration_item'] = 'default'
        if 'centralstation_template' not in self.subscription:
            self.subscription['centralstation_template'] = 'IS&T'

        self.escalation = self.mapper[self.subscription['centralstation_template']]

    def build_payload(self, status, impact, urgency, name, content):
        description = render_to_string(
            'mail/centralstation_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )

        if len(description) > 4000:
            self.attachment = copy.deepcopy(description)
        description = description[:3997] + (description[3997:] and '..')
        description = description.replace('\n', '\\n').replace('\t', '\\t').replace('<br />', '\\n').replace('</BR>', '\\n')

        return {
            'title': name,
            'jobName': self.escalation['jobName'],
            'description': description,
            'Impact': impact,
            'Urgency': urgency,
            'environment': settings.CENTRALSTATION_ENVIRONMENT,
            'configurationItem': self.configuration_item_mapper.get(
                getattr(self.subscription, 'centralstation_configuration_item', 'default').replace('_', ' ').lower(),
                ''
            )
        }

    def validate_ticket(self, ticket):
        ticket = ticket['queryList'][0]['queryTicketListType']
        configissues = []
        if 'configurationItem' in ticket:
            expected = self.configuration_item_mapper.get(
                getattr(self.subscription, 'centralstation_configuration_item', 'default').replace('_', ' ').lower(),
                ''
            )
            if expected != ticket['configurationItem']:
                self.api_stats('centralstation::validation::failure')
                configissues.append('[validate_ticket] Config ITEMS : Expecting %s GOT %s' % (ticket['configurationItem'], expected))
        if 'assignmentGroup' in ticket:
            if 'nmsys-users' in ticket['assignmentGroup']:
                self.api_stats('centralstation::validation::failure')
                configissues.append('[validate_ticket] assignement group is nmSys FIX it')
        if len(configissues) == 0:
            self.api_stats('centralstation::validation::success')
        return {
            'cstissues' : configissues,
            'result': ticket
        }

    def create_ticket(self, uu_pk, create_payload, contact, list_pics):
        data = {}
        try:
            cs_ticket = self.centralstation.create(create_payload)
            data['create'] = cs_ticket
            self.mainLogger.debug('[ centralstation ] result %s' % cs_ticket)
            if 'status' not in cs_ticket or cs_ticket['status'] != 'OK':
                self.api_stats('centralstation::create::systemfailure')
                return "-1", {'status': 'failure', 'details': 'System Error : %s' % cs_ticket}
            elif cs_ticket['ticketId'] == '-1':
                self.api_stats('centralstation::create::failure')
                cs_ticket.update({'status': 'failure', 'details': cs_ticket['errorMessage']})
                return "-1", cs_ticket
            else:
                self.api_stats('centralstation::create::success')
                self.mainLogger.debug('[ centralstation ] result %s %s' % (cs_ticket['status'], contact))
                self.set_id(uu_pk, cs_ticket['ticketId'])
                result = self.centralstation.escalate(cs_ticket['ticketId'], contact, create_payload)
                if 'status' in result and result['status'] == 'OK':
                    self.api_stats('centralstation::update::success')
                else:
                    self.api_stats('centralstation::update::failure')
                data['update'] = result
                self.mainLogger.info('[ GRANDPRIX::centralstation ] escalation %s' % result)

            if list_pics and len(list_pics) > 0:
                for pic in list_pics:
                    try:
                        self.centralstation.attach_image(cs_ticket['ticketId'], '/var/tmp/%s' % pic['name'])
                        self.api_stats('centralstation::attach::success')
                    except Exception as e:
                        self.api_stats('centralstation::attach::failure')
                        self.mainLogger.critical('[ GRANDPRIX::centralstation ] attache image %s error  %s' % ( pic, e))
            if self.attachment and len(self.attachment):
                try:
                    self.centralstation.attach(cs_ticket['ticketId'], str(self.attachment), 'alerts_list.txt')
                    self.api_stats('centralstation::attach::success')
                except Exception as e:
                    self.api_stats('centralstation::attach::failure')
                    self.mainLogger.critical('[ GRANDPRIX::centralstation ] attache dump list alert error  %s' % e)

            ticket = self.centralstation.status(cs_ticket['ticketId'])
            data['checkstatus'] = ticket
            if 'result' in ticket and ticket['result'] == 'critical':
                self.api_stats('centralstation::status::failure')
            else:
                self.api_stats('centralstation::status::success')

            result = {
                'status': 'OK',
                'details': 'CentralStation ticket <a href=\'https://%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.CENTRALSTATION_DOMAIN, cs_ticket['ticketId'], cs_ticket['ticketId']),
                'result': ticket,
                'ticket': cs_ticket['ticketId'],
                'recipient': contact
            }
            data.update(result)
            return ticket, data
        except Exception as e:
            self.mainLogger.critical('[ centralstation ] Problem %s' % e)
            return {'status': 'failure', 'details': 'System Error : %s' % str(e)}

    def _publish(self):
        if not self.auth_status:
            self.content['notification'].append({'status': 'failure', 'details': 'Authentication Error : %s' % self.token})
            return

        if self.digested or self.force_digest:
            raw = {}
            for alert in self.content['content']:
                raw.setdefault(alert['status'], {"alert": [], "picture": []})
                alert['description'], list_pics = self._epicimg_format(alert['description'])
                raw[alert['status']]['alert'].append(alert)
                if not self.force_digest:
                    raw[alert['status']]['picture'] += list_pics

            for key, value in raw.items():
                olduuid = '%s: %s' % (key.upper(), self.content['name'])
                if self.force_digest:
                    olduuid = 'Forcing digestion for %s alerts: %s' % (len(self.content['content']), olduuid)

                uuid = '%s: %s' % (key.upper(), self.content['name'])
                content = {}
                ticket = None
                ticket_id = self.get_id(olduuid, uuid)

                if not ticket_id or ticket_id == '-1':
                    content = {
                        'debug': "No ticket found, creating a new one"
                    }
                    if 'picture' in value:
                        self._epic_img_store(value['picture'])
                    else:
                        value['picture'] = None

                    contact, impact, urgency = self.find_severity(key.lower())

                    subject = self.build_subject(key.upper(), value['alert'], digested=True)
                    payload = self.build_payload(key, impact, urgency, subject, value['alert'])
                    ticket, data = self.create_ticket(uuid, payload, contact, value['picture'])
                    content.update(data)
                elif self.centralstation.isclosed(ticket_id):
                    content = {
                        'debug': "An older ticket was found but was closed <a href=\'https://%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a> , creating a new one" % (settings.CENTRALSTATION_DOMAIN, ticket_id, ticket_id)
                    }
                    self.purge_id(olduuid, uuid)
                    if 'picture' in value:
                        self._epic_img_store(value['picture'])
                    else:
                        value['picture'] = None

                    contact, impact, urgency = self.find_severity(key.lower())

                    subject = self.build_subject(key.upper(), value['alert'], digested=True)
                    payload = self.build_payload(key, impact, urgency, subject, value['alert'])
                    ticket, data = self.create_ticket(uuid, payload, contact, value['picture'])
                    content.update(data)
                else:
                    ticket = self.centralstation.status(ticket_id)
                    self.api_stats('centralstation::status::success')
                    # Transition to the NewID
                    self.set_id(uuid, ticket_id, False)
                    content = {
                        'status': 'OK',
                        'result': ticket,
                        'details': 'Found a ticket openned for this issue, not creating a new one <a href=\'https://%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.CENTRALSTATION_DOMAIN, ticket_id, ticket_id),
                        'ticket': ticket_id,
                    }
                    if self.attachment and len(self.attachment):
                        try:
                            self.centralstation.attach(ticket_id, str(self.attachment), 'alerts_list.txt')
                            self.api_stats('centralstation::attach::success')
                        except Exception as e:
                            self.api_stats('centralstation::attach::failure')
                            self.mainLogger.critical('[ GRANDPRIX::centralstation ] attache dump list alert error  %s' % e)
                # rdar://problem/60856653
                try:
                    content.update(self.validate_ticket(ticket))
                except Exception as e:
                    self.mainLogger.critical("Validate problem %s %s" % (ticket, e))
                # Log
                self.content['notification'].append(content)
                # Cleanup             
                self._epic_img_unlink(value['picture'])
        else:
            for alert in self.content['content']:
                try:
                    # Cache Key
                    olduuid = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
                    if len(olduuid) > 240:
                        olduuid = "%s : %s %s" % (alert['status'], self.content['name'], alert['node'])

                    uuid = "%s %s: %s %s" % (alert['status'], self.content['name'], alert['alert'], alert['node'])
                    content = {}
                    ticket = None

                    list_pics = []
                    # Check if we have a ticket already
                    ticket_id = self.get_id(olduuid, uuid)
                    if not ticket_id or ticket_id == '-1':
                        content = {
                            'content': alert,
                            'debug': "No ticket found, creating a new one"
                        }
                        # Picture Stuff first
                        alert['description'], list_pics = self._epicimg_format(alert['description'])
                        self._epic_img_store(list_pics)
                        contact, impact, urgency = self.find_severity(alert['status'].lower())

                        subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                        payload = self.build_payload(alert['status'], impact, urgency, subject, [alert])


                        ticket, data = self.create_ticket(uuid, payload, contact, list_pics)
                        content.update(data)
                        # Cleanup             
                        self._epic_img_unlink(list_pics)
                    elif self.centralstation.isclosed(ticket_id):
                        content = {
                            'content': alert,
                            'debug': "An older ticket was found but was closed <a href=\'https://%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a> , creating a new one" % (settings.CENTRALSTATION_DOMAIN, ticket_id, ticket_id)
                        }
                        self.purge_id(olduuid, uuid)
                        alert['description'], list_pics = self._epicimg_format(alert['description'])
                        self._epic_img_store(list_pics)
                        contact, impact, urgency = self.find_severity(alert['status'].lower())

                        subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                        payload = self.build_payload(alert['status'], impact, urgency, subject, [alert])

                        ticket, data = self.create_ticket(uuid, payload, contact, list_pics)
                        content.update(data)
                        # Cleanup             
                        self._epic_img_unlink(list_pics)
                    else:
                        ticket = self.centralstation.status(ticket_id)
                        self.api_stats('centralstation::status::success')
                        # Transition to the NewID
                        self.set_id(uuid, ticket_id, False)
                        content = {
                            'status': 'OK',
                            'content': alert,
                            'details': 'Found a ticket opened for this issue, not creating a new one <a href=\'https://%s/tkt.do?tkt=%s\' target=\'_blank\'>%s</a>' % (settings.CENTRALSTATION_DOMAIN, ticket_id, ticket_id),
                            'ticket': ticket_id,
                            'result': ticket
                        }
                    # rdar://problem/60856653
                    try:
                        content.update(self.validate_ticket(ticket))
                    except Exception as e:
                        self.mainLogger.critical("Validate problem %s %s" % (ticket, e))
                    # Log
                    self.content['notification'].append(content)
                except Exception as e:
                    self.mainLogger.critical('[ centralstation ] Main loop issue %s : %s' % (alert, e))
