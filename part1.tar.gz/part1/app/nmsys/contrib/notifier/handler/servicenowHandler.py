__author__ = 'rfoucher'

import logging
import re
from contrib.notifier.notifier import Notifier
from django.template.loader import render_to_string
from django.conf import settings
from django.template import Template
from requests.auth import HTTPBasicAuth

import requests
import recertifi
from requests.exceptions import SSLError, ConnectionError



import copy

# Logging
logger = logging.getLogger("django")
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
logger.addHandler(ch)


class Servicenow(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Servicenow, self).__init__(subscription, alert, data, stats, logger)
        self.attachment = False


    def build_payload(self, alert):
        return {
            "source": alert['application'],
            "event_class": "%s %s %s %s %s" % (alert['status'], alert['alert'], alert['node'], alert['locale'], alert['instance']),
            "resource": "%s %s %s" % (alert['alert'], alert['locale'], alert['instance']),
            "node": alert['node'],
            "metric_name": alert['alert'],
            "type": alert['alert'],
            "severity": alert['state'],
            "description": alert['description'],
            "additional_info": alert['labels'],
        }

    def _send_raw(self, servicenowendpoint, content):
        endpoint = "https://%s%s" % (servicenowendpoint,  settings.SERVICENOW)
        try:
            try:
                r = requests.post(endpoint, json=content, timeout=60, auth=HTTPBasicAuth(settings.SERVICENOW_USER, settings.SERVICENOW_PASSWORD))
            except SSLError as e:
                r = requests.post(endpoint, json=content, timeout=60, verify=False, auth=HTTPBasicAuth(settings.SERVICENOW_USER, settings.SERVICENOW_PASSWORD)) 
            except ConnectionError:
                r = requests.post(endpoint, json=content, timeout=60, proxies=settings.DPS_HTTP_PROXY, auth=HTTPBasicAuth(settings.SERVICENOW_USER, settings.SERVICENOW_PASSWORD)) 
            result = {
                'status': 'OK',
                'details': 'Servicenow POST status code %s ' % r.status_code,
                'remote_content': r.text,
                'endpoint': endpoint
            }
            return result
        except Exception as e:
            self.mainLogger.critical('[ servicenow post ] Problem %s' % e)
            return {'status': 'failure', 'endpoint': endpoint, 'details': 'System Error : %s' % str(e)}

    def _publish(self):
        raw = []
        for alert in self.content['content']:
            raw.append(self.build_payload(alert))

        result = self._send_raw(self.subscription['email-contact'], {'records': raw})
        self.content['notification'].append(result)

