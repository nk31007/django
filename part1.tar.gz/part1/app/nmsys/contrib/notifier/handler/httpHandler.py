__author__ = 'nmsys'

from contrib.notifier.notifier import Notifier
from django.template.loader import render_to_string
from django.conf import settings
import requests
import recertifi
from requests.exceptions import SSLError, ConnectionError

class Http(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Http, self).__init__(subscription, alert, data, stats, logger)
        self.array_email = None

    def build_message(self, status, content):
        text_content = render_to_string(
            'mail/text_notification.html',
            {
                'status': status.upper(),
                'details': self.hostname,
                'content': self.content,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )
        return text_content

    def _send_raw(self, endpoint, content):
        try:
            try:
                content['stats'] = content['stats'].to_dict()
            except:
                content.pop('stats', None)
            try:
                r = requests.post(endpoint, json=content, headers={'ENDPOINT': settings.ENDPOINT}, timeout=60)
            except SSLError as e:
                r = requests.post(endpoint, json=content, headers={'ENDPOINT': settings.ENDPOINT}, timeout=60, verify=False)
            except ConnectionError:
                r = requests.post(endpoint, json=content, headers={'ENDPOINT': settings.ENDPOINT}, timeout=60, proxies=settings.DPS_HTTP_PROXY)
            result = {
                'status': 'OK',
                'details': 'HTTP POST status code %s ' % r.status_code,
                'remote_content': r.text,
                'endpoint': endpoint 
            }
            return result
        except Exception as e:
            self.mainLogger.critical('[ http post ] Problem %s' % e)
            return {'status': 'failure', 'endpoint': endpoint, 'details': 'System Error : %s' % str(e)}

    def _publish(self):
        if len(self.content['content']) > 0:
            information = getattr(self.alert, 'information')
            self.content['description'] = getattr(information, 'description', '')
            self.content['documentation'] = getattr(information, 'gitlink', '')
            result = self._send_raw(self.subscription['email-contact'], self.content)
            self.content['notification'].append(result)
