__author__ = 'rfoucher'

from contrib.notifier.notifier import Notifier
from django.template.loader import render_to_string
from django.conf import settings
import requests


class Slack(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Slack, self).__init__(subscription, alert, data, stats, logger)
        self.proxies = settings.DPS_HTTP_PROXY
        self.color = [
            '#757575',
            'good', '#757575', '#0372B8', '#FF9B01', 'danger',
            'danger', '#757575', '#757575', '#757575',
            '#757575', '#757575', '#0372B8',
            '#757575', '#757575', '#757575'
        ]

    def build_payload(self, alert_list):
        blocks = []
        for alert in alert_list:
            blocks.append({
                "mrkdwn_in": ["text"],
                "color": self.color[alert['state']],
                "text": render_to_string(
                    'mail/slack_notification.html',
                    {
                        'content': self.content,
                        'details': self.hostname,
                        'verdad': {},
                        'definition': self.alert,
                        'subscription': self.subscription,
                        'alert': alert,
                        'SITE_URL': settings.NOTIF_INFO['SITE_URL']
                    }
                ),
                "ts": alert['u_ptime']
            })
        return {
            "attachments": blocks
        }

    def trigger_incident(self, channel_url, content):
        response = requests.post(
            channel_url,
            json=content,
            proxies=self.proxies
        )
        result = {
            'status': 'OK',
            'details': response.text,
            'channel': channel_url
        }
        return result

    def _publish(self):
        raw = {}
        raw = self.regroup(getattr(self.subscription, 'group-by', 'id'), self.content['content'])
        for key, value in raw.items():
            payload = self.build_payload(value['alert'])
            result = self.trigger_incident(self.subscription['email-contact'], payload)
            self.content['notification'].append(result)
