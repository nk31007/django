__author__ = 'nmsys'

from contrib.notifier.notifier import Notifier
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from email.mime.image import MIMEImage
from django.conf import settings
import smtplib
import re

class Email(Notifier):
    def __init__(self, subscription, alert, data, stats, logger):
        super(Email, self).__init__(subscription, alert, data, stats, logger)
        self.array_email = None

    def image_mime(self, msg, pictures):
        for pic in pictures[0:100]:
            image = MIMEImage(open('/var/tmp/%s' % pic['name'], "rb").read())
            image.add_header('Content-ID', '<%s>' % pic['name'])
            image.add_header("Content-Disposition", "inline")
            image.add_header("Content-Type", "image/png")
            msg.attach(image)

    def _send_email(self, _subject, _to, html_content, text_content, pictures):
        try:
            msg = EmailMultiAlternatives(
                _subject,
                text_content,
                settings.NOTIF_INFO['from'],
                _to
            )
            msg.attach_alternative(html_content, "text/html")
            msg.mixed_subtype = 'related'
            try:
                self.image_mime(msg, pictures)
            except:
                pass
            info = msg.send()
            return {'status': 'OK', 'details': "Email %s sent to %s" % (_subject, _to), 'recipient': _to}
        except smtplib.SMTPException as e:
            self.mainLogger.critical('[ send_email ] Unable to send the email to %s, %s' % (_to, e))
            return {'status': 'critical', 'details': 'SMTP Error : %s ' % str(e), 'recipient': _to}
        except Exception as e:
            self.mainLogger.critical('[ send_email ] Damn it %s, %s' % (_to, e))
            return {'status': 'failure', 'details': 'System Error : %s ' % str(e), 'recipient': _to}

    def build_email(self, status, content):
        html_content = render_to_string(
            'mail/html_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )
        text_content = render_to_string(
            'mail/text_notification.html',
            {
                'status': status.upper(),
                'content': self.content,
                'details': self.hostname,
                'verdad': {},
                'definition': self.alert,
                'extra': self.subscription,
                'list': content,
                'SITE_URL': settings.NOTIF_INFO['SITE_URL']
            }
        )
        return html_content, text_content

    def _publish(self):
        if self.digested or self.force_digest:
            raw = {}
            for alert in self.content['content']:
                raw.setdefault(alert['status'], {"alert": [], "picture": []})
                alert['description'], list_pics = self._epicimg_format(alert['description'])
                alert['description'] = alert['description'].replace('\\n', '<br />').replace('\t', '&nbsp;')
                raw[alert['status']]['alert'].append(alert)
                raw[alert['status']]['picture'] += list_pics

            for key, value in raw.items():
                self._epic_img_store(value['picture'])

                subject = self.build_subject(key.upper(), value['alert'], digested=True)
                html_content, text_content = self.build_email(key, value['alert'])
                _to = getattr(self.subscription, 'input-contact-%s' % key.lower(), '').split(',')
                if _to[0] == '':
                    _to = self.subscription['email-contact'].split(',')
                
                result = self._send_email(
                    subject,
                    _to, html_content, text_content,
                    value['picture']
                )
                self.content['notification'].append(result)
                self._epic_img_unlink(value['picture'])
        else:
            for alert in self.content['content']:
                try:
                    alert['description'], list_pics = self._epicimg_format(alert['description'])
                    alert['description'] = alert['description'].replace('\\n', '<br />').replace('\t', '&nbsp;')
                    # Will need to parse tags from Epic module tags
                    # alert['description'] = self._add_epic_tags(alert['node'], alert['description'])
                    self._epic_img_store(list_pics)
                    html_content, text_content = self.build_email(alert['status'], [alert])
                    _to = getattr(self.subscription, 'input-contact-%s' % alert['status'].lower(), '').split(',')
                    if _to[0] == '':
                        _to = self.subscription['email-contact'].split(',')

                    subject = self.build_subject(status=alert['status'], content=[alert], digested=False)
                    result = self._send_email(
                        subject,
                        _to, html_content, text_content, list_pics
                    )
                    result['content'] = alert
                    self.content['notification'].append(result)
                    self._epic_img_unlink(list_pics)
                except Exception as e:
                    self.mainLogger.critical('[ _publish ] Unable to send notification %s %s' % (alert, e))

