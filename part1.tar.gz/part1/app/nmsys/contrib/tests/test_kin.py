__author__ = 'nmsys'
from contrib.kin import Kin
from django.conf import settings
from backend.models import Alert
# Python
import unittest
# Django


class MyTestCase(unittest.TestCase):

    def test_publish_kin(self):
        test_array = [
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "gateway",
                "alert": "default@reachable-snmp"
            },
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "tor",
                "alert": "default@reachable-snmp"
            }
        ]
        self.assertTrue('location' in Kin().publish_alerts(test_array))

    def test_correlate_kin(self):
        test_array = [
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "gateway",
                "alert": "default@reachable-snmp"
            },
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "tor",
                "alert": "default@reachable-snmp"
            }
        ]
        test_correlate = [
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "tor",
                "alert": "default@reachable-snmp"
            },
            {
                "instance": "adminsys",
                "locale": "nk11",
                "node": "host",
                "alert": "bob@random-alert"
            }
        ]
        obj = Kin()
        location = obj.publish_alerts(test_array)
        result = obj.fetch_correlation(location['location'], test_correlate)
        self.assertTrue('simple' in result and 'causal' in result)

    def test_full_kin(self):
        obj = Kin()
        obj.task()
        location = obj.get_last_publish()
        test_correlate = [
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "usscz2-bb-cr2.corp.apple.com",
                "alert": "gnsnet@gns_cs_ip_interface_state_usprz3-bb-cr2.corp.apple.com_et-1_1_6"
            },
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "cr1.corp.apple.com_et-2_1_6usatl4-bb-cr1.corp.apple.com",
                "alert": "gnsnet@gns_cs_ip_interface_state_usatl4-bb-cr1.corp.apple.com_et-2_1_6"
            },
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "usnyc4-1232-01-02-gw2",
                "alert": "default@reachable-snmp"
            },
            {
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "usnyc4-1232-01-02-gw2",
                "alert": "default@reachable-snmp"
            },
            {
                "alert": "gnsnet@gns_dc_external_interface_traffic_usnyc4-1232-01-07-edg-gw2_Ethernet1_34",
                "instance": "gnsnet",
                "locale": "mr11",
                "node": "usnyc4-1232-01-07-edg-gw2"
            }
        ]
        result = obj.fetch_correlation(location, test_correlate)
        self.assertTrue('simple' in result and 'causal' in result)

    def test_fulful_kin(self):
        obj = Kin()
        obj.task()
        location = obj.get_last_publish()
        result = obj.fetch_correlation(location, Alert().kin_fetch({'status': 'CRITICAL', 'instance': 'gnsnet'})[0:10])
        self.assertTrue('simple' in result and 'causal' in result)

    def test_node_dependencies(self):
        obj = Kin()
        result = obj.fetch_topology('nwk1-0226-isg-sw1', 'nk11', 'gnsnet', 1, 1)
        self.assertTrue('nodes' in result)
        result = result['nodes'][0]
        self.assertTrue('dependents' in result and 'dependencies' in result)

    def test_fetch_related_alerts(self):
        obj = Kin()
        result = obj.fetch_topology('nwk1-0226-isg-sw1', 'nk11', 'gnsnet', '*', '*')


