__author__ = 'nmsys'

from django.test import TestCase
from contrib.notifier.handler.espressoHandler import Espresso
from contrib.notifier.handler.espresso.espresso import Espresso as Ticket
from backend.models import Filter
import mock
from django.conf import settings


class EspressoTestCase(TestCase):
    def setUp(self):
        self.filter_test = Filter(
            **{
                "application": "filter",
                "definition": {
                    "alert": "nmsys@puppet",
                    "instance": "iadsys",
                    "node": "!~verdad.tag=.*exclude"
                },
                "details": {
                    "Acknowledged": 0,
                    "CRITICAL": 117,
                    "OK": 217,
                    "WARNING": 2
                },
                "information": {
                    "description": "iAd puppet",
                    "gitlink": "https://iswiki.apple.com/confluence/display/ISOSREL2/Puppet",
                    "name": "puppet",
                    "update": "Submit",
                    "username": "ISO_SSC"
                },
                "name": "ISO_SSC@puppet",
                "pk": "631b1315-7d38-4268-86ed-3447ca7aa94d",
                "resource_uri": "/nmsys/api/rest/v2/filter/631b1315-7d38-4268-86ed-3447ca7aa94d/",
                "state": 5,
                "status": "CRITICAL",
                "subscription": [
                    {
                    "email-contact": "nmsys-users",
                    "notif-ifcritical": "on",
                    "notification_type": "espresso",
                    "priority": "P3",
                    "priority-critical": "P3",
                    "priority-warning": "P3",
                    "resend-after": 1440,
                    "select-duration": 60,
                    "subscriber": "nmsys-users"
                    }
                ],
                "timestamp": 1493220371,
                "u_ctime": 1493156022
                }

        )

        self.alerts = {"took":8,"timed_out":False,"_shards":{"total":5,"successful":5,"failed":0},"hits":{"total":4,"max_score":None,"hits":[{"_index":"epic","_type":"alert","_id":"vp21a00is-hpat01073301.isg.apple.com__epicd@epic2nmsysV2_vp21_csesys","_score":None,"_source":{"node":"vp21a00is-hpat01073301.isg.apple.com","status":"CRITICAL","description":"alertd not processing in 300s\n\nprocessing interval: Fri Apr 28 13:28:00 2017","u_ctime":1493411768,"locale":"vp21","timestamp":1493412396,"alert":"epicd@epic2nmsysV2","instance":"csesys","state":5,"u_mtime":1493411768,"ng":""},"sort":[5]},{"_index":"epic","_type":"alert","_id":"vp21a00is-hpat01073301.isg.apple.com__epicd@epic2nmsys_vp21_itsst","_score":None,"_source":{"node":"vp21a00is-hpat01073301.isg.apple.com","status":"CRITICAL","description":"alertd not processing in 300s\n\nprocessing interval: Fri Apr 28 13:30:00 2017","u_ctime":1493412001,"locale":"vp21","timestamp":1493412385,"ng":"","instance":"itsst","state":5,"u_mtime":1493412001,"alert":"epicd@epic2nmsys"},"sort":[5]},{"_index":"epic","_type":"alert","_id":"vp21a00is-hpat01073301.isg.apple.com__epicd@epic2nmsysV2_vp21_itsst","_score":None,"_source":{"node":"vp21a00is-hpat01073301.isg.apple.com","status":"CRITICAL","description":"alertd not processing in 300s\n\nprocessing interval: Fri Apr 28 13:30:00 2017","u_ctime":1493412000,"locale":"vp21","timestamp":1493412385,"ng":"","instance":"itsst","state":5,"u_mtime":1493412000,"alert":"epicd@epic2nmsysV2"},"sort":[5]},{"_index":"epic","_type":"alert","_id":"vp21a00is-hpat01073301.isg.apple.com__epicd@epic2nmsys_vp21_csesys","_score":None,"_source":{"node":"vp21a00is-hpat01073301.isg.apple.com","status":"CRITICAL","description":"alertd not processing in 300s\n\nprocessing interval: Fri Apr 28 13:28:00 2017","u_ctime":1493411771,"locale":"vp21","timestamp":1493412396,"alert":"epicd@epic2nmsys","instance":"csesys","state":5,"u_mtime":1493411771,"ng":""},"sort":[5]}]},"aggregations":{"bucket":{"doc_count_error_upper_bound":0,"sum_other_doc_count":0,"buckets":[{"key":"CRITICAL","doc_count":4}]}}}
        self.stats = {
            'CRITICAL': 8,
            'WARNING': 2,
            'OK': 10
        }

        self.espresso = Ticket(
            {
                'classpath': settings.ESPRESSO_CLASSPATH,
                'uname': settings.ESPRESSO_USER,
                'pd': settings.ESPRESSO_PASSWORD,
                'dry': False,
                'job': settings.ESPRESSO_PROCESS_NAME,
                'u_id': settings.ESPRESSO_USER_ID
            }
        )
        self.payload = {
            'subject': '[nmSys dec] TEST : ignore_just_testing',
            'priority': 3,
            'description': 'Making sure this works',
        }
        self.escalate = 'nmsys-users'

    def skip_create(self):
        espresso_ticket = self.espresso.create(self.payload)
        self.assertTrue('TICKETID' in espresso_ticket)
        self.espresso.close(espresso_ticket['TICKETID'])

    def skip_escalate(self):
        espresso_ticket = self.espresso.create(self.payload)
        self.assertTrue('TICKETID' in espresso_ticket)
        result = self.espresso.escalate(espresso_ticket['TICKETID'], 'nmsys-users')
        self.espresso.close(espresso_ticket['TICKETID'])

    def skip_update(self):
        espresso_ticket = self.espresso.create(self.payload)
        self.assertTrue('TICKETID' in espresso_ticket)
        result = self.espresso.escalate(espresso_ticket['TICKETID'], 'nmsys-users')
        self.espresso.update_details(espresso_ticket['TICKETID'], 'UPDATEIT')
        self.espresso.close(espresso_ticket['TICKETID'])
        raise

    def test_parser_update(self):
        obj = Espresso(self.filter_test['subscription'][0], self.filter_test, self.alerts, self.stats, logger)
        raise
