__author__ = 'nmsys'
from contrib.notifier.handler.slackHandler import Slack
from backend.models import Filter
from mock import patch
import logging
logger = logging.getLogger("django")
import unittest


def mock_cst(self, application):
    return 0

class SlackTestCase(unittest.TestCase):
    def setUp(self):
        self.eventlist = {'hits': { 'hits': [
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys", 
                "_source" : {"ack": 0,
                "alert": "nmsys@hardware",
                "application": "nmsys",
                "description": "CRITICAL:\n\t PSU2 Input        ( 0 Watts           ) status  cr\n",
                "instance": "iadsys",
                "locale": "st11",
                "ng": "",
                "node": "st44p01ad-kafka096.iad.apple.com",
                "occurrence": "Occurrence : 1 Critical in 1 checks",
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565771254,
                "u_ctime": 5858410942,
                "u_mtime": 5860738454,
                "u_ptime": 5858410942
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : {"ack": 0,
                "alert": "nmsys@puppet",
                "application": "nmsys",
                "description": "Puppet has not been running for the last 1206600 hour and 38 min\n",
                "instance": "itssys",
                "locale": "ms11",
                "ng": "",
                "node": "ms11p00it-qugc18021901",
                "occurrence": "Occurrence : 5 Critical in 5 checks",
                "occurrence_array": [
                    5,
                    5,
                    5,
                    5,
                    5
                ],
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565801340,
                "u_ctime": 5856267519,
                "u_mtime": 5860768627,
                "u_ptime": 5856267519
            }},
        ]}}
        
    def test_case0(self):
        stats = {
            "Acknowledged": 4,
            "OK": 253,
            "WARNING": 9,
            "ratio": 3
        }
        filt = Filter(**{
            "application": "filter",
            "definition": {
                "alert": "nmsys@delivery_memory",
                "node": "~verdad.tag=delivery-sre-services-alert"
            },
            "information": {
            "description": "Delivery_SRE delivery_memory alert",
            "name": "dserv_memory_sys_nccp1",
            "username": "delivery-sre-alerts"
            },
            "last_modification": "sworkers",
            "name": "delivery-sre-alerts@dserv_memory_sys_nccp1",
            "pk": "e26e3a8c-404b-481d-8921-927a06e661ba",
            "state": 4,
            "status": "WARNING",
            "subscription": [
                {
                    "comment": "",
                    "url": "https://hooks.slack.com/services/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",
                    "notif-ifcritical": "on",
                    "notification_type": "slack",
                    "resend-after": 43200,
                    "select-duration": 1,
                    "subscriber": "rfoucher",
                }
            ],
            "timestamp": 1553514665,
            "u_ctime": 1553514665
        })
        obj = Slack(
            filt.subscription[0], 
            filt, 
            self.eventlist, 
            stats, 
            logger
        )
        obj.publish()
