_author__ = 'nmsys'
from contrib.resource.search import SearchFilter
# Python
import unittest
import logging
# Django


class MyTestCase(unittest.TestCase):
    fixtures = ['alert.json']

    def setUp(self):
        logging.disable(logging.CRITICAL)
        self.maxDiff = None

    def test_multiple_with_tag(self):
        obj = SearchFilter('n:~verdad.tag=epic-nmsys-cluster AND a:memory')
        self.assertEqual(obj.filter().to_dict(), {'regexp': {'n': '.*nk11a00is-nmsys001.isg.apple.com.*'}})

    def test_basic(self):
        obj = SearchFilter('n:nk11a00is-nmsys001.isg.apple.com')
        self.assertEqual(obj.filter().to_dict(), {'regexp': {'n': '.*nk11a00is-nmsys001.isg.apple.com.*'}})

    def test_group(self):
        obj = SearchFilter('n:~verdad.tag=.*nmsys.*')
        result = obj.filter().to_dict()
        self.assertTrue('terms' in result)
        self.assertTrue('node' in result['terms'])
        self.assertTrue(len(result['terms']['node']) > 0)

    def test_group_empty_result(self):
        obj = SearchFilter('n:~^verdad.tag=nmsys$')
        with self.assertRaises(ValueError):
            obj.filter().to_dict()

    def test_group_nonempty_result(self):
        obj = SearchFilter('n:~verdad.tag=nmsys')
        result = obj.filter().to_dict()
        self.assertTrue('terms' in result)
        self.assertTrue('node' in result['terms'])
        self.assertTrue(len(result['terms']['node']) > 0)

    def test_nested_query(self):
        obj = SearchFilter('p:pof')
        obj.model_map = {
            'p': 'pif.paf'
        }
        result = obj.filter().to_dict()
        self.assertTrue('nested' in result)
        self.assertTrue('path' in result['nested'])
        self.assertTrue('query' in result['nested'])
        self.assertTrue(result['nested']['path'] == 'pif')
        self.assertTrue(result['nested']['query'] == {'regexp': {'pif.paf': '.*pof.*'}})

    def test_wrong_key(self):
        filter_test = "miko:blah"
        
        search_filter = SearchFilter(filter_test)
        search_filter.model_map = {
            'p': 'pif.paf'
        }
        with self.assertRaises(ValueError):
            qs = search_filter.filter()

    def test_search_exclude_only(self):
        filter_test = "!p:001"
        search_filter = SearchFilter(filter_test)
        search_filter.model_map = {
            'p': 'pif'
        }
        qs = search_filter.filter()
        self.assertEqual({'bool': {'must_not': [{'regexp': {'pif': '.*001.*'}}]}}, qs.to_dict())

    def test_empty_search(self):
        search_filter = SearchFilter("")
        search_filter.model_map = {
            'p': 'pif'
        } 
        self.assertEqual(search_filter.filter().to_dict(), {'match_all': {}})

    def test_search_builder_withOR(self):
        filters_test = "p:admin OR e:epic"
        search_filter = SearchFilter(filters_test)
        search_filter.model_map = {
            'p': 'pif',
            'e': 'epaf'
        }
        qs = search_filter.filter()
        self.assertEqual({'bool': {'should': [{'regexp': {'pif': '.*admin.*'}}, {'regexp': {'epaf': '.*epic.*'}}]}},
                         qs.to_dict())

    def test_search_builder_withAND(self):
        filters_test = "p:admin AND e:epic"
        search_filter = SearchFilter(filters_test)
        search_filter.model_map = {
            'p': 'pif',
            'e': 'epaf'
        } 
        qs = search_filter.filter()
        self.assertEqual({'bool': {'must': [{'regexp': {'pif': '.*admin.*'}}, {'regexp': {'epaf': '.*epic.*'}}]}},
                         qs.to_dict())

    def test_search_stupid(self):
        filter_test = "p: "
        obj = SearchFilter(filter_test)
        obj.model_map = {
            'p': 'pif'
        } 
        with self.assertRaises(ValueError):
            obj.filter()

