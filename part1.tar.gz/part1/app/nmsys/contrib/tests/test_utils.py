__author__ = 'rfoucher'


from django.test import TestCase
from contrib.utils import time_to_datetime, get_secret
from contrib.utils import epic_generator
import time
import datetime
import os


class UtilsTestCase(TestCase):

    def test_days(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime('2days', reference=reference), reference-172800)

    def test_empty(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime('10', reference=reference), reference-10)

    def test_year(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime('2years', reference=reference), reference-63072000)

    def test_month_misspelled(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime('2mos', reference=reference), reference-5184000)

    def test_month(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime('2months', reference=reference), reference-5184000)

    def test_full_date(self):
        now = datetime.datetime.now()
        formated = now.strftime("%Y-%m-%d %H:%M:%S.%f")
        expected = int(now.strftime("%s"))
        self.assertEqual(time_to_datetime(formated), expected)

    def test_integer(self):
        reference = int(time.time())
        self.assertEqual(time_to_datetime(100, reference), reference-100)

    def test_get_secret(self):
        self.assertEqual('empty', get_secret('yeah'))



class UtilsEpicCase(TestCase):
    def test_all(self):
        result = epic_generator()
        self.assertGreater(len(result), 150)

    def test_locale(self):
        result = epic_generator(locale_filter=['nk11'])
        self.assertGreater(len(result), 20)
        self.assertLess(len(result), 50)
        self.assertTrue('https://nk11-epic.isg.apple.com/ifsys' in [i['url'] for i in result])

    def test_instance(self):
        result = epic_generator(instance_filter=['adminsys'])
        self.assertGreater(len(result), 10)
        self.assertLess(len(result), 30)
        self.assertTrue('https://nk11-epic.isg.apple.com/adminsys' in [i['url'] for i in result])

    def test_one(self):
        result = epic_generator(locale_filter=['nk11'], instance_filter=['adminsys'])
        self.assertEqual(1, len(result))


class UtilsSecretCase(TestCase):
    def test_emptyl(self):
        self.assertEqual('empty', get_secret('not'))
