__author__ = 'nmsys'
from backend.models import Maintenance
import logging
logger = logging.getLogger("django")
import unittest
import time


class MaintenanceTestCase(unittest.TestCase):
    def setUp(self):
        self.eventlist = [
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys", 
                "_source" : {"ack": 0,
                "alert": "nmsys@hardware",
                "application": "nmsys",
                "description": "CRITICAL:\n\t PSU2 Input        ( 0 Watts           ) status  cr\n",
                "instance": "iadsys",
                "locale": "st11",
                "ng": "",
                "node": "st44p01ad-kafka096.iad.apple.com",
                "occurrence": "Occurrence : 1 Critical in 1 checks",
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565771254,
                "u_ctime": 5858410942,
                "u_mtime": 5860738454,
                "u_ptime": 5858410942
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : {"ack": 0,
                "alert": "nmsys@puppet",
                "application": "nmsys",
                "description": "Puppet has not been running for the last 1206600 hour and 38 min\n",
                "instance": "itssys",
                "locale": "ms11",
                "ng": "",
                "node": "ms11p00it-qugc18021901",
                "occurrence": "Occurrence : 5 Critical in 5 checks",
                "occurrence_array": [
                    5,
                    5,
                    5,
                    5,
                    5
                ],
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565801340,
                "u_ctime": 5856267519,
                "u_mtime": 5860768627,
                "u_ptime": 5856267519
            }},
        ]
        
    def test_case0(self):
        now = int(time.time())
        filt = Maintenance(**{
            "application": "maintenance",
            "created_at": "2020-06-29T18:05:42+00:00",
            "last_modification": "rfoucher",
            "last_modifier": "rfoucher",
            "pk": "15308c37-1a8d-907e-ff55-2f8068e44521",
            "schedule": {
                "alert": "default@.*",
                "dependencies": "0",
                "dependents": "0",
                "description": "Check 123",
                "endmaintenance": now+1000,
                "multiif-alert": "on",
                "node": "~.*epic.*",
                "owner": "rfoucher",
                "startmaintenance": now-1000
            },
            "status": "PENDING",
            "timestamp": 1593453942
        })
        filt.execute(True)
    