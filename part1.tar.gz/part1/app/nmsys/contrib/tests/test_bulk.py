__author__ = 'rfoucher'

# Python
import unittest
import requests
import ujson as json
import logging
import time
from elasticsearch_dsl import Q
from contrib.resource.redisrouter import RedisRouter
from random import randint

# Django
from backend.models import Alert
logger = logging.getLogger('django')



class MyTestCase(unittest.TestCase):
    def setUp(self):
        self.epic_url_real = 'http://nk11-epic.isg.apple.com/adminsys?a=alert&cmd=list&state=[1-5]&s=e-2weeks'
        self.expire = 100
        self.dic_alert = {
            "alert": {
                "list": [
                    {
                        "alert": "default@fake_full_ok",
                        "description": "description1",
                        "node": "fake1",
                        "state": 1,
                        "u_ctime": 1383634740,
                        "u_ptime": 1383634750,
                        "ng": "",
                        "u_mtime": "1383845400",
                        "id": 885
                    },
                    {
                        "alert": "default@fake_no_ptime",
                        "description": "description no ptime",
                        "node": "fake_no_ptime",
                        "state": 1,
                        "u_ctime": 1383634740,
                        "ng": "",
                        "u_mtime": "1383845400",
                        "id": 885
                    },
                    {
                        "alert": "default@fake_no_ptime",
                        "description": "state_all",
                        "node": "nwk1-d11-315-bc-14-4k-1",
                        "state": 1,
                        "u_ctime": 1382825160,
                        "u_ptime": 1382825170,
                        "ng": "",
                        "u_mtime": "1383845340",
                        "id": 112929
                    },
                    {
                        "alert": "default@fake_ptime_recent",
                        "description": "state_all",
                        "node": "nwk1-d11-315-bc-14-4k-1",
                        "state": 1,
                        "u_ctime": 1382825160,
                        "u_ptime": int(time.time()),
                        "ng": "",
                        "u_mtime": "1383845340",
                        "id": 112929
                    },
                    {
                        "alert": "default@fake_specific_origin",
                        "description": "state_all",
                        "node": "nwk1-d11-315-bc-14-4k-1",
                        "state": 1,
                        "locale": "other_locale",
                        "instance": "other_instance",
                        "u_ctime": 1382825160,
                        "u_ptime": int(time.time()),
                        "ng": "",
                        "u_mtime": "1383845340",
                        "id": 112929
                    },
                ]
            }
        }


    def test_case0(self):
        logger.debug('Testing basic bulk alerts')
        Alert().bulk('fakedc', 'fakeinstance', json.dumps(self.dic_alert))
        result = Alert().search().query(Q('match', node='fake1'))
        result.execute()
        self.assertEqual(result.hits.count, 1)

    def test_case1(self):
        redis_instance = RedisRouter().retrieve_redis_connection('common', 'delivery')
        redis_instance.flushdb()
        alert = {
            "alert": "default@test_case1",
            "description": "test_case1",
            "node": "test_case2",
            "state": 3,
            "u_ctime": 1383634740,
            "ng": "",
            "u_mtime": "1383845400",
            "id": 885
        }
        Alert().bulk('fakedc', 'fakeinstance', json.dumps({'alert': {'list': [alert]}}), True)

        # Testing Redis
        aa = redis_instance.get('Alert::fakedc::fakeinstance::default@test_case1::test_case1')
        time.sleep(1)
        self.assertEqual(alert['state'], int(aa))

        # Testing ES
        result = Alert().search().query(Q('match', node='test_case2'))
        content = result.execute()

        self.assertEqual(content[0]['state'], alert['state'])

        alert['state'] += 1
        Alert().bulk('fakedc', 'fakeinstance', json.dumps({'alert': {'list': [alert]}}), True)
        time.sleep(1)
        # Testing Redis
        aa = redis_instance.get('Alert::fakedc::fakeinstance::default@test_case1::test_case1')
        self.assertEqual(alert['state'], int(aa))

        # Testing ES
        result = Alert().search().query(Q('match', node='test_case2'))
        content = result.execute()

        self.assertEqual(content[0]['state'], alert['state'])

    def test_case2(self):
        dic_test = {
            "alert": {
                "list": [
                    {
                        "alert": "default@fake_full_ok",
                        "description": "description1",
                        "node": "fake1",
                        "state": 1,
                        "u_ctime": 1383634740,
                        "u_ptime": 1383634750,
                        "ng": "",
                        "u_mtime": "1383845400",
                        "id": 885
                    }
                ]
            }
        }
        Alert().bulk('fakedc', 'fakeinstance', json.dumps(dic_test), True)
        result = Alert().search().query(Q('match', node='fake1'))
        content = result.execute()
        dic_test['alert']['list'][0]['u_ptime'] = int(time.time())
        dic_test['alert']['list'][0]['state'] = 5
        Alert().bulk('fakedc', 'fakeinstance', json.dumps(dic_test), True)
        result2 = Alert().search().query(Q('match', node='fake1'))
        content2 = result2.execute()

        dic_test['alert']['list'][0]['u_ptime'] = int(time.time())
        dic_test['alert']['list'][0]['state'] = 2
        Alert().bulk('fakedc', 'fakeinstance', json.dumps(dic_test), True)
        result3 = Alert().search().query(Q('match', node='fake1'))
        content3 = result3.execute()

        #raise
if __name__ == '__main__':
    unittest.main()
