__author__ = 'nikita'

# For you reader, all regexp queries in ES are anchored, never let double-anchoring happening !

import logging
from django.test import TestCase
from contrib.resource.search_ply import parser
logger = logging.getLogger('django')
from backend.models import Alert
import json

data = {
    "alert": {
        "list": [
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group0",
                "node": "f00bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group1",
                "node": "f00baz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group2",
                "node": "f000bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group3",
                "node": "f04bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },


            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group4",
                "node": "f04barbuh",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "f04baz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "foo.bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "group9",
                "node": "f000barz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "gr10,gr11",
                "node": "barfoo",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=/node=barney",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=bar/node=foo",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=baz/node=foo",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=bar/node=bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=bar/node=baz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/foo=baz/node=baz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/app=1/node=f00bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/app=2/node=f00baz",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            },
            {
                "alert": "common@cpu_utilization",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/itssys?a=g&ds=totalCpuLinux&ng=&n=nk11p00it-ztdv30284701&m=&s=1534186140</epicimg>\\nCPU utilization is within acceptable limits\\n   Expr:  sysstat_cpu.all.total.percent < 90\\n   Value: 4.7125 < 90\\n",
                "id": 1607037,
                "ng": "",
                "node": "/app=3/node=f04bar",
                "state": 1,
                "u_ctime": 1534193340,
                "u_mtime": 1535402760,
                "u_ptime": 1534193543
            }
        ]
    }
}

# origin = instance@locale
dc = 'dc2'
instance = 'ins2'


class AlertSearchTestCase(TestCase):

    def setUp(self):
        logger.debug("INN SET UP3")
        self.total_count = 0
        self.result = []
        self.expected = []
        Alert().bulk(dc, instance, json.dumps(data))

    # Positive test cases
    def test_case0(self):
        logger.debug("In testcase 0 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group1)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group1)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case1(self):
        logger.debug("In testcase 1- INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group.*)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group.*)'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case2(self):
        logger.debug("In testcase 2 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(keygroup5=group5)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(keygroup5=group5)'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f04baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case3(self):
        logger.debug("In testcase 3 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(keygroup5=group.*)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(keygroup5=group.*)'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug(query.to_dict())
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f04baz", "foo.bar", "f04barbuh", "f000bar"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case4(self):
        logger.debug("In testcase 4 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(.*)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'f000bar', 'f04barbuh', 'f000barz', 'barfoo', 'foo.bar', '/foo=/node=barney', '/foo=bar/node=foo', '/foo=bar/node=baz', 'f04ba',
                         '/foo=bar/node=bar', '/app=1/node=f00bar', '/foo=baz/node=bar', '/app=3/node=f04bar', 'f04baz', '/foo=baz/node=foo', '/foo=baz/node=baz', '/app=2/node=f00baz']
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case5(self):
        logger.debug("In testcase 5 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*) INTERSECT ANY(group1))")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*) INTERSECT ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case6(self):
        logger.debug("In testcase 6 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group0) UNION ANY(group9))")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group0) UNION ANY(group9))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f000barz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case7(self):
        logger.debug("In testcase 7 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*) UNION ANY(group1))")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*) UNION ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case8(self):
        logger.debug("In testcase 8 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*),ANY(group1))")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (ANY(group.*),ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case9(self):
        logger.debug("In testcase 9 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group[1|2])")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ANY(group[1|2])'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz", "f000bar"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case10(self):
        logger.debug("In testcase 10 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ALL(gr1[0|1])")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ALL(gr1[0|1])'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case11(self):
        logger.debug("In testcase 11 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ALL(gr10)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ALL(gr10)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case12(self):
        logger.debug("In testcase 12 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (ALL(gr10) UNION ALL(gr11))")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (ALL(gr10) UNION ALL(gr11))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case13(self):
        logger.debug("In testcase 13 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ~group.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ~group.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case14(self):
        logger.debug("In testcase 14 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (ANY(group.*) MINUS ANY(group1))")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (ANY(group.*) MINUS ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00bar", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    # test cases for node-patterns
    def test_case15(self):
        logger.debug("In testcase 15 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT f00.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT f00.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00bar", "f00baz", "f000bar", "f000barz", "/app=1/node=f00bar", "/app=2/node=f00baz"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case15_1(self):
        logger.debug("In testcase 15_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ^f00.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ^f00.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00bar", "f00baz", "f000bar", "f000barz"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case16(self):
        logger.debug("In testcase 16 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT f04baz?")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT f04baz?'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', 'f04barbuh', 'f04ba', '/app=3/node=f04bar', 'f04baz']
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case16_1(self):
        logger.debug("In testcase 16_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ^f04baz?$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ^f04baz?'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', 'f04barbuh', 'f04ba', 'f04baz']
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case16_2(self):
        logger.debug("In testcase 16_2 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ^f04baz?$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^f04baz?$'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f04ba", "f04baz"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case17(self):
        logger.debug("In testcase 17 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  foo.bar")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  foo.bar'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['foo.bar']
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case17_1(self):
        logger.debug("In testcase 17_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^foo.bar$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^foo.bar$'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["foo.bar"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case18(self):
        logger.debug("In testcase 18 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  .*foo.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  .*foo.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['foo.bar', 'barfoo', '/foo=/node=barney', '/foo=bar/node=foo', '/foo=bar/node=baz',
                         '/foo=bar/node=bar', '/foo=baz/node=bar', '/foo=baz/node=foo', '/foo=baz/node=baz']
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case18_1(self):
        logger.debug("In testcase 18_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (.*foo.* MINUS /foo.*)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (.*foo.* MINUS /foo=.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["foo.bar", "barfoo"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case19(self):
        logger.debug("In testcase 19 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^[a-z]{3}.b.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^[a-z]{3}.b.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["foo.bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case19_1(self):
        logger.debug("In testcase 19 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  [a-z]{3}.b.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  [a-z]{3}.b.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['foo.bar', '/foo=/node=barney', '/foo=bar/node=foo', '/foo=bar/node=baz',
                         '/foo=bar/node=bar', '/foo=baz/node=bar', '/foo=baz/node=foo', '/foo=baz/node=baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case20(self):
        logger.debug("In testcase 20 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT  (f00bar,^f04.*)")
        exp = 'INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (^f00bar$,^f04.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f04bar', 'f04barbuh', 'f04ba', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case20_1(self):
        logger.debug("In testcase 20_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar,f04.*)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar,f04.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', 'f04barbuh', 'f04ba', '/app=1/node=f00bar', '/app=3/node=f04bar', 'f04baz', 'f00bar']
        self.assertItemsEqual(self.result, self.expected)

    def test_case20_2(self):
        logger.debug("In testcase 20_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar,^f04.*)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar,^f04.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', 'f04barbuh', 'f04ba', '/app=1/node=f00bar', 'f04baz', 'f00bar']
        self.assertItemsEqual(self.result, self.expected)

    # tag-value test cases
    def test_case22(self):
        logger.debug("In testcase 22 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar INTERSECT f04.*)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00bar INTERSECT f04.*)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case23(self):
        logger.debug("In testcase 23 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (f00.* - f00baz)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (f00.* - f00baz)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f000bar', 'f000barz', '/app=1/node=f00bar']
        self.assertItemsEqual(self.result, self.expected)

    def test_case23_1(self):
        logger.debug("In testcase 23_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (^f00.* - f00baz)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (^f00.* - f00baz)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f000bar', 'f000barz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case24(self):
        logger.debug("In testcase 24 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (^f00.* MINUS f00baz)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (^f00.* MINUS f00baz)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f000bar', 'f000barz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case25(self):
        logger.debug("In testcase 25 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=()")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node=()"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case26(self):
        logger.debug("In testcase 26 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=(foo)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node=(foo)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=baz/node=foo"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case27(self):
        logger.debug("In testcase 27 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=(foo|bar)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node=(foo|bar)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=baz/node=foo", "/foo=bar/node=bar", "/foo=baz/node=bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case28(self):
        logger.debug("In testcase 28 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node=()")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node=()"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case29(self):
        logger.debug("In testcase 29 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node=(foo)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node=(foo)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case30(self):
        logger.debug("In testcase 30 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node=(foo|bar)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node=(foo|bar)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case31(self):
        logger.debug("In testcase 31 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=()")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node!=()"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=foo", "/foo=baz/node=foo", "/foo=bar/node=bar",
                         "/foo=baz/node=bar",  "/foo=bar/node=baz", "/foo=baz/node=baz", "/app=3/node=f04bar",
                         "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case32(self):
        logger.debug("In testcase 32 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=(foo)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node!=(foo)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz",
                         "/app=3/node=f04bar", "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case33(self):
        logger.debug("In testcase 33 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=fo.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node!=fo.*"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz",
                         "/app=3/node=f04bar", "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case34(self):
        logger.debug("In testcase 34 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=f.*o")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node!=f.*o"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz",
                         "/app=3/node=f04bar", "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case35(self):
        logger.debug("In testcase 35 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=[a-z]{2}o")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=[a-z]{2}o'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz",
                         "/app=3/node=f04bar", "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case36(self):
        logger.debug("In testcase 36 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=(foo|bar)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/node!=(foo|bar)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=baz", "/foo=baz/node=baz", "/app=3/node=f04bar",
                         "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case37(self):
        logger.debug("In testcase 37 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=()")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node!=()"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case38(self):
        logger.debug("In testcase 38 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=(foo)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node!=(foo)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case39(self):
        logger.debug("In testcase 39 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=(foo|bar)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=bar/node!=(foo|bar)"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case40(self):
        logger.debug("In testcase 40 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^/foo=ba.$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^/foo=ba.$'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case40_1(self):
        logger.debug("In testcase 40_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=ba.")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=ba.'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case41(self):
        # Works wrong in server
        logger.debug("In testcase 41 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^/node=baz/foo=ba.$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ^/node=baz/foo=ba.$'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case42(self):
        logger.debug("In testcase 42 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=ba.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=ba.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=baz/node=foo", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case43(self):
        logger.debug("In testcase 43 -(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (/foo=ba.* UNION /node=baz/foo=ba.)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (/foo=ba.* UNION /node=baz/foo=ba.)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=baz/node=foo", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case44(self):
        logger.debug("In testcase 44 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=ba.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=ba.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case45(self):
        logger.debug("In testcase 45 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=barx?")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=barx?"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case46(self):
        logger.debug("In testcase 46 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=barx?")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=barx?'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case47(self):
        # Works wrong in server self.expected = ["/foo=/node=barney"]
        logger.debug("In testcase 47 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo="'
        self.assertRaises(ValueError, parser, exp)

    def test_case48(self):
        # Works wrong in server self.expected = ["/foo=/node=barney"]
        logger.debug("In testcase 48 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (/foo=,/foo=)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (/foo=,/foo=)'
        self.assertRaises(ValueError, parser, exp)

    def test_case49(self):
        # Works wrong in server self.expected = ["/foo=/node=barney"]
        logger.debug("In testcase 49 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=/node=.*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=/node=.*"'
        self.assertRaises(ValueError, parser, exp)

    def test_case50(self):
        # Works wrong in server self.expected = []
        logger.debug("In testcase 50 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=/node=bar")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  "/foo=/node=bar"'
        self.assertRaises(ValueError, parser, exp)

    def test_case51(self):
        logger.debug("In testcase 51 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  .*")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ".*"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f04barbuh",
                         "/foo=baz/node=bar",
                         "f00baz",
                         "f000bar",
                         "f00bar",
                         "/foo=/node=barney",
                         "/foo=baz/node=foo",
                         "/foo=baz/node=baz",
                         "/foo=bar/node=bar",
                         "foo.bar",
                         "/foo=bar/node=baz",
                         "/foo=bar/node=foo",
                         "f04baz",
                         "f04bar",
                         "f04ba",
                         "barfoo",
                         "f000barz",
                         "/app=1/node=f00bar",
                         "/app=2/node=f00baz",
                         "/app=3/node=f04bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case52(self):
        logger.debug("In testcase 52 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (/node=.* MINUS /node=foo)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ("/node=.*" MINUS "/node=foo")'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=baz/node=bar", "/foo=/node=barney", "/foo=baz/node=baz",
                         "/foo=bar/node=bar",  "/foo=bar/node=baz", "/app=1/node=f00bar",
                         "/app=2/node=f00baz", "/app=3/node=f04bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case53(self):
        logger.debug(
            'In testcase 53 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  EXPAND("/app=[123]/node=<>",ANY(.*))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  EXPAND("/app=[123]/node=<>",ANY(.*))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/app=1/node=f00bar", "/app=3/node=f04bar", "/app=2/node=f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case53_1(self):
        logger.debug(
            'In testcase 53_1 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  EXPAND("/app=[123]/node=<>",/foo=)')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  EXPAND("/app=[123]/node=<>",/foo=)'
        self.assertRaises(ValueError, parser, exp)

    def test_case54(self):
        logger.debug(
            'In testcase 54 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) UNION ANY(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) UNION ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/app=1/node=f00bar", "/app=3/node=f04bar", "/app=2/node=f00baz", "f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case55(self):
        logger.debug(
            'In testcase 55 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) INTERSECT ANY(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) INTERSECT ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case56(self):
        logger.debug(
            'In testcase 56 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) INTERSECT ANY(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (EXPAND("/app=[123]/node=<>",ANY(.*)) INTERSECT ~group1)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case57(self):
        logger.debug("In testcase 57 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ANY(    group1)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ANY(    group1)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    # test-cases for case-insensitivity

    def test_case58(self):
        logger.debug(
            'In testcase 58 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPAND("/app=[123]/node=<>",ANY(.*)))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPAND("/app=[123]/node=<>",ANY(.*)))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/app=1/node=f00bar", "/app=3/node=f04bar", "/app=2/node=f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case59(self):
        logger.debug(
            'In testcase 59 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (Expand("/app=[123]/node=<>",aNy(.*)) Union ANY(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (Expand("/app=[123]/node=<>",aNy(.*)) Union ANY(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/app=1/node=f00bar", "/app=3/node=f04bar", "/app=2/node=f00baz", "f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case60(self):
        logger.debug(
            'In testcase 60 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPAnd("/app=[123]/node=<>",aNy(.*)) inTERsect aNy(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPAnd("/app=[123]/node=<>",aNy(.*)) inTERsect aNy(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case61(self):
        logger.debug(
            'In testcase 61 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPand("/app=[123]/node=<>",ANy(.*)) intersect ANy(group1))')
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  (exPand("/app=[123]/node=<>",ANy(.*)) intersect ANy(group1))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case62(self):
        logger.debug("In testcase 62 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  any(    group1)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  any(    group1)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["f00baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case63(self):
        logger.debug("In testcase 63 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  all(gr1[0|1])")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  all(gr1[0|1])'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case64(self):
        logger.debug("In testcase 64 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  aLL(gr10)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  aLL(gr10)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        self.assertItemsEqual(self.result, self.expected)

    # single quote test cases
    def test_case65(self):
        logger.debug("In testcase 65 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node!=(foo|bar)")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/node!=(foo|bar)'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=/node=barney", "/foo=bar/node=baz", "/foo=baz/node=baz", "/app=3/node=f04bar",
                         "/app=2/node=f00baz", "/app=1/node=f00bar"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case66(self):
        logger.debug("In testcase 66 - SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=()")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=bar/node!=()'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case67(self):
        logger.debug("In testcase 67 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=(foo)")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=bar/node!=(foo)'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case68(self):
        logger.debug("In testcase 68 - SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=bar/node!=(foo|bar)")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=bar/node!=(foo|bar)'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case69(self):
        logger.debug("In testcase 69 - SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=ba.")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=ba.'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case70(self):
        logger.debug("In testcase 70 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=ba.")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/node=baz/foo=ba.'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = []
        self.assertItemsEqual(self.result, self.expected)

    def test_case71(self):
        logger.debug("In testcase 71 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT /foo=ba.*")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=ba.*'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=baz/node=foo", "/foo=bar/node=bar", "/foo=baz/node=bar",
                         "/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case72(self):
        logger.debug("In testcase 72 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=ba.*")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/node=baz/foo=ba.*'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case73(self):
        logger.debug("In testcase 73 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=barx?")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=barx?'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case74(self):
        logger.debug("In testcase 74 - SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /node=baz/foo=barx?")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/node=baz/foo=barx?'"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case75(self):
        logger.debug("In testcase 75 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo='")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo='"
        self.assertRaises(ValueError, parser, exp)

    def test_case76(self):
        logger.debug("In testcase 76 -SQ (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=/node=.*")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=/node=.*'"
        self.assertRaises(ValueError, parser, exp)

    def test_case77(self):
        logger.debug("In testcase 77 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  /foo=/node=bar")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  '/foo=/node=bar'"
        self.assertRaises(ValueError, parser, exp)

    def test_case78(self):
        logger.debug(
            "In testcase 78 -SQ - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ('/foo=bar/node!=(foo)' UNION '/foo=ba.*')")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ('/foo=bar/node!=(foo)' UNION '/foo=ba.*')"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=bar", "/foo=bar/node=baz", "/foo=bar/node=foo",
                         "/foo=baz/node=foo", "/foo=baz/node=bar", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    # negative test cases
    def test_case79(self):
        logger.debug("In testcase 79 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ANY()")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ANY()"
        self.assertRaises(ValueError, parser, exp)

    def test_case80(self):
        logger.debug("In testcase 80 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  'foo UNION'")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  'foo UNION'"
        self.assertRaises(ValueError, parser, exp)

    def test_case81(self):
        logger.debug("In testcase 81 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ANY(group1")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT  ANY(group1"
        self.assertRaises(ValueError, parser, exp)

    def test_case82(self):
        logger.debug("In testcase 82 - (INSTANCE(ins2) INTERSECT LOCALE(dc2))")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2))"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'barfoo', '/foo=bar/node=bar', '/foo=baz/node=bar', '/app=1/node=f00bar', '/app=3/node=f04bar', 'foo.bar',
                         '/foo=/node=barney', '/foo=baz/node=baz', 'f04ba', 'f000barz', '/foo=bar/node=foo', '/foo=baz/node=foo', 'f04barbuh', '/foo=bar/node=baz', '/app=2/node=f00baz', 'f000bar', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case83(self):
        logger.debug("In testcase 83 - (INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ''")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT ''"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'barfoo', '/foo=bar/node=bar', '/foo=baz/node=bar', '/app=1/node=f00bar', '/app=3/node=f04bar', 'foo.bar',
                         '/foo=/node=barney', '/foo=baz/node=baz', 'f04ba', 'f000barz', '/foo=bar/node=foo', '/foo=baz/node=foo', 'f04barbuh', '/foo=bar/node=baz', '/app=2/node=f00baz', 'f000bar', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case84(self):
        logger.debug("In testcase 84 - ")
        exp = "           "
        self.assertRaises(ValueError, parser, exp)

    def test_case21(self):
        # look arounds doesnt work in ES engine; server query was f00bar,"f04((?!z).)*"
        # Expected Result -> ['f00bar', 'f04bar', 'f04barbuh', 'f04ba', '/app=3/node=f04bar']
        logger.debug("In testcase 21 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (^f00bar$,^f04[^z]*$)")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (^f00bar$,^f04[^z]*$)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f04bar', 'f04barbuh', 'f04ba']
        self.assertItemsEqual(self.result, self.expected)

    def test_case85(self):
        logger.debug("In testcase 85 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT ^.*f04.*&~(.*z.*)$")
        exp = '(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT "^.*f04.*&~(.*z.*)$"'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', '/app=3/node=f04bar', 'f04ba', 'f04barbuh']
        self.assertItemsEqual(self.result, self.expected)

    def test_case86(self):
        logger.debug("In testcase 86 - INSTANCE(ins2) INTERSECT LOCALE(dc2) INTERSECT (^f00bar$,'^f04.*&~(.*z)$')")
        exp = "(INSTANCE(ins2) INTERSECT LOCALE(dc2)) INTERSECT (^f00bar$,'^f04.*&~(.*z)$')"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f04bar', 'f04barbuh', 'f04ba', 'f00bar']
        self.assertItemsEqual(self.result, self.expected)

    def test_case87(self):
        logger.debug("In testcase 87 - ANY('')")
        exp = "ANY('')"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)

    # deprecated syntax test cases - translator 2 (ronan's syntax)
    def test_case88(self):
        logger.debug("In testcase 88 - i:ins2 l:dc2 ~group1")
        exp = 'i:ins2 l:dc2 ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case89(self):
        logger.debug("In testcase 89- instance:ins2 AND l:dc2 ~group.*")
        exp = 'instance:ins2 AND l:dc2 ~group.*'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case90(self):
        logger.debug("In testcase 90 - i:ins2 AND l:dc2 AND ~keygroup5=group5")
        exp = 'i:ins2 AND l:dc2 AND ~keygroup5=group5'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f04baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case91(self):
        logger.debug("In testcase 91 - i:ins2 AND l:dc2 ~keygroup5=group.*")
        exp = 'i:ins2 AND l:dc2 ~keygroup5=group.*'
        query = parser(exp)
        logger.debug("Query:")
        logger.debug(query.to_dict())
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f04baz", "foo.bar", "f04barbuh", "f000bar"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case92(self):
        logger.debug("In testcase 92 - instance:ins2 AND l:dc2 AND ~.*")
        exp = 'instance:ins2 AND l:dc2 AND ~.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'f000bar', 'f04barbuh', 'f000barz', 'barfoo', 'foo.bar', '/foo=/node=barney', '/foo=bar/node=foo', '/foo=bar/node=baz', 'f04ba',
                         '/foo=bar/node=bar', '/app=1/node=f00bar', '/foo=baz/node=bar', '/app=3/node=f04bar', 'f04baz', '/foo=baz/node=foo', '/foo=baz/node=baz', '/app=2/node=f00baz']
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case93(self):
        logger.debug("In testcase 93 - i:ins2 AND l:dc2 AND ~group.* AND ~group1")
        exp = 'i:ins2 AND l:dc2 AND ~group.* AND ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case94(self):
        logger.debug("In testcase 94 - i:ins2 l:dc2 ~group0 OR ~group9")
        exp = 'i:ins2 l:dc2 ~group0 OR ~group9'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f000barz"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case95(self):
        logger.debug("In testcase 95 - i:ins2 AND l:dc2 AND ~group.* OR ~group1")
        exp = 'i:ins2 AND l:dc2 AND ~group.* OR ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case96(self):
        logger.debug("In testcase 96 - i:ins2 AND l:dc2 ~group.* OR ~group1")
        exp = 'i:ins2 AND l:dc2 ~group.* OR ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00bar", "f00baz", "f04bar", "f000barz", "f000bar", "f04barbuh"]
        logger.debug("Expected Result:")
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case97(self):
        logger.debug("In testcase 97 - i:ins2 AND l:dc2 AND ~group[1|2]")
        exp = 'i:ins2 AND l:dc2 AND ~group[1|2]'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        self.expected = ["f00baz", "f000bar"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case98(self):
        logger.debug("In testcase 98 - instance:ins2 AND locale:dc2 AND ~gr1[0|1]")
        exp = 'instance:ins2 AND locale:dc2 AND ~gr1[0|1]'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["barfoo"]
        logger.debug(self.expected)
        self.assertItemsEqual(self.result, self.expected)

    def test_case99(self):
        logger.debug("In testcase 99 - i:ins2 AND l:dc2 AND ")
        exp = "i:ins2 AND l:dc2 AND "
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'barfoo', '/foo=bar/node=bar', '/foo=baz/node=bar', '/app=1/node=f00bar', '/app=3/node=f04bar', 'foo.bar',
                         '/foo=/node=barney', '/foo=baz/node=baz', 'f04ba', 'f000barz', '/foo=bar/node=foo', '/foo=baz/node=foo', 'f04barbuh', '/foo=bar/node=baz', '/app=2/node=f00baz', 'f000bar', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case100(self):
        logger.debug("In testcase 100 -SQ - i:ins2 AND l:dc2 AND /node=baz/foo=ba.*")
        exp = "i:ins2 AND l:dc2 AND /node=baz/foo=ba.*"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case101(self):
        logger.debug("In testcase 101 -SQ - instance:ins2 l:dc2 /foo=barx?")
        exp = "instance:ins2 l:dc2 /foo=barx?"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=foo", "/foo=bar/node=bar", "/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case102(self):
        logger.debug("In testcase 102 - SQ - i:ins2 l:dc2 AND /node=baz/foo=barx?")
        exp = "i:ins2 l:dc2 AND /node=baz/foo=barx?"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case103(self):
        logger.debug("In testcase 103 -SQ - i:ins2 l:dc2 /foo=")
        exp = "i:ins2 l:dc2 /foo="
        self.assertRaises(ValueError, parser, exp)

    def test_case104(self):
        logger.debug("In testcase 104 -SQ i:ins2 AND l:dc2 AND /foo=/node=.*")
        exp = "i:ins2 AND l:dc2 AND /foo=/node=.*"
        self.assertRaises(ValueError, parser, exp)

    def test_case105(self):
        logger.debug("In testcase 105 -SQ - i:ins2 AND l:dc2 AND /foo=/node=bar")
        exp = "i:ins2 AND l:dc2 AND /foo=/node=bar"
        self.assertRaises(ValueError, parser, exp)

    def test_case106(self):
        logger.debug(
            "In testcase 106 -SQ - i:ins2 AND l:dc2 AND /foo=bar/node!=(foo) OR /foo=ba.*")
        exp = "i:ins2 AND l:dc2 AND /foo=bar/node!=(foo) OR /foo=ba.*"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ["/foo=bar/node=bar", "/foo=bar/node=baz", "/foo=bar/node=foo",
                         "/foo=baz/node=foo", "/foo=baz/node=bar", "/foo=baz/node=baz"]
        self.assertItemsEqual(self.result, self.expected)

    def test_case107(self):
        logger.debug(
            "In testcase 107 -SQ - i:ins2,!ins1")
        exp = "i:ins2,!ins1"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['f00bar', 'f00baz', 'f04bar', 'barfoo', '/foo=bar/node=bar', '/foo=baz/node=bar', '/app=1/node=f00bar', '/app=3/node=f04bar', 'foo.bar', '/foo=/node=barney',
                         '/foo=baz/node=baz', 'f04ba', 'f000barz', '/foo=bar/node=foo', '/foo=baz/node=foo', 'f04barbuh', '/foo=bar/node=baz', '/app=2/node=f00baz', 'f000bar', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    def test_case108(self):
        logger.debug(
            "In testcase 108 -SQ - locale:dc1,dc2")
        exp = "locale:dc1,dc2"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['fakenode5.apple.com', 'fakenode7.apple.com', '/key1=value1/key2=value2/key3=value3', '/key2=value4/key4=value4/key1=value1', '/key1=value1/key5=nodetest2', 'f00bar', 'f00baz', 'f04bar', 'barfoo', '/foo=bar/node=bar', '/foo=baz/node=bar', '/app=1/node=f00bar', '/app=3/node=f04bar', 'fakenode9.apple.com', '/key1=value1/key5=nodetest4', '/key1=value2/key2=value22', 'foo.bar', '/foo=/node=barney', '/foo=baz/node=baz', 'fakenode2.apple.com', 'fakenode3.apple.com',
                         'fakenode6.apple.com', 'fakenode8.apple.com', '/key1=value1', 'nodetest3', 'nodetest4', '/key1=value1/key5=nodetest1', '/key1=value1/key5=nodetest3', '/key1=value2/key2=value2', 'f04ba', 'f000barz', '/foo=bar/node=foo', '/foo=baz/node=foo', 'fakenode1.apple.com', 'fakenode10.apple.com', 'nodetest1', 'nodetest2', 'f04barbuh', '/foo=bar/node=baz', '/app=2/node=f00baz', 'fakenode0.apple.com', 'fakenode4.apple.com', '/key1=value1/key4=value4', '/key1=value11/key5=nodetest4', 'f000bar', 'f04baz']
        self.assertItemsEqual(self.result, self.expected)

    # deprecated syntax test cases - translator 1 (ryan's syntax)
    def test_case109(self):
        logger.debug(
            "In testcase 109 -SQ - ~gr1[0|1]:enum:intersect")
        exp = "~gr1[0|1]:enum:intersect"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['barfoo']
        self.assertItemsEqual(self.result, self.expected)

    def test_case110(self):
        logger.debug(
            "In testcase 110 -SQ - ~gr1[0|1]:intersect")
        exp = "~gr1[0|1]:intersect"
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        search_obj = Alert().search().query(query)
        count = search_obj.count()
        response = search_obj[0:count].execute()
        logger.debug("total nodes(hits):" + " " + str(response.hits.total))
        self.result = [dic_obj['_source']['node'] for dic_obj in response.hits.hits]
        logger.debug("Result:")
        logger.debug(self.result)
        logger.debug("Expected:")
        self.expected = ['barfoo']
        self.assertItemsEqual(self.result, self.expected)
