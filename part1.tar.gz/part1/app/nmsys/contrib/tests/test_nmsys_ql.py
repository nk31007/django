__author__ = 'nikita'

# For you reader, all regexp queries in ES are anchored, never let double-anchoring happening !

import logging
from django.test import TestCase
from contrib.resource.search_ply import *
logger = logging.getLogger('django')
from elasticsearch_dsl import Search
from elasticsearch_dsl import Q


class AlertSearchTestCase(TestCase):

    def setUp(self):
        self.total_count = 0
        self.result = []
        self.expected = []
    
    # Positive test cases
    def test_case0(self):
        logger.debug("In testcase 0 - alert(fakealert)")
        exp = 'alert(fakealert)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "regexp": {
                            "alert": "fakealert"
                          }
                        }, query.to_dict())
    
    
    def test_case1(self):
        logger.debug("In testcase 1 - any(fakegroup1)")
        exp = 'any(fakegroup1)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                            "terms": {
                            "node": [
                              "fakenode0.apple.com",
                              "fakenode1.apple.com"
                            ]
                        }
                    }, query.to_dict())

    def test_case2(self):
        logger.debug("In testcase 2 - NODE(any(fakegroup1)) union any(fakegroup2)")
        exp = 'NODE(any(fakegroup1)) union any(fakegroup2)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case3(self):
        logger.debug("In testcase 3 - pif.paf(pof)")
        exp = 'pif.paf(pof)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "nested": {
                            "path": "pif",
                            "query": {
                              "regexp": {
                                "pif.paf": "pof"
                              }
                            }
                          }
                        },query.to_dict())

    def test_case4(self):
        logger.debug('In testcase 4 - pif.paf("pof")')
        exp = 'pif.paf("pof")'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "nested": {
                            "path": "pif",
                            "query": {
                              "regexp": {
                                "pif.paf": "pof"
                              }
                            }
                          }
                        },query.to_dict())

    def test_case5(self):
        logger.debug("In testcase 5 - Node(nk11a00is-nmsys001.isg.apple.com)")
        exp = 'Node(nk11a00is-nmsys001.isg.apple.com)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "regexp": {
                            "node": "nk11a00is-nmsys001.isg.apple.com"
                          }
                        }, query.to_dict())


    def test_case6(self):
        logger.debug("In testcase 6 - Node(~verdad.tag=epic-nmsys-cluster) intersect ALERT(memory)")
        exp = 'Node(~verdad.tag=epic-nmsys-cluster) intersect ALERT(memory)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "regexp": {
                                  "alert": "memory"
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    # old-new syntax translate test cases
    def test_case7(self):
        logger.debug("In testcase 7 - instance:ins2 locale:dc2 ~group1")
        exp = 'instance:ins2 locale:dc2 ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case8(self):
        logger.debug("In testcase 8 - i:ins2 l:dc2 ~group1")
        exp = 'i:ins2 l:dc2 ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case9(self):
        logger.debug("In testcase 9 - instance:ins2 AND l:dc2 ~group.*")
        exp = 'instance:ins2 AND l:dc2 ~group.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case10(self):
        logger.debug("In testcase 10 - i:ins2 AND l:dc2 AND ~keygroup5=group5")
        exp = 'i:ins2 AND l:dc2 AND ~keygroup5=group5'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case11(self):
        logger.debug("In testcase 11 - i:ins2 AND l:dc2 ~keygroup5=group.*")
        exp = 'i:ins2 AND l:dc2 ~keygroup5=group.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case12(self):
        logger.debug("In testcase 12 - instance:ins2 AND l:dc2 AND ~.*")
        exp = 'instance:ins2 AND l:dc2 AND ~.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                          }, query.to_dict())

    def test_case13(self):
        logger.debug("In testcase 13 - i:ins2 AND l:dc2 AND ~group.* AND ~group1")
        exp = 'i:ins2 AND l:dc2 AND ~group.* AND ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "terms": {
                                        "node": [
                                          "fakenode0.apple.com",
                                          "fakenode1.apple.com"
                                        ]
                                      }
                                    },
                                    {
                                      "bool": {
                                        "must": [
                                          {
                                            "regexp": {
                                              "locale": "dc2"
                                            }
                                          },
                                          {
                                            "regexp": {
                                              "instance": "ins2"
                                            }
                                          }
                                        ]
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case14(self):
        logger.debug("In testcase 14 - i:ins2 l:dc2 ~group0 OR ~group9")
        exp = 'i:ins2 l:dc2 ~group0 OR ~group9'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "terms": {
                                        "node": [
                                          "fakenode0.apple.com",
                                          "fakenode1.apple.com"
                                        ]
                                      }
                                    },
                                    {
                                      "bool": {
                                        "must": [
                                          {
                                            "regexp": {
                                              "locale": "dc2"
                                            }
                                          },
                                          {
                                            "regexp": {
                                              "instance": "ins2"
                                            }
                                          }
                                        ]
                                      }
                                    }
                                  ]
                                }
                              },
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case15(self):
        logger.debug("In testcase 15 - i:ins2 AND l:dc2 AND ~group.* OR ~group1")
        exp = 'i:ins2 AND l:dc2 AND ~group.* OR ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "terms": {
                                        "node": [
                                          "fakenode0.apple.com",
                                          "fakenode1.apple.com"
                                        ]
                                      }
                                    },
                                    {
                                      "bool": {
                                        "must": [
                                          {
                                            "regexp": {
                                              "locale": "dc2"
                                            }
                                          },
                                          {
                                            "regexp": {
                                              "instance": "ins2"
                                            }
                                          }
                                        ]
                                      }
                                    }
                                  ]
                                }
                              },
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case16(self):
        logger.debug("In testcase 16 - i:ins2 AND l:dc2 ~group.* OR ~group1")
        exp = 'i:ins2 AND l:dc2 ~group.* OR ~group1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "terms": {
                                        "node": [
                                          "fakenode0.apple.com",
                                          "fakenode1.apple.com"
                                        ]
                                      }
                                    },
                                    {
                                      "bool": {
                                        "must": [
                                          {
                                            "regexp": {
                                              "locale": "dc2"
                                            }
                                          },
                                          {
                                            "regexp": {
                                              "instance": "ins2"
                                            }
                                          }
                                        ]
                                      }
                                    }
                                  ]
                                }
                              },
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case17(self):
        logger.debug("In testcase 17 - i:ins2 AND l:dc2 AND ~group[1|2]")
        exp = 'i:ins2 AND l:dc2 AND ~group[1|2]'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case18(self):
        logger.debug("In testcase 18 - instance:ins2 AND locale:dc2 AND ~gr1[0|1]")
        exp = 'instance:ins2 AND locale:dc2 AND ~gr1[0|1]'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "terms": {
                                  "node": [
                                    "fakenode0.apple.com",
                                    "fakenode1.apple.com"
                                  ]
                                }
                              },
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "locale": "dc2"
                                      }
                                    },
                                    {
                                      "regexp": {
                                        "instance": "ins2"
                                      }
                                    }
                                  ]
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case19(self):
        logger.debug("In testcase 19 - i:ins2 AND l:dc2 AND n:/foo=bar/node!=(foo) OR  n:/foo=ba.*")
        exp = 'i:ins2 AND l:dc2 AND n:/foo=bar/node!=(foo) OR  n:/foo=ba.*'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "bool": {
                                  "must": [
                                    {
                                      "regexp": {
                                        "node": "/foo=bar/node!=(foo)"
                                      }
                                    },
                                    {
                                      "bool": {
                                        "must": [
                                          {
                                            "regexp": {
                                              "locale": "dc2"
                                            }
                                          },
                                          {
                                            "regexp": {
                                              "instance": "ins2"
                                            }
                                          }
                                        ]
                                      }
                                    }
                                  ]
                                }
                              },
                              {
                                "regexp": {
                                  "node": "/foo=ba.*"
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    def test_case20(self):
        logger.debug("In testcase 20 - i:ins2,ins1")
        exp = 'i:ins2,ins1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "should": [
                              {
                                "regexp": {
                                  "instance": "ins2"
                                }
                              },
                              {
                                "regexp": {
                                  "instance": "ins1"
                                }
                              }
                            ]
                          }
                        }, query.to_dict())


    def test_case21(self):
        logger.debug("In testcase 21 - i:ins2,!ins1")
        exp = 'i:ins2,!ins1'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must_not": [
                              {
                                "regexp": {
                                  "instance": "ins1"
                                }
                              }
                            ],
                            "must": [
                              {
                                "regexp": {
                                  "instance": "ins2"
                                }
                              }
                            ]
                          }
                        }, query.to_dict())


    def test_case22(self):
        logger.debug("In testcase 22 - a.b:nikita instance:nikita2")
        exp = 'a.b:nikita instance:nikita2'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})
        self.assertEqual({
                          "bool": {
                            "must": [
                              {
                                "nested": {
                                  "path": "a",
                                  "query": {
                                    "regexp": {
                                      "a.b": "nikita"
                                    }
                                  }
                                }
                              },
                              {
                                "regexp": {
                                  "instance": "nikita2"
                                }
                              }
                            ]
                          }
                        }, query.to_dict())

    # Negative test cases
    def test_case10(self):
        logger.debug("In testcase 10 - pif(admin) union epaf(epic)")
        exp = 'pif(admin) union epaf(epic)'
        self.assertRaises(ValueError, parser, exp)

    def test_case11(self):
        logger.debug("In testcase 11 - pif(admin) intersect epaf(epic)")
        exp = 'pif(admin) intersect epaf(epic)'
        self.assertRaises(ValueError, parser, exp)

    def test_case12(self):
        logger.debug("In testcase 12 - pif()")
        exp = 'pif()'
        self.assertRaises(ValueError, parser, exp)
    
    '''
    def test_case22(self):
        logger.debug("In testcase 22 - node(any(nikita))")
        exp = 'node(any(nikita))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})

    def test_case22(self):
        logger.debug("In testcase 22 - node(alert(nikita))")
        exp = 'node(alert(nikita))'
        self.assertRaises(ValueError, parser, exp)


    def test_case22(self):
        logger.debug("In testcase 22 - node(any(nikita) union instance(nikita))")
        exp = 'node(any(nikita) union instance(nikita))'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})


    def test_case22(self):
        logger.debug("In testcase 22 - node(nikita)")
        exp = 'node(nikita)'
        query = parser(exp)
        logger.debug("Query: ")
        logger.debug({'query': query.to_dict()})

    '''


    



    


