__author__ = 'nmsys'
from contrib.explode import epic_url_parser, epic_call, explode_epic, explode_nmsys_plugin, explode_nmsys
from django.utils.http import urlquote
# Python
import unittest
import logging
# Django


class MyTestCase(unittest.TestCase):
    fixtures = ['alert.json']

    def setUp(self):
        logging.disable(logging.CRITICAL)

        self.various_urls = [
            'https://epic.isg.apple.com/i/adminsys@nk11/element?gr=sysstat_cpu&n=nk11a00is-nmsys.*.isg.apple.com&e=1517334375&title=CPU%20Utilization%20(%25)&h=120&w=360&u=100&l=0&high_water=0&low_water=0&slope_mode=true&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&no_title=1&no_border=1&gr=&a=graph&origin=adminsys%40nk11',
            'https://epic.isg.apple.com/i/adminsys@nk11/element?a=graph&expand=0&origin=adminsys%40nk11&title=Alert%20Update%20per%20Instance&n=nmsys.isg.apple.com&order=last%3Adesc&ds=alert_updated_instance.*%3Atitle%3D-&e=1517264335&s=1517242735&%24defaults=&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&no_title=1&no_border=1&no_controls=0',
            'https://epic.isg.apple.com/api/server/adminsys@nk11/?gr=sysstat_cpu&a=json&n=nk11a00is-nmsys001.isg.apple.com&origin=adminsys%40nk11&e=1517334375&s=1517312775&%24defaults=&no_title=0&v=4&X=1'
            'https://nk11-epic.isg.apple.com/epic-adminsys/?p=view-graph&n=nmsys.isg.apple.com&ds=nmsysserver_queue.*&f=3hours&graph=1&order=last:desc',
            'https://epic.isg.apple.com/i/adminsys@nk11/element?a=g&n=nmsys.isg.apple.com&ds=nmsysinternal_internal_alert_count',
            'https://nk11-epic.isg.apple.com/adminsys?a=g&md5=e12bf5044dab8d2ab8197864217ab893',
            'https://nk11-epic.isg.apple.com/epic-adminsys/?p=view-graph&gr=ServerCpu&no_legend=1&h=60&w=360&&ng=nk11_a00is_nmsys&e=2018/01/30%2009:59&h=180&w=480&summary=&no_legend=1&graph=1&table=1',
            'https://nk11-epic.isg.apple.com/epic-adminsys/default/view-graph.php?&h=180&w=480&no_legend=1&graph=1&table=1&ng=nk11_a00is_nmsys&n=&ds=sysstat_cpu.all.total.percent:color=ff0000:title=Total%20CPU&m=&title=Total%20CPU&s=2018/01/28%2010:00&e=2018/01/30%2009:59&cts=1517335333.21574',
            'https://nk11-epic.isg.apple.com/epic-adminsys/?p=view-page&h=180&w=480&no_legend=1&graph=1&table=1&ng=nk11_a00is_nmsys&ds=sysstat_cpu.all.total.percent:color=ff0000:title=Total+CPU&title=Total%20CPU&s=2018/01/28%2010:00&e=2018/01/30%2009:59&cts=1517335333.21574&f=172740&c=2018/01/29%2009:59&pd=&filter=&explode=1',
            'https://nk11-epic.isg.apple.com/adminsys?a=json&md5=410cff60cbe479e3f9a6a4957835ddf9&X=1'
            'https://epic.isg.apzones.com/i/gnsnet@ty51/element?n=xagya1-103-01-04-ks-edg-gw1.istnet.net&origin=gnsnet%40ty51&a=graph&ds=ifinerrors.*&title=CpuUtil%20%25&h=270&w=720&high_water=0&low_water=0&slope_mode=true&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&no_graph=0&no_legend=0&no_border=1&no_controls=0',
        ]

    def test_qa_special(self):
        i = 'https://epic.isg.apple.com/i/gnsnet@pv31_qa/element?n=xagya1-103-01-04-ks-edg-gw1.istnet.net&origin=gnsnet%40ty51&a=graph&ds=ifinerrors.*&title=CpuUtil%20%25&h=270&w=720&high_water=0&low_water=0&slope_mode=true&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&no_graph=0&no_legend=0&no_border=1&no_controls=0'
        params, url, instance = epic_url_parser(urlquote(i))
        content = epic_call(url, instance, params)
        self.assertTrue(self.check_result(content, True))

    def test_qa_special_direct_UI(self):
        i = 'https://pv31_qa-epic.isg.apple.com/epic-ifsys?%24defaults=&a=graph&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&ds=sysstat_loadavg.1%3Atitle%3D%20&h=270&m=expand&n=vp21q01wd-ztbu23054401.carnival.apple.com&no_border=1&no_controls=0&no_graph=0&no_legend=0&summary=avg&w=720&s=1580317948&e=1580339548&no_title='
        params, url, instance = epic_url_parser(urlquote(i))
        content = epic_call(url, instance, params)
        self.assertTrue(self.check_result(content, True))

    def test_silkroad(self):
        i = 'https://epic-usmsc12a.sgsin06.app.apzones.com/i/gnsnet@sr01/element?n=gnsnet-db-0.gnsnet-db.epic-production.svc.kube.usmsc12e.k8s.cloud.silu.net&origin=gnsnet%40sr01&a=graph&ds=ping_rtt_ms&title=Ping%20(ms)&h=270&w=720&high_water=0&low_water=0&slope_mode=true&color=BACK%3AFFFFFF%2CSHADEA%3AFFFFFF%2CSHADEB%3AFFFFFF&m=avg&no_graph=0&no_legend=0&no_border=1&no_controls=0'
        params, url, instance = epic_url_parser(urlquote(i))
        content = epic_call(url, instance, params)
        #self.assertTrue(self.check_result(content, True))

    def check_params(self, dd):
        if 'md5' in dd:
            return True
        if 'n' not in dd and 'ng' not in dd:
            return False
        if 'gr' not in dd and 'ds' not in dd:
            return False
        return True

    def check_result(self, dd, t_filter=False):
        required = ['instance', 'node']
        if t_filter:
            required += ['mode', 'datasource', 'url']
        else:
            required += ['locale', 'alert']
        for key in required:
            if key not in dd:
                return False
        return True

    def test_epic_domain_check(self):
        for i in self.various_urls:
            params, url, instance = epic_url_parser(urlquote(i))
            self.assertEqual(url, 'https://nk11-epic.isg.apple.com')
            self.assertEqual(instance, 'adminsys')
            self.assertTrue(self.check_params(params))

    def test_epic_call(self):
        for i in self.various_urls:
            params, url, instance = epic_url_parser(urlquote(i))
            content = epic_call(url, instance, params)
            self.assertTrue(self.check_result(content, True))

    def test_explode_epic(self):
        params = explode_epic({'data': urlquote(self.various_urls[0])})
        self.assertTrue(self.check_result(params, True))

    def test_explode_nmsys(self):
        params = explode_nmsys({'owner': 'test'})
        self.assertTrue(self.check_result(params, False))

    def check_plug(self, dd):
        required = ['run', 'command', 'occurrence', 'servicename', 'params', 'path', 'action']
        for key in required:
            if key not in dd:
                return False
        return True

    def test_explode_nmsys_plugin(self):
        params = explode_nmsys_plugin({'status': u'PENDING', 'application': 'plugin', 'plugin': {'class': 'NmsysPlugin'}})
        self.assertTrue(self.check_plug(params))

    def test_explode_nmsys_missing_plugin(self):
        params = explode_nmsys_plugin({'status': u'PENDING', 'application': 'plugin', 'plugin': {'class': 'NotPlugin'}})
        self.assertTrue('run' in params and 'params' in params)


if __name__ == '__main__':
    unittest.main()
