__author__ = 'nmsys'
from contrib.pager import pager, email_me
from contrib.notifier.handler.pagerduty.pagerduty import PagerDuty as ppduty
from django.core.mail import send_mail
from django.conf import settings

# Python
import unittest
# Django


class MyTestCase(unittest.TestCase):

    def test_pager(self):
        pass
