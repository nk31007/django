__author__ = 'nmsys'

# Python
import unittest
# Django
from backend.models import *



class SearchCase(unittest.TestCase):

    def test_aging(self):
        result = Alert().aging_stats()
        import pprint
        pprint.pprint(result)
        raise
