__author__ = 'rfoucher'


from django.test import TestCase
from contrib.resource.redisrouter import RedisRouter
from contrib.redisrouter_old import RedisRouter  as RedisRouterOld
from django.conf import settings

class RedisRouterTestCase(TestCase):

    def test_real_organization(self):
        obj = RedisRouter()
        redis_object = obj.retrieve_redis_connection('common', 'epic')
        details = redis_object.info()
        self.assertEqual(12100, details['tcp_port'])

    def test_defaults(self):
        obj = RedisRouter()
        redis_object = obj.retrieve_redis_connection('common', 'iad')
        details = redis_object.info()
        self.assertEqual(12100, details['tcp_port'])

    def test_down(self):
        obj = RedisRouter()
        self.assertEqual(None, obj.retrieve_redis_connection('test', 'iad'))

    def test_wrong(self):
        obj = RedisRouter()
        self.assertEqual(False, obj.retrieve_redis_connection('nothing', 'iad'))

    def test_all_redis(self):
        for key,value in settings.REDIS_INSTANCES.items():
            for kk in value.keys():
                obj = RedisRouterOld(key.lower(), kk)
                obj_new = RedisRouter()
                db = obj.retrieve_redis_connection().connection_pool.connection_kwargs['db']
                db_new = obj_new.retrieve_redis_connection(key.lower(), kk).connection_pool.connection_kwargs['db']
                
                redis_object = obj.retrieve_redis_connection().info()
                redis_object_new = obj.retrieve_redis_connection(key.lower(), kk).info()
                
                self.assertEqual(redis_object['tcp_port'], redis_object_new['tcp_port'])
                self.assertEqual(redis_object['ip'], redis_object_new['ip'])
                self.assertEqual(db, db_new)
