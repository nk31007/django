__author__ = 'nmsys'
# Python
import unittest
# Django
from backend.models import Filter





class MyTestCase(unittest.TestCase):


    def setUp(self):
        self.query = 'nk11a00is-nmsys001.isg.apple.com'


    def test_filter_empty_subscription(self):
        pass
