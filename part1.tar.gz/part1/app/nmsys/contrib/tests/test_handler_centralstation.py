__author__ = 'nmsys'
from contrib.notifier.handler.centralstationHandler import Centralstation
from backend.models import Filter
import logging
logger = logging.getLogger("django")
import unittest
import time
from contrib.resource.redisrouter import RedisRouter


def mock_cst(self, application):
    return 0

class CSTTestCase(unittest.TestCase):
    def setUp(self):
        self.eventlist = {'hits': { 'hits': [
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys", 
                "_source" : {"ack": 0,
                "alert": "nmsys@hardware",
                "application": "nmsys",
                "description": "CRITICAL:\n\t PSU2 Input        ( 0 Watts           ) status  cr\n",
                "instance": "iadsys",
                "locale": "st11",
                "ng": "",
                "node": "st44p01ad-kafka096.iad.apple.com",
                "occurrence": "Occurrence : 1 Critical in 1 checks",
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565771254,
                "u_ctime": 5858410942,
                "u_mtime": 5860738454,
                "u_ptime": 5858410942
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : {"ack": 0,
                "alert": "nmsys@puppet",
                "application": "nmsys",
                "description": "Puppet has not been running for the last 1206600 hour and 38 min\n",
                "instance": "itssys",
                "locale": "ms11",
                "ng": "",
                "node": "ms11p00it-qugc18021901",
                "occurrence": "Occurrence : 5 Critical in 5 checks",
                "occurrence_array": [
                    5,
                    5,
                    5,
                    5,
                    5
                ],
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1565801340,
                "u_ctime": 5856267519,
                "u_mtime": 5860768627,
                "u_ptime": 5856267519
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : {"ack": 0,
                "alert": "gnsnet-gns_dc_splunk_clos_memory_parity@splunk_errors",
                "application": "gns_dc_splunk_clos_memory_parity",
                "description": "An alert was triggered for: gns-dc | CLOS Parity Error<br><a href='https://admin.splunk.iso.apple.com/app/GNSNetworking/search?q=%7Cloadjob%20scheduler_ZGFuaWVsX3ByaWNl__GNSNetworking__RMD5f3f13b62a6c71334_at_1593643200_44436_CA349BCE-3603-4C8B-8CD7-B29DFA988347%20%7C%20head%201%20%7C%20tail%201&earliest=0&latest=now'>Splunk Link</a><br>Additional Info:<br >count: 12<br />msg: Entry exists<br />splunk_search_lag: 00h 04min 54s.154<br />splunk_index_lag: 00h 02min 28s<br />",
                "instance": "gnsnet",
                "locale": "mr11",
                "ng": "",
                "node": "usprz2-cnb-tor-189.prz.apple.com",
                "resource_uri": "/nmsys/api/rest/v2/alert/usprz2-cnb-tor-189.prz.apple.com__gnsnet-gns_dc_splunk_clos_memory_parity@splunk_errors_mr11_gnsnet/",
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1593643218,
                "u_ctime": 1593643209,
                "u_ptime": 1593643209
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : {"ack": 0,
                "alert": "gnsnet-gns_dc_splunk_clos_memory_parity@splunk_errors",
                "application": "gns_dc_splunk_clos_memory_parity",
                "description": "An alert was triggered for: gns-dc | CLOS Parity Error<br><a href='https://admin.splunk.iso.apple.com/app/GNSNetworking/search?q=%7Cloadjob%20scheduler_ZGFuaWVsX3ByaWNl__GNSNetworking__RMD5f3f13b62a6c71334_at_1593643200_44436_CA349BCE-3603-4C8B-8CD7-B29DFA988347%20%7C%20head%201%20%7C%20tail%201&earliest=0&latest=now'>Splunk Link</a><br>Additional Info:<br >count: 12<br />msg: Entry exists<br />splunk_search_lag: 00h 04min 54s.154<br />splunk_index_lag: 00h 02min 28s<br />",
                "instance": "gnsnet",
                "locale": "mr11",
                "ng": "",
                "node": "usprz2-cnb-tor-189.prz.apple.com",
                "resource_uri": "/nmsys/api/rest/v2/alert/usprz2-cnb-tor-189.prz.apple.com__gnsnet-gns_dc_splunk_clos_memory_parity@splunk_errors_mr11_gnsnet/",
                "state": 5,
                "status": "CRITICAL",
                "timestamp": 1593643218,
                "u_ctime": 1593643209,
                "u_ptime": 1593643209 
            }},
            {
                "_id": "st44p01ad-kafka096.iad.apple.com__nmsys@hardware_st11_iadsys",
                "_source" : 
                {"ack": 0,
                "alert": "gnsnet@gns_dc_internal_interface_input_errors_nwk1-118-81-15-mons2-gw1.apple.com_Ethernet2_16",
                "application": "epic",
                "description": "<epicimg>http://nk11-epic.isg.apple.com/gnsnet?a=g&ds=ifInErrors.Ethernet2_16!ifOutErrors.Ethernet2_16:inverse&title=Ethernet2_16%20Errors&ng=&n=nwk1-118-81-15-mons2-gw1.apple.com&m=&s=1594019160</epicimg>\\nEthernet2_16 errors In within acceptable limits\\n   Expr:  ifInErrors.Ethernet2_16,ifInBroadcastPkts.Ethernet2_16,ifInMulticastPkts.Ethernet2_16,ifInUcastPkts.Ethernet2_16,+,+,/,100,* ! NULL\\n   Value: 0 ! NULL\\n",
                "instance": "gnsnet",
                "locale": "nk11",
                "ng": "",
                "node": "nwk1-118-81-15-mons2-gw1.apple.com",
                "resource_uri": "/nmsys/api/rest/v2/alert/nwk1-118-81-15-mons2-gw1.apple.com__gnsnet@gns_dc_internal_interface_input_errors_nwk1-118-81-15-mons2-gw1.apple.com_Ethernet2_16_nk11_gnsnet/",
                "state": 1,
                "status": "OK",
                "timestamp": 1594051868,
                "u_ctime": 1594026360,
                "u_mtime": 1594051380,
                "u_ptime": 1594026543
                }},
        ]}}

    def test_case_dedup(self):
        stats = {
            "Acknowledged": 4,
            "OK": 253,
            "WARNING": 9,
            "ratio": 3
        }
        filt = Filter(**{
            "application": "filter",
            "definition": {
                "alert": "gnsnet.*gns_dc_splunk_clos_memory_parity@splunk_errors",
                "instance": "gnsnet"
            },
            "information": {
            "description": "Delivery_SRE delivery_memory alert",
            "name": "uat_validation_case1",
            "username": "rfoucher"
            },
            "name": "rfoucher@uat_validation_case1",
            "pk": "e26e3a8c-404b-481d-8921-927a06e661ba",
            "state": 4,
            "status": "WARNING",
            "subscription": [
                {
                    "attach_groups": "on",
                    "centralstation_configuration_item": "default",
                    "centralstation_template": "IS&T",
                    "custom-severity": "on",
                    "custom-title": "on",
                    "email-contact": "nmsys-users",
                    "impact": "2 - Medium",
                    "impact-critical": "2 - Medium",
                    "impact-warning": "3 - Low",
                    "input-contact-critical": "nmsys-users",
                    "input-contact-warning": "nmsys-users",
                    "multiif-email": "on",
                    "notif-ifcritical": "on",
                    "notif-ifwarning": "on",
                    "notif-maxdigest": "200",
                    "notification_type": "centralstation",
                    "resend-after": "20",
                    "resend-create-new-incident": "on",
                    "select-duration": "1",
                    "subscribe": "Submit",
                    "subscriber": "rfoucher",
                    "title": "RED | ERRORS | {alertgns}",
                    "urgency": "2 - Medium",
                    "urgency-critical": "3 - Low",
                    "urgency-warning": "3 - Low"
                }
            ],
            "timestamp": 1553514665,
            "u_ctime": 1553514665
        })
        obj = Centralstation(
            filt.subscription[0], 
            filt, 
            self.eventlist, 
            stats, 
            logger
        )
        for alert in obj.content['content']:
            olduuid = "%s %s: %s %s" % (alert['status'], obj.content['name'], alert['alert'], alert['node'])
            if len(olduuid) > 240:
                olduuid = "%s : %s %s" % (alert['status'], obj.content['name'], alert['node'])

            uuid = "%s %s: %s %s" % (alert['status'], obj.content['name'], alert['alert'], alert['node'])
            ticket_id = obj.get_id(olduuid, uuid)
            if not ticket_id or ticket_id == '-1':
                print("create")
            elif obj.centralstation.isclosed(ticket_id):
                print("closed")
            else:
                print("open")
        obj._publish()
        r_base = RedisRouter().retrieve_redis_connection('id_cache', 'default')
        for i in r_base.keys():
            print(r_base.ttl(i))
        

