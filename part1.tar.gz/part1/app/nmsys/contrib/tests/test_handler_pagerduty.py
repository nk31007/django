import os
from unittest import TestCase

import requests

from mock import patch, Mock
from django.conf import settings
from contrib.notifier.handler.pagerduty.base import AuthorizedResource, Resource
from contrib.notifier.handler.pagerduty.exceptions import ConfigurationException, PagerDutyAPIServerException


class ResourceTests(TestCase):
    """
    Tests for Resource
    """

    def setUp(self):
        self.TEST_URL = 'https://www.google.com'

    @patch.object(requests, 'post')
    def test_post_not_ok(self, mock_post):
        """
        Test ._post() handles a not ok response
        """
        mock_response = Mock(name='response', ok=False, status_code=500, text='Server Error')
        mock_post.return_value = mock_response

        resource = Resource()

        with self.assertRaises(PagerDutyAPIServerException):
            resource._post(url=self.TEST_URL)

        mock_post.assert_called_once_with(
            url=self.TEST_URL,
        )


class AuthorizedResourceTests(TestCase):

    @patch.object(os.environ, 'get', spec_set=True)
    def test_resource_with_arg(self, os_environ_mock):
        """
        Test the api_key gets set by an argument
        """

        resource = AuthorizedResource(api_key='123')

        self.assertFalse(os_environ_mock.called)

        self.assertEqual(resource.api_key, '123')

    @patch.object(os.environ, 'get', spec_set=True)
    def test_resource_from_os(self, os_environ_mock):
        """
        Test the api_key gets set by the OS
        """
        os_environ_mock.return_value = '123'

        resource = AuthorizedResource()

        os_environ_mock.assert_called_once_with('PAGERDUTY_API_KEY')

        self.assertEqual(resource.api_key, '123')

    @patch.object(os.environ, 'get', spec_set=True)
    def test_resource_raises_error(self, os_environ_mock):
        """
        Test the api_key is not set
        """
        os_environ_mock.return_value = None

        with self.assertRaises(ConfigurationException):
            AuthorizedResource()

        os_environ_mock.assert_called_once_with('PAGERDUTY_API_KEY')

import logging

import ujson as json
import unittest
from mock import patch
import requests


from contrib.notifier.handler.pagerduty.exceptions import IncidentKeyException
from contrib.notifier.handler.pagerduty.pagerduty import PagerDuty



logging.disable(logging.FATAL)
DUMMY_API_KEY = '1234'


class PagerDutyTests(unittest.TestCase):

    def setUp(self):
        super(PagerDutyTests, self).setUp()

        self.service_key = '4baa5d20cfba466a5e075b02698f455c'
        self.client = 'Apple'

        self.incident_key = '/alert/110'

        self.alert = PagerDuty(service_key=self.service_key)

    @patch.object(requests, 'post')
    def test_trigger_assigns_incident_key(self, mock_post):
        """
        Test triggering an alert without an incident_key sets one for the alert
        """
        alert = PagerDuty(service_key=self.service_key)

        self.assertIsNone(alert.incident_key)

        # Call the method
        alert.trigger(description='No data')

        # Assert we made one
        self.assertIsNotNone(alert.incident_key)

    @patch.object(requests, 'post')
    def test_trigger_success(self, mock_post):
        """
        Test .trigger() calls the correct endpoint with correct parameters
        """
        # Call the method
        self.alert.trigger(
            description='No data received',
            incident_key=self.incident_key,
            client='apple_0033c42e190872c508666ab6acbbd2e7',
            client_url='https://apple.ambition.com',
            details={'some_key': 'some_value'}
        )

        # Assert we made one
        mock_post.assert_called_once_with(
            data=json.dumps({
                'service_key': self.service_key,
                'event_type': 'trigger',
                'incident_key': self.incident_key,
                'description': 'No data received',
                'client': 'apple_0033c42e190872c508666ab6acbbd2e7',
                'client_url': 'https://apple.ambition.com',
                'details': {'some_key': 'some_value'},
            }, sort_keys=True),
            headers=self.alert.headers,
            url=self.alert.URL,
        )

    @patch.object(requests, 'post')
    def test_acknowledge_success(self, mock_post):
        """
        Test .acknowledge() calls the correct endpoint with correct parameters
        """
        # Call the method
        self.alert.acknowledge(
            incident_key=self.incident_key,
            description='No data received',
            details={'some_key': 'some_value'}
        )

        # Assert we made one
        mock_post.assert_called_once_with(
            data=json.dumps({
                'service_key': self.service_key,
                'event_type': 'acknowledge',
                'incident_key': self.incident_key,
                'description': 'No data received',
                'details': {'some_key': 'some_value'},
            }, sort_keys=True),
            headers=self.alert.headers,
            url=self.alert.URL,
        )

    @patch.object(requests, 'post')
    def test_acknowledge_raises_error(self, mock_post):
        """
        Test .acknowledge() raises an IncidentKeyException
        """
        alert = PagerDuty(service_key=self.service_key)

        # Call the method
        with self.assertRaises(IncidentKeyException):
            alert.acknowledge(
                description='No data received',
                details={'some_key': 'some_value'}
            )

    @patch.object(requests, 'post')
    def test_resolve_success(self, mock_post):
        """
        Test .resolve() calls the correct endpoint with correct parameters
        """
        # Call the method
        self.alert.resolve(
            incident_key=self.incident_key,
            description='No data received',
            details={'some_key': 'some_value'}
        )

        # Assert we made one
        mock_post.assert_called_once_with(
            data=json.dumps({
                'service_key': self.service_key,
                'event_type': 'resolve',
                'incident_key': self.incident_key,
                'description': 'No data received',
                'details': {'some_key': 'some_value'},
            }, sort_keys=True),
            headers=self.alert.headers,
            url=self.alert.URL,
        )

    @patch.object(requests, 'post')
    def test_resolve_raises_error(self, mock_post):
        """
        Test .resolve() raises an IncidentKeyException
        """
        alert = PagerDuty(service_key=self.service_key)

        # Call the method
        with self.assertRaises(IncidentKeyException):
            alert.resolve(
                description='No data received',
                details={'some_key': 'some_value'}
            )
