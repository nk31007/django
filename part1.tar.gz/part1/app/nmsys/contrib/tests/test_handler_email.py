__author__ = 'nmsys'
from contrib.notifier.handler.emailHandler import Email

