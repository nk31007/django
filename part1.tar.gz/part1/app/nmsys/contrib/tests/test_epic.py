__author__ = 'nmsys'

# Python
import unittest
# Django
from contrib.epic import EpicSearch



class MyTestCase(unittest.TestCase):
    fixtures = ['alert.json']

    def setUp(self):
        self.query = 'nk11a00is-nmsys001.isg.apple.com'

    def test_cached(self):
        obj = EpicSearch()
        node_list = obj.find_list('nk11a00is-nmsys001.isg.apple.com')

    def test_uncached(self):
        obj = EpicSearch()
        node_list = obj.find_list('nk11a00is-nmsys001.isg.apple.com', cache=False)

    def test_validate(self):
        obj = EpicSearch()
        self.assertRaises(Exception, obj.find_list('.*'))
        obj = EpicSearch()
        self.assertRaises(Exception, obj.find_list('[^'))

    def test_simple_node(self):
        obj = EpicSearch()
        list_result = obj.find_list('.*nmsys.*')
        self.assertEqual(len(list_result), 44)

    def test_simple_iad(self):
        obj = EpicSearch()
        list_result = obj.find_list('.*ad-filer.*')
        self.assertEqual(len(list_result), 62)

    def test_simple_ng(self):
        obj = EpicSearch()
        list_result = obj.find_list('~.*nmsys,!deprecated-linux')
        self.assertEqual(len(list_result), 14)

    def test_simple_group(self):
        obj = EpicSearch()
        list_result = obj.find_list('~.*nmsys')
        self.assertEqual(len(list_result), 14)

    def test_complex_node(self):
        obj = EpicSearch()
        list_result = obj.find_list('.*nmsys.*,!.*002.*')
        self.assertEqual(len(list_result), 41)

    def test_full_node(self):
        obj = EpicSearch()
        list_result = obj.find_list('nk11a00is-nmsys001.isg.apple.com')
        self.assertEqual(len(list_result), 1)

    def test_toolarge(self):
        obj = EpicSearch()
        self.assertRaises(Exception, obj.find_list('.*'))

if __name__ == '__main__':
    unittest.main()
