import requests
from elasticsearch import Elasticsearch
import os



def es_check():

    es_hosts = os.environ.get('ES_HOST', '127.0.0.1')
    result = {}
    error = []
    for server in es_hosts.split(","):
        host, port = server.strip().split(":")
        es = Elasticsearch([{'host': host, 'port': port}])
        try:
            result[server] = es.cluster.health()
        except Exception as e:
            error.append('[ERROR] Server %s, details %s' % (server, e))

    for server, response in result.items():
        print(response)
        if response['status'] != 'green':
            error.append(
                'Status is %s \n'
                'Host is %s'
                '(Unassigned shards %s, )' % (
                    response['status'],
                    server,
                    response['unassigned_shards'])
            )



def redis_check():
    pass


def sentinel_health():
    pass

def mysql_health():
    pass



def mysql_backup():
    pass

if __name__ == "__main__":
    es_check()




