import os
import shutil
import logging
import time
import re
import yaml
import requests
from git import Repo, Actor
from django.conf import settings
from backend.models import Filter
from elasticsearch_dsl import Q, Search
from elasticsearch.exceptions import NotFoundError, ConflictError
import socket
from contrib.resource.redisrouter import RedisRouter
import uuid
from datetime import datetime, timedelta
from contrib.pager import email_me
import threading

logger = logging.getLogger("django")


class Listener(threading.Thread):
    def __init__(self, r, channels):
        threading.Thread.__init__(self)
        self.redis = r
        self.pubsub = self.redis.pubsub()
        self.pubsub.subscribe(channels)

    def run(self):
        for item in self.pubsub.listen():
            if item['data'] == "KILL":
                self.pubsub.unsubscribe()
                break
            elif item['data'] == 'rsync_with_remote':
                NmsysConfig().task_sync_up()


class NmsysConfig(object):

    def __init__(self):
        self.repo_url = settings.ALERT_REPO % (
            os.environ.get('GIT_ID', ''),
            os.environ.get('GIT_TOKEN', ''),
            os.environ.get('GIT_ALERT_REPO', '')
        )

        self.path = settings.ALERT_BACKUP
        if not os.path.exists(self.path):
            self.clone_repo()
        self.repo = Repo(self.path)
        self.r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')

    def backup(self, alert_id, username, email, create=False):
        self.repo.remote('origin').pull()
        filename = Filter.get(id=alert_id).backup()
        self.repo.index.add([filename])
        committer = Actor(username, email)
        self.repo.index.commit("Filter modifier on %s" % int(time.time()), author=committer, committer=committer)
        self.repo.remote('origin').push()

    def delete(self, alert_id, username, email):
        obj = Filter.get(id=alert_id)
        filename = obj.backup()
        try:
            self.repo.index.remove([filename])
        except:
            pass
        obj.cleandelete()
        committer = Actor(username, email)
        self.repo.index.commit("Filter modifier on %s" % int(time.time()), author=committer, committer=committer)
        self.repo.remote('origin').push()

    def backup_all(self):
        for i in Filter.search().extra(from_=0, size=10000):
            i.backup()
        self.repo.git.add(A=True)
        self.repo.index.commit("Automatic backup %s" % int(time.time()))
        self.repo.remote('origin').push()

    def load(self):
        for subdir, dirs, files in os.walk(self.path):
            for config in files:
                if not config.endswith('.yaml'):
                    continue
                with open(os.path.join(subdir, config), 'r') as stream:
                    try:
                        definition = yaml.load(stream)
                        result = Filter.search().query(
                            Q('bool', must=[

                                Q("nested", path="information",
                                  query=Q("match", **{'information.username': definition['information']['username']})),
                                Q("nested", path="definition",
                                  query=Q("match", **{'information.name': definition['information']['name']}))
                            ])
                        ).execute()
                        definition['name'] = '%s@%s' % (definition['information']['username'], definition['information']['name'])
                        if result.hits.total == 1:
                            s = result[0]
                            if 'pk' not in definition:
                                definition['pk'] = s._id
                            s.update(**definition)
                        else:
                            s = Filter(**definition)
                            if 'pk' in definition:
                                s._id = definition['pk']
                            else:
                                s._id = s.pk = str(uuid.uuid4())
                        s.save()
                    except yaml.YAMLError as exc:
                        print(exc)
        self.backup_all()

    def verify(self):
        for subdir, dirs, files in os.walk(self.path):
            for config in files:
                if not config.endswith('.yaml'):
                    continue
                with open(os.path.join(subdir, config), 'r') as stream:
                    try:
                        definition = yaml.load(stream)
                        try:
                            #if definition['pk'] != '2ff9b107-56b5-4bd6-8005-fae6c0175b34':
                            #	continue
                            result = Filter.get(id=definition['pk'])
                        except Exception as e:
                            try:
                                content = requests.get('https://epic.isg.apple.com/epic/us01/nmsys/?a=json&X=1&ds=.*:sum&v=4&n=/api=nmsys.isg.apple.com/filter=%s&f=1week&s=1546486260&e=1546918260'% definition['pk']).json()
                                data = content['intervals']
                                ungood = False
                                for k in data.keys():
                                    if data[k][0] != None:
                                        ungood = True
                                        break

                                if ungood and not definition['information']['name'].startswith('delivery-sre'):
                                    print('Was good at some point  load it %s' %  definition['pk'])
                                    print('%s@%s' % (definition['information']['username'], definition['information']['name']))
                                    print('Missing %s %s' % (e, definition['pk']))
                                    definition['name'] = '%s@%s' % (definition['information']['username'], definition['information']['name'])
                                    s = Filter(**definition)
                                    s._id = definition['pk']
                                    s.save()
                            except Exception as j:
                                print(j)
                    except yaml.YAMLError as exc:
                        print(exc)
    
    def update_local(self):
        if not os.path.exists(self.path):
            self.clone_repo()
        for i in Filter.search():
            i.load()

    def update_remote(self):
        if os.path.exists(self.path):
            self.clone_repo()
        self.backup_all()

    def cleanup_local(self):
        if os.path.exists(self.path):
            shutil.rmtree(self.path)
        os.mkdir(self.path)

    def remote_update(self):
        changes = False
        if self.git_check_head():
            changes = True
        self.repo.remote('origin').pull()
        self.repo.git.clean('-xdf')
        if changes:
            self.load()

    # Check if the local copy is up to date
    def git_check_head(self):
        self.repo.remotes.origin.fetch()
        # commits_ahead = self.repo.iter_commits('origin/master..master')
        commits_behind = self.repo.iter_commits('master..origin/master')
        # count_ahead = sum(1 for c in commits_ahead)
        return sum(1 for c in commits_behind)

    # Validates that all cluster members are up-to-data
    def get_semaphore(self, sha):
        all_shas = self.r_base.hgetall('gitsync')
        print(all_shas)
        print('****')
        for host, remote_sha in all_shas.items():
            if sha != remote_sha:
                return False
        return True

    def task_sync_up(self, force=False):
        sha = self.repo.head.object.hexsha
        last_update = self.repo.commit(sha).authored_datetime
        if self.git_check_head():
            self.repo.remote('origin').pull()
            self.repo.git.clean('-xdf')
        if self.get_semaphore(sha) or force:
            last_sync = self.r_base.get('gitsync_lastupdate')
            try:
                last_sync = int(last_sync)
            except:
                last_sync = 0
            if force:
                last_sync = 0
            last_sha = datetime.fromtimestamp(last_sync)
            if self.find_all_modifications(last_sha):
                self.r_base.set('gitsync_lastupdate', int(time.time()))

        if self.repo.is_dirty():
            self.repo.git.add(update=True)
            self.repo.index.commit("cleanup %s" % int(time.time()))
            self.repo.git.clean('-xdf')
            self.repo.remote('origin').push()

        self.r_base.hset('gitsync', socket.gethostname(), self.repo.head.object.hexsha)

    def audit_filter(self):
        
        for i in Filter.search().extra(from_=0, size=10000):
            if i.pk != i._id:
                i.pk = i._id
            if i.name != '%s@%s' % (i.definition.username, i.definition.name):
                i.name = '%s@%s' % (i.definition.username, i.definition.name)
            
    def apply_change(self, filename, create=False):
        try:
            with open(os.path.join(self.path, filename), 'r') as stream:
                try:
                    definition = yaml.load(stream)
                    name_temp = '%s@%s' % (definition['information']['username'], definition['information']['name'])
                    if 'pk' in definition:
                        try:
                            result = Filter.get(id=definition['pk'])
                            name = '%s@%s' % (result['information']['username'], result['information']['name'])
                            if name_temp != name:
                                stream.close()
                                self.repo.index.remove([filename])
                                self.repo.index.commit("Automatic loadup/backup Deleting file %s %s" % (filename, int(time.time())))
                            definition['name'] = '%s@%s' % (definition['information']['username'], definition['information']['name'])
                            result.update(**definition)
                            result.save()
                            yaml_backup = result.backup()
                            self.repo.index.add([yaml_backup])
                            self.repo.index.commit("Automatic Adding file %s %s" % (yaml_backup, int(time.time())))
                        except NotFoundError as e:
                            result = Filter(**definition)
                            if 'pk' in definition:
                                result._id = definition['pk']
                            else:
                                result._id = s.pk = str(uuid.uuid4())
                            result.save()
                            stream.close()
                            self.repo.index.remove([filename])
                            self.repo.index.commit("Automatic loadup/backup Deleting file %s %s" % (filename, int(time.time())))
                            yaml_backup = result.backup()
                            self.repo.index.add([yaml_backup])
                            self.repo.index.commit("Automatic Adding file %s %s" % (yaml_backup, int(time.time())))
                        except ConflictError as e:
                            print(e)
                            email_me('[nmsysinternal] Filter %s is a duplicate %s ' % (socket.gethostname(), filename),
                                     'Name %s error %s' % (definition['pk'], e))
                        except Exception as e:
                            print(e)
                            email_me('[nmsysinternal] Filter %s  major error %s ' % (socket.gethostname(), filename),
                                     'Name %s error %s' % (definition['pk'], e))
                    else:
                        result = Filter.search().query(
                            Q('bool', must=[
                                Q("nested", path="information",
                                  query=Q("match", **{'information.username': definition['information']['username']})),
                                Q("nested", path="definition",
                                  query=Q("match", **{'information.name': definition['information']['name']}))
                            ])
                        ).execute()
                        if result.hits.total > 1:
                            email_me(
                                '[nmsysinternal] Filter %s is a duplicate %s ' % (socket.gethostname(), filename),
                                'Result %s, Name %s' % (
                                    result, '%s@%s' % (definition['information']['username'],
                                                       definition['information']['name'])
                                )
                            )
                            stream.close()
                        elif result.hits.total == 1:
                            result = result[0]
                            if 'pk' not in definition:
                                definition['pk'] = result._id
                            result.update(**definition)
                            yaml_backup = result.backup()
                            self.repo.index.add([yaml_backup])
                            self.repo.index.commit("Automatic Adding file %s %s" % (yaml_backup, int(time.time())))
                        else:
                            result = Filter(**definition)
                            if 'pk' in definition:
                                result._id = definition['pk']
                            else:
                                result._id = result.pk = str(uuid.uuid4())
                            result.save()
                            yaml_backup = result.backup()
                            self.repo.index.add([yaml_backup])
                            self.repo.index.commit("Automatic Adding file %s %s" % (yaml_backup, int(time.time())))
                except yaml.YAMLError as exc:
                    print(exc)
                finally:
                    stream.close()
        except IOError as exc:
            print('File %s is already deleted' % filename)

    def cleanup_unused(self, list_all):
        pass

    def find_all_modifications(self, last_update):
        result = {}
        change = False
        commit = ''
        for i in self.repo.git.log('--name-status', '--since=%s' % last_update).split('\n'):
            if 'commit' in i:
                commit = i.split(' ')[1]
            elif 'yaml' in i and re.match('([A-Z])\s+(.*)', i):
                modif, filename = i.split()
                result.setdefault(modif, [])
                result[modif].append((commit, filename))
        if 'M' in result:
            self.extract_modified(result['M'])
            change = True
        if 'D' in result:
            self.extract_deleted(result['D'])
            change = True
        if 'A' in result:
            self.extract_created(result['A'])
            change = True
        if change:
            self.repo.git.clean('-xdf')
            self.repo.index.commit("Automatic loadup/backup %s" % int(time.time()))
            self.repo.remote('origin').push()
            return True
        return False

    def extract_created(self, added):
        all_modified = set([i[1] for i in added])
        for filename in all_modified:
            self.apply_change(filename, True)

    def extract_modified(self, modified):
        all_modified = set([i[1] for i in modified])
        for filename in all_modified:
            self.apply_change(filename, False)

    def extract_deleted(self, deleted):
        to_delete = []
        for i in deleted:
            commit, filename = i
            content = self.repo.git.show(commit)
            for j in content.split('\n'):
                if j.startswith('-pk'):
                    to_delete.append(j.split(' ')[1])
        for pk in to_delete:
            try:
                Filter.get(id=pk).delete()
            except Exception as e:
                print('Error %s' % e)
                print('Delete issue %s ' % e)

    def clone_repo(self):
        self.cleanup_local()
        Repo.clone_from(self.repo_url, self.path, depth=1)
