__author__ = 'nmsys'


from contrib.notifier.handler.pagerduty.pagerduty import Pagerduty as pd


from django.core.mail import send_mail
from django.conf import settings
import socket
import time


def pager(subject, content=""):
    try:
        alert = {
            'node': socket.gethostname(),
            'alert': '[nmsys internal] %s' % subject,
            'description': content,
            'u_ptime':int(time.time()),
            'status': 'critical'

        }
        uu_pk = "%s %s: %s %s" % (alert['status'], '', alert['alert'], alert['node'])
        obj = pd(settings.PAGERDUTY_TOKEN, settings.PAGERDUTY_ESCALATION, settings.DPS_HTTP_PROXY)
        result = obj.trigger_incident(
            uu_pk,
            alert
        )
    except Exception as e:
        print(e)
        email_me('Unable to contact Pagerduty %s' % subject, content="")

def email_me(subject, content=""):
    try:
        send_mail('[nmsys_internal] %s' % subject, content, 'rfoucher@apple.com', ['rfoucher@apple.com'])
    except Exception as e:
        print('[email_me] Failure %s' % e)
