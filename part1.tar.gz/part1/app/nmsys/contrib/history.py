#!/usr/bin/python
# coding=utf-8

__author__ = 'rfoucher'
import time
import json
import ast
import logging
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from django.conf import settings
from contrib.resource.redisrouter import RedisRouter
from datetime import datetime, timedelta

# Logging
logger = logging.getLogger(__name__)


class History:
    def __init__(self):
        self._index = 'history'
        self.conn = Elasticsearch(**settings.ES_CONFIG)
        self.to_search = [
            '',
            'OK', 'UNKNOWN', 'INFO', 'WARNING', 'CRITICAL',
            'FATAL', '', '', '',
            'AUTO-RESUME ADMINISTRATIVE', 'PERMANENT ADMINISTRATIVE', 'MAINTENANCE',
            '', '', ''
        ]

    def stream_other(self, key, raw):
        r_stream_stream = RedisRouter().retrieve_redis_connection('history', 'default')
        c = [str(e) for e in raw]
        try:
            r_stream_stream.sadd('bulk::OTHER::%s' % key, *c)
        except:
            pass
    def task_epic(self, redis_key):
        r_stream_stream = RedisRouter().retrieve_redis_connection('history', 'default')
        content = r_stream_stream.spop(redis_key, 30000)

        result = []
        func, incr, application, locale, instance, source = redis_key.split('::')

        for check in content:
            try:
                alert = ast.literal_eval(check)
                if 'u_ctime' not in alert:
                    continue
                result.append(alert)
            except Exception as e:
                logger.critical("[History::task_epic] Application %s, Type %s key %s content %s Error on reformat %s" % (
                    application, incr, redis_key, check, e
                ))

        try:
            result.sort(key=lambda x: x['u_ctime'], reverse=False)
        except Exception as e:
            logger.critical("[History::task_epic] Application %s, Type %s content %s Error on reformat %s" % (
                application, incr, result, e
            ))
        self.stream_epic_content(application, locale, instance, result)

    def task_other(self, app_key):
        r_stream_stream = RedisRouter().retrieve_redis_connection('history', 'default')
        content = r_stream_stream.spop(app_key, 500000)
        kk, tt, application = app_key.split('::')
        self.stream_raw_content(application, content)

    def create_index(self, append_date=None):
        if not append_date:
            # Find last Sunday and create index for it)
            append_date = (datetime.today()-timedelta(((datetime.today().weekday() + 1) % 7))).strftime('%Y_%m_%d')
        for i in ['alert', 'filter', 'notification']:
            print(self.conn.indices.create(
                '%s_%s_week_of_%s' % (i, self._index, append_date),
                json.loads(open(getattr(settings, "BASE_DIR")+'/nmsys/history-%s.json' % i).read()), ignore=400
            ))
        return self.conn

    def stream_epic_content(self, application, locale, instance, content):
        data = []
        append_date = (datetime.today()-timedelta(((datetime.today().weekday() + 1) % 7))).strftime('%Y_%m_%d')
        for alert in content:
            try:
                data.append(self.rebuild_alerts(application, locale, instance, append_date, alert))
            except Exception as e:
                logger.critical("Problem with %s (%s, %s, %s) while ingesting %s" % (alert, application, locale, instance, e))
        bulk(self.conn, data)
        return len(data)

    def stream_raw_content(self, source, content):
        now = time.time() * 1000
        data = []
        append_date = (datetime.today()-timedelta(((datetime.today().weekday() + 1) % 7))).strftime('%Y_%m_%d')
        for entry in content:
            obj = json.loads(entry)
            for key in obj.keys():
                if key[0] == '_':
                    obj.pop(key)
            if 'timestamp' not in obj:
                obj['timestamp'] = now
            obj.update({
                '_index': '%s_%s_week_of_%s' % (source, self._index, append_date),
                '_type': '_doc',
                '_op_type': 'index'
            })
            data.append(obj)
        bulk(self.conn, data)
        return data

    def rebuild_alerts(self, application, locale, instance, append_date, data):
        data['post_application'] = application
        data['post_locale'] = locale
        data['post_instance'] = instance

        for key in ['u_ptime', 'u_ctime', 'u_mtime']:
            if key in data:
                data[key] *= 1000
        if 'u_ctime' in data:
            data['timestamp'] = data['u_ctime']
        else:
            data['timestamp'] = int(time.time()) * 10000
        data.update({
            'status': self.to_search[int(data['state'])],
            '_index': '%s_week_of_%s' % (self._index, append_date),
            '_type': 'alert',
            '_op_type': 'index',
        })
        try:
            data.pop('id')
        except:
            pass

        return data
