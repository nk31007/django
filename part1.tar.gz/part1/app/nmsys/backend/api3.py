import logging

from tastypie import fields
from tastypie.resources import ModelResource, ALL, ALL_WITH_RELATIONS
from contrib.resource.serializer import TemplateSerializer
from django.contrib.sessions.models import Session
# Resources declared below
from provider.oauth2.models import AccessToken
from provider.oauth2.models import Client

from tastypie.http import HttpForbidden, HttpConflict, HttpBadRequest
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from contrib.resource.search_ply import ParserNmsysSearch
from tastypie.exceptions import ImmediateHttpResponse, BadRequest
from elasticsearch_dsl import Q
from dateutil.parser import parse
from tastypie.resources import convert_post_to_patch
from elasticsearch.helpers import bulk
from tastypie import http
from contrib.epic import EpicSearch
from contrib.history import History
from contrib.utils import time_to_datetime
from backend.models import Filter
from backend.models import Maintenance
from backend.models import Plugin
from contrib.kin import Kin
import time
import ujson as json
import uuid
import re
import socket
import pytz
from django.utils.timezone import utc
from django.conf import settings

# Django stuff for Auth
from tastypie.authentication import MultiAuthentication
from contrib.resource.authenticate import NmSysSessionAuthentication, OAuth20Authentication, verify_nmsys_token
from contrib.resource.authorization import NmsysAuthorization
from tastypie.authorization import Authorization
from contrib.resource.redisrouter import RedisRouter
from datetime import datetime, timedelta
from contrib.nmsysconfig import NmsysConfig
from contrib.resource.resource import ElasticsearchResource
from contrib.lint import Lint
logger = logging.getLogger('django')



class PluginResource(ElasticsearchResource):
    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_PLUGIN_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        bucket = None

        model_map = {
            'TAG'   : 'tag',

            'NAME'  : 'name',
            'OWNER' : 'owner',

            'STATUS': 'status',
            'STATE' : 'status',
            'PLUGIN': 'plugin' 
        }

        limit = 200
        max_limit = 2000
        list_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']
        detail_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']

        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])
        private_fields = ['name', 'application', 'pk', 'status']

        default_sorting = "name"

        authorization = NmsysAuthorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

    def build_query(self, filters=None):
        query = []
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        if 'expand' in filters:
            filters.pop('expand')
        result = super(PluginResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result

    def dehydrate(self, bundle):
        if bundle.request.GET.get('expand', '') and 'pk' in bundle.data:
            bundle.data['expand'] = Plugin.get(id=bundle.data['pk']).emulate()
        return bundle

    def obj_create(self, bundle, **kwargs):
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        bundle.data['status'] = 'PENDING'
        if 'pk' not in bundle.data:
            bundle.data['pk'] = uuid.uuid4().urn[9:]

        content = super(PluginResource, self).obj_create(bundle, ** kwargs)
        return content

    def obj_update(self, bundle, **kwargs):
        bundle.data['status'] = 'PENDING'
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        content = super(PluginResource, self).obj_update(bundle, ** kwargs)
        return content

    def obj_delete(self, bundle, **kwargs):
        return super(PluginResource, self).obj_delete(bundle, ** kwargs)

class NotificationResource(ElasticsearchResource):
    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_NOTIFICATION_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        model_map = {
            'INSTANCE' : 'content.instance',
            'LOCALE'   : 'content.locale',
            'ALERT'    : 'content.alert',
            'NODE'     : 'content.node',

            'ROUTE'    : 'route',
            'NAME'     : 'name',
            'RECIPIENT': 'recipient',

            'STATUS'   : 'status',
            'STATE' : 'status',
            'SUBSCRIBER': 'subscriber',

            'ID' : 'id',
        }
        limit = 20
        max_limit = 2000

        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())
        private_fields = ['name', 'subscriber', 'id', 'route']

        list_allowed_methods = ['get']
        detail_allowed_methods = ['get']
        default_sorting = "-timestamp"
        bucket = 'name'
        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])

    def build_query(self, filters=None):
        query = []
        now = int(time.time()) * 1000
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        if 'start' in filters:
            start = time_to_datetime(filters['start'], now*1000)
            query.append(
                Q('range', timestamp={"gte": start})
            )
            filters.pop('start')
        if 'end' in filters:
            end = time_to_datetime(filters['end'], now)
            query.append(
                Q('range', timestamp={"lte": end*1000})
            )
            filters.pop('end')
        result = super(NotificationResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result


class AcknowledgementResource(ElasticsearchResource):

    def hydrate_user(self, bundle):
        if 'user' not in bundle.data:
            bundle.data['user'] = bundle.request.user.username
        if 'date_modified' not in bundle.data:
            bundle.data['date_modified'] = datetime.utcnow().replace(tzinfo=utc)
        return bundle

    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_ACK_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        resource_name = 'ack'
        default_sorting = '-timestamp'
        bucket = 'user_ack'
        limit = 200
        max_limit = 2000

        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

        list_allowed_methods = ['get', 'post']
        detail_allowed_methods = ['get', 'post']

        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])


class ClientResource(ElasticsearchResource):
    def build_query(self, filters=None):
        query = []
        now = int(time.time())
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        result = super(ClientResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result

    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_NODE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20
        
        limit = 20
        max_limit = 200

        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

        list_allowed_methods = ['get']
        detail_allowed_methods = ['get']
        default_sorting = 's_hostname'
        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])

        model_map = {
            'default': 's_hostname',
        }

        bucket = 'kernel'


class AlertResource(ElasticsearchResource):

    def build_query(self, filters=None):
        query = []
        now = int(time.time())
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        if 'tag' in filters:
            list_node = EpicSearch().find_list(filters['tag'])
            if len(list_node) > 1024:
                mini_query = []
                for buk in [list_node[i:i + 1000] for i in list(range(0, len(list_node), 1000))]:
                    mini_query.append(Q(
                        'terms',
                        node=buk
                    ))
                query.append(Q(
                    'bool',
                    should=mini_query,
                ))
            else:
                query.append(Q(
                    'terms',
                    node=list_node
                ))
            filters.pop('tag')
        if 'definition' in filters:
            obj = Filter.get(id=filters['definition'])
            query.append(obj.filter())
            filters.pop('definition')
        if 'acknowledged' not in filters or int(filters['acknowledged']) == 0:
            query.append(
                Q(
                    'bool',
                    should=[
                        Q(
                            'bool',
                            should=[
                                ~Q("exists", field="silence"),
                                Q('range', silence={"lte": int(time.time())}),
                            ],
                            minimum_should_match=1
                        ),
                        Q(
                            'bool',
                            should=[
                                ~Q("exists", field="ack"),
                                Q('term', ack=0)
                            ],
                            minimum_should_match=1
                        )
                    ],
                    minimum_should_match=2
                )
            )
        elif int(filters['acknowledged']) == 1:
            query.append(
                Q(
                    'bool',
                    should=[
                        Q('range', silence={"gte": int(time.time())}),
                        Q('term', ack=1)
                    ],
                    minimum_should_match=1
                )
            )
            filters.pop('acknowledged')
        else:
            filters.pop('acknowledged')
        if 'expand' in filters:
            filters.pop('expand')
        if 'start' in filters:
            start = time_to_datetime(filters['start'], now)
            query.append(
                Q('range', u_ptime={"gte": start})
            )
            filters.pop('start')
        if 'end' in filters:
            end = time_to_datetime(filters['end'], now)
            query.append(
                Q('range', u_ptime={"lte": end})
            )
            filters.pop('end')
        result = super(AlertResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result

    def dehydrate(self, bundle):
        if bundle.request.GET.get('expand', ''):
            bundle.data['expand'] = Kin().find_causal([{
                'node': bundle.data['node'],
                'alert': bundle.data['alert'],
                'locale': bundle.data['locale'],
                'instance': bundle.data['instance']
            }])
        return bundle

    def obj_create(self, bundle, **kwargs):
        if not {"node", "alert", "status", "locale", "instance", "state", "u_ctime", "description"} <= set(bundle.data):
            raise BadRequest('Object is missing required keys see documentation')
        return super(AlertResource, self).obj_create(bundle, ** kwargs)

    def obj_update(self, bundle, **kwargs):
        if not {"node", "alert", "status", "locale", "instance", "state", "u_ctime", "description"} <= set(bundle.data):
            raise BadRequest('Object is missing required keys see documentation')
        return super(AlertResource, self).obj_update(bundle, ** kwargs)

    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_ALERT_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        bucket = 'status'

        model_map = {
            'INSTANCE' : 'instance',
            'LOCALE'   : 'locale',
            'ALERT'    : 'alert',
            'STATUS'   : 'status',
            'DESCRIPTION' : 'description',
            'STATE' : 'state',
            'MTIME' : 'mtime'
        }

        limit = 200
        max_limit = 10000
        list_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']
        detail_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']

        private_fields = ['node', 'alert', 'state', 'status', 'instance', 'locale', 'u_ptime']
        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])
        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())
        default_sorting = "-state,-u_ctime"


class FilterResource(ElasticsearchResource):

    def build_query(self, filters=None):
        query = []
        now = int(time.time())
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        if 'disabled' not in filters:
            query.append(
                Q(
                    'bool',
                    should=[
                        ~Q("exists", field="silence"),
                        ~Q("exists", field="ack"),
                        Q(
                            'bool',
                            filter=[
                                Q('range', silence={"lte": int(time.time())}),
                                Q('term', ack=0)
                            ],
                            minimum_should_match=1
                        )
                    ],
                    minimum_should_match=2
                )
            )
        else:
            query.append(
                Q(
                    'bool',
                    should=[
                        Q('range', silence={"gte": int(time.time())}),
                        Q('term', ack=1)
                    ],
                    minimum_should_match=1
                )
            )
            filters.pop('disabled')
        if 'start' in filters:
            start = time_to_datetime(filters['start'], now)
            query.append(
                Q('range', u_ctime={"gte": start})
            )
            filters.pop('start')
        if 'end' in filters:
            end = time_to_datetime(filters['end'], now)
            query.append(
                Q('range', u_ctime={"lte": end})
            )
            filters.pop('end')
        if 'expand' in filters:
            filters.pop('expand')
        if 'clear_cache' in filters:
            filters.pop('clear_cache')
        result = super(FilterResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result


#  Would be nice but low priority for now
#    def obj_get(self, bundle, **kwargs):
#        logger.critical('GET::%s' % kwargs)
#        content = super(FilterResource, self).obj_get(bundle, ** kwargs)
#        try:
#            validate = Lint(True).validate(content['_source'])
#            content['_source']['validation'] = validate
#        except Exception as e:
#            logger.critical('Lint %s::%s' % (e, content))
#        return content
    def obj_get(self, bundle, **kwargs):
        if bundle.request.GET.get('clear_cache', '') and 'pk' in kwargs:
            logger.critical('Clearing the cache for %s' % kwargs)
            Filter.get(id=kwargs['pk']).filter(cache=False)
        return super(FilterResource, self).obj_get(bundle, ** kwargs)

    def obj_create(self, bundle, **kwargs):
        bundle.data['name'] = '%s@%s' % (bundle.data['information']['username'], bundle.data['information']['name'])
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        bundle.data.pop('details', None)
        username = bundle.request.user.username
        email = bundle.request.user.email

        if len(self.lookup(**{'name': bundle.data['name']})) > 0:
            raise ImmediateHttpResponse(
                HttpConflict("There's already a resource named %s, either change the name, or update the existing." % bundle.data['name'])
            )
        validate = Lint(False).validate(bundle.data)
        if len(validate) > 0:
            logger.critical("There's a problem with your configuration: %s" % ','.join(validate))
            raise ImmediateHttpResponse(
                HttpBadRequest("There's a problem with your configuration: %s" % ','.join(validate))
            )
        if 'pk' not in bundle.data:
            bundle.data['pk'] = uuid.uuid4().urn[9:]
        if 'status' not in bundle.data:
            bundle.data['status'] = 'PENDING'
        content = super(FilterResource, self).obj_create(bundle, ** kwargs)
        try:
            if 'alert-transaction' not in bundle.data['information']['name']:
                NmsysConfig().backup(content.data['_id'], username, email, True)
        except Exception as e:
            logger.critical('Filter Creation issue on %s nmsysconfig backup %s' % (socket.gethostname(), e))
        try:
            if settings.HISTORICAL:
                content.data['action'] = 'create'
                content.data['timestamp'] = int(time.time()) * 1000
                History().stream_other(self._meta.doc_type, [json.dumps(content.data)])
        except Exception as e:
            logger.critical('Filter Creation issue on %s history %s %s' % (socket.gethostname(), e, content))
        return content

    def obj_update(self, bundle, **kwargs):
        bundle.data['name'] = '%s@%s' % (bundle.data['information']['username'], bundle.data['information']['name'])
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        bundle.data.pop('details', None)
        validate = Lint(False).validate(bundle.data)
        if len(validate) > 0:
            logger.critical("There's a problem with your configuration: %s" % ','.join(validate))
            raise ImmediateHttpResponse(
                HttpBadRequest("There's a problem with your configuration: %s" % ','.join(validate))
            )
        username = bundle.request.user.username
        email = bundle.request.user.email
        obj = self.obj_get(bundle, ** kwargs)
        if obj['found']:
            if obj['_source']['name'] != bundle.data['name']:
                NmsysConfig().delete(kwargs.get('pk'), username, email)
        if 'status' not in bundle.data:
            bundle.data['status'] = 'PENDING'
        content = super(FilterResource, self).obj_update(bundle, ** kwargs)
        try:
            NmsysConfig().backup(content.data['_id'], username, email, False)
        except Exception as e:
            logger.critical('Filter Update issue on %s nmsysconfig backup %s' % (socket.gethostname(), e))
        try:
            if settings.HISTORICAL:
                content.data['action'] = 'update'
                content.data['timestamp'] = int(time.time()) * 1000
                History().stream_other(self._meta.doc_type, [json.dumps(content.data)])
        except Exception as e:
            logger.critical('Filter Update issue on %s history %s %s' % (socket.gethostname(), e, content))
        return content

    def obj_delete(self, bundle, **kwargs):
        username = bundle.request.user.username
        email = bundle.request.user.email
        content = super(FilterResource, self).obj_get(bundle, ** kwargs)
        try:
            if 'alert-transaction' not in content['_source']['name']:
                NmsysConfig().delete(kwargs.get('pk'), username, email)
        except Exception as e:
            logger.critical('Filter Delete issue on %s nmsysconfig backup %s' % (socket.gethostname(), e))
        try:
            if settings.HISTORICAL and 'alert-transaction' not in content['_source']['name']:
                content = content['_source']
                content.data['action'] = 'delete'
                content.data['timestamp'] = int(time.time()) * 1000
                History().stream_other(self._meta.doc_type, [json.dumps(content.data)])
        except Exception as e:
            logger.critical('Filter Deletion issue on %s history %s %s' % (socket.gethostname(), e, content))

        return super(FilterResource, self).obj_delete(bundle, ** kwargs)

    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_FILTER_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        bucket = 'status'
        model_map = {
            'INSTANCE' : 'definition.instance',
            'LOCALE'   : 'definition.locale',
            'ALERT'    : 'name',
            'NAME'     : 'name',

            'STATUS'   : 'status',
            'STATE' : 'status',

            'OWNER' : 'information.username',
            'DESCRIPTION': 'information.description',

            'APPLICATION': 'application',
        }

        limit = 200
        max_limit = 2000
        list_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']
        detail_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']
        private_fields = ['name', 'application', 'pk', 'status']

        always_return_data = True
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])

        default_sorting = "-state,name"

        authorization = NmsysAuthorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

    def dehydrate(self, bundle):
        if bundle.request.GET.get('format', '') == 'csv':
            bundle.data.pop('details', None)
        if bundle.request.GET.get('expand', '') and 'pk' in bundle.data:
            bundle.data['expand'] = Filter.get(id=bundle.data['pk']).emulate()
        return bundle



class MaintenanceResource(ElasticsearchResource):
    class Meta:
        es_server = getattr(settings, "ES_HOST")
        index = getattr(settings, "ES_MAINTENANCE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
        es_timeout = 20

        bucket = 'status'

        model_map = {
            'NAME'     : 'name',
            'OWNER' : 'schedule.owner',
            'USER': 'schedule.owner',
            'DESCRIPTION': 'information.description',
            'STATUS': 'status',
        }

        limit = 200
        max_limit = 2000
        list_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']
        detail_allowed_methods = ['get', 'put', 'post', 'delete', 'patch']

        always_return_data = True
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])
        private_fields = ['application', 'pk', 'status']

        default_sorting = "-timestamp"

        authorization = NmsysAuthorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

    def build_query(self, filters=None):
        query = []
        if 'search_q' in filters:
            obj = ParserNmsysSearch()
            obj.model_map = self._meta.model_map
            query.append(obj.get_es_query(filters['search_q']))
            filters.pop('search_q')
        if 'expand' in filters:
            filters.pop('expand')
        result = super(MaintenanceResource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result

    def dehydrate(self, bundle):
        if bundle.request.GET.get('expand', '') and 'pk' in bundle.data:
            bundle.data['expand'] = Maintenance.get(id=bundle.data['pk']).emulate()
        return bundle

    def obj_create(self, bundle, **kwargs):
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        bundle.data['status'] = 'PENDING'
        if 'pk' not in bundle.data:
            bundle.data['pk'] = uuid.uuid4().urn[9:]

        content = super(MaintenanceResource, self).obj_create(bundle, ** kwargs)
        return content

    def obj_update(self, bundle, **kwargs):
        bundle.data['status'] = 'PENDING'
        bundle.data['last_modification'] = bundle.request.user.username
        bundle.data['timestamp'] = int(time.time())
        content = super(MaintenanceResource, self).obj_update(bundle, ** kwargs)
        return content

    def obj_delete(self, bundle, **kwargs):
        return super(MaintenanceResource, self).obj_delete(bundle, ** kwargs)
