import logging

from tastypie import fields
from tastypie.resources import ModelResource, ALL, ALL_WITH_RELATIONS
from contrib.resource.serializer import TemplateSerializer
from django.contrib.sessions.models import Session
# Resources declared below
from provider.oauth2.models import AccessToken
from provider.oauth2.models import Client

from tastypie.http import HttpForbidden, HttpConflict, HttpBadRequest
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from contrib.resource.search import SearchFilter
from tastypie.exceptions import ImmediateHttpResponse, BadRequest
from elasticsearch_dsl import Q
from dateutil.parser import parse
from tastypie.resources import convert_post_to_patch
from elasticsearch.helpers import bulk
from tastypie import http
from contrib.epic import EpicSearch
from contrib.history import History
from contrib.utils import time_to_datetime
from backend.models import Filter
from backend.models import Maintenance
from backend.models import Plugin
from contrib.kin import Kin
import time
import ujson as json
import uuid
import re
import socket
import pytz
from django.utils.timezone import utc
from django.conf import settings

# Django stuff for Auth
from tastypie.authentication import MultiAuthentication
from contrib.resource.authenticate import NmSysSessionAuthentication, OAuth20Authentication, verify_nmsys_token
from contrib.resource.authorization import NmsysAuthorization
from tastypie.authorization import Authorization
from contrib.resource.redisrouter import RedisRouter
from datetime import datetime, timedelta
from contrib.nmsysconfig import NmsysConfig
from contrib.resource.resource import ElasticsearchResource
from contrib.lint import Lint
logger = logging.getLogger('django')


class GroupResource(ModelResource):
    class Meta:
        queryset = Group.objects.all()
        resource_name = 'group'
        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())
        list_allowed_methods = ['get', 'post']
        filtering = {
            'id': ALL,
            'name': ALL
        }


class UserResource(ModelResource):
    groups = fields.ToManyField(GroupResource, 'groups', blank=True, full=True)

    def build_filters(self, filters=None):
        if filters is None:
            filters = {}

        orm_filters = super(UserResource, self).build_filters(filters)

        if 'session' in filters:
            logger.debug('UserResource Checking that session %s' % filters.get('session'))
            token = Session.objects.get(pk=filters.get('session'))
            logger.debug('UserResource Checking that token %s' % token)
            uid = token.get_decoded().get('_auth_user_id')
            logger.debug('UserResource Checking that user %s' % uid)
            orm_filters.update({'pk': uid})
            filters.pop('session')
        elif 'oauth' in filters:
            try:
                obj = AccessToken.objects.get(token=filters['oauth'])
                orm_filters.update({'id': obj.user_id})
            except:
                response = http.HttpUnauthorized("You area not allowed to access details", content_type="text/plain")
                raise ImmediateHttpResponse(response)
        else:
            response = http.HttpUnauthorized("You area not allowed to access details", content_type="text/plain")
            raise ImmediateHttpResponse(response)
        if 'version' in filters:
            if filters['version'] != settings.CLI_VERSION:
                response = http.HttpUnauthorized("You have to run the latest version %s of nmsys-cli to use this API, "
                                                 "please download it again from the UI" % settings.CLI_VERSION, content_type="text/plain")
                raise ImmediateHttpResponse(response)

        return orm_filters

    class Meta:
        queryset = User.objects.all()
        resource_name = 'user'
        authorization = NmsysAuthorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())
        excludes = ['email', 'password', 'is_active', 'is_staff', 'is_superuser']
        filtering = {
            'username': ALL,
            'groups': ALL_WITH_RELATIONS
        }


class AccessTokenResource(ModelResource):

    def obj_create(self, bundle, **kwargs):
        user = User.objects.get(id=bundle.request.user.id)
        oauth_client, cr = Client.objects.get_or_create(user=user,
                                                    name="Api account", client_type=1,
                                                    url="http://nmsysapi.isg.apple.com")
        token, cr = AccessToken.objects.get_or_create(user=user, client=oauth_client, scope=6, expires=datetime.now() + timedelta(days=5*365))
        bundle.data = token
        return bundle

    def obj_update(self, bundle, **kwargs):
        try:
            tok = AccessToken.objects.select_related().get(id=kwargs['pk'])
            if tok.user.id == bundle.request.user.id:
                tok.expires = datetime.now() + timedelta(days=5*365)
                tok.save()
        except:
            response = http.HttpNotFound("Not found", content_type="text/plain")
            raise ImmediateHttpResponse(response)
        return bundle

    def obj_delete(self, bundle, **kwargs):
        try:
            tok = AccessToken.objects.select_related().get(id=kwargs['pk'])
            if tok.user.id == bundle.request.user.id:
                tok.delete()
        except:
            response = http.HttpNotFound("Not found", content_type="text/plain")
            raise ImmediateHttpResponse(response)
        return bundle

    def build_filters(self, filters=None):
        if filters is None:
            filters = {}
        orm_filters = super(AccessTokenResource, self).build_filters(filters)
        try:
            token = verify_nmsys_token(filters.get('session_key'))
            uid = token.user.id
            orm_filters.update({'user_id': uid})
            return orm_filters
        except Exception as e:
            logger.critical('Access to resource denied %s' % e)
        response = http.HttpUnauthorized("Denied", content_type="text/plain")
        raise ImmediateHttpResponse(response)

    class Meta:
        queryset = AccessToken.objects.all()
        resource_name = 'tokens'

        # Authorization is needed for write methods
        authorization = NmsysAuthorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

        list_allowed_methods = ['get', 'put', 'post', 'delete']
        detail_allowed_methods = ['get', 'put', 'post', 'delete']
        filtering = {
            'user': ALL,
            'name': ALL,
            'user_id': ALL
        }
        always_return_data = False


class AcknowledgementV1Resource(ElasticsearchResource):

    def hydrate_user(self, bundle):
        if 'user' not in bundle.data:
            bundle.data['user'] = bundle.request.user.username
        if 'date_modified' not in bundle.data:
            bundle.data['date_modified'] = datetime.utcnow().replace(tzinfo=utc)
        return bundle

    def obj_create(self, bundle, **kwargs):
        obj = self.full_hydrate(bundle).obj
        params = dict(kwargs)
        pk = params.get('pk', obj.get('pk'))
        if not pk:
            pk = uuid.uuid4()
        content = {
            "comment": obj['comment'],
            "user": obj['user'],
            "type_action": obj['modification'],
            "user_ack": obj['user'],
            "time_ack": int(time.time()),
            "alert_list": obj['alert_id'],
            "modification_value": obj['modification_value'],
            "pk": pk
        }
        result = self.client.index(self._meta.index, self._meta.doc_type, content,
                                   id=pk, refresh=True)
        result.update(content)
        return result

    class Meta:
        es_server = getattr(settings, "ES_HOST")

        index = getattr(settings, "ES_ACK_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")
    
        resource_name = 'ack'
        default_sorting = '-timestamp'
        bucket = 'status'
        limit = 20
        max_limit = 200

        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())

        list_allowed_methods = ['get', 'post']
        detail_allowed_methods = ['get', 'post']

        always_return_data = False
        serializer = TemplateSerializer(formats=['json'])


class AlertV1Resource(ElasticsearchResource):

    def build_query(self, filters=None):
        query = []
        if 'search_q' in filters:
            obj = SearchFilter(filters['search_q'])
            obj.model_map = self._meta.model_map
            query.append(obj.filter())
            filters.pop('search_q')
        if 'definition' in filters:
            obj = Filter.get(id=filters['definition'])
            query.append(obj.filter())
            filters.pop('definition')
        if 'ack' not in filters or int(filters['ack']) == 0:
            query.append(
                Q(
                    'bool',
                    should=[
                        Q(
                            'bool',
                            should=[
                                ~Q("exists", field="silence"),
                                Q('range', silence={"lte": int(time.time())}),
                            ],
                            minimum_should_match=1
                        ),
                        Q(
                            'bool',
                            should=[
                                ~Q("exists", field="ack"),
                                Q('term', ack=0)
                            ],
                            minimum_should_match=1
                        )
                    ],
                    minimum_should_match=2
                )
            )
            if 'ack' in filters:
                filters.pop('ack')
        elif int(filters['ack']) == 1:
            query.append(
                Q(
                    'bool',
                    should=[
                        Q('range', silence={"gte": int(time.time())}),
                        Q('term', ack=1)
                    ],
                    minimum_should_match=1
                )
            )
            filters.pop('ack')
        else:
            filters.pop('ack')
        if 'cts' in filters:
            filters.pop('cts')
        result = super(AlertV1Resource, self).build_query(filters)
        for t_query in query:
            if t_query is None:
                continue
            if result:
                result &= t_query
            else:
                result = t_query
        return result

    class Meta:
        es_server = getattr(settings, "ES_HOST")

        index = getattr(settings, "ES_ALERT_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

        resource_name = 'alert'
        bucket = 'status'
        model_map = {

            'n': 'node',
            'node': 'node',

            'dc': 'locale',
            'datacenter': 'locale',
            'locale': 'locale',
            'l': 'locale',

            'i': 'instance',
            'instance': 'instance',

            'alert': 'alert',
            'e': 'alert',
            'a': 'alert',

            's': 'status',
            'status': 'status',

            'state': 'state',
            'description': 'description',

            'mtime': 'timestamp',
        }

        limit = 200
        max_limit = 2000
        list_allowed_methods = ['get', 'post', 'put', 'patch']
        detail_allowed_methods = ['get', 'post', 'put', 'patch']

        private_fields = ['node', 'alert', 'state', 'status', 'instance', 'locale', 'u_ptime']
        always_return_data = False
        serializer = TemplateSerializer(formats=['json', 'yaml', 'csv'])
        authorization = Authorization()
        authentication = MultiAuthentication(NmSysSessionAuthentication(), OAuth20Authentication())
        default_sorting = "-state"

    def empty_to_none(self, d):
        clean_data = {}
        for k,v in d.items():
            if v=='':
                clean_data[k] = None
            else:
                clean_data[k] = v
        return clean_data

    def obj_create(self, bundle, **kwargs):
        obj = self.full_hydrate(bundle).obj
        params = dict(kwargs)
        pk = params.get('pk', obj.get('pk'))
        if not pk:
            pk = uuid.uuid4()
        content = {
            "alert": obj['alert_service'],
            "description": obj['alert_output'],
            "instance": "%s%s" % (obj['alert_organization'], obj['alert_instance']),
            "ng": "",
            "node": obj['alert_server'],
            "state": obj['alert_status_id'],
            "status": obj['alert_status'],
            "timestamp": int(time.time()),
            "u_ctime": int(parse(obj.get('alert_ctime')).strftime('%s')),
            "u_mtime": int(parse(obj.get('alert_mtime')).strftime('%s'))
        }
        silence = parse(obj.get('alert_downtime'))
        if silence > datetime.utcnow().replace(tzinfo=pytz.utc):
            content['silence'] = silence.strftime('%s')
        if obj['alert_ack'] == 1:
            content['ack'] = 1
        result = self.client.index(self._meta.index, self._meta.doc_type, content,
                                   id=pk, refresh=True)
        result.update(content)
        if settings.HISTORICAL:
            content['timestamp'] = int(time.time()) * 1000
            History().stream_other(self._meta.doc_type, [json.dumps(result)])
        return result

    def obj_update(self,  bundle, **kwargs):
        obj = self.full_hydrate(bundle).obj
        params = dict(kwargs)
        pk = params.get('pk', obj.get('pk'))
        content = {
            "alert": obj['alert_service'],
            "description": obj['alert_output'],
            "instance": "%s%s" % (obj['alert_organization'], obj['alert_instance']),
            "ng": "",
            "node": obj['alert_server'],
            "state": obj['alert_status_id'],
            "status": obj['alert_status'],
            "timestamp": int(time.time()),
            "u_ctime": int(parse(obj.get('alert_ctime')).strftime('%s')),
            "u_mtime": int(parse(obj.get('alert_mtime')).strftime('%s'))
        }
        silence = parse(obj.get('alert_downtime'))
        if silence > datetime.utcnow().replace(tzinfo=pytz.utc):
            content['silence'] = silence.strftime('%s')
        if obj['alert_ack'] == 1:
            content['ack'] = 1

        result = self.client.index(self._meta.index, self._meta.doc_type,
                                   content, id=pk, refresh=True)
        result.update(content)
        if settings.HISTORICAL:
            content['timestamp'] = int(time.time()) * 1000
            History().stream_other(self._meta.doc_type, [json.dumps(result)])
        return result

    def patch_list(self, request, **kwargs):
        request = convert_post_to_patch(request)
        deserialized = self.deserialize(request, request.body, format=request.META.get('CONTENT_TYPE', 'application/json'))
        torun = []
        for key, tmp_content in deserialized.items():
            for data in tmp_content:
                try:
                    url_str = data.pop('resource_uri')
                    pk = url_str.split('/')[-2:-1][0]
                except:
                    continue
                if key == 'deleted_objects':
                    result = {
                        '_id': pk,
                        '_index': self._meta.index,
                        '_type': self._meta.doc_type,
                        '_op_type': 'delete'
                    }
                else:
                    content = {}
                    if 'alert_service' in data:
                        content['alert'] = data['alert_service']
                    if 'alert_output' in data:
                        content['description'] = data['alert_output']
                    if 'alert_organization' in data and 'alert_instance' in data:
                        content['instance'] = "%s%s" % (data['alert_organization'], data['alert_instance'])
                    if 'alert_server' in data:
                        content['node'] = data['alert_server']
                    if 'alert_status_id' in data:
                        content['state'] = data['alert_status_id']
                    if 'alert_status' in data:
                        content['status'] = data['alert_status']
                    if 'alert_ctime' in data:
                        content['u_ctime'] = int(parse(data.get('alert_ctime')).strftime('%s'))
                    if 'alert_mtime' in data:
                        content['u_mtime'] = int(parse(data.get('alert_mtime')).strftime('%s'))
                    if 'alert_downtime' in data:
                        silence = parse(data.get('alert_downtime'))
                        if silence > datetime.utcnow().replace(tzinfo=pytz.utc):
                            content['silence'] = silence.strftime('%s')
                        else:
                            content['silence'] = int(time.time())
                    if 'alert_ack' in data:
                        if int(data['alert_ack'])==1:
                            content['ack'] = 1
                        else:
                            content['ack'] = 0
                    content.update({'timestamp': int(time.time())})
                    result = {
                        '_id': pk,
                        '_index': self._meta.index,
                        '_type': self._meta.doc_type,
                        'doc': content,
                        '_op_type': 'update',
                        'doc_as_upsert': True
                    }
                torun.append(result)
        if len(torun):
            try:
                bulk(self.client, torun, raise_on_error=True, raise_on_exception=True)
            except Exception as exc:
                msg = "%s(%s)" % (exc.__class__.__name__, exc)
                response = http.HttpApplicationError(msg, content_type="text/plain")
                raise ImmediateHttpResponse(response)
            else:
                return http.HttpNoContent("The Patch was applied properly")
        else:
            return http.HttpBadRequest()

    def alter_detail_data_to_serialize(self, request, data):
        result = {
            "alert_counter": 0,
            "alert_ctime": datetime.utcfromtimestamp(data.obj['_source']['u_ctime']).replace(tzinfo=pytz.utc),
            "alert_dependency": 0,
            "alert_duration": 0,
            "alert_id": data.obj.get("_id"),
            "alert_mtime": datetime.utcfromtimestamp(data.obj['_source'].get('u_mtime', data.obj['_source']['u_ctime'])).replace(tzinfo=pytz.utc),
            "alert_output": data.obj['_source']['description'],
            "alert_server": data.obj['_source']['node'],
            "alert_service": data.obj['_source']['alert'],
            "alert_status": data.obj['_source']['status'],
            "alert_status_id": data.obj['_source']['state'],
        }
        if 'ack' in data.obj['_source'] and data.obj['_source']['ack'] == 1:
            result['alert_ack'] = 1
        else:
            result['alert_ack'] = 0
        if 'silence' in data.obj['_source'] and data.obj['_source']['silence'] > int(time.time()):
            result['alert_downtime'] = datetime.utcfromtimestamp(int(data.obj['_source'].get('silence', data.obj['_source']['silence']))).replace(tzinfo=pytz.utc)
            result['is_ack_until'] = 1
        else:
            result['alert_downtime'] = datetime.utcnow().replace(tzinfo=pytz.utc)
            result['is_ack_until'] = 0
        try:
            result['alert_organization'], result['alert_instance'] = re.findall('(.*)(sys|st|d|net|oob|app|appi|fcast|vendor|proc|clos|kpi)', data.obj['_source']['instance'])[0]
        except:
            result['alert_organization'] = data.obj['_source']['instance']
            result['alert_instance'] = ''
        result['resource_uri'] = data.data['resource_uri']
        data.data = result
        return data

    def alter_list_data_to_serialize(self, request, to_be_serial):
        content = []
        for data in to_be_serial['objects']:
            result = {
                "alert_counter": 0,
                "alert_ctime": datetime.utcfromtimestamp(data.obj['_source']['u_ctime']).replace(tzinfo=pytz.utc),
                "alert_dependency": 0,
                "alert_duration": 0,
                "alert_id": data.obj.get("_id"),
                "alert_mtime": datetime.utcfromtimestamp(data.obj['_source'].get('u_mtime', data.obj['_source']['u_ctime'])).replace(tzinfo=pytz.utc),
                "alert_output": data.obj['_source']['description'],
                "alert_server": data.obj['_source']['node'],
                "alert_service": data.obj['_source']['alert'],
                "alert_status": data.obj['_source']['status'],
                "alert_status_id": data.obj['_source']['state'],
            }
            if 'ack' in data.obj['_source'] and data.obj['_source']['ack'] == 1:
                result['alert_ack'] = 1
            else:
                result['alert_ack'] = 0
            if 'silence' in data.obj['_source'] and data.obj['_source']['silence'] > int(time.time()):
                result['alert_downtime'] = datetime.utcfromtimestamp(int(data.obj['_source'].get('silence', data.obj['_source']['silence']))).replace(tzinfo=pytz.utc)
                result['is_ack_until'] = 1
            else:
                result['alert_downtime'] = datetime.utcnow().replace(tzinfo=pytz.utc)
                result['is_ack_until'] = 0
            try:
                result['alert_organization'], result['alert_instance'] = re.findall('(.*)(sys|st|d|net|oob|app|appi|fcast|vendor|proc|clos|kpi)', data.obj['_source']['instance'])[0]
            except:
                result['alert_organization'] = data.obj['_source']['instance']
                result['alert_instance'] = ''
            result['resource_uri'] = data.data['resource_uri']
            data.data = result
        return to_be_serial
