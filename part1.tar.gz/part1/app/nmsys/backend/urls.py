from django.conf.urls import url, include
from tastypie.api import Api
from backend import views
from backend.api import AlertV1Resource
from backend.api import AcknowledgementV1Resource
from backend.api import UserResource
from backend.api import GroupResource
from backend.api import AccessTokenResource

from backend.api2 import NotificationResource as NotificationResourceV2
from backend.api2 import FilterResource as FilterResourceV2
from backend.api2 import AlertResource as AlertResourceV2
from backend.api2 import MaintenanceResource as MaintenanceResourceV2
from backend.api2 import ClientResource as ClientResourceV2
from backend.api2 import PluginResource as PluginResourceV2 
from backend.api2 import AcknowledgementResource as AcknowledgementResourceV2
from backend.api2 import NotificationTemplateResource


from backend.api3 import NotificationResource as NotificationResourceV3
from backend.api3 import FilterResource as FilterResourceV3
from backend.api3 import AlertResource as AlertResourceV3
from backend.api3 import MaintenanceResource as MaintenanceResourceV3
from backend.api3 import ClientResource as ClientResourceV3
from backend.api3 import PluginResource as PluginResourceV3 
from backend.api3 import AcknowledgementResource as AcknowledgementResourceV3


v1_api = Api(api_name='v1')
v1_api.register(AlertV1Resource())
v1_api.register(AcknowledgementV1Resource())


v2_api = Api(api_name='v2')
v2_api.register(AccessTokenResource())
v2_api.register(UserResource())
v2_api.register(GroupResource())
v2_api.register(NotificationResourceV2())
v2_api.register(FilterResourceV2())
v2_api.register(AlertResourceV2())
v2_api.register(MaintenanceResourceV2())
v2_api.register(ClientResourceV2())
v2_api.register(PluginResourceV2())
v2_api.register(AcknowledgementResourceV2())
v2_api.register(NotificationTemplateResource())


v3_api = Api(api_name='v3')
v3_api.register(AccessTokenResource())
v3_api.register(UserResource())
v3_api.register(GroupResource())
v3_api.register(NotificationResourceV3())
v3_api.register(FilterResourceV3())
v3_api.register(AlertResourceV3())
v3_api.register(MaintenanceResourceV3())
v3_api.register(ClientResourceV3())
v3_api.register(PluginResourceV3())
v3_api.register(AcknowledgementResourceV3())
v3_api.register(NotificationTemplateResource())



_PREFIX = 'api'

urlpatterns = [ 
    url(r'^test/$', views.index),
    url(r'^status/$', views.status),
    # Rest Api using tastypie
    url(r'^rest/', include(v3_api.urls)),
    url(r'^rest/', include(v2_api.urls)),
    url(r'^rest/', include(v1_api.urls)),

    # nmSys client
    url(r'^checks/(?P<node_name>[^/]+)', views.checks),
    url(r'^config/(?P<node_name>[^/]+)', views.nmsys_export),
    url(r'^node/(?P<node_name>[^/]+)', views.nmsys_node),

    # Implementing oAuth
    url(r'^oauth2/', include('provider.oauth2.urls')),

    url(r'^epic_alerts/(?P<instance>[^/]+)/$', views.epic_export),
    url(r'^api_alert/(?P<application>[^/]+)/(?P<locale>[^/]+)/(?P<instance>[^/]+)/$', views.bulk),

]
