__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand
from backend.models import Filter, Alert
from elasticsearch_dsl import Q
from contrib.notifier.handler.centralstationHandler import Centralstation
import re
import logging
from backend.models import RedisRouter
logger = logging.getLogger(__name__)

class Command(BaseCommand):
     def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            ibj.token()
        )
        r_base = RedisRouter().retrieve_redis_connection('id_cache', 'default')
    
        for i in Filter.search().extra(from_=0, size=10000):
            run = False
            if 'subscription' in i:
                for sub in i.subscription:
                    a = sub.to_dict()
                    if a['notification_type'] == 'centralstation':
                        run = True
            if run:
                print('running now %s' % i.name)
                i.notify(True)
