__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand



class Command(BaseCommand):
     def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            ibj.token()
        )
        pprint.pprint(centralstation.status('INC063230331'))
        print(centralstation.isclosed('INC063230331'))

        print(centralstation.isclosed('INC063187638'))
