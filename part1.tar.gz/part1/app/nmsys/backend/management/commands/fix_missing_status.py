from django.core.management.base import BaseCommand, CommandError
import re
import logging
import json
from django.conf import settings
# django
from backend.models import *

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in Filter.search().extra(from_=0, size=10000):
            if 'status' not in i:
                i.update(status='PENDING')
