__author__ = 'nmsys'

from django.core.management.base import BaseCommand
from contrib.utils import epic_generator
from backend.models import Alert
import requests
# django

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for endpoint in epic_generator():
            try:
                raw = requests.get('%s?a=alert&cmd=list&s=e-2years' % endpoint['url']).text
                Alert().bulk(endpoint['locale'], endpoint['instance'], raw)
            except:
                pass
