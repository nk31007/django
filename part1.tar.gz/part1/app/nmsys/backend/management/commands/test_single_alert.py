__author__ = 'nmsys'


from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json
from contrib.kin import Kin
from elasticsearch_dsl import Search, Q
from elasticsearch_dsl.connections import connections
from django.conf import settings

# django
from backend.models import Filter
hosts = []

for server in getattr(settings, "ES_HOST").split(","):
    host, port = server.strip().split(":")
    hosts.append({"host": host, "port": port})
connections.create_connection(hosts=hosts, timeout=120)\

class Command(BaseCommand):

    def handle(self, *args, **options):
        obj = Kin()

        location = obj.get_last_publish()

        content = []
        only_critical = Q(
            'bool',
            should=[Q('match', status="CRITICAL"), Q('match', status="WARNING")],
            must=Q('match', alert='gnsnet@gns_dc_external_interface_traffic_nlams2-5310-01-01-gw1.apple.com_Ethernet10'),
            minimum_should_match=1
        )
        search = Search().query(
            Q('bool', must=[only_critical])
        )

        result = search\
            .using(connections.get_connection())\
            .extra(_source={'includes': ['node', 'alert', 'instance', 'locale']})\
            .index('epic')\
            .doc_type('alert')
        for hit in result.scan():
            content.append(hit.to_dict())
        print obj.fetch_correlation(location, content)

