__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand

from contrib.resource.redisrouter import RedisRouter
import redis



class Command(BaseCommand):
    def handle(self, *args, **options):
	r_base = RedisRouter().retrieve_redis_connection('id_cache', 'default')
	r_old = redis.Redis(host='mr20a00is-quge05162401',port=10106,db=10)
	ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        auth_status, token = ibj.token()

        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            token
        )

	all_old = r_old.keys()
	for i in all_old:
	    key_old = r_old.get(i)
	    key_new = r_base.get(i)
	    if key_new == None:
	        r_base.set(i, key_old)
	    if key_old != key_new:
		if not centralstation.isclosed(key_old):
		    if not centralstation.isclosed(key_new):
		        print 'Ticket Old  %s is still opened replace cache and close new %s' % (key_old, key_new)
			centralstation.close(key_new, '1371721688')
			r_base.set(i, key_old)
		    else:
			print 'Ticket New %s already closed replace cache with %s' % (key_new, key_old)
			r_base.set(i, key_old)
		else:
		    print 'Ticket Old  %s is closed so use new %s' % (key_old, key_new)
