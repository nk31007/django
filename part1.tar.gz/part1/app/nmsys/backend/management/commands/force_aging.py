__author__ = 'nmsys'
from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from backend.models import Alert
import time

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in range(0, 30):
            Alert().aging(True)
            time.sleep(1)

