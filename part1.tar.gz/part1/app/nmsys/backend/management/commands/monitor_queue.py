from django.core.management.base import BaseCommand
from django.conf import settings
from contrib.resource.redisrouter import RedisRouter


class Command(BaseCommand):

    def handle(self, *args, **options):
        for application in settings.STREAM_APP:
            r_stream_stream = RedisRouter().retrieve_redis_connection('common', application)
            keys_list = r_stream_stream.keys('queue*')
            for key_redis in keys_list:
                length = r_stream_stream.scard(key_redis)
                try:
                    app, locale, instance = key_redis.split('::')
                except:
                    app, locale, instance = key_redis.split('_')
                print '%s-%s-%s-size : %s' % (application, locale, instance, length)

