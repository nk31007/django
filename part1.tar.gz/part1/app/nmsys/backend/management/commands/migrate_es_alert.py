__author__ = 'nmsys'


from django.core.management.base import BaseCommand
from django.conf import settings
from datetime import datetime
import json
from elasticsearch_dsl.connections import connections

hosts = []
for server in getattr(settings, "ES_HOST").split(","):
    host, port = server.strip().split(":")
    hosts.append({"host": host, "port": port})

connections.create_connection(
    hosts=hosts,
    timeout=30
)



ALIAS = 'nmsys-filter'
PATTERN = ALIAS + '-*'



