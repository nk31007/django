from django.core.management.base import BaseCommand, CommandError
import time
import logging
import ujson as json
import datetime
# django
from django.contrib.sites.models import Site
from django.contrib.auth.models import User

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        duration = int(10) * 60
        resend = int(30) * 60

        now = int(time.time())
        last = int(time.time()) - 65

        print datetime.datetime.fromtimestamp(now).isoformat()
        print datetime.datetime.fromtimestamp(last).isoformat()
        for i in (range(6) + range(100, 101)):
            print "%s < time < %s" % (datetime.datetime.fromtimestamp(last - duration - resend * i).isoformat(),datetime.datetime.fromtimestamp(now - duration - resend * i).isoformat())
