#!/usr/bin/python

from django.core.management.base import BaseCommand
import os
from django.conf import settings
import pprint
import requests

class Command(BaseCommand):

    def handle(self, *args, **options):
        try:
            if settings.APZ:
                content = requests.get('http://ty51-epic.isg.apzones.com/helix?a=finger&T=eapi')
            else:
                content = requests.get('http://us01-epic.isg.apple.com/nmsys?a=finger&T=eapi')
            epic_conf = "/usr/local/epic/conf/epic.cf"
            arr = content.json()['finger']['type']['eapi']
            all_ips = set()
            port = 11111
            for i in content.json()['finger']['type']['eapi']:
                ip, lport = i.split(':')
                all_ips.add(ip)
                port = lport
            if os.path.exists(epic_conf):
                os.remove(epic_conf)

            a = open(epic_conf,'w')
            a.writelines([
                "$cfg{'IP:EPIC'}         = '%s';\n" % ','.join(all_ips),
                "$cfg{'Port:EPIC'}       = %s;\n" % port,
                "1;\n"
            ])
            a.close()
            eapi_conf = "/usr/local/epic/conf/eapi_ctl.cf"
            if os.path.exists(eapi_conf):
                os.remove(eapi_conf)
            b = open(eapi_conf, 'w')
            b.writelines(["module unix:unix_eapi_proxy:*", "\n"])
            b.close()
        except Exception as e:
            print(e)

