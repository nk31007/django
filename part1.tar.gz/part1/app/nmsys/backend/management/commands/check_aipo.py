__author__ = 'nmsys'
from contrib.notifier.handler.aipo.auth import AipoAuthenticationService
from contrib.notifier.handler.aipo.aipo import Aipo
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand



class Command(BaseCommand):
     def handle(self, *args, **options):
        ibj = AipoAuthenticationService(
            settings.AIPO_ENDPOINT,
            settings.AIPO_CLIENTID,
            settings.AIPO_CLIENTSECRET,
            settings.AIPO_USER,
            settings.AIPO_PAS
        )
        # Test basic auth
        completed, data = ibj.authentication()
        if completed:
            # Test refresh
            print(ibj.refresh(data['refresh_token']))
        

        centralstation = Aipo(
            settings.AIPO_ENDPOINT,
            settings.AIPO_APPID,
            data['access_token']
        )
        
        centralstation.ping()
        data = centralstation.create({
                "configurationItem" : 'nmSys Service',
                "environment" : 'Non-Production',
                "assignmentgroup" : 'nmsys-users',  
                "title" : 'nmSys title',
                "description" : 'Test1Ronan', 
                "Impact": "3 - Low",
                "Urgency": "3 - Low",
        })
        totest =  data['number']
        centralstation.status(totest)
        centralstation.isclosed(totest)

        centralstation.update({
                "id": totest,
                "configurationItem" : 'nmSys Service',
                "environment" : 'Non-Production',
                "assignmentgroup" : 'nmsys-users',  
                "title" : 'nmSys title',
                "description" : 'Test2Ronan', 
                "Impact": "3 - Low",
                "Urgency": "2 - Medium",
        })
        print centralstation.status(totest)
        centralstation.resolve({"id": totest})
        centralstation.close({"id": totest})
        print centralstation.isclosed(totest)
        print centralstation.status(totest)

        
        
