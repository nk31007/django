__author__ = 'nmsys'
from contrib.notifier.handler.espresso.espresso import Espresso as Ticket
from django.conf import settings

from django.core.management.base import BaseCommand



class Command(BaseCommand):
     def handle(self, *args, **options):
        espresso = Ticket(
            {
                'classpath': settings.ESPRESSO_CLASSPATH,
                'uname': settings.ESPRESSO_USER,
                'pd': settings.ESPRESSO_PASSWORD,
                'dry': False,
                'job': settings.ESPRESSO_PROCESS_NAME,
                'u_id': settings.ESPRESSO_USER_ID
            }
        )

        print(e)spresso.close(28924103)
