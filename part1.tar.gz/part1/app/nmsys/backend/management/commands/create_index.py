from django.core.management.base import BaseCommand

from backend.models import Filter, Notification, Alert, Acknowledgement, Plugin, Node, Maintenance, NotificationTemplate
from contrib.history import History



class Command(BaseCommand):

    def handle(self, *args, **options):
        try:
            Filter().create_index()
        except Exception as e:
            print(e)
        try:
            Notification().create_index()
        except Exception as e:
            print(e)
        try:
            Alert().create_index()
        except Exception as e:
            print(e)
        try:
            Maintenance().create_index()
        except Exception as e:
            print(e)
        try:
            Plugin().create_index()
        except Exception as e:
            print(e)
        try:
            Node().create_index()
        except Exception as e:
            print(e)
        try:
            Acknowledgement().create_index()
        except Exception as e:
            print(e)
        try:
            Notification().create_index()
        except Exception as e:
            print(e)
        try:
            History().create_index()
        except Exception as e:
            print(e)
        try:
            NotificationTemplate().create_index()
        except Exception as e:
            print(e)

