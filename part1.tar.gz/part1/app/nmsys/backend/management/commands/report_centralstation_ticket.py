__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
from django.core.management.base import BaseCommand



class Command(BaseCommand):
    def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            ibj.token()
        )
        print(centralstation.search({'query': '^stateNOT IN190,200^assignment_group=851f20e6c3b5020031e8bd4fed5d7562'}))
