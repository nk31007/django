from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from backend.models import Filter

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in Filter.search():
            print(i)
