from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json
from django.conf import settings
# django
from backend.models import *

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in Filter.search().query(Q("nested", path="information", query=Q("term", information__username="gns-dc-external"))).extra(from_=0, size=10000):
            print(i)
            #if 'name' not in i:
            #    i.delete()
            main_filter = i.filter()
            stats = i.get_stats()
            now = int(time())
            for idx, subscription in enumerate(i.subscription):
                if 'silence' in subscription and subscription['silence'] > int(time()):
                    continue
                if "notif-ifcritical" not in subscription and \
                    "notif-ifwarning" not in subscription and \
                    "notif-ifunknown" not in subscription and \
                    "recovery" not in subscription:
                    continue
                if subscription['notification_type'] != 'centralstation':
                   continue
                search = Search().query(
                    Q('bool', must=[main_filter, i.filter_notification(subscription, now, True)])
                )[0:10000]
                search.aggs.bucket('bucket', 'terms', field='status', size=settings.ES_AGGREGATION_SIZE)
                if "ratio" in subscription:
                    sum_bad = float(stats.get('CRITICAL', 0) + stats.get('WARNING', 0))
                    sum_total = float(sum(stats.itervalues()))
                    if sum_total > 0:
                        ratio = int((sum_bad / sum_total) * 100)
                    else:
                        ratio = 0
                    stats['ratio'] = ratio
                    if ratio < subscription['ratio']:
                        continue
                result = search.using(connections.get_connection()).index('epic').doc_type('alert').execute()
                cl = load_class_from_name(
                    'contrib.notifier.handler.%sHandler.%s' % (
                        subscription['notification_type'],
                        subscription['notification_type'].capitalize()
                    )
                )
                obj = cl(subscription, i, result.to_dict(), stats, logger)
                obj.publish()

