from django.core.management.base import BaseCommand
from contrib.resource.redisrouter import RedisRouter


class Command(BaseCommand):

    def handle(self, *args, **options):
        try:
            r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
            r_base.set('maintenance', '1')
        except Exception as e:
            print(e)
