__author__ = 'nmsys'
from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from backend.models import Filter

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in Filter.search().extra(from_=0, size=10000):
            if 'name' not in i:
                i.delete()
                continue
            print(i.name)
            i.filter()
