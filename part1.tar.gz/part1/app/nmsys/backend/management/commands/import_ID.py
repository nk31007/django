__author__ = 'nmsys'
#!/usr/bin/python

from django.core.management.base import BaseCommand
from contrib.resource.redisrouter import RedisRouter


class Command(BaseCommand):

    def handle(self, *args, **options):
        old_redis = RedisRouter().retrieve_redis_connection('common', 'default')
        new_redis = RedisRouter().retrieve_redis_connection('id_cache', 'default')
        _keys = old_redis.keys()
        for key in _keys:
            if key.startswith('celery-task'):
                continue
            value = old_redis.get(key)
            new_redis.set(key, value)
