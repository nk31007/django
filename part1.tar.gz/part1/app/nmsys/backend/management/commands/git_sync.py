__author__ = 'nmsys'
#!/usr/bin/python

import yaml
import pprint
from django.core.management.base import BaseCommand
import os
from contrib.nmsysconfig import Listener
from contrib.resource.redisrouter import RedisRouter
from django.conf import settings

class Command(BaseCommand):

    def handle(self, *args, **options):
        Listener(RedisRouter().retrieve_redis_connection('semaphore', 'default'), ['git_sync']).start()
