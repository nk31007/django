from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from django.contrib.auth.models import Group


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('id', nargs='+', type=str)
        parser.add_argument('name', nargs='+', type=str)

    def handle(self, *args, **options):
        gp, created = Group.objects.get_or_create(id=options['id'][0])
        gp.name = options['name'][0]
        gp.save()
