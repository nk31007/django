
import redis
from redis.sentinel import Sentinel
from redis.sentinel import MasterNotFoundError
from django.conf import settings
from contrib.resource.redisrouter import RedisRouter
SENTINEL_FLAG = True  ###
SENTINEL_INSTANCE = {'nmsys_celery-redis-cluster': [('10.35.196.72', '12100'), ('10.35.196.85', '12100')], 'nmsys_cache-redis-cluster': [('10.35.196.72', '12101'), ('10.35.196.85', '12101')], 'nmsys_stats-redis-cluster': [('10.35.196.72', '12102'), ('10.35.196.85', '12102')], 'nmsys_alert-redis-cluster': [('10.35.196.72', '12103'), ('10.35.196.85', '12103')], 'nmsys_script-redis-cluster': [('10.35.196.72', '12104'), ('10.35.196.85', '12104')], 'nmsys_semaphore-redis-cluster': [('10.35.196.72', '12105'), ('10.35.196.85', '12105')], 'nmsys_idcache-redis-cluster': [('10.35.196.72', '12106'), ('10.35.196.85', '12106')], 'nmsys_history-redis-cluster': [('17.142.128.217', '12107'), ('17.142.129.20', '12107'), ('10.35.196.72', '12107'), ('10.35.196.85', '12107')]}  ###

SENTINEL_PASS = '_kkt_KS_TOA'  ###

from django.core.management.base import BaseCommand
import os
from django.conf import settings

class Command(BaseCommand):

    def handle(self, *args, **options):

        for i in SENTINEL_INSTANCE.keys():
            src = Sentinel(SENTINEL_INSTANCE[i], password=SENTINEL_PASS).master_for(i, socket_timeout=30, retry_on_timeout=False)
            red = i.split("_")[1].split('-')[0]
            dst = RedisRouter().retrieve_redis_connection(red, 'common')

            for key in src.keys('*'):
                ttl = src.ttl(key)
                if ttl < 0:
                    ttl = 0
                try:
                    value = src.dump(key)
                    dst.restore(key, ttl * 1000, value, replace=True)
               except Exception as e:
                   print("Failed to restore key: %s %s" % (key, e))
