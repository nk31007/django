__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand



class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument('id', nargs='+', type=str)

    def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        auth_status, token = ibj.token()

        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            token
        )

        for ticket in options['id']:
            centralstation.close(ticket, '1371721688')
