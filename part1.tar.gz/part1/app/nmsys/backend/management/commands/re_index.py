__author__ = 'nmsys'


from django.core.management.base import BaseCommand
from django.conf import settings
from datetime import datetime
import json
from elasticsearch_dsl.connections import connections

list_idx = [settings.ES_ACK_INDEX, settings.ES_ALERT_INDEX, settings.ES_FILTER_INDEX, settings.ES_MAINTENANCE_INDEX, settings.ES_NODE_INDEX, settings.ES_NOTIFICATION_INDEX, settings.ES_PLUGIN_INDEX, settings.ES_TEMPLATE_INDEX]



hosts = []
for server in getattr(settings, "ES_HOST").split(","):
    host, port = server.strip().split(":")
    hosts.append({"host": host, "port": port})

connections.create_connection(
    hosts=hosts,
    timeout=30
)





class Command(BaseCommand):

    def handle(self, *args, **options):
        for i in list_idx:
            pattern = i + '-*'

            # construct a new index name by appending current timestamp
            next_index = pattern.replace('*', datetime.now().strftime('%Y%m%d%H%M%S%f'))

            # get the low level connection
            es = connections.get_connection()
            print(next_index)

            # create new index, it will use the settings from the template
            es.indices.create(next_index, json.loads(open(getattr(settings, "BASE_DIR")+'/nmsys/%s.json' % i).read()))
            body={"source": {"index": i}, "dest": {"index": next_index}}
            if settings.ES_MIGRATE:
                body['source']['remote'] = settings.ES_MIGRATE_CONFIG
            print(body)

            # move data from current alias to the new index
            #es.reindex(
            #    body={"source": {"index": ALIAS}, "dest": {"index": next_index}},
            #    request_timeout=3600
            #)
            # refresh the index to make the changes visible
            #es.indices.refresh(index=next_index)

            # repoint the alias to point to the newly created index
            #try:
            #    es.indices.update_aliases(body={
            #        'actions': [
            #            {"remove": {"alias": ALIAS, "index": PATTERN}},
            #            {"add": {"alias": ALIAS, "index": next_index}},
            #        ]
            #    })
            #except Exception as e:
            #    print(e)
            #    es.indices.delete(ALIAS)
            #    es.indices.update_aliases(body={
            #        'actions': [
            #            {"add": {"alias": ALIAS, "index": next_index}},
            #        ]
            #    })
