from django.core.management.base import BaseCommand

# django
from contrib.nmsysconfig import NmsysConfig

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        NmsysConfig().load()
