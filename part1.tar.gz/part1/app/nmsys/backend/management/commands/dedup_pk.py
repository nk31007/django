__author__ = 'nmsys'
#!/usr/bin/python

import yaml
import pprint
from django.core.management.base import BaseCommand
import os
from django.conf import settings

class Command(BaseCommand):

    def handle(self, *args, **options):
        path = settings.ALERT_BACKUP
        list_pk = {}
        for subdir, dirs, files in os.walk(path):
            for config in files:
                if not config.endswith('.yaml'):
                    continue
                with open(os.path.join(subdir, config), 'r') as stream:
                    try:
                        definition = yaml.load(stream)
                        if definition['pk'] not in list_pk:
                            list_pk[definition['pk']] = []
                        list_pk[definition['pk']].append(definition)
                    except Exception as e:
                        print(e)

        for pk in list_pk:
            if len(list_pk[pk]) > 1:
                print pk
                print '=' * 60
                pprint.pprint(list_pk[pk])
