__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand
from backend.models import Filter, Alert
from elasticsearch_dsl import Q
from contrib.notifier.handler.centralstationHandler import Centralstation
import re
import logging
from backend.models import RedisRouter
logger = logging.getLogger(__name__)

class Command(BaseCommand):
     def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            ibj.token()
        )
        r_base = RedisRouter().retrieve_redis_connection('id_cache', 'default')
        all_of_them = r_base.keys()
        count = 0
        broken = 0
        for i in all_of_them:
            ticket_id = r_base.get(i)
            if not ticket_id.startswith('INC') and i.contains('centralstation'):
                print("Problem %s %s" % (ticket_id, i))
                broken+=1
                #r_base.delete(i)
            elif centralstation.isclosed(ticket_id):
                r_base.delete(i)
                count+=1
        
        print("Total cached %s" % len(all_of_them))
        print("Purged %s tickets" % count)
        print("Broken %s tickets" % broken)
        
