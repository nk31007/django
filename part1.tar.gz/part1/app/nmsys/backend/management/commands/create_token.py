from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from provider.oauth2.models import AccessToken
from provider.oauth2.models import Client
from datetime import datetime, timedelta
from django.contrib.auth.models import User


class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('token', nargs='+', type=str)
        parser.add_argument('name', nargs='+', type=str)

    def handle(self, *args, **options):
        user, created = User.objects.get_or_create(username=options['name'][0])
        user.save()

        oauth_client, cr = Client.objects.get_or_create(user=user,
                                name="NmsysClient account", client_type=1,
                            url="http://nmsysapi.qa.isg.apple.com")
        token, cr = AccessToken.objects.get_or_create(user=user, client=oauth_client, scope=6)
        token.expires = datetime.now() + timedelta(days=5*365)

        token.token = options['token'][0]
        token.save()
