from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from django.contrib.sites.models import Site
from django.contrib.auth.models import User
from django.conf import settings

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        result = Site.objects.all()
        if len(result) > 0:
            for r in result:
                r.delete()
        Site.objects.create(domain=settings.FRONTENDPOINT, name=settings.FRONTENDPOINT)
        for i in settings.SUPER_U.split(','):
            ss, created = User.objects.get_or_create(username=i)
            ss.is_staff = True
            ss.is_superuser = True
            ss.save()

