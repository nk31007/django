

from django.core.management.base import BaseCommand
from backend.models import *


class Command(BaseCommand):
    help = 'Notify'

    def handle(self, *args, **options):
        Filter.get(id='860aef10-b3ce-1d17-70b6-64121b0a34ab').notify(True)
