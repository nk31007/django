__author__ = 'nmsys'
from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from backend.models import Filter
import time

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        for i in Filter.search().extra(from_=0, size=10000):
            content = getattr(i.definition, 'node', None)
            if content and content not in ['.*', '*', '~.*', '~*']:
                result_v2 = i.node_definition_to_filter(content, False, 'v2')
                result_v3 = i.node_definition_to_filter(content, False, 'v3')

                if result_v2 != result_v3:
                    print("ERROR")
