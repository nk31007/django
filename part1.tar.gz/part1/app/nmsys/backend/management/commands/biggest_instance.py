from django.core.management.base import BaseCommand
from contrib.utils import epic_generator
import ujson as json
import requests


class Command(BaseCommand):

    def handle(self, *args, **options):
        max = 0
        max_url = ''
        for url in epic_generator():
            try:
                result = requests.get('%s?a=alert&cmd=list&s=e-2years' % url['url']).text
                if len(json.loads(result)['alert']['list']) > max:
                    max = len(json.loads(result)['alert']['list'])
                    max_url = url
            except:
                continue
        print '%s is %s' % (max_url, max)

