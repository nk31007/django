__author__ = 'nmsys'


from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json
from contrib.kin import Kin
from elasticsearch_dsl import Search, Q
from elasticsearch_dsl.connections import connections
from django.conf import settings

# django
from backend.models import Filter
hosts = []

for server in getattr(settings, "ES_HOST").split(","):
    host, port = server.strip().split(":")
    hosts.append({"host": host, "port": port})
connections.create_connection(hosts=hosts, timeout=120)

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def add_arguments(self, parser):
        parser.add_argument('filt', nargs='+', type=str)

    def handle(self, *args, **options):
        obj = Kin()
        obj.task()

        location = obj.get_last_publish()

        main_filter = Filter.get(id=options['filt'][0]).filter()
        content = []
        only_critical = Q(
            'bool',
            should=[Q('match', status="CRITICAL"), Q('match', status="WARNING")],
            minimum_should_match=1
        )
        search = Search().query(
            Q('bool', must=[main_filter, only_critical])
        )

        result = search\
            .using(connections.get_connection())\
            .extra(_source={'includes': ['node', 'alert', 'instance', 'locale']})\
            .index('epic')\
            .doc_type('alert')
        for hit in result.scan():
            content.append(hit.to_dict())
        print(obj.fetch_correlation(location, content))

