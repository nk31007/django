__author__ = 'nmsys'
from contrib.notifier.handler.grandprix.lib.SSPAuthenticationService import SSPAuthenticationService
from contrib.notifier.handler.grandprix.grandprix import Grandprix
from django.conf import settings
import pprint
from django.core.management.base import BaseCommand
from backend.models import Filter, Alert
from elasticsearch_dsl import Q
from contrib.notifier.handler.centralstationHandler import Centralstation
import re
import logging

logger = logging.getLogger(__name__)

class Command(BaseCommand):
     def handle(self, *args, **options):
        ibj = SSPAuthenticationService(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            settings.CENTRALSTATION_PAS
        )
        centralstation = Grandprix(
            settings.CENTRALSTATION_URL,
            settings.CENTRALSTATION_ENV,
            settings.CENTRALSTATION_ID,
            ibj.token()
        )
        escalated_workgroup = 'ISO SSC auto'
        configuration_item = 'SSC Delivery SRE'
        result = centralstation.status('INC075183253')
        problem = False
        if 'queryList' in result:
            if len(result['queryList']) == 1:
                obj = result['queryList'][0]['queryTicketListType']
                if obj['configurationItem'] != configuration_item:
                    problem = True 
                if escalated_workgroup not in obj['configurationItem']:
                    problem = True

                if problem:
                    node = re.findall(r'Node\s:\s([^\\]+)', obj['description'])[0]
                    alert = re.findall(r'Alert\s:\s([^\\]+)', obj['description'])[0]
                    name = re.findall(r'Name\s:\s([^\\]+)', obj['description'])[0]
                    ofilter = Filter.search().query("match", name=name).execute()
                    oalert = Alert.search().query(Q('bool', must=[Q('match', alert=alert), Q('match', node=node)])).execute()
                    myfilter=ofilter[0]
                    alert=oalert[0].to_dict()
                    subscription = None
                    for i in myfilter.subscription:
                        definition = i.to_dict()
                        if 'centralstation_configuration_item' in definition:
                            if definition['centralstation_configuration_item'] == configuration_item:
                                subscription = i
                    o = Centralstation(subscription, myfilter, oalert.to_dict(), myfilter.details, logger)

                    alert_special = re.compile('^([a-zA-Z\]+)@([a-zA-Z_]+)_([a-zA-Z\.\-0-9]+)_([a-zA-Z\-0-9_]+)$')
                    uu_pk = "%s %s: %s %s" % (alert['status'], o.content['name'], alert['alert'], alert['node'])
                    if len(uu_pk) > 240:
                        uu_pk = "%s : %s %s" % (alert['status'], o.content['name'], alert['node'])
                    # Will allow custom subjects later
                    subject = '%s' % uu_pk
                    if alert['alert'].startswith('gns') and '@gns' in alert['alert']:
                        cc = alert_special.findall(alert['alert'])
                        if len(cc) > 0:
                            subject = '%s: %s %s - %s' % (
                                alert['status'],
                                ' '.join(cc[0][0].split('_')[3:]),
                                cc[0][1],
                                cc[0][2].replace('_', '/')
                            )
                    elif o.content['name'] == alert['alert']:
                        subject = "%s : %s %s" % (alert['status'], o.content['name'], alert['node'])


                    contact = getattr(subscription, 'input-contact-%s' % alert['status'].lower(), '').split(',')
                    priority = getattr(subscription, 'priority-%s' % alert['status'].lower(), '').replace("P", "")
                    if contact[0] == '':
                        contact = subscription['email-contact'].split(',')
                        priority = getattr(subscription, 'priority', '').replace("P", "")

                    payload = o.build_payload(alert['status'], priority, subject, [alert])
                    
