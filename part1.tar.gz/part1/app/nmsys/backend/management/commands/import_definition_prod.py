
from django.core.management.base import BaseCommand, CommandError
import re
import logging
import ujson as json

# django
from contrib.nmsysv2config import NmsysV2Config

class Command(BaseCommand):
    help = 'Import alerts from Production'

    def handle(self, *args, **options):
        NmsysV2Config().import_old()
