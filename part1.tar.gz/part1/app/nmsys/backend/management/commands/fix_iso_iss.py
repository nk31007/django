from django.core.management.base import BaseCommand, CommandError
import re
import logging
import json
from django.conf import settings
# django
from backend.models import *

class Command(BaseCommand):
    help = 'Closes the specified poll for voting'

    def handle(self, *args, **options):
        change = False
        for i in Filter.search().extra(from_=0, size=10000):
            if 'subscription' in i:
                for su in i.subscription:
                    if 'centralstation_template' in su:
                        if su.centralstation_template == 'ISO':
                            su.centralstation_template = 'IS&S'
                            change = True
                        if su.centralstation_template == '1':
                            su.centralstation_template = 'IS&T'
                            change = True
                if change:
                    i.save()
                    change = False
