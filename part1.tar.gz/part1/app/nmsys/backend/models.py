#!/usr/bin/python
#############################################
# File Name : models.py
#
# Purpose : model for alerting
#
# Created By : Ronan FOUCHER <rfoucher@apple.com>
#
# Copyright 2013 Apple Inc. All rights reserved.
#
#############################################

import logging
from datetime import datetime, timedelta
from elasticsearch_dsl import Document 
from elasticsearch_dsl.connections import connections
from contrib.resource.serializer import TemplateSerializer
from django.conf import settings
from contrib.resource.redisrouter import RedisRouter
from elasticsearch_dsl import Search, Q
from contrib.epic import EpicSearch
from contrib.utils import load_class_from_name, chunks
from elasticsearch.helpers import bulk, BulkIndexError
from elasticsearch.exceptions import TransportError
from threading import Thread
from contrib.pager import email_me
import socket
from time import time
import ujson as json
import re
import os
from itertools import chain
from contrib.metrics import create_metric

logger = logging.getLogger(__name__)

connections.create_connection(**settings.ES_CONFIG)

class IndexManagement(Document):
    def create_index(self, extra=''):
        details = self.to_dict(True)
        connections.get_connection().indices.create(
            '%s%s' % (details['_index'], extra),
            json.loads(open(getattr(settings, "BASE_DIR")+'/nmsys/%s.json' % details['_index']).read()),
            ignore=400,
            include_type_name=True
        )

    def delete_index(self, extra=''):
        details = self.to_dict(include_meta=True)
        connections.get_connection().indices.delete(details['_index'])

    def rotate_index(self):
        details = self.to_dict(include_meta=True)
        return (datetime.today()-timedelta(((datetime.today().weekday() + 1) % 7))).strftime('%Y_%m_%d')

    def update_index(self, content):
        details = self.to_dict(include_meta=True)
        connections.get_connection().indices.put_mapping(
            index=details['_index'], doc_type=details['_doc_type'], body=content
        )

    def list_snapshot_list(self):
        return connections.get_connection().snapshot.get_repository(repository='_all').items()

    def snapshot_index(self, indices, snap_name):
        get_all_repo = self.list_snapshot_list()
        connections.get_connection().snapshot(
            get_all_repo[0],
            snap_name,
            body={'indices': indices}
        )

    def restore_index(self, extra=''):
        pass

    def alias_index(self, alias_index, data_index):
        details = self.to_dict(include_meta=True)
        connections.get_connection().indices.put_alias(index=data_index, name=alias_index)

    def reindex(self, data_index):
        details = self.to_dict(include_meta=True)
        connections.get_connection().indices.delete(index="%s-%s" % data_index, ignore=[400, 404])
        
        connections.get_connection().indices.create(index="index_source", ignore=[400, 404])
        connections.get_connection().helpers.reindex(
            client=connections.get_connection(),
            source_index=details['_index'],
            target_index=details['_index'],
            target_client=connections.get_connection())

class NotificationTemplate(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_TEMPLATE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_TEMPLATE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")



class Alert(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_ALERT_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_ALERT_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")


    to_search = [
        '',
        'OK', 'UNKNOWN', 'INFO', 'WARNING', 'CRITICAL',
        'FATAL', '', '', '',
        'AUTO-RESUME ADMINISTRATIVE', 'PERMANENT ADMINISTRATIVE', 'MAINTENANCE',
        '', '', ''
    ]

    def aging(self, force=False):
        result = self.search().query(
            Q('range', timestamp={"lt": int(time()) - settings.RETENTION * 60 * 60})
        )[0:100000]
        content = result.execute()
        count = content.hits.total

        if 0 < count < 100000 or force:
            if force:
                print(count)
            content = content.to_dict()['hits']['hits']
            for item in content:
                item.pop('_source')
                item['_op_type'] = 'delete'
            bulk(connections.get_connection(), content)
        elif count > 100000:
            logger.critical('Deleting large number of alerts %s' % content)
        return count

    # For FULL resend : will check if alert already exists
    #   refresh if unchanged,
    #   upsert if changed or absent
    def fetch_existing(self, application, locale, instance, raw):
        mget_list = []
        data_upsert = []
        data_update = []
        details = self.to_dict(include_meta=True)
        now = int(time())
        content = json.loads(raw)['alert']['list']
        for alert in content:
            alert.setdefault('locale', locale)
            alert.setdefault('instance', instance)
            mget_list.append("%s_%s_%s_%s_%s" % (
                alert['node'].replace('/', '_'),
                alert['ng'].replace('/', '_'),
                alert['alert'].replace('/', '_'),
                alert['locale'],
                alert['instance']
            ))
        result = self.mget(mget_list)
        for idx, data in enumerate(result):
            # Mget returns None if missing - alert was either missed or aged
            if data is None:
                data_upsert.append(content[idx])
            elif 'u_ptime' in data and content[idx]['u_ptime'] > data['u_ptime']:
                data_upsert.append(content[idx])
            elif 'u_ctime' in data and content[idx]['u_ctime'] > data['u_ctime']:
                data_upsert.append(content[idx])
            else:
                data_update.append(content[idx])

        bulk(connections.get_connection(), 
            self.update_data(application, locale, instance, details, data_update) +
            self.build_data(application, locale, instance, details, data_upsert)
        )

    # Refresh data in bulk
    def update_data(self, application, locale, instance, details, content):
        now = int(time())
        data =[]
        for alert in content:
            try:
                alert.setdefault('locale', locale)
                alert.setdefault('instance', instance)
                alert.setdefault('application', application)
                alert.setdefault('ng', '')
                data.append({
                    '_id': "%s_%s_%s_%s_%s" % (
                        alert['node'].replace('/', '_'),
                        alert['ng'].replace('/', '_'),
                        alert['alert'].replace('/', '_'),
                        alert['locale'],
                        alert['instance']
                    ),
                    '_index': details['_index'],
                    '_type': '_doc',
                    '_op_type': 'update',
                    'doc_as_upsert': True,
                    'doc': {
                        'timestamp': now,
                    }
                })
            except Exception as e:
                logger.critical("[Alert::update_data] Problem with %s (%s, %s) "
                                "while ingesting %s %s" % (alert, locale, instance, details, e))
        return data

    # Upsert data builder
    def build_data(self, application, locale, instance, details, content):
        now = int(time())
        data =[]
        for alert in content:
            try:
                alert.pop('id', None)
                alert.setdefault('u_ptime', alert['u_ctime'])
                alert.setdefault('locale', locale)
                alert.setdefault('instance', instance)
                alert.setdefault('application', application)
                alert.setdefault('ng', '')
                if alert['u_ptime'] > int(time()) - 120:
                    alert['ack'] = 0
                alert.update({
                    'status': self.to_search[int(alert['state'])],
                    'timestamp': now,
                })
                data.append({
                    '_id': "%s_%s_%s_%s_%s" % (
                        alert['node'].replace('/', '_'),
                        alert['ng'].replace('/', '_'),
                        alert['alert'].replace('/', '_'),
                        alert['locale'],
                        alert['instance']
                    ),
                    '_index': details['_index'],
                    '_type': '_doc',
                    '_op_type': 'update',
                    'doc_as_upsert': True,
                    'doc': alert
                })
            except Exception as e:
                logger.critical("[Alert::build_data] Problem with %s (%s, %s) "
                                "while ingesting %s %s" % (alert, locale, instance, details, e))
        return data

    # Generic wrapper, will allow cache and uncached bulk upsert
    def bulk(self, application, locale, instance, raw, cache=False):
        details = self.to_dict(include_meta=True)
        now = int(time())
        if cache:
            raw = self.check_cache(locale, instance, raw)
        content = json.loads(raw)['alert']['list']
        data = self.build_data(application, locale, instance, details, content)
        bulk(connections.get_connection(), data)
        return len(data)


    @staticmethod
    def create_script(redis_instance):
        ff = open(getattr(settings, "BASE_DIR")+'/nmsys/alert_script.lua')
        content = ff.read()
        ff.close()
        return redis_instance.register_script(content)

    def check_cache(self, locale, instance, raw, test=False):
        redis_instance = RedisRouter().retrieve_redis_connection('common', 'dsemond')
        redis_script = self.create_script(redis_instance)
        # Will pass the index
        update_key = 'Result_stream_%s_%s_%s' % (locale, instance, time())
        retry = True
        counter = 0
        # Checking Cache
        while retry:
            try:
                redis_script(keys=[raw, update_key, locale, instance], args=[])
                retry = False
            except Exception as e:
                print(e)
                logger.critical("[ check_cache ] : Problem with redis script %s " % len(raw))
                logger.critical("[ check_cache ] : Problem with redis script %s " % e)
                if counter < 5:
                    counter += 1
                else:
                    logger.critical("[ check_cache ] : Major problem - just ingest everything")
                    return raw
        result_update = json.loads(redis_instance.get(update_key))
        redis_instance.delete(update_key)
        return json.dumps({'alert': {'list': result_update}})

    # Retuns stats for alert to be deleted in the next 10 minutes
    def aging_stats(self):
        tstamp = (settings.RETENTION * 60 * 60) + 10 * 60
        metrics = []
        search = self.search().query(
            Q('range', timestamp={"lt": int(time()) - tstamp})
        )
        search.update_from_dict({"size": 0})
        search.aggs.bucket('alert', 'terms', field='alert', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('instance', 'terms', field='instance', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('locale', 'terms', field='locale', size=settings.ES_AGGREGATION_SIZE)
        try:
            result = search.execute()
            metrics = [{'node': '/type=delete/filter=all', 'count': ('GAUGE', result.hits.total)}]
            aggregates = result.aggregations.to_dict()
            if result.hits.total > 100000:
                logger.critical('Very large number of alerts to be deleted %s %s' % (socket.gethostname(), result.hits.total),
                         'CRITICAL %s ' % aggregates)
                raise ValueError('Too many alert to delete')
            for i in aggregates['alert']['buckets']:
                for j in i['instance']['buckets']:
                    for k in j['locale']['buckets']:
                        metrics.append({
                            'node': '/type=delete/alert=%s/instance=%s/locale=%s' % (i['key'], j['key'], k['key']),
                            'count': ('GAUGE', k['doc_count'])
                        })
        except Exception as exc:
            logger.critical('[aging_stats] Error task %s' % exc)
        return metrics

    # Retuns stats for alert to be deleted in the next 10 minutes
    def updated_stats(self):
        now = int(time())
        metrics = []
        search = self.search().query(
            Q('range', u_ptime={"gte": now - 60, "lte": now})
        )
        search.update_from_dict({"size": 0})
        search.aggs.bucket('alert', 'terms', field='alert', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('instance', 'terms', field='instance', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('locale', 'terms', field='locale', size=settings.ES_AGGREGATION_SIZE)
        try:
            result = search.execute()
            metrics = [{'node': '/type=update/filter=all', 'count': ('GAUGE', result.hits.total)}]
            aggregates = result.aggregations.to_dict()

            for i in aggregates['alert']['buckets']:
                for j in i['instance']['buckets']:
                    for k in j['locale']['buckets']:
                        metrics.append({
                            'node': '/type=update/alert=%s/instance=%s/locale=%s' % (i['key'], j['key'], k['key']),
                            'count': ('GAUGE', k['doc_count'])
                        })
        except Exception as exc:
            logger.critical('[updated_stats] Error task %s' % selfexc)
        return metrics

    # Retuns stats for alert to be deleted in the next 10 minutes
    def refreshed_stats(self):
        now = int(time())
        metrics = []
        search = self.search().query(
            Q('range', timestamp={"gte": now - 60, "lte": now})
        )
        search.update_from_dict({"size": 0})
        search.aggs.bucket('alert', 'terms', field='alert', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('instance', 'terms', field='instance', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('locale', 'terms', field='locale', size=settings.ES_AGGREGATION_SIZE)
        try:
            result = search.execute()
            metrics = [{'node': '/type=refresh/filter=all', 'count': ('GAUGE', result.hits.total)}]
            aggregates = result.aggregations.to_dict()

            for i in aggregates['alert']['buckets']:
                for j in i['instance']['buckets']:
                    for k in j['locale']['buckets']:
                        metrics.append({
                            'node': '/type=refresh/alert=%s/instance=%s/locale=%s' % (i['key'], j['key'], k['key']),
                            'count': ('GAUGE', k['doc_count'])
                        })
        except Exception as exc:
            logger.critical('[refreshed_stats] Error task %s' % exc)
        return metrics

    # Retuns stats of all alerts
    def overall_stats(self):
        now = int(time())
        metrics = []
        search = self.search().query()
        search.update_from_dict({"size": 0})
        search.aggs.bucket('alert', 'terms', field='alert', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('instance', 'terms', field='instance', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('locale', 'terms', field='locale', size=settings.ES_AGGREGATION_SIZE)
        try:
            result = search.execute()
            metrics = [{'node': '/type=overall/filter=all', 'count': ('GAUGE', result.hits.total)}]
            aggregates = result.aggregations.to_dict()

            for i in aggregates['alert']['buckets']:
                for j in i['instance']['buckets']:
                    for k in j['locale']['buckets']:
                        metrics.append({
                            'node': '/type=refresh/alert=%s/instance=%s/locale=%s' % (i['key'], j['key'], k['key']),
                            'count': ('GAUGE', k['doc_count'])
                        })
        except Exception as exc:
            logger.critical('[overall_stats] Error task %s' % exc)
        return metrics

    def kin_fetch(self, filter_a):
        query = []
        for k, v in filter_a.items():
            if isinstance(v, list):
                t_query = []
                for i in v:
                    t_query.append(Q("match", **{k: v}))
                query.append(Q('bool', should=t_query, minimum_should_match=1))
            else:
                query.append(Q("match", **{k: v}))

        search = self.search().query(
            Q('bool', must=query, must_not=[Q('regexp', alert="epicd.*|.*bgpPeerState.*|.*bgppeer.*")])
        )

        content = []
        try:
            result = search.extra(_source={'includes': ['node', 'alert', 'instance', 'locale']}).execute()
            for hit in result.scan():
                content.append(hit.to_dict())
            return content
        except Exception as exc:
            print(exc)
            return []


class Filter(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_FILTER_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_FILTER_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")


    def build_filter_regex(self, key, content):
        arr_alert = []
        for filt in content.split(','):
            if filt == '.*' or filt == '*':
                continue
            #if not re.match('\^.*\$', filt):
            #    filt = '^%s$' % filt
            arr_alert.append(Q("regexp", **{key: "%s" % filt}))
        return arr_alert

    def definition_to_filter(self, key_filter, specific_filter):
        if not specific_filter:
            raise ValueError
        real_match = re.compile(r"\^(.*)\$")
        include_filter = []
        exclude_filter = []

        for pre_filter in specific_filter.split(','):
            if pre_filter.startswith('!'):
                full = real_match.search(pre_filter[1:])
                if full:
                    post_filter = full.group(1)
                else:
                    post_filter = pre_filter[1:]
                exclude_filter.append(Q('regexp', **{key_filter: post_filter}))
            else:
                full = real_match.search(pre_filter)
                if full:
                    post_filter = full.group(1)
                else:
                    post_filter = pre_filter
                include_filter.append(Q('regexp', **{key_filter: post_filter}))

        return Q('bool', should=include_filter, minimum_should_match=1), exclude_filter

    def node_definition_to_filter(self, specific_filter, cache, version='v2'):
        if not specific_filter:
            raise ValueError
        if '~' not in specific_filter and ':intersect' not in specific_filter:
            include, exclude = self.definition_to_filter('node', specific_filter)
            return Q('bool', must=include, must_not=exclude)

        # Specific optimization exclusion only, look for any exclusion and reverse the search
        exclusion_only = re.findall('!([^,]+)+', specific_filter)

        if len(specific_filter.split(',')) == len(exclusion_only):
            exc = EpicSearch(version=version).find_list(','.join(exclusion_only), cache=cache)
            if len(exc) > 0:
                return ~Q('terms', node=exc)
        else:
            inc = EpicSearch(version=version).find_list(specific_filter, cache=cache)
            if len(inc) > 0:
                return Q('terms', node=inc)
        # Fallback to v3 API in case v2 is empty (Ram reported a problem with v2 - time to transition)
        return self.node_definition_to_filter_v3(specific_filter, cache=cache, version='v3')
        # raise NameError("Node filter returns no result, please check in %s %s " % (settings.EPIC_URL, specific_filter))

    def node_definition_to_filter_v3(self, specific_filter, cache, version='v3'):
        if not specific_filter:
            raise ValueError
        if '~' not in specific_filter and ':intersect' not in specific_filter:
            include, exclude = self.definition_to_filter('node', specific_filter)
            return Q('bool', must=include, must_not=exclude)
        # Specific optimization exclusion only, look for any exclusion and reverse the search
        exclusion_only = re.findall('!([^,]+)+', specific_filter)
        if len(specific_filter.split(',')) == len(exclusion_only):
            exc = EpicSearch().find_list(','.join(exclusion_only), cache=cache)
            if len(exc) > 0:
                return ~Q('terms', node=exc)
        elif len(specific_filter.split(',')) == len(exclusion_only):
            result = set()
            for i in exclusion_only:
                result.add(EpicSearch().find_list(i, cache=cache, version=version))
            if len(result) > 0:
                return ~Q('terms', node=exc)
        else:
            inc = EpicSearch().find_list(specific_filter, cache=cache, version=version)
            if len(inc) > 0:
                return Q('terms', node=inc)
        raise NameError("Node filter returns no result, please check in %s %s " % (settings.EPIC_URL, specific_filter))

    def node_definition_to_filter_special(self, specific_filter, cache, version='v3'):
        if '~' not in specific_filter and ':intersect' not in specific_filter:
            include, exclude = self.definition_to_filter('node', specific_filter)
            return Q('bool', must=include, must_not=exclude)
        # Specific optimization exclusion only, look for any exclusion and reverse the search
        exclusion_only = re.findall('!([^,]+)+', specific_filter)
        if len(specific_filter.split(',')) == len(exclusion_only):
            result = set()
            for i in exclusion_only:
                result.add(EpicSearch().find_list(i, cache=cache, version=version))
            if len(result) > 0:
                return ~Q('terms', node=result)
        else:
            inc = EpicSearch().find_list(specific_filter, cache=cache, version=version)
            if len(inc) > 0:
                return Q('terms', node=inc)
        raise NameError("Node filter returns no result, please check in %s %s " % (settings.EPIC_URL, specific_filter))


    def filter(self, cache=True):
        include_filter = []
        exclude_filter = []

        filter_s = Q()
        disabled = getattr(self, 'disabled', False)
        if disabled:
            raise ValueError
        if self.application != 'filter':
            return Q('bool', should=[
                Q('match', alert="%s@%s" % (self.information.username, self.information.name)),
                Q('regexp', alert="%s@%s/.*" % (self.information.username, self.information.name)),
            ], minimum_should_match=1)
        else:
            for key in ['alert', 'instance', 'locale']:
                content = getattr(self.definition, key, None)
                if content and content not in ['.*', '*', '~.*', '~*']:
                    include, exclude = self.definition_to_filter(key, content)
                    include_filter.append(Q('bool', should=include, minimum_should_match=1))
                    exclude_filter += exclude

        if len(include_filter):
            filter_s = Q('bool', filter=include_filter)

        #  Requires to use a filter since node terms list can be > 1024 (limit for query objects)
        # Removing Exception around that - otherwise we end up with no node filter
        content = getattr(self.definition, 'node', None)
        if content and content not in ['.*', '*', '~.*', '~*']:
            filter_s &= Q('bool', filter=self.node_definition_to_filter(content, cache))

        if len(exclude_filter) > 0:
            filter_s &= ~Q('bool', filter=exclude_filter)
        return filter_s

    def occurrence(self):
        # Sampling interals is fixed for now - 60s
        pass

    def emulate(self):
        from contrib.kin import Kin

        obj = Kin()
        location = obj.get_last_publish()
        main_filter = self.filter()
        content = []
        try:
            only_critical = Q(
                'bool',
                should=[Q('match', status="CRITICAL"), Q('match', status="WARNING")],
                minimum_should_match=1
            )
            search = Alert().search().query(
                Q('bool', must=[main_filter, only_critical])
            )
            result = search.extra(_source={'includes': ['node', 'alert', 'instance', 'locale']})
            for hit in result.scan():
                content.append(hit.to_dict())
            return obj.fetch_correlation(location, content)
        except Exception as e:
            logger.critical("Error %s" % e)
            return {'me': 'ornot'}

    def filter_notification(self, subscription, now, force):
        last = self.get_time_marker(subscription['subscriber'])
        if last is None or force:
            last = 0
        last = int(last)
        filter_s = Q(
            'bool',
            should=[
                Q(
                    'bool',
                    should=[
                        ~Q("exists", field="silence"),
                        Q('range', silence={"lte": int(time())}),
                    ],
                    minimum_should_match=1
                ),
                Q(
                    'bool',
                    should=[
                        ~Q("exists", field="ack"),
                        Q('term', ack=0)
                    ],
                    minimum_should_match=1
                )
            ],
            minimum_should_match=2
        )
        duration = int(subscription['select-duration']) * 60
        resend = int(subscription['resend-after']) * 60
        delay_processing = 30 # 60 * 2  # 120 (06/16/21 Ryan requested reduction of the delay)

        from_time = last - ((duration + delay_processing))
        to_time = now - ((duration + delay_processing))

        filter_s &= Q(
            'bool',
            should=[
                Q('range', u_ptime={
                    "gte": (from_time - (resend * i)),
                    "lte": (to_time - (resend * i))
                }) for i in chain(range(6), range(100, 101))
            ],
            minimum_should_match=1
        )

        filt = []
        if "notif-ifcritical" in subscription and subscription["notif-ifcritical"] == "on":
            filt.append(Q('match', status="CRITICAL"))
        if "notif-ifwarning" in subscription and subscription["notif-ifwarning"] == "on":
            filt.append(Q('match', status="WARNING"))
        if "notif-ifunknown" in subscription and subscription["notif-ifunknown"] == "on":
            filt.append(Q('match', status="UNKNOWN"))
        if "notif-ifinfo" in subscription and subscription["notif-ifinfo"] == "on":
            filt.append(Q('match', status="INFO"))
        if "recovery" in subscription and subscription["recovery"] == "on":
            filt.append(
                Q('match', status="OK") &
                Q('range', u_ptime={
                    "gte": (last - duration - delay_processing),
                    "lte": (now - duration - delay_processing)
                    })
            )
        if len(filt) > 0:
            filter_s &= Q(
                'bool',
                should=filt,
                minimum_should_match=1
            )
        else:
            raise ValueError('No status filter present in subscription'
                             'just throw an error to prevent crap from being sent')
        return filter_s

    def backup(self):
        self.information.username = self.information.username.strip()
        self.information.name = self.information.name.strip()

        directory = os.path.join(settings.ALERT_BACKUP, self.information.username)
        filename = '%s_%s.yaml' % (self.information.username, self.information.name)
        if not os.path.exists(directory):
            os.makedirs(directory)
        f = open(os.path.join(directory, filename), 'wb')
        content = self.to_dict()
        if 'pk' not in content:
            content['pk'] = self.meta.id
        for k in ['state', 'status', 'timestamp', 'u_ctime', 'name', 'details', 'resource_uri']:
            content.pop(k, None)

        f.write(TemplateSerializer().to_yaml(content))
        return os.path.join(directory, filename)

    def cleandelete(self):
        directory = os.path.join(settings.ALERT_BACKUP, self.information.username)
        filename = '%s_%s.yaml' % (self.information.username, self.information.name)
        try:
            os.remove(os.path.join(directory, filename))
        except:
            pass

    def clear_lock(self):
        r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
        self.release_lock(r_base)

    def acquire_lock(self, conn, timestamp):
        return conn.setnx('Lock::%s' % self.name, timestamp)

    def release_lock(self, conn):
        return conn.delete('Lock::%s' % self.name)

    def check_lock(self, conn):
        start = int(time())
        main_lock = int(conn.get('Lock::%s' % self.name))
        if main_lock and 600 < start - main_lock < 6400:
            logger.info("Another worker is already working on %s for %s" % (self.name, start - main_lock))
        elif main_lock and start - main_lock > 6400:
            logger.critical("Task is taking more than %s seconds\
             for the filter %s to run - Allowing it to run again" % (start - main_lock, self.name))
            email_me('Notify is taking too long %s' % socket.gethostname(), 'Timer %s s, filter %s' % (start - main_lock, self.name))
            self.release_lock(conn)

    def execute(self, main_filter, now, force, subscription):
        try:
            search = Alert().search().query(
                Q('bool', must=[main_filter, self.filter_notification(subscription, now, force)])
            )[0:10000]
        except ValueError as e:
            logger.info('[nofify (minor) issue] Subscription %s issue while building filter %s' % (
                subscription['subscriber'], e
            ))
            return
        if not getattr(self, 'details', False):
                details = self.set_stats()
        if "ratio" in subscription:
            details = self.details.to_dict()
            ratio = int(details['ratio'])

            if ratio > int(subscription['ratio']):
                logger.critical("[Filter::execute] Ratio is %s limit is %s executing" % (ratio, subscription['ratio']))
            else:
                logger.debug('[Filter::execute] Ratio is not reached, skipping (%s/%s)'% (ratio, subscription['ratio']))
                return
        try:
            result = search.execute()
            cl = load_class_from_name(
                'contrib.notifier.handler.%sHandler.%s' % (
                    subscription['notification_type'],
                    subscription['notification_type'].capitalize()
                )
            )
            if result.hits.total > 0:
                obj = cl(subscription, self, result.to_dict(), self.details, logger)
                obj.publish()
                self.set_time_marker(subscription['subscriber'], now)
            else:
                logger.debug('[Filter::execute] no alert matching, skipping')
        except Exception as e:
            logger.critical('[Filter::execute] Error with subscription %s %s' % (subscription, e))

    def notify(self, force=False, cst=False):
        start = int(time())
        r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
        if not r_base.get('maintenance'):
            logger.info('[Filter::notify] Cluster currrently under maintenance - skipping')
            return
        locked = self.acquire_lock(r_base, start)
        if not getattr(self, 'subscription', False) or len(self.subscription) == 0:
            return
        if not locked:
            self.check_lock(r_base)
            return
        try:
            main_filter = self.filter()
            now = int(time())
            tasks = []
            for idx, subscription in enumerate(sorted(self.subscription, key=lambda k: k['notification_type'])):
                try:
                    if 'silence' in subscription and int(subscription['silence']) > int(time()):
                        continue
                    if cst and subscription['notification_type'] != 'centralstation':
                        continue
                    if settings.THREAD_NOTIFICATION:
                        task = Thread(target=self.execute, args=(main_filter, now, force, subscription))
                        tasks.append(task)
                        task.start()
                    else:
                        self.execute(main_filter, now, force, subscription)
                except Exception as e:
                    logger.critical("Error in filter %s with subscription %s %s %s" % (self.name, subscription, e, idx))
            if settings.THREAD_NOTIFICATION:
                for task in tasks:
                    task.join()
        except Exception as e:
            logger.critical("Error with filter %s %s" % (self.name, e))
        finally:
            end = int(time())
            self.release_lock(r_base)
            logger.info("[%s] Tasks are threaded %s and took %ss" % (self.name, settings.THREAD_NOTIFICATION, end-start))

    def export_epic(self):
        if self.application != 'epic':
            return None
        threshold = []
        list_status = ['', 'ok', 'unknown', 'info', 'warning', 'critical']
        for aggr, info in sorted(self.threshold.to_dict().items()):
            for nest in info['definition']:
                threshold.append('alert = %s; state = %s;   alert_dep = %s;  expr = %s;   description = ;' % (
                    self.name,
                    list_status.index(info['status'].lower()),
                    aggr,
                    ' '.join(nest)))
        if self.definition.mode == 'average':
            mode = 'avg'
        elif self.definition.mode == 'sum':
            mode = ''
        else:
            mode = self.definition.mode
        if 'epicimg' in self.information and self.information.epicimg != '':
            description = "%s <epicimg>%s</epicimg>" % (self.information.description, self.information.epicimg)
        else:
            description = self.information.description
        definition = 'alert_node = %s; ng = %s; n = %s; m = %s; description =%s' % (
            self.name,
            '',
            self.definition.node,
            mode,
            description
        )
        return definition, threshold

    def export_yaml(self):
        return TemplateSerializer().to_yaml(self.to_dict())

    def get_time_marker(self, subscriber):
        r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
        return r_base.get('TimeMarker::%s::%s' % (self.name, subscriber))

    def set_time_marker(self, subscriber, time_marker):
        r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
        return r_base.set('TimeMarker::%s::%s' % (self.name, subscriber), time_marker)

    def set_stats(self):
        search = Alert().search().query(self.filter())
        search.aggs.bucket('bucket', 'terms', field='status', size=settings.ES_AGGREGATION_SIZE).bucket(
            'ack',
            'filter',
            Q(
                'bool',
                should=[
                    Q('range', silence={"gte": int(time())}),
                    Q('term', ack=1)
                ],
                minimum_should_match=1
            )
        )
        search.update_from_dict({"size": 0})
        status_add = [
            '',
            'OK', 'UNKNOWN', 'INFO', 'WARNING', 'CRITICAL',
            'FATAL', '', '', '',
            'AUTO-RESUME ADMINISTRATIVE', 'PERMANENT ADMINISTRATIVE', 'MAINTENANCE',
            '', '', ''
        ]
        try:
            result = search.execute()
            content = {}
            worst_state = -1
            data = result.aggregations.to_dict()
            total_ack = 0
            for item in data['bucket']['buckets']:
                status = item['key'].upper()
                total = item['doc_count']
                ack = item['ack']['doc_count']
                content[str(status)] = total - ack
                total_ack += ack
                if worst_state < status_add.index(status):
                    worst_state = status_add.index(status)
        except TransportError as e:
            logger.critical('[set_stats] ES transport request issue task Error %s %s' % (self.name, e))
        except Exception as exc:
            logger.critical('[set_stats] ES request issue task Error %s %s' % (self.name, exc))
            return {}
        try:
            if not getattr(self, 'state', False) or worst_state != self.state:
                logger.debug('[set_stats] %s Status has changed, updating the overall state %s %s' % (self.name, getattr(self, 'state', False), worst_state ))
                self.update(status=status_add[worst_state] if worst_state != -1 else 'PENDING', state=worst_state)

            content['Acknowledged'] = total_ack
            sum_bad = float(content.get('CRITICAL', 0) + content.get('WARNING', 0))
            sum_total = float(sum(content.values())) - total_ack
            ratio = 0
            if sum_total > 0:
                ratio = int((sum_bad / sum_total) * 100)
            content['ratio'] = ratio
            try:
                if getattr(self, 'details', False):
                    for key, value in self.details.to_dict().items():
                        if key not in content:
                           content[key] = 0
                content.pop('', None)
                self.update(details=content)
            except Exception as exc:
                logger.critical('[set_stats] ES update unable to set state %s %s %s' % (self.name, exc, content))
            return content
        except Exception as exc:
            logger.critical('[set_stats] ES update unable to set state %s %s' % (self.name, exc))
            return {}

class Notification(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_NOTIFICATION_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_NOTIFICATION_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")


    # Retuns stats of all notification
    def notification_stats(self):
        metrics = []
        now = int(time()) * 1000
        search = self.search().query(Q('range', timestamp={"gte": now - 60000, "lte": now}))
        search.update_from_dict({"size": 0})
        search.aggs.bucket('route', 'terms', field='route', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('name', 'terms', field='name', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('subscriber', 'terms', field='subscriber', size=settings.ES_AGGREGATION_SIZE)\
            .bucket('hostname', 'terms', field='hostname', size=settings.ES_AGGREGATION_SIZE)
        try:
            result = search.execute()
            metrics = [{'node': '/type=notification/filter=all', 'count': ('GAUGE', result.hits.total)}]
            aggregates = result.aggregations.to_dict()
            for i in aggregates['route']['buckets']:
                for j in i['name']['buckets']:
                    for k in j['subscriber']['buckets']:
                        for l in k['hostname']['buckets']:
                            metrics.append({
                                'node': '/type=notification/route=%s/name=%s/subscriber=%s/hostname=%s' % (
                                    i['key'], j['key'], k['key'], l['key']
                                ),
                                'count': ('GAUGE', k['doc_count'])
                            })
        except Exception as exc:
            logger.critical('[notification_stats] Error task %s' % exc)
        return metrics
 
    def aging(self, force=False):
        result = self.search().query(
            Q('range', timestamp={"lt": (int(time()) - 60 * 24 * 60 * 60)*1000})
        )[0:10000]
        content = result.execute()
        count = content.hits.total
        content = content.to_dict()['hits']['hits']
        for item in content:
            item.pop('_source')
            item['_op_type'] = 'delete'
        bulk(connections.get_connection(), content)
        return count



class Acknowledgement(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_ACK_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_ACK_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")





class Node(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_NODE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_NODE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    def bulk(self, raw):
        data = []
        details = self.to_dict(include_meta=True)
        now = int(time())
        for content in raw:
            try:
                node = json.loads(content)
                node.pop('id', None)

                data.append({
                    '_id': node['node'].replace('/', '_'),
                    '_index': details['_index'],
                    '_type': '_doc',
                    '_op_type': 'update',
                    'doc_as_upsert': True,
                    'doc': node
                })
            except Exception as e:
                logger.critical("[Node::bulk] Problem while ingesting %s" % e)
        bulk(connections.get_connection(), data)
        return len(data)


class Maintenance(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_MAINTENANCE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_MAINTENANCE_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    def emulate(self):
        result = {}
        expand = True
        if self.schedule['dependents'] == '0' and self.schedule['dependencies'] == '0':
            expand = False
        try:
            result['node'] = self.find_nodes(True)
        except:
            result['error'] = 'Too many devices matching your filter, the maintenance will be ignored'
            return result
        kin_list = []
        if expand:
            node_list = []
            for node in result['node']:
                kin, node = self.find_kin(node, False)
                node_list += node
                kin_list.append(kin)
        else:
            node_list = [n['node'] for n in result['node']]
        result['node_list'] = node_list
        result['kin_list'] = kin_list

        # ES won't let you put > 1024 nodes in a boolean query
        result['alert_list'] = []
        for kk in chunks(result['node_list'], 1020):
            result['alert_list'] += self.find_alerts(kk, True)

        return result

    def find_nodes(self, expand):
        node_list = EpicSearch().find_list(self.schedule['node'], expand=expand)
        if len(node_list) > 40000:
            raise ValueError('Too many nodes in your filter (maximum is 40000 per maintenance), '
                             'maintenance cannot be applied')
        elif len(node_list) == 0:
            node_list = EpicSearch().find_list(self.schedule['node'].split('.')[0], expand=expand)
            # When node is deprecated from Epic, the search will return 0
            # Apply a simple find perfect match to fix this rdar://problem/64517168
            if len(node_list) == 0:
                for i in self.schedule['node'].split(','):
                    node_list.append({'node': i})
        return node_list

    def diff_nodes(self):
        node_list = EpicSearch().find_list(self.schedule['node'], expand=True, version='v2', cache=False)
        node_list1 = EpicSearch().find_list(self.schedule['node'], expand=True, version='v3', cache=False)
        if len(node_list) != len(node_list1):
            print('%s %s %s filter %s ' % (self.name, len(node_list), len(node_list1), self.deployment.tag))
        if len(node_list) > 350000:
            print('filter %s too big %s' % (self.name, len(node_list1)))


    def find_kin(self, node, reduced=True):
        from contrib.kin import Kin

        obj = Kin().fetch_topology(
            node['node'],
            node['locale'],
            node['instance'],
            self.schedule['dependents'],
            self.schedule['dependencies'],
            True
        )
        if reduced:
            return list(self.node_list('properties', obj))
        else:
            return obj, list(self.node_list('properties', obj))

    def find_alerts(self, nodelist, started):
        query = Q('terms', node=nodelist)
        if 'alert' in self.schedule and self.schedule['alert'] != '.*':
            logger.critical('filter on alert %s' % self.schedule['alert'] )
            query &= Q('regexp', alert=self.schedule['alert'])
        if started:
            query &= Q(
                'bool',
                should=[
                    Q(
                        'bool',
                        should=[
                            ~Q("exists", field="silence"),
                            Q('range', silence={"lte": int(time())}),
                        ],
                        minimum_should_match=1
                    ),
                    Q(
                        'bool',
                        should=[
                            ~Q("exists", field="ack"),
                            Q('term', ack=0)
                        ],
                        minimum_should_match=1
                    )
                ],
                minimum_should_match=2
            )
        search = Search().query(
            query
        )[0:100000]

        result = Alert().search().query(
            query
        )[0:100000]
        content = search.execute()
        return content.hits.hits

    def unsilence(self, pk, user, alerts):
        now = int(time())
        to_run = []
        for item in alerts:
            result = {
                '_id': item['_id'],
                '_index': item['_index'],
                '_type': '_doc',
                'doc': {
                    'silence': now,
                    'time_ack': now,
                    'maintenance': pk,
                    'deleteuser': user,
                    'comment': 'Automatic maintenance was deleted \n %s' % pk
                },
                '_op_type': 'update',
                'doc_as_upsert': False
            }
            to_run.append(result)
        if len(to_run):
            try:
                bulk(connections.get_connection(), to_run, raise_on_error=True, raise_on_exception=True)
            except Exception as exc:
                logger.critical("%s(%s)" % (exc.__class__.__name__, exc))


    def silence(self, alerts):
        now = int(time())
        to_run = []
        for item in alerts:
            result = {
                '_id': item['_id'],
                '_index': item['_index'],
                '_type': '_doc',
                'doc': {
                    'silence': int(self.schedule['endmaintenance']),
                    'time_ack': now,
                    'maintenance': self.pk,
                    'user': self.schedule['owner'],
                    'comment': 'Automatic maintenance: \n %s \n(Node %s [%s:%s]\nStart %s/ End %s) \n'
                               '(<a href="/nmsys/alerting/maintenance/%s/"> details </a>)' % (
                        self.schedule['description'],
                        self.schedule['node'],
                        self.schedule['dependents'],
                        self.schedule['dependencies'],
                        self.schedule['startmaintenance'],
                        self.schedule['endmaintenance'],
                        self.pk
                    ),
                },
                '_op_type': 'update',
                'doc_as_upsert': False
            }
            to_run.append(result)
        if len(to_run):
            try:
                bulk(connections.get_connection(), to_run, raise_on_error=True, raise_on_exception=True)
            except Exception as exc:
                logger.critical("%s(%s)" % (exc.__class__.__name__, exc))

    def execute(self, started=False):
        result = {}
        alert_list = []
        if self.schedule['dependents'] == '0' and \
                        self.schedule['dependencies'] == '0':
            node_list = self.find_nodes(False)
        else:
            node_list = []
            for node in self.find_nodes(True):
                node_list += self.find_kin(node)
        for kk in chunks(node_list, 1020):
            alert_list += self.find_alerts(kk, True)
        self.silence(alert_list)

    def cleanup_execute(self, pk, user):
        remaining = True
        # Going for chunks of 50k to unsilence
        maxsize = 50000
        # Stop after 500k alerts unsilenced.
        maxloop = 10
        countloop = 0

        query = Q('match', maintenance=pk)
        # We only remove maintenance on alerts which are still under maintenance,
        # might be calling for trouble otherwise
        query &= Q('range', silence={"gte": int(time())})

        while True:
            search = Alert.search().query(
                query
            )[0:maxsize]
            content = search.execute()
            size = content.to_dict()['hits']['total']
            if size == 0:
                break
            logger.info("Deleting maintenance %s by %s matching %s" % (pk, user, size))
            self.unsilence(pk, user, content.hits.hits)
            # all Done ... or ... too much done exit
            if size < maxsize or countloop > maxloop:
                break
            countloop += 1
                
    def task(self):
        # Find alerts that might have showed up
        try:
            search = Maintenance.search().query(
                Q('match', status='ACTIVE')
            )[0:10000]
            for i in search.execute():
                i.execute(True)
        except Exception as e:
            print(e)
        # Find Starting maintenance
        try:
            search = Maintenance.search().query(
                Q(
                    'bool',
                    must=[
                        Q(
                            "nested",
                            path='schedule',
                            query=Q('range', schedule__startmaintenance={"lte": int(time())})
                        ),
                        Q('match', status='PENDING')
                    ]
                )
            )[0:10000]
            for i in search.execute():
                try:
                    i.execute(False)
                    i.update(status='ACTIVE')
                except:
                    i.update(status='ERROR')
        except Exception as e:
            print(e)

        # Complete Maintenance
        try:
            search = Maintenance.search().query(
                Q(
                    'bool',
                    must=[
                        Q(
                            "nested",
                            path='schedule',
                            query=Q('range', schedule__endmaintenance={"lte": int(time())})
                        ),
                        Q('match', status='ACTIVE')
                    ]
                )
            )[0:10000]
            for i in search.execute():
                i.update(status='COMPLETED')
        except Exception as e:
            print(e)

    def node_list(self, key, dictionary):
        for k, v in dictionary.items():
            if k == key:
                yield v['node']
            elif isinstance(v, dict):
                for result in self.node_list(key, v):
                    yield result
            elif isinstance(v, list):
                for d in v:
                    for result in self.node_list(key, d):
                        yield result

class Plugin(IndexManagement):
    class Meta:
        name = getattr(settings, "ES_PLUGIN_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    class Index:
        name = getattr(settings, "ES_PLUGIN_INDEX")
        doc_type = getattr(settings, "ES_DOCTYPE")

    def lock_update(self):
        r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'default')
        r_base.set('lock_nmsysclient', True)

    def unlock_update(self):
        r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'default')
        r_base.set('lock_nmsysclient', False)

    def flush_db(self):
        r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'nodes')
        r_base.flushdb()

    def emulate(self):
        result = {}
        try:
            result['node_list'] = [n['node'] for n in self.find_nodes(True)]
        except Exception as e:
            result['error'] = 'Too many devices matching your filter, the plugin will be ignored %s ' % e
            return result

        return result

    def find_nodes(self, expand):
        node_list = EpicSearch().find_list(self.deployment.tag, expand=expand, version='v3')
        if len(node_list) > 250000:
            raise ValueError('Too many nodes in your filter (maximum is 2500000 per plugin), '
                             'plugin cannot be applied')
        return node_list

    def update_plugin(self):
        try:
            node_list = EpicSearch().find_list(self.deployment.tag)
        except:
            self.update(status='ERROR')
            return
        definition = {
            'pluginClass': self.plugin['class'],
            'pluginName': self.name,
            'tag': self.deployment.tag,
            '__name__': '%s %s' % (self.plugin['class'], self.name)
        }
        if self.configuration:
            definition.update(self.configuration.to_dict())
        r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'nodes')
        with r_base.pipeline(transaction=False) as pipe:
            pipe.multi()
            for i in node_list:
                pipe.sadd(i, json.dumps(definition))
            pipe.execute()
        self.update(status='ACTIVE')

    def backup(self):
        directory = os.path.join(settings.PLUGIN_BACKUP, self.information.username)
        filename = '%s_%s.yaml' % (self.information.username, self.information.name)
        if not os.path.exists(directory):
            os.makedirs(directory)
        f = open(os.path.join(directory, filename), 'w')
        content = self.to_dict()
        if 'pk' not in content:
            content['pk'] = self._id
        f.write(TemplateSerializer().to_yaml(content))
        return os.path.join(directory, filename)

