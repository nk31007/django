
from django import template
from delorean import parse, epoch
import re
import datetime
from contrib.kin import Kin
import requests
from django.template import Library, Node
from django.utils.html import strip_tags
from django.conf import settings
from htmlslacker import HTMLSlacker

register = template.Library()

@register.simple_tag(takes_context=True)
def epicimg(context, url='c', id_def='pas', node='bien', alert='grave', description='', html=False):
    try:
        if not html:
            description = re.sub(
                r'<cid="(.*)" link="(.*)">',
                r'',
                description
            )
            return description.replace('\\n', '').replace('%', '')
        else:
            description = re.sub(
                r'<cid="(.*)" link="(.*)">',
                r'<br/> <img src="cid:\1" style="margin:0"> <br /> <a href="\2">Link to Epic View Graph</a>',
                description
            )
            return description
    except Exception:
        return ''

@register.simple_tag()
def localize_timestamp(timestamp):
    timezone = "America/Los_Angeles"
    return epoch(int(timestamp)).shift(timezone).datetime.strftime("%c %Z%z")


def localize_datetime(timezone, string):
    realtime = parse(string)
    realtime.shift(timezone)
    return realtime.datetime.strftime("%Y-%m-%d %H:%M:%S %Z%z")

@register.simple_tag(takes_context=True)
def localize_time(context, string):
    string = str(string)
    timezone = "America/Los_Angeles"
    return localize_datetime(timezone, string)

@register.simple_tag
def keyLookup(the_dict, key):
    try:
        return reduce(dict.get, key.split("__"), the_dict)
    except:
        return ""


@register.simple_tag
def attributeLookup(the_object, attribute_name):
   return getattr(the_object, attribute_name, None)

@register.simple_tag(takes_context=True)
def epictags(context, nodename, html=True):
    result = ''
    try:
        content = requests.get('%s/api/search/rest/v2/node/?format=json&limit=1&node=%s' % (settings.EPIC_URL, nodename)).json()
        content = content['objects'][0]
        result += ' <ul>'
        for gp in content['groups']:
            if '=' in gp and not re.match('^sysinfo.*|^network.*|^_.*', gp):
                result += '<li>%s</li>' % gp
        result += '</ul>'
    except Exception as e:
        result = 'Unable to fetch groups for <a href="https://epic.isg.apple.com/search/?n=%s">%s</a>' % (nodename, nodename)
    if not html:
        result = result.replace('</li>', '\n </li>')
        result = strip_tags(result)
    return result


@register.simple_tag(takes_context=True)
def epicsysinfo(context, nodename, html=True):
    result = ''
    try:
        content = requests.get('%s/api/search/rest/v2/node/?format=json&limit=1&node=%s' % (settings.EPIC_URL, nodename)).json()
        content = content['objects'][0]
        regroup = {}
        for gp in content['groups']:
            if '=' not in gp:
                continue
            k, v = gp.split('=')
            if '.' not in k:
                continue
            source, info = k.split('.', 1)
            if source not in regroup:
                regroup[source] = []
            if '@' not in v:
                v = v.replace('.', ' ').replace('_', ' ')
            regroup[source].append("%s: %s" % (info.replace('.', " ").capitalize(), v.capitalize()))
        for i, v in regroup.items():
            result += '<h4>%s</h4> <ul>' % i
            for p in v:
                result += '<li>%s</li>' % p
            result += '</ul>'
    except Exception as e:
        result = 'Unable to fetch groups for <a href="https://epic.isg.apple.com/search/?n=%s">%s</a>' % (nodename, nodename)
    if not html:
        result = result.replace('<h4>', '\t <h4>')
        result = result.replace('</h4>', '\n </h4>')
        result = result.replace('<li>', '\t\t <li>')
        result = result.replace('</li>', '\n </li>')
        result = strip_tags(result)
    return result



@register.simple_tag(takes_context=True)
def stats(context, stats, html=True):
    if stats == {}:
        return ''
    result = ' <ul>'
    for key, value in stats.items():
        result += '<li>%s : %s</li>' % (key, value)
    result += ' </ul>'
    if not html:
        result = result.replace('</li>', '\n </li>')
        result = strip_tags(result)
    return result

@register.simple_tag(takes_context=True)
def correlate(context, node, alert, locale, instance, html=True):
    result = ''
    try:
        content = Kin().find_causal([{
            'node': node,
            'alert': alert,
            'locale': locale,
            'instance': instance
        }])
        if 'causal' in content and len(content['causal']) > 0:
            result += '<br /> Correlation:<br /><hr><div class="section-margin"><b class="section-title">Correlation</b><br /><br />'
            result += 'The issue might be related to the following alert : ' \
                      '<br />&nbsp;&nbsp;%s on %s detected on Epic %s@%s' % (
                          content['causal'][0]['cause']['alert'],
                          content['causal'][0]['cause']['node'],
                          content['causal'][0]['cause']['instance'],
                          content['causal'][0]['cause']['locale']
                      )
            result += '<br /> </div>'
        if not html:
            result = result.replace('<br />', '\n')
            result = strip_tags(result)
    except Exception as e:
        result = 'Correlation not available'
    return result


@register.tag
def lineless(parser, token):
    nodelist = parser.parse(('endlineless',))
    parser.delete_first_token()
    return LinelessNode(nodelist)


class LinelessNode(Node):
    def __init__(self, nodelist):
        self.nodelist = nodelist

    def render(self, context):
        input_str = self.nodelist.render(context)
        output_str = ''
        for line in input_str.splitlines():
            if line.strip():
                output_str = '\n'.join((output_str, line))
        return output_str

@register.simple_tag(takes_context=True)
def md(context, description):
    return HTMLSlacker(description).get_output()
