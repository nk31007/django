# Python
import ujson as json
import logging
import time
# Django
from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from backend.models import Filter
from backend.models import connections
from django.conf import settings
from elasticsearch_dsl import Q
from contrib.resource.redisrouter import RedisRouter
from contrib.bulk import status_bulk, chunk_bulk, node_stream, single_bulk, delay_bulk
import socket 
from contrib.metrics import create_metric
from contrib import metrics


logger = logging.getLogger()


def parse_labels(*args, **kwargs):
    request = args[0]
    try:
        ip_source = request.META['X-Forwarded-For'].split(',')[0]
    except Exception as e:
        ip_source = request.META['REMOTE_ADDR']
    application = kwargs['application']
    return [application, ip_source]


monitor = metrics.InvocationMonitor('views_request_latency_seconds',
                                    'Summary of request latency for views', ['operation']).monitor_invocation

bulk_ingestion_summary = create_metric('summary', 'bulk_events_received',
                                       'Summary of bulk events received', ['source', 'source_ip'])
bulk_ingestion_errors = create_metric('counter', 'bulk_errors',
                                      'Count of errors while processing bulk events', ['source', 'source_ip'])
bulk_monitor = metrics.InvocationMonitorWithArgParser('bulk_ingestion_latency_seconds',
                                                      'Histogram of latencies while ingesting bulk events',
                                                      ['source', 'source_ip'],
                                                      parse_labels, metric_type=metrics.MetricType.Histogram,
                                                      optional_args={'buckets': [.005, .01, .025, .05, .075, .1,
                                                                                 .25, .5, .75, 1.0, 2.5, 5.0, 7.5,
                                                                                 10.0, 12.5, 15.0, 20.0,
                                                                                 30.0]}).monitor_invocation




def index(request):
    content = Filter.search().execute()
    count = content.hits.total
    return HttpResponse("OK %s" % count)

@monitor('bulk')
@csrf_exempt
def bulk(request, application, locale, instance):
    try:
        start = int(time.time())
        upload_type = 'unknown'

        try:
            ip_source = request.META['X-Forwarded-For'].split(',')[0]
        except Exception as e:
            ip_source = request.META['REMOTE_ADDR']
        s = bulk_ingestion_summary.labels(application, ip_source)
        error_count = bulk_ingestion_errors.labels(application, ip_source)

        if 'PUSH-TYPE' in request.META:
            upload_type = request.META['PUSH-TYPE']

        if upload_type == 'full':
            delay_bulk(application, locale, instance, upload_type, request.body)
            return HttpResponse(
                json.dumps({"success": True, "result": "Full dump added with success"}), status=201
            )
        elif application == 'delivery':
            logger.critical('DELIVERY DEBUG %s %s %s %s %s' % (application, locale, instance, upload_type, request.body))
            single_bulk(application, locale, instance, upload_type, request.body)
            return HttpResponse(
                json.dumps({"success": True, "result": "added"}), status=201
            )
        else:
            content = json.loads(request.body)['alert']['list']
            length_list = len(content)
            s.observe(length_list)
            try:
                content = chunk_bulk(application, locale, instance, upload_type, content)
                end = int(time.time())
                return HttpResponse(
                    json.dumps({"success": True, "result": "%s added to queue %s" % (length_list, content)}), status=201
                )
            except Exception as e:
                error_count.inc()
                return HttpResponse(
                    json.dumps({"success": False, "result": "Bulk import issue", "error": str(e)}), status=406
                )
    except Exception as e:
        error_count.inc()
        logger.critical('[bulk_api_source] ERROR  application %s locale %s instance %s error %s content %s' % (application, locale, instance, e, request.body))
        return HttpResponse(
            json.dumps({"success": False, "result": "Content not appropriate", "error": str(e)}), status=406
        )

@monitor('checks')
@csrf_exempt
def checks(request, node_name):
    obj = request.body
    if node_name != "" and obj != "":
        try:
            status_stream(node_name, obj)
            return HttpResponse(json.dumps({"success": True, "result": "Fine"}), status=201)
        except Exception as e:
            return HttpResponse(json.dumps({"success": False, "result": "", "error": str(e)}), status=406)
    else:
        return HttpResponse(json.dumps({"success": False, "result": "", "error": "node_name and obj cannot be empty"}),
                            status=400)

@monitor('nmsys_node')
@csrf_exempt
def nmsys_node(request, node_name=None):
    try:
        logger.debug('[nmsys_node] %s' % node_name)
        try:
            content = node_stream(node_name, request.body)
            return HttpResponse(
                json.dumps({"success": True, "result": "%s added to queue %s " % (node_name, content)}), status=200
            )
        except Exception as e:
            return HttpResponse(
                json.dumps({"success": False, "result": "Node import issue", "error": str(e)}), status=406
            )
    except Exception as e:
        return HttpResponse(
            json.dumps({"success": False, "result": "Content not appropriate", "error": str(e)}), status=406
        )

@monitor('nmsys_export')
def nmsys_export(request, node_name=None):
    r_base = RedisRouter().retrieve_redis_connection('nmsysclient', 'nodes')
    content = r_base.smembers(node_name)
    if not content:
        content = []
    else:
        content = [json.loads(kk) for kk in content]
    return HttpResponse(json.dumps({"success": True, "result": content}), status=200)

@monitor('epic_export')
def epic_export(request, instance):
    list_epic = Filter.search()\
        .query(Q(
            'bool',
            must=[Q('match', application='epic')],
            should=[
                Q('nested', path="definition", query=Q("regexp", **{"definition.instance": '.*%s.*' % instance})),
                Q('nested', path="definition", query=Q("match", definition__instance='*', _expand__to_dot=False))
            ],
            minimum_should_match=1
        )) \
        .extra(from_=0, size=10000).sort("name")
    definition = []
    application = []
    for al in list_epic.execute():
        try:
            appl, threshold = al.export_epic()
            definition += threshold
            application.append(appl)
        except Exception as e:
            logger.info('[ epic export ] problem with %s %s' % (al, e))

    return HttpResponse(
        render(request, 'epic/definition.html', {'definitions': definition, 'applications': application}),
        content_type="text/plain"
    )

@monitor('status')
@csrf_exempt
def status(request):
    es_status = connections.get_connection().cluster.health()
    r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
    bulk = {}
    try:
        r_bulk = RedisRouter().retrieve_redis_connection('common', 'default')
        for key_redis in r_bulk.smembers('BULK_LIST'):
            bulk[key_redis] = r_bulk.scard(key_redis)
    except:
        pass
    queue = {}
    try:
        r_queue = RedisRouter().retrieve_redis_connection('task', 'main_queue')
        for i in 'default', 'epic_queue', 'notifier_queue', 'dsemond_queue', 'nodes_queue', 'notifierclient_queue', 'cache_queue', 'notifier_queue', 'plugin_queue' :
            queue[i] = r_queue.llen(i)
    except:
        pass
    myhost = socket.gethostname()
    redis_status = {}
    content = Filter.search().execute()
    count = content.hits.total
    if not settings.SENTINEL_KUBE:
        for i, k in settings.REDIS_INSTANCES.items():
            for p, l in k.items():
                try:
                    result = RedisRouter().retrieve_redis_connection(i, p).ping()
                    if result:
                        redis_status['Main %s Instance %s' % (i, p)] = 'OK'
                    else:
                        redis_status['Main %s Instance %s' % (i, p)] = 'KO'
                except Exception as e:
                    redis_status['Main %s Instance %s' % (i, p)] = 'KO Error in config %s' % e
    return HttpResponse(
        render(
            request, 
            'health.html',
            {
                'es': es_status,
                'bulk': bulk,
                'queue': queue,
                'redis': redis_status,
                'filter': count,
                'hostname': myhost,
                'version': settings.VERSION, 
                'commit': settings.COMMIT, 
                'maintenance': r_base.get('maintenance')
            }
        ),
        content_type="text/plain"
    )

# Simple connectivity checkers for the required endpoints   
@monitor('validate_connectivity')
@csrf_exempt
def validate_connectivity(request):
    es_status = connections.get_connection().cluster.health()
    r_base = RedisRouter().retrieve_redis_connection('semaphore', 'default')
    bulk = {}
    try:
        r_bulk = RedisRouter().retrieve_redis_connection('common', 'default')
        for key_redis in r_bulk.smembers('BULK_LIST'):
            bulk[key_redis] = r_bulk.scard(key_redis)
    except:
        pass
    queue = {}
    try:
        r_queue = RedisRouter().retrieve_redis_connection('task', 'main_queue')
        for i in 'default', 'epic_queue', 'notifier_queue', 'dsemond_queue', 'nodes_queue', 'notifierclient_queue', 'cache_queue', 'notifier_queue', 'plugin_queue' :
            queue[i] = r_queue.llen(i)
    except:
        pass
    myhost = socket.gethostname()
    redis_status = {}
    content = Filter.search().execute()
    count = content.hits.total

    for i, k in settings.REDIS_INSTANCES.items():
        for p, l in k.items():
            try:
                result = RedisRouter().retrieve_redis_connection(i, p).ping()
                if result:
                    redis_status['Main %s Instance %s' % (i, p)] = 'OK'
                else:
                    redis_status['Main %s Instance %s' % (i, p)] = 'KO'
            except Exception as e:
                redis_status['Main %s Instance %s' % (i, p)] = 'KO Error in config %s' % e
    return HttpResponse(
        render(
            request, 
            'health.html',
            {
                'es': es_status,
                'bulk': bulk,
                'queue': queue,
                'redis': redis_status,
                'filter': count,
                'hostname': myhost,
                'version': settings.VERSION, 
                'commit': settings.COMMIT, 
                'maintenance': r_base.get('maintenance')
            }
        ),
        content_type="text/plain"
    )


