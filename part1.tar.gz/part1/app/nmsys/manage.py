#!/usr/bin/env python
import os
import sys
import os.path as path
import recertifi

path_lib_default = "nmsys.settings"

if __name__ == "__main__":
    sys.path.append(path.join(path.dirname(__file__)))

    os.environ.setdefault("DJANGO_SETTINGS_MODULE", path_lib_default)

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
