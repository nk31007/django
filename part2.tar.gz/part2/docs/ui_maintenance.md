title: Maintenance Menu
name: ui_maintenance
---



### Main views

![FilterView](images/Main_Maintenance.png)

- Context set to your username : sub-menus will default to display `ALL` the maintenance related to your username AND all the groups you are part of.
- Context set to a group: sub-menus will filter only on the maintenance for this group name.

![FilterView](images/Menu_create_Maintenance.png)

See [maintenance resource](./api_resource_maintenance.html#search-q-parameter) for details about the search bar and the allowed filters.

### Create maintenance

The maintenance wizard allows you to configure the node, list of nodes (comma separated), regex of nodes, Epic tag, to which apply the silence.

You can either search via the autocomplete feature or list your own pattern.

![FilterView](images/Auto_complete_Maintenance.png)


To prevent user errors, we strictly limit the node list to 250 nodes at a time (does not include the Kin expansion).

#### Description

The description will be appended to the silence message and tied to the owner of the maintenance configuration.

#### Filter specific alerts

You can chose to filter the alerts which should be silenced (by default nmSys will silence all the alerts for the device - and dependents/dependencies).

The filter supports only regex :

        e.f. if you want to silence all reachability alerts and interface alerts :

                default@reachable.*|.*interface_.*

#### Schedule

The schedule can start in the past (will set the silence immediately), and finish anytime in the future (we might restrict that if the system is being abused).

#### Kin

The Kin integration allows you to also silence dependents and/or dependencies. For now only GNS devices are supported, the dependents are the upstream devices, dependencies are the downstream.

You can chose the number of hops up/down the stream you would like to silence (* means as far as you can traverse the tree).


![FilterView](images/Configure_Maintenance.png)


### Status and Maintenance Details

![FilterView](images/Status_Maintenance.png)

A maintenance can be in 4 different states :

    - PENDING : The maitnenance hasn't started yet

    - ACTIVE : The maintenance has started - nmSys is activaly silencing existing/new coming alerts during the specified timeframe

    - COMPLETED : The maintenance is complete - the endtime is passed, Maintenancen is archived for future reference

    - ERROR : There is an error in your definition, see the Explain tab for more details

![FilterView](images/Explain_Maintenance.png)

When you are in the main Maintenance view, you can access the details of the configuration as well as an Explain panel.

The Explain panel expands the maintenance configuration to give the details about the steps involved when the maintenance starts.

 Based on the configuration, it will details
    - the primary filter
    - the Kin dependent/dependency
    - the alert sub-filtering
    - the current list of alert which will be impacted


If you choose to find dependents and/or dependencies, the explain tab will also list what was found.

![FilterView](images/Explain_Maintenance_Kin.png)

### Silence message


![FilterView](images/Applied_silence_message_Maintenance.png)

When the maintenance starts, the workers will check for alerts matching your configuration and silence with a specific template for the time you picked.

Every 60s the workers will be looking for incoming alerts and silence them as well for the whole duration of the maintenance.

Once completed the silence as well as the maintenance will complete and expire.
