title: Context and Ownership
name: alert_context
---

The context feature is used to control ownership of filters and subscriptions. The idea being that only the owner can edit filter definitions and subscriptions.

When on your main subscription page you will be able to see only the subscription set for the context
(if set to your username (default) you will see all your personal subscription as well as your group subscriptions)
See (walk-through)[#8nmsys-ui-walk-through] for more examples.


You can add new group for ownership from the UI by clicking on:

![Overview](images/apple_ds_group.png)
