title: nmSys Architecture Diagrams and processes
name: alerting
---

## 1.Overall App

![Overview](images/app_arch.png)

```
HAPROXY (FRONT): https://nmsys.isg.apple.com

HAPROXY (BACK): http://nmsysapi.isg.apple.com
```

Both serving the same content (one over http, one over https)





### 1.1.API :

    App name (nmsys_prod)
    Listens on port 8015
    Serves HTTP traffic :
            - Frontend traffic (HTML/JS/CSS)
            - API Traffic : REST/BULK


### 1.2.WORKER:
    App name (nmsys_prod_worker)
    Execute tasks found in the Redis task instance
        List of available tasks :

                - Bulk : (streaming task)
                    Runs every 20s : POP from the Redis Alert quque 50k alert at a time - re-order and update ES

                - Aging :
                    Runs every 60s : delete alerts which havent' been updated in the past 6hours

                - Notifier:
                    Runs every 60s :
                        For each filter,subscriber look for alert updated in the past:
                            send after * 60s
                            resend after * 60s * [1..5], 100

                            For each match
                                Escalate via appropriate route:
                                    Email
                                    Pagerduty
                                    Centralstation
                                    Espresso
                                    ...

                - Stats:
                    Trend number of Notifications/Alerts ingested, ...

                - Plugin:
                    For each plugin look for host matching and pre-cache new configuration for the nmSys client

### 1.3.BEAT:

    App name (nmsys_prod_beat)
    Simple scheduler for each task find schedule and insert tasks in the Redis Task Queue

### 1.3.Elasticsearch:

    App name (nmsys_prod_es)
    Listens on port 9210 and 9310
    Runs ES 5.4.1
    2 Replicas / 10 shards

    Stores the various objects :

        Alert

        Filter

        Notification

        Ack

        Maintenance

### 1.4.Xtradb Cluster(Mysql)

    App name (nmsys_prod_mysql)
    Listens on port 11306 and 11444, 4567, 11567-11568
    Runs Xtradb cluster 5.6.24-72.2-56
    Used for authentication (to be deprecated with JWT)


## 2. Services

## 2.1. Swarm

![Overview](images/service_list_swarm.png)


## 2.2. Existing

![Overview](images/existing_app_normal.png)

![Overview](images/existing_app_redis.png)



## 3.Dashboards

## 3.1.Production

https://epic.isg.apple.com/d/epic-admin@nmsys_production


## 3.1.VP21 QA

https://epic.isg.apple.com/d/epic-admin@nmsys_qa



## 4.External service Requirements

### 4.1 KIN

Kin is used to




## 5.Sources of alerts:

### 5.1. Epic Server

Epic server from the various origins (instances/locales) fetches new threshold definition via a specific API :

http://nmsysapi.isg.apple.com/nmsys/api/epic_alerts/isgd/

These definitions are loaded every 5 minutes as a single transaction, if one of the definition from any user is improperly formated, the Epic server will bail on loading all of them.

At night Epic servers will load the definitions one by one allowing the properly defined thresholds to be loaded.

Once loaded in the Epic alert deamon, Epic will process the thresholds based on the definition by comparing the datasources to the actual values set by end user and push back the alert state to nmSys via the nmSys BULK API.


### 5.2. nmSys Client

The nmSys client runs nagios type of checks (any check with respond to a OK/NOT OK type of monitor). It caches the result in memory and on disk to keep track of the check states and publishes on state change / or resend schedule to the nmSys BULK API.



### 5.3. Nanny (delivery)

Nanny is used to monitor the Citrix LBs (netscaler) as well as DLB and few other delivery related services, it publishes stateless data to the BULK API which has to compare the states with the previous know state before inserting the data into ES.


### 5.4. Dsemond (Storage)

Dsemond process is used to monitor the Storage equipements (Netapp , Ramsan, Isilons, ...) for hardware/LUN configuration etc   it publishes stateless data to the BULK API which has to compare the states with the previous know state before inserting the data into ES.


### 5.5. Other:

Splunk, SRE, ESX Monitoring, ...



## 6.Backup

nmSys uses Github repo to backup the changes happening :













## 2.Bulk API

### 2.1.URLS
    
    /nmsys/api/

### 2.2.Diagram Bulk Inserts Stateful Application (Epic, nmSys client)

![Overview](images/Bulk_API_Insert_process.png)


### 2.3.Diagram Bulk Inserts Stateless Applications (Delivery SRE Nanny, Storage ISG_DSE)

![Overview](images/Bulk_Insert_process_for_stateless_applications.png)


## 3.REST API

### 3.1.URLS

    /nmsys/api/rest/

### 3.2. Overview

![Overview](images/API_Call_resource_access.png)

