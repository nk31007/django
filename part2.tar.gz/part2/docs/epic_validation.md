
Find your alert in Epic API
=====
```
http://nk11-epic.isg.apple.com/adminsys?a=alert&s=e-2year&cmd=list&X=1&alert={alertname}
```
Find all Rulesets in Epic API
=====
```
http://st11-epic.isg.apple.com/adminsys?a=query&alert_rule=1&X=1
```

Find all Rulesets applied to node in Epic API
=====
```
http://st11-epic.isg.apple.com/adminsys?a=query&alert_node=1&X=1
```
