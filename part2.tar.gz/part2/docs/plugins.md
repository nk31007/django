title: Plugins
name: alert_plugins
---

Plugins are specific class in the nmSys client which either run checks and/or publish specific metrics for various applications.

These can be enabled via configuration files on the hosts, or via the Plugin page in the nmSys UI.

### Remote configuration

Plugins can be enabled via the Plugin wizard in the nmSys UI. It gives you the flexibility to configure your checks to run/Plugin to publish metrics from the UI.

![Overview](images/client_plugin.png)

Simply pick the plugin you need, configure as you would in [Plugin configurations](./plugins_config.html)
