title: State based Checks
name: alert_state_checks
---

These checks run either from the latest Epic client package which embeds the nmSys client code, or from the nmSys client package.

They will run client (host) side and be published straight into nmSys server's alert queue.

#### Load

- Alert name: nmsys@load_utilization

    Definition:
    ```
        Load above 10 (divided by  number of cores): CRITICAL
        Load above 5 (divided by number of cores): WARNING
        Load below 5: OK
    ```
    Link : [check_load.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_load.py)

#### Memory

- Alert name: nmsys@memory_utilization

    Definition:
    ```
        Memory usage above 99 AND amount of memory left below 512MB: CRITICAL
        Memory usage above 98 WARNING
        Memory usage below 98% OK
    ```
    Link : [check_memory_utilization.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_memory_utilization.py)

#### Disk Usage

- Alert name: nmsys@disk_utilization

    Definition:
    ```
    Space left on disk < 97% OR iNodes left < 97%: CRITICAL
    Space left on disk < 94% OR iNodes left < 94%: CRITICAL
    Spave left > 94% AND iNodes left > 94%: OK
    ```

    Mount filters:
    ```
    Linux: ext[2,3,4]|xfs
    SunOs: all except nfs
    Darwin: / and /Volumes/Server

    (Except the following application mounts: ^/(blob|media|snapshot|cassandra|hadoop|apps|rrd|data|mnt)|^/dev/shm$|^devfs$)
    ```
    Link : [check_disk_local.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_disk_local.py)

#### Swap

- Alert name: nmsys@swap

    Definition:
    ```
    Make sure the Swap usage > 1% and actively swapping
    Otherwise : OK
    ```
    Link : [check_swap.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_swap.py)

#### Ulimit

- Alert name: nmsys@user_limit

    Definition:
    ```
    Loop through the list of all PIDs collect limits / status
    Alert if any PID is approaching its limit
    Also alert if any given user aggregated process count is approching limit
    By default excludes users root and haproxy.
    ```
    Link : [check_user_limits.pl](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_user_limits.pl)


#### Filesystem

- Alert name: nmsys@filesystem

    Definition:
    ```
    NFS Mounts in fstab readonly when mounter as RW : CRITICAL
    Root is read only : CRITICAL
    Otherwise : OK
    ```
    Link : [check_filesystem.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_filesystem.py)

#### Mounts

- Alert name nmsys@mounts

    Definition:
    ```
    * Missing mounts in fstab (manually mounted) : CRITICAL
    * Mounts in fstab not mounted : CRITICAL
    * Mounts are mounted multiple times : WARNING
    * Otherwise OK
    ```
    Link : [check_mounts.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_mounts.py)

#### Mailq

- Alert name: nmsys@mailq

    Definition:
    ```
    Mail in queue > 20: CRITICAL
    Mail in queue > 10: WARNING
    Mail in queue < 10: OK
    ```
    Link : [check_mailq.pl](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_mailq.pl)

#### Network

- Alert name: nmsys@network

    Definition:
    ```
    Test ssh connectivity via check_ssh to 127.0.0.1 CRITICAL if unable to connect
    ```
    Link : [check_network.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_network.py)

#### Puppet

- Alert name: nmsys@puppet

    Definition:
    ```
    Puppet yaml summary reports any error : CRITICAL
    Puppet lock file older than 30minutes : CRITICAL
    Otherwise: OK
    ```
    Link : [check_puppet_run.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_puppet_run.py)

#### Processes

- Alert name: nmsys@processes

    Definition:
    ```
    * crond is running (at least 1 process) and not piling up number < 50
    * snmpd is not piling up if running
    * routed is not running
    * ntpd or chronyd is running
    ```
    Link : [check_running_process.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_running_process.py)
