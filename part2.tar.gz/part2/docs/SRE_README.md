# Operations

### Orchestration

    The current setup - or lack of setup requires manual start to ensure all services are properly started 
    (otherwise the application will crash if one of the services (redis/es/mysql) is not available)
    
    Long term solution to facilitate hand off : migrate to k8s 
    Short term solution : I will work on a script based on the tags listed below to help SRE in case of a crash.

### Cluster

    QA : ~verdad.tag=epic-nmsys-qa
    PRODUCTION : ~verdad.tag=epic-nmsys-production

### Services

    * `WebApp` (api/front) cluster : `~verdad.tag=epic-nmsys-cluster-webapp`
    
    * `Worker` (celery workers) cluster : `~verdad.tag=epic-nmsys-cluster-worker`
    
    * `Beat` (celery scheduler): `~verdad.tag=epic-nmsys-cluster-beat` (one per cluster if host is dead tag needs to be moved) 
        [IMPORTANT!!!!]
    
    * `Xtradb` Cluster :    `~verdad.tag=epic-nmsys-cluster-xtradb`
    
    * `Elasticsearch` cluster : `~verdad.tag=epic-nmsys-cluster-elasticsearch`

    * Redis / Sentinel (auto start / join sentinel via puppet):
       `~verdad.tag=epic-nmsys-cluster-redis`

        `vd find --ic isg.service.epic.redis -T /type/=/host/`
        mr20a00is-quge05173701.isg.apple.com
        mr20a00is-quge05183601.isg.apple.com
        mr20a00is-quge05183701.isg.apple.com
        pv31a00is-hpat12033901.isg.apple.com
        pv31a00is-hpat12034001.isg.apple.com
        pv51a00is-hyia17010701.isg.apple.com
        pv51a00is-hyia17011801.isg.apple.com

Example of a search : 
    
    List all production servers which should be running mysql :

    ```~verdad.tag=epic-nmsys-production & ~verdad.tag=epic-nmsys-cluster-xtradb```

### Health

    Prod : https://nmsys.isg.apple.com/nmsys/api/status/
    QA : https://nmsys.qa.isg.apple.com/nmsys/api/status/

### Dashboards

    Prod: https://epic.isg.apple.com/d/nmsys-admin@prod
    QA: https://epic.isg.apple.com/d/nmsys-admin@QA

### RIO BUILDS

    https://rio.apple.com/projects/iso-nmsys-server
	One for Prod, One for QA

### API ALERT / THRESHOLD DETAILS

![Overview](images/App_Diagram.png)



All the APIs require Elasticsearch (see details in the Service description). Below are listed the various APIs with there specific dependency.


API with a Redis dependency

![Overview](images/api_details.png)

    * Bulk API is used by consumer to publish alerts. Alerts have to follow the specified Alert schema provided in the docs. The expected HTTP response is 201. The API will store the content in a Redis Queue to be later ingested in Elasticsearch.

    * Epic alerts API is the list of threshold that Epic should be processing. The task is in Epic server to pull all the threshold on schedule (every 15min see script https://github.pie.apple.com/epic/epic-common/blob/master/src/all/ubin/cron.minutely/inst.epicd.config.30_nmsysV2_alerts) The Thresholds are stored in ES in the filter index.

    * Config API is the list of plugin to run on the nmSys Agent. The agent pull all the new plugins once every 12 hours (see config class https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/lib/config.py) The configs are stored in ES in the node index.


API with a mysql dependency

    * Rest API require mysql for Auth / RBAC. It will serve all requests matching /nmsys/api/rest/{v1,2,3,4}/{resource_name}/

### MONITORING

API Response (Definition: epic-admin@epic_http_nmsys_api)

	https://nmsys.isg.apple.com/nmsys/alerting/filter/alert/daecc778-756b-47b1-bc95-caad635c90e3/
	Escalation contact : http://iris.qa.isg.apple.com/api/v1/alerts?hipchat_rooms=7165,6474
	Escalation contact : epic@applepie.pagerduty.com,epic-admin-alert@group.apple.com,epic-oncall@sre-oncall.pagerduty.com
	Escalation contact : rfoucher@apple.com,nmsys-oncall@sre-oncall.pagerduty.com


UI Response (Definition: epic-admin@epic_http_nmsys_ui)

	https://nmsys.isg.apple.com/nmsys/alerting/filter/alert/dabb0241-a376-3b45-ddb0-53bbdea36631/
	Escalation contact : evanroode@apple.com	
	Escalation contact : rfoucher@apple.com,nmsys-oncall@sre-oncall.pagerduty.com

	Action details

```
	Check status page 
	Check services health in dashboard
	Check logs
	Restart whatever needs to be restarted
```

Elasticsearch (Definition: epic-admin@check_elasticsearch_cluster_status):

	https://nmsys.isg.apple.com/nmsys/alerting/filter/alert/69da28e6-cb8b-37d0-37d6-5266c00e2094/
	Escalation contact : epic@applepie.pagerduty.com,epic-oncall@sre-oncall.pagerduty.com,epic-sre@group.apple.com
	Escalation contact : rfoucher@apple.com,nmsys-oncall@sre-oncall.pagerduty.com

	Action details (will be sent with notification)
```
	Performing elasticsearch health check against localhost
	127.0.0.1 port 9210
	Expecting status green
	ssh to machine, sudo su -
	make restart_es
	if the network bridge is not cleaned on stop - simply service docker restart and re-run the make restart_es
	Wait for the green light 
	make health_es
	FYI  the commands are in the Makefile and the available commands for ES are 
	make start_es
	make stop_es
	make restart_es
	make health_es
```


Transaction Check (Definition None - direct page from script)

	Action details :

```
Check the logs / Dashboard / Content of the Notification
```	

### SERVICE DESCRIPTION

![Overview](images/App_Diagram.png)


* Workers : responsible for various tasks they can execute any of them as soon as they are available. Some of the important tasks are listed below.
    
    - Notification
    - Aging
    - Trend to Epic
    - Maintenance

* API / UI : serve all user traffic as well as the BULK requests.

* Beat : MUST ONLY RUN ONCE PER CLUSTER responsible to scheduling cron type jobs

* Elasticsearch : Stores all the critical data except the centralstation/pagerduty deduplication cache.

* Sentinel : health/routing to the redis primaries

* Redis : mostly used for queue / cache it doesn't contain any critical data. The only caviat is the centralstation/pagerduty deduplication cache which could be problematic (nmSys would create 1000s of duplicate tickets on resend if the cache went missing)



### Manage the service (List of commands)

    OPERATION :
        
        overall health
        ```
        sudo su -
        make health
        make status
        ```

        update application
        ```
        sudo su -
        make update
        ```

        check what should be running
        ```
        sudo su -
        make whatami
        ```

	ES :
		check health :
			```
			sudo su -
			make health_es
			```
		
		restart service:
			```
			sudo su -
			make restart_es
			```

	MYSQL : 

		check health : 
        ```
        sudo su -
        make health_mysql
        ```

		restart service:
		```
        sudo su -
        make restart_mysql
        ```

	APP : 
	
		check health:
		```
		sudo su - 
		make health_app
		```

		restart service:
        ```
        sudo su -
        make restart_app
        ```

	WORKER :
	
		check health:
		```
		sudo su - 
		make health_worker
		```

		restart service:
		```
		sudo su -
        make restart_worker
		```

	BEAT : 
		
		check health:
		```
        sudo su -
        make health_beat
        ```

        restart service:
        ```
        sudo su -
        make restart_beat
        ```


### Update the application

The process is not automated :

    ```
    sudo su -
    make update
    ```

    The VERSION file in /root/ will be incremented if the docker image is present in the repo and will restart API/WORKERS for you
    Do one node at a time and validate health/status after restart



###Logs :



#### Splunk :

    https://admin.splunk.iso.apple.com

    1 - Application :

    index=docker| spath tag | search tag="nmsys_prod|docker.apple.com/epic/nmsys_prod*"

    2 - Elasticsearch :

    index=docker | spath tag | search tag="nmsys_prod_authes|docker.apple.com/elasticsearch/elasticsearch:*"

    3 - Redis

    index=epic source="/var/log/redis/nmsys*"

    4 - MYSQL 

    index=docker | spath tag | search tag="nmsys_prod_mysql|docker.apple.com/epic/xtradbcluster:latest"

#### Local :

    1 - Application 

    tail -f /data/logs/**/*

    2 - Elasticsearch 

    docker exec into

    3 - Redis

    /var/log/redis/

    4 - Mysql 

    docker exec into 
    
    
    
## Other tips for ES DEBUG
Check the thread pool status (reject counter should remain stable). Check that the active counter is not stuck on one node. 


	`curl  "localhost:9210/_cat/thread_pool/search?v&h=node_name,name,active,rejected,completed"`
	
Find the IP of the node :

	`curl localhost:9210/_cat/nodes`
	
More ES stuff :

curl "http://localhost:9210/_cat/recovery?v&h=i,s,t,ty,st,rep,snap,f,fp,b,bp" | grep -v done
curl  "localhost:9210/_cat/nodes?v&h=id,ip,port,v,m"


Carefull with (try to recover indices when broken):
curl -X POST "http://localhost:9200/_cluster/reroute?retry_failed"
