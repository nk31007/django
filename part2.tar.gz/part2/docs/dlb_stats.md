title: Nginx / DLB Stats 
name: nginx_dlb
---

The DLB hosts will now have a specific tab to view the health of the various VIPs present on the host.

## Epic UI

When properly configured a Tab will show up for a DLB host which will allow you to explore the various [metrics](#metrics-) available :

![DLB](images/dlb_tab.png)

The Node will expand the metrics in various menus to detail global, per zone and per upstream stats :

![DLB](images/dlb_available_menu.png)

![DLB](images/dlb_node_page.png)


## Auto discovery 

The stats will automatically start being published once the host is tagged as a member of a DLB cluster. The current pattern supported is expecting to see the host tagged as "verdad.tag=(.*)?-dlb"

e.g.:
```
vd expand bm23a01ls-dlb0104.ls.apple.com -T /module.epic.node.tag/
item bm23a01ls-dlb0104.ls.apple.com
    module.epic.node.tag = geo-dlb
```

## Configuration :

```
server {
    listen 8080 default_server backlog=1024;
    location /status {
        root   /usr/share/nginx/html;
        access_log off;
        status;
        deny all;
        allow 127.0.0.1;
    }
}
```


## Non ISO DLB Hosts:

If your DLB hosts are not part of the ISO framework, the auto-discovery won't work so you will need to create a new Plugin to enable the self discovery of your DLB / Nginx hosts : 

In nmSys UI [duplicate](https://nmsys.isg.apple.com/nmsys/alerting/wizard/duplicate/plugin/97c373a9-fef6-41ab-bd30-774770f7206f/) the following plugin

![DLB](images/dlb_plugin.png)

And configure it with your own configuration / tag to enable the plugin.



## Metrics :


```
    # Default
    'active_connections': DERIVE,
    'conn_accepted': DERIVE,
    'conn_handled': DERIVE,
    'req_handled': DERIVE,
    'req_per_conn': DERIVE,
    'act_reads': DERIVE,
    'act_writes': DERIVE,
    'act_waits': DERIVE,
    # Plus
    'generation': DERIVE,
    'load_timestamp': DERIVE,
    'processes.respawned': GAUGE,
    'accepted': DERIVE,
    'dropped': DERIVE,
    'active': GAUGE,
    'idle': GAUGE,
    'handshakes': DERIVE,
    'handshakes_failed': DERIVE,
    'session_reuses': DERIVE,
    'total': DERIVE,
    'current': GAUGE,
    # Server zones
    'processing': GAUGE,
    'requests': DERIVE,
    'responses.1xx': DERIVE,
    'responses.2xx': DERIVE,
    'responses.3xx': DERIVE,
    'responses.4xx': DERIVE,
    'responses.5xx': DERIVE,
    'responses.total': DERIVE,
    'discarded': DERIVE,
    'received': DERIVE,
    'sent': DERIVE,
    # Stream server zones
    # - Processing
    'sessions.total': DERIVE,
    'sessions.2xx': DERIVE,
    'sessions.4xx': DERIVE,
    'sessions.5xx': DERIVE,
    # - Discarded
    # - Received
    # - Sent
    # Cache
    'size': DERIVE,
    'max_size': DERIVE,
    'hit.responses': DERIVE,
    'hit.bytes': DERIVE,
    'miss.responses': DERIVE,
    'miss.bytes': DERIVE,
    'stale.responses': DERIVE,
    'stale.bytes': DERIVE,
    'updating.responses': DERIVE,
    'updating.bytes': DERIVE,
    'revalidated.responses': DERIVE,
    'revalidated.bytes': DERIVE,
    'revalidated.responses_written': DERIVE,
    'revalidated.bytes_written': DERIVE,
    'expired.responses': DERIVE,
    'expired.bytes': DERIVE,
    'expired.responses_written': DERIVE,
    'expired.bytes_written': DERIVE,
    'bypass.responses': DERIVE,
    'bypass.bytes': DERIVE,
    'bypass.responses_written': DERIVE,
    'bypass.bytes_written': DERIVE,
    # Upstreams
    # (disabled) 'keepalive': GAUGE,
    # (disabled)  'zombies': GAUGE,
    'queue.max_size': GAUGE,
    'queue.overflows': DERIVE,
    'queue.size': GAUGE,
    'available': GAUGE,
    # - Peers
    # (disabled)  'backup': GAUGE,
    # (disabled)  'weight': GAUGE,
    #   - Active
    # 'header_time': GAUGE,
    # 'response_time': GAUGE,
    #   - Responses
    #   - Sent
    #   - Received
    'fails': DERIVE,
    #   - Zombies
    # (disabled)  'unavail': DERIVE,
    # (disabled)  'health_checks.checks': DERIVE,
    # (disabled)  'health_checks.fails': DERIVE,
    # (disabled)  'health_checks.last_passed': GAUGE,
    # (disabled)  'health_checks.unhealthy': DERIVE,
    # (disabled) 'downtime': DERIVE,
    # (disabled) 'downstart': DERIVE,
    # (disabled) 'selected': DERIVE,
    'header_time': GAUGE,
    # 'response_time': GAUGE,
    #   - Available
    'state': GAUGE,
    # Stream upstreams
    'connections': DERIVE,
    'max_conns': GAUGE,
    'connect_time': GAUGE,
    'first_byte_time': GAUGE,
    # 'response_time': GAUGE,

```
