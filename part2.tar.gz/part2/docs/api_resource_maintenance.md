title: Alert Resource
---

### Parameters

Parameter | Description
--- | ---
`status` | Exact match on status or list of status (PENDING,ACTIVE,COMPLETED)
`schedule__owner` | Exact match on the owner of the maintenance
`schedule__node` | Exact match on the node set by the maintenance


### `search_q` parameter

`search_q` is the generic way of filtering, you can either pass part of a string or a fully anchored regex.

The following keys are allowed.

Key | Description
--- | ---
`d`, `node` | filter on the node set for maintenance
`user`, `a`, `o` | filter on the owner of the maintenance
`description` | filter on description *look for word only no regex*
`status` | filter on the status

### Schema

```json
    {
        "aggregations": {
            "bucket": {
                "buckets": [
                    {
                        "doc_count": 2,
                        "key": "ACTIVE"
                    }
                ],
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0
            }
        },
        "meta": {
            "limit": 200,
            "next": null,
            "offset": 0,
            "previous": null,
            "took": 2,
            "total_count": 2
        },
        "objects": [
            {
                "application": "maintenance",
                "last_modifier": "rfoucher",
                "pk": "8b95af6f-773c-6bda-09ed-212d97a4d567",
                "resource_uri": "/nmsys/api/rest/v2/maintenance/8b95af6f-773c-6bda-09ed-212d97a4d567/",
                    "schedule": {
                    "dependencies": "0",
                    "dependents": "0",
                    "description": "Just shut up when I say",
                    "node": "~.*nmsys",
                    "endmaintenance": 1521660180,
                    "owner": "rfoucher",
                    "startmaintenance": 1521400980
                },
                "status": "ACTIVE",
                "timestamp": 1521487419,
                "u_ctime": 1521487419
            },
            {
                "application": "maintenance",
                "last_modifier": "rfoucher",
                "pk": "65d7703b-0114-f90a-7c68-33323c3b7c0a",
                "resource_uri": "/nmsys/api/rest/v2/maintenance/65d7703b-0114-f90a-7c68-33323c3b7c0a/",
                "schedule": {
                    "alert": ".*interface.*",
                    "dependencies": "*",
                    "dependents": "0",
                    "description": "Check 1 -2",
                    "node": "usden5-bbisp-gw2.corp.apple.com",
                    "endmaintenance": 1521580920,
                    "multiif-alert": "on",
                    "owner": "epic-admin-test",
                    "startmaintenance": 1521490920
                },
                "status": "ACTIVE",
                "timestamp": 1521577334,
                "u_ctime": 1521577334
            }
        ]
    }
```

* `aggregations` (buckets):

Returns the count per Status for any of your search

Field | Type | Description
--- | --- | ---
doc_count | Integer | counter of filters per status
key | String | status label


* `objects` (array of alerts)

**Mandatory fields**

Field | Type | Description
--- | --- | ---
application | String | type of the object (must be maintenance here)
status | String | type of the object (must be PENDING on create)
schedule[node] | String | Node / node name (can also be a group)
schedule[description] | String | Description for the maintenance
schedule[owner] | String | Owner of the maintenance
schedule[dependents] | String | Kin depth for dependents (upstream)
schedule[dependencies] | String | Kin depth for dependencies (downstream)
schedule[startmaintenance] | Integer | Unix timestamp of the start of the maintenance
schedule[endmaintenance] | Integer | Unix timestamp of the end of the maintenance
u_ctime | Integer | Unix timestamp of the last status change (creation time)

**Optional maintenance fields**

Field | Type | Description
--- | --- | ---
schedule[alert] | Text | Subfilter on specific alerts (by default will set maintenance on all alerts)




### Examples

Create a maintenance :
```
cat data.json
{"application": "maintenance",
 "schedule": {"dependencies": "0",
       "dependents": "0",
       "description": " - maintenance",
       "endmaintenance": 1602791133,
       "node": "myhost.apple.com",
       "owner": "mygroupinnmsys",
       "startmaintenance": 1602788433},
 "status": "PENDING",
 "timestamp": 1602788433,
 "u_ctime": 1602788433}
```

And curl it : 
```
curl -kH "Content-Type: application/json" -X POST -d @data.json  "https://nmsys.isg.apple.com/nmsys/api/rest/v2/maintenance/?oauth_consumer_key={**redacted**}"
```
