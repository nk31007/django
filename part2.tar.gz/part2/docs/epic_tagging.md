title: Epic Tagging
name: alert_epic_tagging
---

Epic uses various sources of truth to provide a tagging solution which suits the various SRE teams.

    ISO : Verdad
    GNS: Capri

    ALL:
        - Network discovery from the host if available
        - iTrac info from verdad if available

You can use the tags to create filters, apply custom thresholds, run searches in Epic alerting (nmSys) or in Epic search.

By default, node filters are node-name regex, when using tags, we use the tilde notation `~` internally as a special
reference to `tags` to tell the processes to expand the search to a list of nodes instead node-name regex.

e.g. for tag named `verdad.tag=mynewtag` the search / threshold definition will be `~verdad.tag=mynewtag`

Few examples :

- Search: https://epic.isg.apple.com/search/?n=~verdad.group=epic-nmsys-cluster
- nmSys alerts: https://nmsys.isg.apple.com/nmsys/alerting/search/alert/?query=n:~verdad.group=epic-nmsys-cluster
- nmSYS Filter : [Filter example](./key_objects.html#Alert-Filters)

### Custom tags from Verdad

Epic allows you to create custom tags from Verdad via two specific keys :

- `module.epic.node.tag` which will tag the nodes like `verdad.tag=`{value}

- `module.epic.node.group` which will tag the nodes like `verdad.group=`{value}

e.g.

    ```
    -0-rfoucher@st11a00is-admin001:~ $ vd expand mr20a00is-quge05162401.isg.apple.com -T /epic.node.tag/
    item mr20a00is-quge05162401.isg.apple.com
        module.epic.node.tag = (
            sre-l2-alert3
            epic-nmsys-cluster
        )
    ```
![Overview](images/verdad_custom_tag.png)

And you can then use them in your custom threshold filters/filters :

![Overview](images/verdad_custom_tag_filter.png)

### Default tags from iTrac

The tags are pulled from iTrac via verdad which is a requirements for this to work.

Here are the tags discovered when avaible :

    verdad.asset.config
    verdad.asset.manuf
    verdad.location.country
    verdad.localtion.dc
    verdad.location.site

### Default tags from Capri

The tags are pulled from Capri and available only for network nodes present in Epic

    capri.id
    capri.model
    capri.priority
    capri.state
    capri.status
    capri.type
    capri.vendor


### Default tags from hosts discovery

Epic uses LLDP discovery packets to extract network information about the closest neighbor (the switch the node is attached to).

This is not always available since as it requires LLDP to be enabled on the network node it's attached to.

Here are the tags discovered when enabled :

    network.default.local.port
    network.default.local.ip.address
    network.default.local.mac.address
    network.default.uplink.name
    network.default.uplink.port
    network.default.uplink.ip.address

### Default process discovery for process statistics (procstats)

Epic uses pattern matching against process names to tag the hosts with the applications running on it.

See [Procstats module for details](https://github.pie.apple.com/epic/epic-client/blob/master/src/conf/eapi_module_procstat.cf)

Only few processes name patterns are being tracked by this module, if you need to add some extra pattern feel free to open a PR.

As of today processes matching:

    - "epic-"
    - "httpd"
    - "/rad/Current/sbin/rad-"
    - "WD40"
    - "CIESecurity/certd/bin/certd"

Once tagged the node will be tagged with the given process name:

    e.g. ~procstat.proc=process_name

### Default tags from Carnival

Epic runs crawlers which goes after all carnival endpoints to and tag all hosts it can find accordingly.

If a host has been discovered it will be tag with

    carnival.app={property}_{environment}_{group}_{application}

    e.g. ~carnival.app=icloud_prod_nlams_contentedge

### Default tags from Casserole

Epic runs crawlers which goes after all casserole endpoints to and tag all hosts it can find accordingly.

If a host has been discovered it will be tag with

    casserole.cassandra={cluster-name}_{application}

    e.g. ~casserole.cassandra=iadusrinfo-eu_iadusrinfo

### Tips and tricks about node filtering

- All filters are anchored !

```
    ~groupA,~groupB:intersect
```

is translated to :

```
    ~^groupA$,~^groupB$:intersect
```

which is different from

```
    ~^.*groupA.*$,~^.*groupB.*$:intersect
```

You will not get groupA, groupAA, groupAAA etc.


- Request nodes present in both group A AND group B
```
    ~groupA,~groupB:intersect
```
- Request nodes present in group A OR group B
```
    ~groupA,~groupB
```
- Request nodes present in group A But not in group B

```
    ~groupA,!~groupB
```
OR
```
    ~groupA,!~groupB:intersect
```

- Syntax which will NOT work in alerting:
```
    ~groupA AND ~groupB
    ~groupA OR ~groupB
```
- Always make sure you put the intersect at the end of the filter
```
    ~groupA,!~groupB:intersect,groupC
```
Will give you nodes in groupA except nodes in groupB, and nodes in groupC


