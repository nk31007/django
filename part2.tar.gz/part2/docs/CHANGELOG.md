# Change Log

5.4.0.0 (and 5.3.0.0) Fork to fix Redis setup for baremetal cluster (non Kube)

* [Ugly hack to workaround epic GCBD / APZ misconfiguration.](https://github.pie.apple.com/epic/nmsys-server/commit/f4019e38f968292a28f4e12641e72debb43b3d03)
* [Merge pull request #89 from rjhorwood/apz-hack](https://github.pie.apple.com/epic/nmsys-server/commit/3ee308fc9b306d2135be0c823a2ed2040acf3dd3)
* [Fixing secrets and linter to use the right Epic search](https://github.pie.apple.com/epic/nmsys-server/commit/46d1e0040f29106a83b550ebff6a5665076e76e3)
* [Merge branch 'master' of github.pie.apple.com:epic/nmsys-server](https://github.pie.apple.com/epic/nmsys-server/commit/ade39b5c02ad8b5594ab7eb58db14a843f0448e1)
* [Secrets for production](https://github.pie.apple.com/epic/nmsys-server/commit/14e34984f051866e44b4742a1b81bc9b1dd07a91)
* [Making sure we will never have issues with artifacts in the secrets](https://github.pie.apple.com/epic/nmsys-server/commit/9415966ba7a49c6397b79677868471d1897651ac)
* [Sentinel cache library custom for SR](https://github.pie.apple.com/epic/nmsys-server/commit/0e7c4792529f22877767db675c92edcb92a5a2bf)
* [Kube GCBD more fixes for sentinel](https://github.pie.apple.com/epic/nmsys-server/commit/2281e54464c169913193ff0fb5a563dee303e0a1)
* [Add some tools to nmsys base image build.](https://github.pie.apple.com/epic/nmsys-server/commit/3fe333399eb3ac05962d9b35ee1e349e60751e0b)
* [Merge pull request #90 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/8c829cb862e35dde3f1573aff1c2ae3201b12160)
* [Add tcpdump to aid packet capture/debug in kube.](https://github.pie.apple.com/epic/nmsys-server/commit/f013675f100bd88479ff270cfe67da8e7a5603d1)
* [Merge pull request #91 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/4f0169dea2677f64c2b51b59b6db56d933bb41d9)
* [add lsof, remove tcpdump](https://github.pie.apple.com/epic/nmsys-server/commit/3bafe63f7706dcde741456f37ef4098feec5f5b7)
* [Merge pull request #92 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/61cd407d7a313dbea0cceda8dc3a3d5f0b020fd8)
* [Switch to django_sentinel](https://github.pie.apple.com/epic/nmsys-server/commit/524880d17cb7e22b44af3f9bcc8a3027d8770e94)
* [Merge pull request #93 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/2525fbccd29fcc7c98e476b456ecccf614b111a8)
* [Add sentinel_kwargs capability](https://github.pie.apple.com/epic/nmsys-server/commit/37d4c72ee58bdf949b128a525c30ea54d0e66232)
* [Merge pull request #94 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/98c37a6b3d96e136b584173ca3de259c00f8eebd)
* [Add hiredis](https://github.pie.apple.com/epic/nmsys-server/commit/eef10edef4161c2fe18b93c456973d7efbb6246f)
* [Merge pull request #95 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/e55ea577ae689f9bc2c183734c91a8a9f4a4a170)
* [Ensure redis cache functions with password protected sentinel.](https://github.pie.apple.com/epic/nmsys-server/commit/2c8422b1e91a64d3211edeb82cda7be73a7071c5)
* [Merge pull request #96 from rjhorwood/gg-debug](https://github.pie.apple.com/epic/nmsys-server/commit/863f439224c3015c8566be9d0ae1aa30a86f9a68)
* [Update VERSION](https://github.pie.apple.com/epic/nmsys-server/commit/e0bbf3b6baec138b61e9e827deeb48801d8ac480)
* [Adding some buffer on Sentinel connect for the Kube setup](https://github.pie.apple.com/epic/nmsys-server/commit/1ff345cadd2d6d1936ea7f2170775f47c414e673)
* [Merge pull request #97 from epic/sentinel-timeout-kube](https://github.pie.apple.com/epic/nmsys-server/commit/767fadc06e60d809fc681f06eda5ffac7ae2c231)
* [Allow retry on timeout for sentinel worker](https://github.pie.apple.com/epic/nmsys-server/commit/bd2959ff8e1d3cec31b22b698e51452b4b10111c)
* [Merge pull request #98 from epic/sentinel-timeout-kube](https://github.pie.apple.com/epic/nmsys-server/commit/478a294441a277c7788fd287bee7be60dfba8643)
* [Delay in ingestion is not acceptable](https://github.pie.apple.com/epic/nmsys-server/commit/eca5257fdf1d25d693edcad0b4b7d1e56cb7edec)
* [Cleaning up some redis changes](https://github.pie.apple.com/epic/nmsys-server/commit/a9282f4860e335d068586bf0be4fea8dcf3cf42f)
* [Duration before notification forced delay reduce to 30s](https://github.pie.apple.com/epic/nmsys-server/commit/1d061d11f27b41de7596fb9d7e88bf795cce9b2e)
* [Bump version to 5.3.4 final](https://github.pie.apple.com/epic/nmsys-server/commit/a89bea9939e9099dbbef3319c95e9942c8e8dacb)
* [Add edge traffic delivery to settings.py](https://github.pie.apple.com/epic/nmsys-server/commit/0eb04cd9d35995a5d78e7907475b1c035d291206)
* [Merge pull request #99 from rjhorwood/master](https://github.pie.apple.com/epic/nmsys-server/commit/82c4a2e06b29d093d3a8e1be62a1cd7cdb4fc408)
* [Bump version](https://github.pie.apple.com/epic/nmsys-server/commit/5b63bc19e3c60b606c8b0280f4612d82ef2d838d)
* [adding CIs for GIO](https://github.pie.apple.com/epic/nmsys-server/commit/4acc8cfabcf78b3f5f1eeb3a46695670d3ab1bcc)
* [Merge pull request #101 from epic/radar-80057549-add-ci-gio](https://github.pie.apple.com/epic/nmsys-server/commit/f559e12466076920402a9e5180b723920db50f19)
* [Clean version](https://github.pie.apple.com/epic/nmsys-server/commit/a37577b26fa16168edaf95ecba6ad653d87d54c5)
* [Support backward compat from older version](https://github.pie.apple.com/epic/nmsys-server/commit/61b65f834bb4d4232d4e596259e3332924658565)%

5.2.0/2 
(Merge update as nmSys in Kube is being deployed)

* [Adding slack support](https://github.pie.apple.com/epic/nmsys-server/commit/645715fc0106455dda16753956a1c0843bfb815e)
* [Adding labels support on ingestion](https://github.pie.apple.com/epic/nmsys-server/commit/d23b99791ed369e2603eebb6ae99eb18b018155f)
* [Espresso is deprecated](https://github.pie.apple.com/epic/nmsys-server/commit/1c0bae79808cacb720d8e9b550c60fdfcf961ab6)
* [This should allow spaces for the maintenance](https://github.pie.apple.com/epic/nmsys-server/commit/b94f1f5d88d5c689fa7e27f28bcab84e47de5e4e)
* [Adding title custom + slack support + regroup support (only slack for now)](https://github.pie.apple.com/epic/nmsys-server/commit/e41ced7a771e8cbeaf04ac984f9f3c1153b22f5a)
* [misc](https://github.pie.apple.com/epic/nmsys-server/commit/31ad725567a1da274c96589ddc91c63074034bad)
* [Merge branch 'master' into customtitle](https://github.pie.apple.com/epic/nmsys-server/commit/b17ded81b3f0d3206924f8cf647c14625fae8f99)
* [Merge pull request #80 from epic/customtitle](https://github.pie.apple.com/epic/nmsys-server/commit/4f9a1d2844ac8ef762ca48d57d6d878de4ca9b48)
* [5.2.1 : fix for env variables with carriage return when < 8 bytes](https://github.pie.apple.com/epic/nmsys-server/commit/8ed3379ab9724de0ebe894ef0f26dc3085c8fbb8)
* [Kube fixing minor](https://github.pie.apple.com/epic/nmsys-server/commit/b3a76ecf779aebbbdb60f80d01a8834468311760)
* [Inefficient, but the go version is coming with the right solution later this month](https://github.pie.apple.com/epic/nmsys-server/commit/5b2f5c837a2002cee0d56c679842d728454c60c3)
* [Enable slack and fix title email](https://github.pie.apple.com/epic/nmsys-server/commit/45a5c634cb34d453a25aaf5b98d5bc7d0e22016c)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/08a33c885627ebe3c73a11f11e021b34d42ab872)
* [Support for group-by and proper form](https://github.pie.apple.com/epic/nmsys-server/commit/bf6225b361da794b8cabc23e8e18a5954fc830a8)
* [Support for group-by and proper form](https://github.pie.apple.com/epic/nmsys-server/commit/1ef596e353ab85c4c3fbc1c331dde1e14e6701c3)
* [[Fix] Pagerduty get_id requires old/new ids](https://github.pie.apple.com/epic/nmsys-server/commit/cb534da7e0c9a297f220e9c704cf7c8e288ff08b)
* [Fixing pagerduty](https://github.pie.apple.com/epic/nmsys-server/commit/c58fc082db8161ccf8b001151a8dc5f125ddaf01)
* [Allow slack as escalation](https://github.pie.apple.com/epic/nmsys-server/commit/ae8e9a1ecde3a6e0304fe2f84a98fe8b51a1fe52)
* [Addind slack](https://github.pie.apple.com/epic/nmsys-server/commit/08b854317850e5ffc2319485d9beb69d892ec693)
* [Fix slack template](https://github.pie.apple.com/epic/nmsys-server/commit/c82125e61426b79cfd710996d4cc0be27e9f7c83)
* [Kube migration complete](https://github.pie.apple.com/epic/nmsys-server/commit/051d70dc4780d205cde5c25e09c438b5cad729d9)




## 5.1.7

* [typos](https://github.pie.apple.com/epic/nmsys-server/commit/5060cf43652539680d96bedb6c46fedfe5baac1b)
* [Fix for maintenance filter in the nmsys cli script](https://github.pie.apple.com/epic/nmsys-server/commit/d268007aa95416c73b38b45bd98a0fd0836d93dd)
* [rdar://68174591 (Please create new Configuration Item "GIO CloudKit Solr SRE" and "GIO ACI Hadoop" for subscriptions)](https://github.pie.apple.com/epic/nmsys-server/commit/ad49ca8855218c7296f65c68ed50c5258652a0dd)
* [too verbose removing print](https://github.pie.apple.com/epic/nmsys-server/commit/61013e29e8d0392d9e245c82825108f7b04cd2fc)
* [<rdar://problem/66616190> GIO_Sys_ISS_Nmsys: CLI option to cross check wether the set of hosts are under maintainance](https://github.pie.apple.com/epic/nmsys-server/commit/49b7464c5b7aec96adef2a7c242a806e80dabca9)
* [rdar://69411151 (GIO_ISS_nmsys: Please create new CI "GIO DC Tools" for nmsys subscription)](https://github.pie.apple.com/epic/nmsys-server/commit/c5242a214b6851f73ab5b75ed20f9d4d0403d4b0)
* [Fixing bug escalated by Maps on Digested notification use the wrong caching key](https://github.pie.apple.com/epic/nmsys-server/commit/4d23e8a9534788799fd69a087b8872ecd0fbcb23)
* [cleanup](https://github.pie.apple.com/epic/nmsys-server/commit/8bd22bec473c6de1601d8329cee58c08d4c4a6f1)%


## 5.1.6
* [CHANGELOG](https://github.pie.apple.com/epic/nmsys-server/commit/36aa01a96d8369f1ff7d043ccde09de444fd44c9)
* [Improving spawning protocol for notification as well (get the processing down to less than 10s for all filters)](https://github.pie.apple.com/epic/nmsys-server/commit/43dd2923e1c8bfece93422266f1c1d0bb9886811)


## 5.1.5
* [Fixing running maintenance processing delay](https://github.pie.apple.com/epic/nmsys-server/commit/342c028658c78b6cbdd27a3734c93391888f80c1)
* [<rdar://problem/53224928> / <rdar://problem/66951249> / <rdar://problem/67365911> Fixing issue with maintenance not being applied](https://github.pie.apple.com/epic/nmsys-server/commit/f5ce3568d90d99ac53f0db0c0b26eb4dd6931869)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/12ee38b3d23b477e4005602275dadf5ddfe6f3b2)

## 5.1.4
* Adding Exception handler on syntax error in case people modify the maintenance with an invalid value


## 5.1.3
*    <rdar://problem/65915697> GIO_Sys_ISS_Nmsys : Nmsys CLI not completely silencing all alerts
*    <rdar://problem/65915697> GIO_Sys_ISS_Nmsys : Nmsys CLI not completely silencing all alerts

## 5.1.2
:release-date: 2020-07-15 3PM PST
:release-by: Ronan Foucher

* [CHANGELOG](https://github.pie.apple.com/epic/nmsys-server/commit/b96dfc9cff871962649fa9d9f6b720d567bc86d0)
* [Fixing issue with older version of redis which wont allow 0 expire as never expire](https://github.pie.apple.com/epic/nmsys-server/commit/fab545734f7bb9444c1f2baeefaeb468b242ea40)
* [<rdar://problem/65203369> Update backup of nmsys-alert-repo-production](https://github.pie.apple.com/epic/nmsys-server/commit/72f94ad4abaf23b1312a6295052dba83b3643f09)
* [<rdar://problem/64879222> ISO_SSC_nmsys: CI not getting updated for AMP Mozart SRE](https://github.pie.apple.com/epic/nmsys-server/commit/dc07ecaec3691791e00788dbb90a49583aa9671c)
* [<rdar://problem/65579255> NMSYS alerting issue : pv42p01if-ztfj11111501.pv.if.apple.com (dmesg_check)](https://github.pie.apple.com/epic/nmsys-server/commit/72bed62b5517cd37caac882d50ddc49ca27f0182)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/2a53bfdf7d84711996f2b41e1a888d0bacca4222)


## 5.1.1
:release-date: 2020-07-07 8AM PST
:release-by: Ronan Foucher

* [Addind target](https://github.pie.apple.com/epic/nmsys-server/commit/7dd4a307623bbf215c93fea4f671fd4b5564cfde)
* [Addind target](https://github.pie.apple.com/epic/nmsys-server/commit/e617fba44eb9e27653c50e66b7551fe8a5d7e262)
* [None cant be decoded []bug](https://github.pie.apple.com/epic/nmsys-server/commit/943fcdfbf90f331c60dc596b042310439867ee14)
* [<rdar://problem/65014109> Unable to select "P1" in nmsys GUI for CST ticketing](https://github.pie.apple.com/epic/nmsys-server/commit/54c6563fbce79b173abf58c3dd4830090d26dcc7)
* [<rdar://problem/65050501> Getting Reachability Alerts from QA Epic Instance for Prod Hosts](https://github.pie.apple.com/epic/nmsys-server/commit/58ee9c4ebc480a1890ded8f4e5eb5d583fd6552c)
* [Adding support for custom titles (cant find the radar bug GNSrequest)](https://github.pie.apple.com/epic/nmsys-server/commit/31a5949e874f7ba1f318d33d9f00975a1b2457aa)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/cea29ad2c418dfe0929b5048d36082ac08b91a66)
* [<rdar://problem/65149098> nmsys Alert Creation Fails on invalid certificate(?)](https://github.pie.apple.com/epic/nmsys-server/commit/0caeb027961c6403e1e92e4b37ce16b7de8ebbd0)%  


## 5.1.0
:release-date: 2020-06-29 8AM PST
:release-by: Ronan Foucher

* [<rdar://problem/64517168> ISO_SSC_Nmsys: Silenced host generated ticket](https://github.pie.apple.com/epic/nmsys-server/commit/87b87e732693c7f09f412336120502434186df1f)
* [<rdar://problem/64544862> Remove duplication of alarm name when generating CST tickets](https://github.pie.apple.com/epic/nmsys-server/commit/4264daefb02e933e276df897fbebbf92ccf1ae9d)
* [<rdar://problem/63678827> ISO_SSC_nmsys: Add new Configuration Item - Edge Traffic Delivery](https://github.pie.apple.com/epic/nmsys-server/commit/98595de1b29906a4151745519ed990097f48ee47)
* [<rdar://problem/64610269> ISO_SSC_nmsys: Please create new configuration item "GIO AMP Mozart SRE" in nmsys](https://github.pie.apple.com/epic/nmsys-server/commit/e4f54370df1a5c037dc9c80f6b6dadb99b87c29f)
* [keyword fields wont accept a special tokenizer](https://github.pie.apple.com/epic/nmsys-server/commit/bbb9ac887d2a57bbc7031d4b43247d6836c0a6db)
* [forgot the change for dev env](https://github.pie.apple.com/epic/nmsys-server/commit/55559f4c672df648766629df7b02772b93e9034e)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/8f74a2ae826b0602004774112b37c591eaf69fde)
* [CHANGELOG](https://github.pie.apple.com/epic/nmsys-server/commit/9819987d0fa5598c2d28f6b209107fdde45fbc72)
* [Basic helper for changelog generation - I m lazy](https://github.pie.apple.com/epic/nmsys-server/commit/19fe21768d15e9167db2c21b1716b524552da695)
* [<rdar://problem/64760386> NmSYS to create new CST after defined mins if the alerts still exists](https://github.pie.apple.com/epic/nmsys-server/commit/f575e92d162823a85551f29dd46892325dcd616a)
* [This should not count as a fail notification process](https://github.pie.apple.com/epic/nmsys-server/commit/235ea01a721189df3d14fd3e960b453e2ab9062e)
* [<rdar://problem/64760006> On 06/23/2020, during an outage because of disk 100%, there was no alert from nmsys pv43d01ls-hpfi08083801.geo.apple.com](https://github.pie.apple.com/epic/nmsys-server/commit/1c6f23bd7af70fe97edd27501ef4cbe6aefe464d)
* [<rdar://problem/59766708> nmSys: Enable more granular priorities for CST tickets](https://github.pie.apple.com/epic/nmsys-server/commit/999eb66bc0f8a1bec608e59ec022610c9b79e92e)
* [internal stuff for rio](https://github.pie.apple.com/epic/nmsys-server/commit/6998f7fbbe3ce51d343a4c72c905edd6da9e244c)
* [Adding support for redis special lib returning bytes](https://github.pie.apple.com/epic/nmsys-server/commit/074f1135fc07be37d98c4d1817db54d7694d2a1e)
* [Adding support for special CST soon released - first step to migrate to AlertManager](https://github.pie.apple.com/epic/nmsys-server/commit/fee21c6b9bd149b3ba3c98d7805cb06711463eda)
* [<rdar://problem/59766708> nmSys: Enable more granular priorities for CST tickets](https://github.pie.apple.com/epic/nmsys-server/commit/a717343d1f2370a3c665f9b7334ff488723c7841)
* [v++](https://github.pie.apple.com/epic/nmsys-server/commit/425cc8cde664ad5ebfd1fe01ca464abbccc4dab1)


## 5.0.13
	:release-date: 2020-05-05 1PM PST
	:release-by: Ronan Foucher

	* the /test/ page Epic uses for validation  will actually do ES queries so it fails when app is down
	* adding direct notification for any ES issue to me
	* monitoring of ES has been re-enabled (to you and me)
	* New config with full list of ES endpoints (and not just 2 like it was left after the last outage)
added documentation for SRE to take over (https://github.pie.apple.com/epic/nmsys-server/blob/master/docs/OPERATION_HANDOFF.md)
	* Moved the Makefile in root HOMEDIR for SRE to be able to fix the cluster without me see MD file for commands

## 5.0.0
	:release-date: Not yet
	:release-by: Ronan Foucher

Major change:
	Pyhton 3 migration


## 4.19.29
    :release-date: 2019-01-26 8:30 PST
    :release-by: Ronan Foucher

Fix:

	Problem with Epic QA URLs when exploding the graph


## 4.19.23
	:release-date: 2019-01-26 8:30 PST
    :release-by: Ronan Foucher

Migration off old network servers



## 4.19.22
	:release-date: 2019-12-23 8:30 PST
    :release-by: Ronan Foucher

Misc:

    APZ CST CI


## 4.19.21

	:release-date: 2019-11-13 8:30 PST
    :release-by: Ronan Foucher

Misc:

	APZ Aipo config issue
	APZ Aipo incorrect environment
	Config items for SSC

## 4.19.20

	:release-date: 2019-10-17 8:30 PST
    :release-by: Ronan Foucher

Fix:

	AIPO Station : environment set to production
	DSE not using the dedup mechanism
	Centralstation Configuration items for SSC

## 4.19.19

	:release-date: 2019-10-02 11:30 PST
    :release-by: Ronan Foucher

Feature :

	<rdar://problem/51269398> Centralstation KPI for SLO/SLI


Other :

	rdar://55751055 (nmSys Central Station Configuration) Simcloud
	


## 4.19.18
	
    :release-date: 2019-09-26 10:00 PST
    :release-by: Ronan Foucher


Feature:

	AIPO : P1C mapping to High/High in AipoStation


## 4.19.17

    :release-date: 2019-09-18 14:00 PST
    :release-by: Ronan Foucher

Feature:

    Use recertify to fix issue with Apple CA intermediate certs

	Increase HTTP Post timeout for delivery

	Add HTTP header to trace the source of the POST 


## 4.19.16

    :release-date: 2019-08-19 10:00 PST
    :release-by: Ronan Foucher

Fix:
	
	Regression : Epic export thresholds is not sorted causing config to reload every 5min


## 4.19.15

    :release-date: 2019-08-19 9:00 PST
    :release-by: Ronan Foucher

Fixes:

    Reducing whitespace in CST template
	Fixing HTTP post for some endpoints requiring proxy

Misc:
	Adding new CST Configuration items

## 4.19.14

    :release-date: 2019-07-22 9:00 PST
    :release-by: Ronan Foucher

Fixes:

    Reducing whitespace in CST template

## 4.19.13

    :release-date: 2019-06-11 9:00 PST
    :release-by: Ronan Foucher

Features:

    Adding health page

    Epic serializer

## 4.19.12

:release-date: 2019-05-28 9:00 PST
:release-by: Ronan Foucher

Features:

    Support for Alert template in Epic threshold
Fixes:

    Fix for maintenances with short host name 

## 4.19.1

    :release-date: 2019-02-6 11:00 PST
    :release-by: Ronan Foucher

Features:

    Support larger maintenance node filters for DC based silencing (40k nodes at a time)

    Option to disable aggregation with specific queries (some automation are making expensive queries which would timeout)

Fixes:

    Circular import was causing failure when invoking Epic QL

    Stats would not be JSON serialized properly on callback

## 4.19.0

    :release-date: 2019-01-30 11:00 PST
    :release-by: Ronan Foucher

Features:

    Epic Query Language for Alerts
    Enable Search v3 - new query syntax
    History migrated back to ES cluster to support next Gen occurrence based esclation
    New monitoring for source pushes track down source and scehdule
    Support multiple main endpoint of Epic UI

Fixes:

    Silence passed in as String would break escalation

Misc:

    Adding a couple of new Configuration Items

## 4.18.5

    :release-date: 2019-01-09 11:00 PST
    :release-by: Ronan Foucher

Features:

    Notification tab per host
    Support for APZ - Epic metric endpoint can be changed
    Support for APZ - AIPO can be enabled via config flag

Fixes:
    Fallback when Epic Search is down : cache the old value and use it when Epic Search Service in unresponsive
        <rdar://problem/47166809> Redis cache eviction when Epic search is down causes a giant mess
    Filter generator is catching exceptions on failure without reporting the problem.
    GIT backup force sync before commit <rdar://problem/47117174> Backup corruption from ES - current methodology does not work
    Username is converted from unicode improperly  *<rdar://problem/47091872> information / subscription drop down problem with unicode conversion
    nmsys-cli script : SSL certificate issue with DLB 

## 4.18.4

    :release-date: 2019-01-07 11:00 A.M PST
    :release-by: Ronan Foucher

Features :
    Logging improvement and tracability following last fridays outage
    (When docker leaves orphan on upgrade - allow to track them)

Other :
    Various Configuration Items for IS&T

## 4.18.2-3

    :release-date: 2018-12-19 2:00 P.M PST
    :release-by: Ronan Foucher  

Fixes :
    Golden Gate Various configuration fixes

Other :
    Pre christmas Centralstation Fixes

## 4.18.1

    :release-date: 2018-12-14 2:00 P.M PST
    :release-by: Ronan Foucher

Features:

Fixes :

    - Adding stats back using the new epic client
    - Ratio would not be honnored
    - Correcting for notification when there's no attachement
    - Fixes on Notification schema
    - Fix for Pagerduty API - unable to reach the endpoint for 10* subnet

Other :

    - Adding various CS

## 4.18.0
    :release-date: 2018-11-15 12:00 P.M PST
    :release-by: Ronan Foucher

Features:
    
    - Migrate to single database for all Sentinel clusters
    - Correcting some bad behavior caused by the multiple database
    - Improving Ratio on notification
    - Store stats as part of the ES object for versioning
    - Bulk inserts speed up for full vs incremental with proper reordering
    - Maitenance feature to disable notifier and put the cluster in RO mode for maintenance

Fixes :

    - Ratio bug when stats are not set


Other :

    - Adding various CS

## 4.17.0
    :release-date: Not released
    :release-by: Ronan Foucher


## 4.16.2
    :release-date: 2018-10-31 9:00 A.M PST
    :release-by: Ronan Foucher

Fixes:

    - APZ security fixes

Other:

    - Centralstation Configuration Items


## 4.16.1
    :release-date: 2018-09-20 12:00 P.M PST
    :release-by: Ronan Foucher

Fixes:

    - API key issue


## 4.16.0
    :release-date: 2018-09-17 9:00 A.M PST
    :release-by: Ronan Foucher

Features:

    - Notification history can now search for nodes / alerts
    - Stats moved to the dedicated Epic instance
    - Stats are now k/v nodes
    - Few minor UI improvements (count of alerts)
    - Support for re-indexation of indexes and index rotation
    - Migration to ES 5.6
    - Expose Node details from the client via the API
    - Migrating to the new IDMS endpoints
    - JSON/CSV/YAML/exports easier to spot

Fixes:

    - Lots of security fixes :-)
    - Logout page / Refresh either redirecting to 404 or 301


## 4.15.0
:release-date: 2018-08-30 9:00 A.M PST
:release-by: Ronan Foucher

Features:

    - Timeout
    - CS configuration items



## 4.14.2
:release-date: 2018-08-02 9:00 A.M PST
:release-by: Ronan Foucher

Features:

    Support key/value pairs in alert name

    Support Regex name capture for non pythononic format

    Adding various CIs

Fixes

    Fixing plugin task when plugin is causing exception

    Fixing SSC validation on subscription (reducing the scope of the regex)


## 4.14.1

:release-date: 2018-07-05 9:00 A.M PST
:release-by: Ronan Foucher

Fixes :

    Version missmatch in the nmsys-cli script

    Tags layout in Centralstation ticket


## 4.14.0

:release-date: 2018-06-27 9:00 A.M PST
:release-by: Ronan Foucher

UI / Internal features :

    - Support exclusion generically for filters (was only allowed on nodes, now supports alert, instance)

    - Support filtering on locale

    - Subscriber list now shows if multiple contacts have been defined

    - Notification tab now support pagination (filtering is also fixed)

    - Silenced/disabled filter is now separated from status filter to facilitate user interaction

    - Toggled description now remains as a flag during navigation

    - nmSys now support key/value pair node filtering

    - Adding support to force a clear cache on the node filtering from Epic search

    - Adding option to silence until next workday at 10am

Notification features :

    - New template for email notification

    - Notification process now multi-threaded for escalation to reduce the lag when endpoints were timing out

    - Allow user to configure the maximum number of simultaneous alerts before forcing digested notification

    - Allow user to add/remove extra details in the notification : correlation, stats, Epic groups

Correlation features :

    - Per notification, a correlation will be added if Kin has any details about the alert

    - Per filter, a correlation tab will be present allowing user to have a group by alert from Kin with the correlated alerts

Architecture :

    - Redis sharding is now using sentinel to route to the various redis instances

    - The redis instances are now replicated properly, automatic failover is managed trough sentinel

Fix :

    - Notification tab was improperly filtering for a given filter

    - Epic graph link would not work properly

## 4.13.0
    :release-date: 2018-05-25 11:00 A.M PST
    :release-by: Ronan Foucher

- Fix:

    Re-enable HISTORY - auto increment is fixed

## 4.12.3
    :release-date: 2018-04-30 11:00 A.M PST
    :release-by: Ronan Foucher
- Fix:

    Re-enable HISTORY - auto increment is fixed


## 4.12.2
    :release-date: 2018-04-08 11:00 A.M PST
    :release-by: Ronan Foucher
- Fix:

    Some HTTP post output are HTML - don't let them break the UI - move details to remote_content and use status_code as detail
    Context switch not setting properly due to re-authentication
    Security fixes for nginx/update dependencies
    Kin integration minor fixes



## 4.12.1
    :release-date: 2018-04-06 8:30 A.M PST
    :release-by: Ronan Foucher



- Fix :

    Fixing issue on resend when ticket resolved/closed the create function was not called properly
    Fixing DSMEOND route to use LUA script to only update on change 

-Misc :
    Reduce verbosity for splunk
    Fix multithread count for wsgi
    Add specific nmsys source on node call (require proper regex, force anchoring)
    Merge list of supported applications for bulk API
    Change the queue name separator for the bulk API

## 4.12.0
    :release-date: 2018-03-28 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Maintenance :

    Allow you to create maintenance, for nodes, node patterns and dependencies with or without filter subfiltering

- Kin integration (for now only integrated with maintenance feature)
- Allow exports to Yaml, CSV, JSON and fix some bugs

##### Fixes
- 502 Gateway errors : WSGI queue size was not large enough to handle the large number of concurrent requests.
- Reduce verbosity of Nginx logs for Splunk (error is enough)


## 4.11.6
    :release-date: 2018-02-23 4:00 p.M PST
    :release-by: Ronan Foucher

#### Features
- Add historical data




## 4.11.5
    :release-date: 2018-02-23 10:00 A.M PST
    :release-by: Ronan Foucher

#### Other
- Add GNS DC INTERNAL / Core services configuration item


## 4.11.4
    :release-date: 2018-02-22 3:00 P.M PST
    :release-by: Ronan Foucher

#### Fixes
- Fixing CS ticket when Configuration Item is not set - was using default value instead of empty
- Cleaning up minor errors in templates with undeclared variables
- Cleaning up Centralstation subject when alert name and filter name are the same

#### Other
- Add GNS DC EXTERNAL configuration item




## 4.11.3
    :release-date: 2018-02-21 10:00 A.M PST
    :release-by: Ronan Foucher

#### Fixes
- Fixing CS ticket with custom subject for GNS - ticket will fail on creation for interface errors

## 4.11.2
    :release-date: 2018-02-20 11:45 A.M PST
    :release-by: Ronan Foucher

#### Fixes
- Change for Redis sentinel auto fail-over
- Centralstation fix : unable to update Priority when created as P1 from the API
- Centralstation duplicate tickets for GNS overwritten subject

## 4.11.1
    :release-date: 2018-02-19 11:00 A.M PST
    :release-by: Ronan Foucher

#### Fixes
- interface format replace was not working
- Regex on GNS auto generated interface alerts was too broad catching user based alerts


## 4.11.0
    :release-date: 2018-02-15 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Improve display of metrics with proper colors per status
- Improve definition of the Centralstation Configuration Items
- Improve IS&T ticket subject : interface format 
- Add delivery SRE list of Configuration Items
- Add SSC Tools configuration items
- Reorder subscription loop to prioritize Centralstation escalation

#### Fixes
- Fixing minor timing issue when filtering on start/end


## 4.10.0
    :release-date: 2018-02-13 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Add time filter with start and end time on alerts time change and filter updates

####
- Disable lint since it doesnt support some extra syntax
- Wrap an exception handler around User stat when Redis is down


## 4.9.0
    :release-date: 2018-02-05 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- CentralStation Adding support for P1 Critical (Impact 1 - Urgency 2)

## 4.8.0

    :release-date: 2018-02-01 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- CentralStation description limit to 4000 : when bigger, attach the content to the ticket
- Wizard Lint / Syntax validation on filter/custom threshold creation for better feedback
- CentralStation - add Configuration Item for delivery SRE

#### Fixes
- Regex for GNS generated alerts is too broad catching non generated alerts and creating duplicates
- Strip the user entries in the wizard to prevent extra spaces (mostly for node filter)
- Create graph button broken under certain condition

## 4.7.0

    :release-date: 2018-01-25 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Add support for interval - allow filter on updated within n seconds
- Add trend of stream usage per app/locale
- Add trend of API calls per user / URLs

#### Fixes
- Fixing bug on deletion
- Fixing issue with Redis script when Redis replication is enabled
- Fixing posts on callback with requests package making it more resilient to special URLs with auth


## 4.6.0

    :release-date: 2018-01-18 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Improved subject generator for GNS CentralStation tickets
- New Config Item for Jetstream Infrastructure
- Adding ES template for Plugin Configuration

#### Fixes
- Fixing <br> in CentralStation


## 4.5.0
    
    :release-date: 2017-11-15 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- Improving git sync/backup with proper quorum management
- Historical data feature
- Aging special force option
- CentralStation amelioration : template, char limit,

#### Fixes
- Fixing issue in Epic template export

- Reset ACK flag on ptime

- Epic image attachment are not removed after notification (workers running out of space)


## 4.4.0

    :release-date: 2017-10-17 11:00 A.M PST
    :release-by: Ronan Foucher

#### Features
- CentralStation API v3


## 4.3.0

    :release-date: 2017-08-25 11:00 A.M PST
    :release-by: Ronan Foucher

## 4.2.0

    :release-date: 2017-07-05 11:00 A.M PST
    :release-by: Ronan Foucher


## 4.1.0

    :release-date: 2017-06-10 11:00 A.M PST
    :release-by: Ronan Foucher


## 4.0.0

    :release-date: 2017-05-04 11:00 A.M PST
    :release-by: Ronan Foucher

- Scalability:
    greater than 30 million alerts
    10x improvement on response time (now ~50ms for general case)

- Bi-directional sync of config via GitHub version’ing for all changes
    Automatic backup / versioning of all changes in GitHub
    Live update nmSys<->GitHub allowing users to manage their filters and rules from either UI/API or config files in GitHub.
    Improves DR recovery time from hours to minutes

- History of Changes

- New alert wizard simplifies alert management

- New UI

- Notifications on recovery

- New Notification process

- Trend all status changes

## 2.6.3

    :release-date: 2013-10-24 11:00 A.M PST
    :release-by: Ronan Foucher

- Epic/Verdad tags definition for Sets/Subsets definition

- Performance improvements via a new query parser

- New internal Queuing system for performance

- Nmsys-client integration for CSI


## 2.6.2

    :release-date: 2013-08-06 11:00 A.M PST
    :release-by: Ronan Foucher

- Add support for Nmsys Client api 


## 2.6.1

    :release-date: 2013-08-02 11:00 A.M PST
    :release-by: Ronan Foucher

- Nmsys Set on Regex/List :
        
    * Creation of set of alerts using list of alerts pattern or list of regexes. This will allow users to build there own Sets within Nmsys.

    * Typical usage is Epic auto created alerts and Nmsys Client alerts.


## 2.6.0

    :release-date: 2013-07-31 11:00 A.M PST
    :release-by: Ronan Foucher

- Superset of registered alerts : 
        
    * Creation of Superset of Registered Alerts will be used as a container for multiple Registered Alerts to present issues in a correlated way.

    * Creation of Superset of Registered Alerts across multiple organizations or instances.

- Subset of registered alerts : 
        
    * Creation of of subsets for your Registered Alert and Default Registered Alerts will let you inherit the defaults for a particular set of Nodes.
        
- Better Management of Context Switching in the UI.

- Filter based on Acknowledged issues.

- minor improvements and bug fixes

- More Information about Superset/Subset : https://github.isg.apple.com/isg-monitoring/nmsys-frontend/wiki/Supersets-And-Subsets

## 2.5.0

    :release-date: 2013-05-28 11:00 A.M PST
    :release-by: Ronan Foucher


- Add Team Support (Context Switching):

    * You can create / delete alerts for your team,

    * Subscription can be seen / edited by everyone in the DS group

- Add Viewer panel to display the current thresholds

- Add Sortable Alert Creation : alert are managed like ACL order can be modified using drag'n'drop

- Add filtering view in the subscription (filter on list of keywords / status / regex )

- Renaming feature ( you can now directly rename your alert)

- Changing ownership ( you can simply export your registered alerts to your group )

- bug fixes ....

> [ 2012-03-25 ] Release 2.4 : Add Espresso Support, change display, ordering, cancel feature, Change behavior for non digested alert / resend after per alert

> [ 2012-02-25 ] Release 2.3 : Add filtering for emailing per Status - routing as well

> [ 2012-02-22 ] Release 2.2 : Add Host filtering, Service Queries, Aging, queries improvments

> [ 2013-02-18 ] Release 1.1 : Fixing mainly Aging problem  - Add Persistent support for the view

> [ 2013-02-17 ] Release 1.0rc : Rewrite Front and Back

> [ 2013-02-02 ] Release 0.9 : Beta Version

> [ 2013-01-15 ] Give on Alpha version ... rewrite needed

> [ 2013-01-10 ] Release 0.2 : Alpha Version fix

> [ 2012-11-10 ] Release 0.1 : Alpha Version


