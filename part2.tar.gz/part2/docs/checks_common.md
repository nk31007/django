title: Common Checks
name: alert_common_checks
---

The common checks serve as a fallback to provide basic host monitoring.
You can enhance this monitoring by either add your own host based checks or your custom thresholds.
The common checks are prepended with special keywords which cannot be reused :

- default@
- common@
- nmsys@
