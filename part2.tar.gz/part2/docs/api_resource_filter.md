title: Filter Resource
---

### Parameters

Parameter | Description
--- | ---
`subscription.subscriber` | filter on subscribers, can be a list of subscribers
`disabled` | <ul><li>if unset, or set to 0 : will return filters which aren't silenced</li><li>if set to 1 : will return filters which are silenced</li><li>if set to 2 : will return all filters</li></ul>
`start` | Start of the time filter for u_ctime (Processing time when the filter was last modified)
`end`   | End of the time filter for u_ctime (Processing time when the filter was last changed)

### `start` and `end` parameters

Support the following:
    2days
    2d
    1year
    3month

By default always compares to now (now - 2days)


### `search_q` parameter

`search_q` is the generic way of filtering, you can either pass part of a string or a fully anchored regex.

The following keys are allowed.

Key | Description
--- | ---
`n`, `name`, `a` | name of the filter
`application` | filter on the application (epic,filter)
`node` | filter on the definition node
`owner` | filter owner
`description` | filter on the description of the filter
`l`, `locale`, `o` | filter on the Epic locale from which the node is being monitored
`i`, `inst`, `instance` | filter on the Epic instance from which the node is being monitoring
`s`, `status`, `state` | filter on alert status (CRITICAL,WARNING,UNKNOWN,OK,INFO)

### Schema

#### Schema for thresholds

```json
    {
        "aggregations": {
            "bucket": {
                "buckets": [
                    {
                        "doc_count": 2,
                        "key": "OK"
                    },
                    {
                        "doc_count": 1,
                        "key": "PENDING"
                    }
                ],
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0
            }
        },
        "meta": {
            "limit": 1,
            "next": "/nmsys/api/rest/v2/filter/?format=json&application=epic&limit=1&subscription.subscriber=rfoucher&offset=1&session_key=y7zx65kp3zr2mkcay0vwhss2c4tdn1ye",
            "offset": 0,
            "previous": null,
            "took": 4,
            "total_count": 3
        },
        "objects": [
            {
                "application": "epic",
                "definition": {
                "datasource": "memProcess_percent",
                "instance": "adminsys",
                "mode": "expand",
                "node": "vp21a00is-nmsys.*"
            },
            "details": {
                "Acknowledged": 0,
                "OK": 2
            },
            "information": {
                "description": "Yeah I know <epicimg>&ds=\nmemProcess_percent stack\n</epicimg>      <epicimg>&ds=memProcess_percent</epicimg>",
                "gitlink": "",
                "name": "checkMemoryNmsys",
                "username": "rfoucher"
            },
            "name": "rfoucher@checkMemoryNmsys",
            "pk": "04d45a58-ba60-48e6-98ba-b3314618c09d",
            "resource_uri": "/nmsys/api/rest/v2/filter/04d45a58-ba60-48e6-98ba-b3314618c09d/",
            "state": 1,
            "status": "OK",
            "subscription": [
                {
                    "email-contact": "rfoucher@apple.com",
                    "notif-ifcritical": "on",
                    "notif-ifdigest": "on",
                    "notif-ifwarning": "on",
                    "notification_type": "pager",
                    "resend-after": 60,
                    "select-duration": 1,
                    "subscriber": "rfoucher"
                }
            ],
            "threshold": {
                "11": {
                    "definition": [
                        [
                            "memProcess_percent",
                            "<",
                            "50"
                        ]
                    ],
                    "status": "OK"
                },
                "12": {
                    "definition": [
                        [
                            "memProcess_percent",
                            "<=",
                            "70"
                        ]
                    ],
                    "status": "WARNING"
                },
                "13": {
                    "definition": [
                        [
                            "memProcess_percent",
                            ">",
                            "70"
                        ]
                    ],
                    "status": "CRITICAL"
                }
            },
            "u_ctime": 1493852608
        }]
    }
```

#### Schema for filters

```json
    {
        "aggregations": {
            "bucket": {
                "buckets": [
                    {
                        "doc_count": 5,
                        "key": "OK"
                    },
                    {
                        "doc_count": 1,
                        "key": "CRITICAL"
                    },
                    {
                        "doc_count": 1,
                        "key": "PENDING"
                    }
                ],
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0
            }
        },
        "meta": {
            "limit": 1,
            "next": "/nmsys/api/rest/v2/filter/?format=json&application=filter&limit=1&subscription.subscriber=rfoucher,epic-admin&offset=1&session_key=***",
            "offset": 0,
            "previous": null,
            "took": 5,
            "total_count": 9
        },
        "objects": [
            {
                "application": "filter",
                "definition": {
                    "alert": "default@ping,default@reachable.*",
                    "instance": ".*sys",
                    "node": "~verdad.group=dcepicpoller,~verdad.group=dcepicapi"
                },
                "details": {
                    "Acknowledged": 0,
                    "CRITICAL": 1,
                    "OK": 8
                },
                "information": {
                    "description": "Fix this in the morning",
                    "gitlink": "",
                    "name": "pollerapi_health_reachable",
                    "username": "epic-admin"
                },
                "name": "epic-admin@pollerapi_health_reachable",
                "pk": "dc27332f-839d-4e50-8b8a-1656280cb57d",
                "resource_uri": "/nmsys/api/rest/v2/filter/dc27332f-839d-4e50-8b8a-1656280cb57d/",
                "state": 5,
                "status": "CRITICAL",
                "subscription": [
                    {
                        "email-contact": "epic-admin-alert@group.apple.com",
                        "notif-ifcritical": "on",
                        "notif-ifdigest": "on",
                        "notification_type": "email",
                        "resend-after": 1440,
                        "select-duration": 1,
                        "subscriber": "epic-admin"
                    }
                ],
                "u_ctime": 1493852608
            }
        ]
    }
```

* `aggregations` (buckets):

    * returns the count per Status / Acknowledgement and silence state for any of your search

        * "doc_count": counter of filters per status (Type : Integer)

        * "key": status name (Type : String)

* `objects` (array of alerts)

    * Mandatory fields :

        * "definition" :

            - Filters : applied filter to search in the feed of alerts

            - Epic threshold : definition of the node/instance to apply the threshold on

            - Fields :

                * datasource: Epic datasource (for Epic threshold)

                * node: Node definition (You can use either a node name, a node regex, a group or a group regex [!important see tilde notation]

                * mode: [expand,avg,sum]

                * instance: Epic instance

        * "information" :

            - All details about the filter/threshold

            - Fields :

                * name : Real Name of the filter

                * username : Owner of the filter

                * description : details about the filter

                * gitlink : documentation link to embed in the notification

        * "threshold" :

            - Only when creating an Epic threshold

            - Sorted thresholds (Threshold are ordered from lower to higher integer)

            - Format:

                ````
                    {

                        "{priority}" : {
                            "status": "{status}",
                            "definition": [
                                ['value1', 'comparison', 'value2']  
                            ]
                        }
                ```

                - priority : sets the order the lowest value will be first match

                - status : critical|warning|ok

                - definition : Array of Arrays

                    Multiple arrays in the definition implies and AND between the comparisons

                    value1 and value2 are strings containing either :

                        *  single datasource

                        * integers

                        * complex RPN operations

        * "subscription":

            - Array of subscriptions:

                * Mandatory Fields

                    - "subscriber":

                    - "email-contact":

                    - "resend-after":

                    - "select-duration":

                    - "notification_type": http|espresso|centralstation|email

                * Optional Fields
                    - "notif-ifcritical": ("on" / missing) Enable/Disable Notification on CRITICAL

                    - "notif-ifwarning": ("on" / missing) Enable/Disable Notification on WARNING

                    - "notif-ifunknown": ("on" / missing) Enable/Disable Notification on UNKNOWN

                    - "recovery": ("on" / missing) Enable/Disable Notification on Recovery (when status goes back to OK)

                    - "notif-ifdigest": ("on" / missing) Digested notification will wrap all simultaneous alerts into a single notification

                    - "callback-myself":  ("on" / missing) Set nmSys to publish a Notification summary after escalation (http API) see documentation for details about the object

                    - "callback-my-url": (Type String(URL)) if "callback-myself" is set to "on" set proper http URL to your endpoint                  

                * Specific Fields

                    *  Centralstation and Espresso Priorities                        
                        - "priority": (Type String : value "P3"|"P2"|"P1") Default Priority if none are set for critical and warning, as well as unknown and revory if enabled

                        - "priority-critical": (Type String : value "P3"|"P2"|"P1") Priority for CRITICAL alerts on creation

                        - "priority-warning": (Type String : value "P3"|"P2"|"P1") Priority for WARNING alerts on creation                        

### How to manage a filter by the example

{% include_md ./alerting/api_example_of_filter.md %}
