title: nmSys client
---
nmSys Client is a long running daemon that manages passive checks and pushing metrics to Epic.
The client is located under `/usr/local/nmsysclient/`. 


## Adding New nmSys Check Scripts 

A nmSys check script can be any script that runs and exits with:
- 0: OK
- 1: WARNING
- 2: CRITICAL
- 3: UNKNOWN

A check script should output all useful information to `stdout` (nmSys ignores `stderr`).

You may install a check script anywhere on your system, using any means you see fit.
After installing your script, you must [register it with the the nmSys client](#Registering-Check-Scripts).

### Building Check Scripts

You can use any language or library installed on your system when writing a
check script. However, before reinventing the wheel, keep in mind that any system
with the nmSys client includes:

* **Nagios libexecs** - The nmsys client RPM embeds the Nagios libexecs,
   which you can use in your checks. They are located under `/usr/local/nmsys-client/opt/nagios/`.

* **nmSys Common Checks** - nmSys's own [common checks](./client_common_checks.html)
  are useful building blocks for your own scripts. They are located under `/usr/local/nmsys-client/opt/common/`.


## Registering Check Scripts 

To configure nmSys to manage your script, add a config file under `/usr/local/nmsysclient/conf.d/`.
You can add as many config files as you want. The name of your configuration
file must have the pattern `\d{2}_(application_name).ini`. For example, `03_mysupercheck.ini`.

After adding or changing configuration files, you must restart the nmSys client.

{% note info Important %}
- Do not use the prefix `00_`, as it is restricted.
- Do not edit `00_common.ini`.

Instead of editing files that you don't own, you can override their behavior as described under [Overriding Configurations](#Overriding-Configurations).
{% endnote %}

### Configuration File Syntax

The configuration file follows the format:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/yourapp
    servicename: nameThatDisplaysInNmsys
    command: mysupercheck.py
    run: 60

where:

* `path`: the absolute path to your check, not including the script name
* `servicename`: name that displays in nmSys (the alert name)
* `command`: the filename of your script (excluding the path)
* `run`: the interval for running your script in seconds (default: 60); a value
   of 0 disables the check.


### Overriding Configurations

On restart, the nmSys client reads in its configuration as an ordered list of configuration files.
To modify or disable a check defined in another configuration file, create a new file that has a higher leading index number.

For example, `00_common.ini` contains a configuration block:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/yourapp
    command:  mysupercheck.py
    run: 60

You could change this named check to use an entirely different script and interval by adding an `99_override.ini` file:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/bin/otherscript
    servicename: nameThatDisplaysInNmsys
    command:  mydifferentsupercheck.py
    run: 600

### Disabling a Check

To disable a check, add an override file that sets `run` to 0:

    [NmsysPlugin MyCheckUniqueName]
    run: 0
