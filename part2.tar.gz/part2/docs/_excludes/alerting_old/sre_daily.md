title: Daily activities
---

## Logging in to nmSys

To access nmSys, log in to one of these URLs:

* QA(labs,qa env): https://nmsys.qa.isg.apple.com
* PROD (All DCs): https://nmsys.isg.apple.com

## Acknowledging Problems

When you receive a notification, you can acknowledge the problem by following the link in the notification

If you are coming into nmSys from the nmSys front page, your notifications are under the **Notifications** tab.

One you have listing of alerts in the UI, you can click the pencil icon to
acknowledge the alert.

You can also acknowledge alerts from Epic UI. The Epic UI header displays
counters for each type of alert for the current alert. For more information,
refer to Epic UI's [Alert Indicator](../ui/header.html#Alert-Indicator).
