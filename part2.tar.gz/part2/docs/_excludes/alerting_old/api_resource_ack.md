# Details for `alert`

### Filtering


* `user`:

    * will return all the alerts for a given user

### Schema

```
    {
        "aggregations": {
            "bucket": {
                "buckets": [],
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0
            }
        },
        "meta": {
            "limit": 10,
            "next": "/nmsys/api/rest/v2/ack/?alert_list=mr11a00is-admin&format=json&sort_by=-u_ctime&limit=10&offset=10&session_key=8m0cn0jao3q8qelezi9xvg1z5dyqltpi",
            "offset": 0,
            "previous": null,
            "took": 6,
            "total_count": 37
        },
        "objects": [
            {
                "ack": 0,
                "alert_list": [
                    "uschi6-cnd-lef1-7.apple.com__clos-admin@clos-int-in-errs_ci61_gnsclos"
                ],
                "comment": "INC064048654",
                "modification_value": "1495098331 0",
                "pk": "7958e702-276e-6ca1-55cb-fd20e89307a8",
                "resource_uri": "/nmsys/api/rest/v2/ack/7958e702-276e-6ca1-55cb-fd20e89307a8/",
                "silence": 1495098331,
                "time_ack": 1494925531,
                "timestamp": 1494925533,
                "type_ack": "alert",
                "type_action": "silence",
                "u_ctime": 1494925533,
                "user": "rkumar32",
                "user_ack": "rkumar32"
            }
        ]
    }
```

* `aggregations` (buckets):

    * returns the count per Status / Acknowledgement and silence state for any of your search
    
        * "doc_count": counter of filters per user (Type : Integer)

        * "key": status label (Type : String)


* `objects` (array of alerts)

    * Mandatory fields :

        * "alert_list" : `List of alert modified during the PATCH` (Type: Array of strings)

        * "ack" : `Value of the ack set during the PATCH`

        * "comment": `comment for the ack/silence`

        * "modification_value": `value of modications ack and silence as string` 
                
        * "silence": `silence modification timestamp value`
                
        * "time_ack": `timestamp of when the ack happened`
                
        * "timestamp": `timestamp of when the ack happened`
                
        * "type_ack": `type of resource ackd/silenced`
                
        * "type_action": `type of ack (ack|silence)`
                
        * "u_ctime": `timestamp of when the ack happened`
                
        * "user": `user or context set during acknowledgement`
                
        * "user_ack": `user who acknowledged`


