title: Troubleshooting
---

## Alert is in UNKNOWN state

1. Go to alert page in nmsys.
2. Click on definition look at the datasource definition make there’s no gap.
3. If no gap look at the host in epic make sure it’s not DOWN (metrics are NULL when server is Down).
4. Search for the metric named for the given host in UNKNOWN state and check on the value, make sure it exists and has a proper value.
5. Make sure this metric is not polled, if it’s polled, that might be caused by latency in polling (metrics are not ingested fast enough causing some NULL values) - in that case valide the health of the Epic cluster impacted.
  It could also be an ACL, or an improperly configured snmp community, run SNMP walk in that case.
6. If it’s not an issue with pollers, then open a radar against Epic, there’s probably a bug in Epic server alert processing.
