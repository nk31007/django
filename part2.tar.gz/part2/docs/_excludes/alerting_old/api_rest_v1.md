title: RESTful API
---

nmSys provides a RESTful API to access almost any features that it provides.

## Base URL

The base URL is:

```http
http://nmsysapi.isg.apple.com/api/rest/v2/{type}/[{id}/]?oauth_consumer_key={apikey}
```

Calls to `/api/rest/v2/{type}/` act on lists, while calls to `/api/rest/v2/{type}/{id}` operate on individual objects.

The types of objects you can operate on are:

* `ack`
* `alert`
* `filters`
* `notification`

To make API calls, you must pass an API key into requests. To get a key, select **API** in the main dashboard. If you don't have a key yet,
you can generate one from the UI. If your key is missing, nmSys responds with `401 Unauthorized`.


## Allowed HTTP Methods

* `POST`: Create a resource
* `GET`: Read an existing resource
* `PUT`: Update an existing resource
* `DELETE`: Delete an existing resource
* `PATCH`: Update multiple resources

## HTTP Status Codes

* 200 OK : Success
     * GET - Return resource
     * PUT - Provide status or return resource
* 201 Created : Success
     * POST - Provide status or return resource
* 204 : Success
     * DELETE
* 400 Bad Request : Failure
     * PUT, POST - Return error messages, including form validation errors.
* 401 Unauthorized : Failure
     * Credential are required
* 403 Forbidden : Failure
     * You don't have privileges for this resource. Please create a request for the specific resource.
* 404 Not found : Failure
     * See the list of existing resource
* 405 Method Not Allowed : Failure
     * We don't support everything yet, please open a Radar.


## Query Parameters

### `ack`

Filters alert results according to whether the alert has been acked:

* 0 - selects alerts that have not yet been acked
* 1 - selects alerts that have been acked


### `default`

Returns only "default" alerts, which are alerts that match: `default@.*|nmsys@.*|common@.*`.


### `format`

Selects an alternative format.  By default, the API returns JSON. You can change
the format by setting a `format` query parameter to:

* `json`
* `html` (the actual HTML used by the nmSys web UI)
* `csv`


### `limit`

Specifies the maximum number of results to return for a list or search call. The
default is 500.


### `node`

Matches on a particular Epic node or node regex.


### `registered_alert`

Searches for objects associated with a particular numeric filter ID. ("Registered alert" is a synonym for "filter").

{% note info Note %}
If you are searching on alerts, scoping your search to a particular
`registered_alert` value will greatly speed up your query.
{% endnote %}


### `status`

Filters on a comma separated list of uppercase status names. For example,
`status=CRITICAL,WARNING,OK` would return only items with those statuses.

* `CRITICAL`
* `INFO`
* `OK`
* `UNKNOWN`
* `WARNING`


### `tag`

Matches on a particular Epic tag.

## Examples

### Getting a Filter

Returns the filter with ID 258:

```http
GET /api/rest/v1/registered/258/?oauth_consumer_key={apikey}
```

### Getting Alerts

Returns all unacked, CRITICAL and WARNING alerts that are associated with filter 258.

```http
GET /api/rest/v1/alert/?registered_alert=258&status=CRITICAL%2CWARNING&ack=0&oauth_consumer_key={apikey}
```
