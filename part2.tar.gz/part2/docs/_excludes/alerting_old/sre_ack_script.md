title: nmsys-cli.py
---

The `nmsys-cli.py` script is a handy way to check status and ack alerts without going
through the web UI.

## Download nmsys-cli.py

To get `nmsys-cli.py`, [download the source](https://nmsys.isg.apple.com/nmsys-cli.py)
from nmSys directly.

## Commands

``` bash

$ python nmsys-cli.py
$ python nmsys-cli.py list-command
$ python nmsys-cli.py status --help
$ python nmsys-cli.py ack --help
$ python nmsys-cli.py cancel-ack --help
$ python nmsys-cli.py ack-until --help
$ python nmsys-cli.py cancel-ack-until --help

```

## Status

Check status of all services for `nk11a00is-noname001.isg.apple.com`:

``` bash
nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com
```

Check status for Standard Services on `nk11a00is-noname001.isg.apple.com`:

``` bash
nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com --event "Standard Services"
```

Check status for all hosts matching regex `nk11a00is.*` with status `CRITICAL` or `WARNING`:

``` bash
nmsys-cli.py status --node nk11a00is.* -C CRITICAL,WARNING
```

List all events for alert 1901 that are `CRITICAL` or `WARNING` AND already acknowledged:

``` bash
nmsys-cli.py status -r 1901 -C CRITICAL,WARNING -a 1
```

## Ack until

Ack all services on `nk11a00is-noname001.isg.apple.com` for two days:

``` bash
nmsys-cli.py ack-until --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
```

Ack all Standard Services on `nk11a00is-noname001.isg.apple.com` for one hour:

``` bash
nmsys-cli.py ack-until --node nk11a00is-noname001.isg.apple.com --event "Standard Services" -d 1h
```


Ack all hosts matching regex `nk11a00is.*` with status `CRITICAL` or `WARNING` for one hour:

``` bash
nmsys-cli.py ack-until --node nk11a00is.* -C CRITICAL,WARNING -d 1h
```

Ack all hosts matching tag `.*nmsys` with status `CRITICAL` or `WARNING` for one hour:

``` bash
nmsys-cli.py ack-until --tag verdad=.*nmsys -C CRITICAL,WARNING -d 1h
```

Ack all events for alert 1901  with status `CRITICAL` or `WARNING` for one hour:

``` bash
nmsys-cli.py ack-until -r 1901 -C CRITICAL,WARNING -d 1d
```

## Other commands

The **ack** command works the same as **ack-until**, but without a `-d` duration.

The **cancel-ack** and **cancel-ack-until** commands work similarly.
