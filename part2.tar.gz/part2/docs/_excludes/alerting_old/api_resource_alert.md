title: Alert Resource
---

### Parameters

Parameter | Description
--- | ---
`alert` | Exact match on alert name
`instance` | Exact match on alert instance
`locale` | Exact match on alert locale (Epic local)
`node` | Exact match on alert node (FQDN)
`state` | Exact match on status (0-15 integer)
`status` | Exact match on status or list of status
`tag` | Return all the alerts for a given group (has to start with ~)
`group` | Return all the alerts for a given group (has to start with ~)
`definition` | Return all the alerts for a given filter definition
`acknowledged` | <ul><li>if unset, or set to 0 : will return alerts which aren't ack'd nor silenced</li><li>if set to 1 : will return alerts which are ack'd or silenced</li><li>if set to 2 : will return all alerts (no filter)</li></ul>

### `search_q` parameter

`search_q` is the generic way of filtering, you can either pass part of a string or a fully anchored regex.

The following keys are allowed.

Key | Description
--- | ---
`n`, `node` | filter on the nodename
`e`, `a`, `alert` | filter on the alert
`dc`, `datacenter`, `locale` | filter on the Epic locale from which the node is being monitored.
`i`, `instance` | filter on the Epic instance from which the node is being monitoring.
`s`, `status`, `state` | filter on alert status (CRITICAL,WARNING,UNKNOWN,OK,INFO)
`description` | filter on description *look for word only no regex*
`mtime`, `timestamp` | filter on modification time

### Schema

```json
    {
        "aggregations": {
            "bucket": {
                "buckets": [
                    {
                        "doc_count": 11,
                        "key": "OK"
                    },
                    {
                        "doc_count": 1,
                        "key": "UNKNOWN"
                    }
                ],
                "doc_count_error_upper_bound": 0,
                "sum_other_doc_count": 0
            }
        },
        "meta": {
            "limit": 2,
            "next": "/nmsys/api/rest/v2/alert/?node=st11a00is-admin003.isg.apple.com&limit=2&offset=1&format=json&session_id=**",
            "offset": 0,
            "previous": null,
            "took": 5,
            "total_count": 12
        },
        "objects": [
            {
                "alert": "iso-tools@dns-hosts-st",
                "description": "Ping check for ST dns host fleet <epicimg>http://st11-epic.isg.apple.com/adminsys?a=g&&ds=ping&ng=&n=st11a00is-admin003.isg.apple.com&m=&s=1493925720</epicimg>\\nstate implicitly set to unknown (2): no rules matched",
                "instance": "adminsys",
                "locale": "st11",
                "ng": "",
                "node": "st11a00is-admin003.isg.apple.com",
                "resource_uri": "/nmsys/api/rest/v2/alert/st11a00is-admin003.isg.apple.com__iso-tools@dns-hosts-st_st11_adminsys/",
                "state": 2,
                "status": "UNKNOWN",
                "timestamp": 1494259523,
                "u_ctime": 1493932920,
                "u_mtime": 1494259320
            },
            {
                "alert": "gnsnet@gns_dc_external_interface_traffic_uklon5-424-01-03-edg-gw1.apple.com_Ethernet1_44",
                "comment": "INC063947947",
                "description": "<epicimg>http://mr11-epic.isg.apple.com/gnsnet?a=g&ds=ifInOctets.Ethernet1_44:color=FF0000!ifOutOctets.Ethernet1_44:color=0000FF33:area:hwv:hwb!ifInOctets.Ethernet1_44:color=FF000066:shift=-7d:inverse!ifOutOctets.Ethernet1_44:color=0000FF18:area:shift=-7d:inverse&no_gray=1&title=Ethernet1_44%20(bytes)&ng=&n=uklon5-424-01-03-edg-gw1.apple.com&m=&s=1478942220</epicimg>\\nifInOctets is zero\\n   Expr:  ifInOctets.Ethernet1_44 = 0\\n   Value: 0 = 0\\n\\nifOutOctets is zero\\n   Expr:  ifOutOctets.Ethernet1_44 = 0\\n   Value: 0 = 0\\n\\n",
                "instance": "gnsnet",
                "locale": "mr11",
                "ng": "",
                "node": "uklon5-424-01-03-edg-gw1.apple.com",
                "resource_uri": "/nmsys/api/rest/v2/alert/uklon5-424-01-03-edg-gw1.apple.com__gnsnet@gns_dc_external_interface_traffic_uklon5-424-01-03-edg-gw1.apple.com_Ethernet1_44_mr11_gnsnet/",
                "silence": 3071664970,
                "state": 5,
                "status": "CRITICAL",
                "time_ack": 1493944363,
                "timestamp": 1494356953,
                "u_ctime": 1478949420,
                "u_mtime": 1494355920,
                "user": "rfoucher"
            }
        ]
    }
```

* `aggregations` (buckets):

Returns the count per Status / Acknowledgement and silence state for any of your search

Field | Type | Description
--- | --- | ---
doc_count | Integer | counter of filters per status
key | String | status label


* `objects` (array of alerts)

**Mandatory fields**

Field | Type | Description
--- | --- | ---
alert | String | Alert name
node | String | Node name
ng | String | Node group name
locale | String | epic locale or source locale
instance | String | epic instance or source instance
description | Text | description or output of the alert
state | Integer | State 0 to 15
status | String | Current Status of the alert
u_ctime | Integer | Unix timestamp of the last status change (creation time)

**Optional Acknowledgement fields**

Field | Type | Description
--- | --- | ---
comment | Text | comment of the last acknowledgement or silence
silence | Integer | Unix timestamp of the date until it is silenced
user | String | username of the last modifier
time_ack | Integer | Unix timestamp of the date when it was ack'd / silenced

**Optional Internal fields**

Field | Type | Description
--- | --- | ---
u_mtime | Integer | Unix timestamp Epic/nmSys internal refresh timemarker
timestamp | Integer | Unix timestamp of last ES update call for the object
