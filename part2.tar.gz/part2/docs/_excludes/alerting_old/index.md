title: Notification Manager System (nmSys) Overview
---

nmSys is an alerting system, integrated with Epic. It handles tens of millions
of unique [alerts](./concepts.html) that update every minute, and sends tens of
thousands of notifications every day.

nmSys's features include:

- Filtered based escalation with multi-criteria pattern matching
- Threshold alert creation for any Epic metric
- Subscription based escalation
- Default monitoring for all hosts running nmSys-client/epic-client
- Escalation paths supported: CentralStation, Espresso, PagerDuty, Pager, Email 
- Export formats: JSON, HTML, CSV, XML, PNG
- Per event escalation triage
- Modular client supporting: default alerting, user plugins, scheduling, method to publish stats to Epic

For more information about nmSys, refer to:

- [Core Concepts](./concepts.html) -- Explains nmSys alerts, filters (a set of
  criteria for registering alerts of interest), and subscriptions (a filter plus
  a group to be notified).
- [nmSys client](./client_overview.html) -- Describes how to configure the nmSys
  client and how to create our own custom check scripts.
- [REST API](./api_rest.html) -- Documents the nmSys REST API, which enables you to
  programmatically set up and tear down alerts, filters, subscriptions, and
  acknowledgements. There is also a [Bulk Update API](./api_stream.html).
