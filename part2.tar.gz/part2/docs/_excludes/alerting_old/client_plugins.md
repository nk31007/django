title: Plugins
---

Any system with Epic client automatically has access to these core plugins:

* CpuPlugin
* NetworkPlugin
* MemoryPlugin
* IOstatsPlugin
* DiskPlugin

While Epic client's plugins handle core system metrics, the nmSys client supports additional plugins that are more application-specific.


#### HaproxyPlugin

Configuration:

    [HaproxyPlugin]
    user: secretuser
    password: secretpass
    source: http://localhost:6610/stats;csv


#### MemcachedPlugin

Configuration:

    [MemcachedPlugin]


#### MongodbPlugin

Configuration:

    [MongodbPlugin mysql_app_name]


#### MysqlPlugin

Metrics for MySQL (Basic, Extended, Replication, xtradb cluster)

Configuration:

    [MysqlPlugin mysql_app_name]
    user: secretuser
    password: secretpass
    host:localhost
    port:3306


#### NginxPlugin

Configuration:

    [NginxPlugin]


#### NmsysPlugin

Nagios / Ninja checks on the nmSys framework (metrics runtime / status)

Configuration:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/yourapp
    servicename: nameThatWillShoupinNmsys
    command: mysupercheck.py
    run: 60


#### PuppetPlugin

Metrics for Puppet client (runtime, changes, execution)

Configuration:

    [PuppetPlugin mysql_app_name]


#### RabbitMqPlugin

Configuration:

    [RabbitmqPlugin]
    rabbitMQStatusUrl = http://localhost:15672/api/overview
    rabbitMQUser = _user
    rabbitMQPass = _pass


#### RedisPlugin

Configuration:

    [RedisPlugin mysql_app_name]


#### Plugin Remote configuration

The nmSys server UI enables you to pilot the nmSys client to run any of its plugins via one of Epic's tags.

* Verdad tags: `~verdad={TAG}`
* Capri tags: `~capri.support={NAME}`
* Epic Nodegroup: `~{NODEGROUP}`
