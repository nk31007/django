title: Common Checks
---

This is the default list of checks that nmsys-client runs for all its hosts.

These checks are generic and are able to run on any \*IX system (please open a Radar if you find any issues).

If you need more specific monitoring for memory/cpu/disk usage, please use nmSys server to create custom filters.


##  Disk Utilization

* servicename: `disk_utilization-local`
* command: `check_disk_local.py`

Checks disk utilization %:
- 94% Warning
- 97% Critical

## Memory Utilization

* servicename: `memory_utilization-local`
* command: `check_memory_utilization.py`

Checks memory utilization %:
* 90% Warning
* 95% Critical


## Load

* servicename: `cpu_utilization-local`
* command: `check_load.py`

Checks load:
* 5 Warning
* 10 Critical


## Hardware

* servicename: `hardware`
* command: `check_hardware.py`

Checks fan, power, temperature, processor, and memory
from IPMI, hpasmcli, Sun Commands, and macOS Hardware Status.

Some of these hardware checks are not available for all types of hardware.

## Hard Drive

* servicename: `harddrive`
* command: `check_harddrive.py`

Checks that all hard drives listed in `fdisk` are passing their **smartctl** check.


## Mailq

* servicename: `mailq`
* command: `check_mailq.pl`

Checks Mailq size:
* < 10 warning
* < 20 critical


## Mounts

* servicename: `mounts`
* command: `check_mounts.py`

Checks that:
* mounts defined in fstab are properly mounted
* root `/` is writeable
* no mounts are manually mounted

Can be reused for more since it is mapping vfstab and (mounts).

{% note info Note %}
For simplicity, this script only checks NFS mounts.
{% endnote %}

For Linux, try to avoid any IP stack call that hangs when filers are not
working.


## Network

* servicename: `network`
* command: `check_network.py`

Checks ssh localhost.


## Puppet

* servicename: `puppet`
* command: `check_puppet_run.py`

Checks that:
* the last Puppet run didn't return errors
* the Puppetlock file is not older than 30 minutes


## User limit Utilization

* servicename: `user_limit`
* command: `check_user_limits.pl`

Checks user limit parameters vs usage.


## Running Processes

* servicename: `processes`
* command: `check_running_process.py`

Checks that:
* crond is running (at least 1 process) and not piling up number < 50
* snmpd is not piling up if running
* routed is not running
* ntpd is running
