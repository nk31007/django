title: RESTful API
---

nmSys provides a RESTful API to access almost any features that it provides.


## Base endpoints :

Production :
    ```http
        https://nmsys.isg.apple.com
    ```
QA:
    ```http
        https://nmsys.qa.isg.apple.com
    ```

## Base PATH

The base PATH is:

```http
/nmsys/api/rest/v2/{resource}/[{id}/]?oauth_consumer_key={apikey}
```

Calls to `/api/rest/v2/{resource}/` act on lists, while calls to `/api/rest/v2/{resource}/{id}` operate on individual objects.


## Resources
The types of resources you can operate on are:

* `ack`
* `alert` [alert filtering and schema](./api_resource_alert.html)
* `filter` [filter schema](./api_resource_filter.html)
* `notification`

{% note info %}
To make API calls, you must pass an API key into requests. To get a key, select **API** in the main dashboard. If you don't have a key yet,
you can generate one from the UI. If your key is missing, nmSys responds with `401 Unauthorized`.
{% endnote %}

## Allowed HTTP Methods

* `POST`: Create a resource
* `GET`: Read an existing resource
* `PUT`: Update an existing resource
* `DELETE`: Delete an existing resource
* `PATCH`: Update multiple resources

## HTTP Status Codes

* 200 OK : Success
     * GET - Return resource
     * PUT - Provide status or return resource
* 201 Created : Success
     * POST - Provide status or return resource
* 204 : Success
     * DELETE
* 400 Bad Request : Failure
     * PUT, POST - Return error messages, including form validation errors.
* 401 Unauthorized : Failure
     * Credential are required
* 403 Forbidden : Failure
     * You don't have privileges for this resource. Please create a request for the specific resource.
* 404 Not found : Failure
     * See the list of existing resource
* 405 Method Not Allowed : Failure
     * We don't support everything yet, please open a Radar.

## Common Query Parameters

* `format`

Selects an alternative format.  By default, the API returns JSON. You can change
the format by setting a `format` query parameter to:

    * json
    * html (the actual HTML used by the nmSys web UI)


* `limit`

Specifies the maximum number of results to return for a list or search call. The
default is 500.

* `search_q`

Allow you to filter the result via key/value pairs. See [query parameter per resource](#Resources) for more details.

* `sort_by`

Allow you to sort the results by specific keys (to reverse order prepend the key with '-') 

## Authentication

To access the resources you must add as a get parameter your OAUTH token.

{% note info %}
`oauth_consumer_key` is required to fetch any data.
{% endnote %}
