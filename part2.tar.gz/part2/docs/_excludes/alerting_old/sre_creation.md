title: Alerts, Filters and Subscriptions
---

## Starting the Wizard

The nmSys UI provides a creation wizard, which permits creation of new alerts or filtering pre-existing alerts.

* From an Epic UI graph, click the **Create Alert** button on the top row.
  This navigates to nmSys and activates the wizard, prepopulated with values
  taken from the graph.

* From the username dropdown, select **New Alert**, then select a type of
  `Filter` and click **Next**. This starts creating a filter from scratch.

* [**deprecated**] From the username dropdown, select **New Alert**, then select
  a type of `Epic` and click **Next**. nmSys then prompts you to enter an Epic
  graph URL which will prepopulate the wizard. This method is equivalent to
  clicking **Create Alert** and should no longer be used.

## Creating the Filter

There are four types of fields on the filter creation screen:

* **Node** - An Epic node, node regex, or comma separated list of nodes.
* **Org** - An organization to match on, such as `cse` or `apns`.
* **Instance** - An instance to match on, such as `sys` or `clos`.
* **Alert** - An alert name to match on, such as `gns-dc-central@cpu`.

## Adding a Subscription

* **Registered Alert Name** - The name of the filter. The prefix before the `@` is your
  username. The remainder can be any alphanumeric character, `.`, `_`, and `-`.
  Spaces will automatically be replaced by underscores.

* **Description** - A succinct definition of what this filter's purpose is.

* **Direct Link to documentation** - An optional URL that links to more
  information about the filter.

* **Ratio for Notification** - Indicates whether there is a threshold of issues
  before sending a notification. If toggled "ON", you can specify the
  percentage.

* **Type Notification** - Indicates how to send notifications (pager, email,
  espresso, and so on).

* **Multi contact Notification** - Indicates whether to notify different groups
  depending on the whether the alert is a `CRITICAL` OR `WARNING`. If toggled
  "ON", you can specify multiple groups.

* **Notify on Critical**, **Notify on Warning** - Specifies which statuses
  should trigger a notification

* **Digested Notification** - Creates a single notification per Service Issue
   and then aggregates it with the list of related issues per node.

* **Notify per unique event** - The opposite of digested notification. 

* **Duration before notification** - Selects the delay in minutes between when the alert
  is first received and when a notification should be sent.

* **Resend after n minutes** - Selects the base interval between resending notification.

* **Backoff** - Indicates whether to use a backoff algorithm when resending.
  The backoff algorithm increases the interval after each resend attempt. 

* **Set a callback on Notification** - Indicates whether to ping a callback URL
  on notification. If toggled "ON", a URL field becomes available. This option
  enables you to integrate nmSys notifications with other systems.

* **Append Epic Graph in notification** - Indicates whether to include an Epic
  PNG for the node in the notification output.

The default alert contact is your email/pager contact. You can specify multiple destinations seperated by a comma.
