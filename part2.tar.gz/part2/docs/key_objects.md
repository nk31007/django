title: Key Objects
name: alert_key_objects
---

### Alert

Alerts are individual message objects with the following fields:

Field | Definition
--- | ---
`alert` | name of the alert in the form `owner@name` or `source@name`
`description` | free-form description
`node` | node or hostname
`instance` | Epic instance
`locale`| Epic locale
`state` | numeric state: CRITICAL(5) WARNING(4) INFO(3) UNKNOWN(2) OK(1)
`u_ctime` | unix epoch create time (when the issue started)
`u_ptime` | unix epoch process time (when the issue was diagnosed)

The uniqueness of an object is controlled by the tuple (alert,node,instance,locale)

### Filter

Both [Alert Filters](#Alert-Filters) and [Custom Threshold Filters](#Custom-thresholds) require a name, a owner and a description (Only the owner will be allowed to edit the attributes of the filter).

The filter will always be displayed as `owner`@`filter_name` in the UI.

![Overview](images/filter_information.png)

See [context section](./context_ownership.html) for more details about naming

#### Alert Filters

The filter definition is a set of criteria that matches alerts. You must have at least one of the following filter configured:

    * `node`: node expressions, such as ~verdad.tag=my_custom_tag * See filtering details
    * `locale`: Epic locale such as nk11 or mr11
    * `instance`: Epic instance such as adminsys, gnsnet or itssys
    * `alert`: alert name such as gns-dc-external@interface_errors, nmsys@puppet,...

![Overview](images/filter_definition.png)

#### Custom thresholds

The custom thresholds are just a type of filter with extra attributes.
The name (`owner`@`filter_name`) of the Filter will be used by Epic Alerting daemon as the alert name and push then into
 nmSys server alert queue (this name will be used as to filter it back from the queue)

The definition for your custom threshold is set of criteria to apply your threshold to (fields are all required):

    * `node`: 1 or more node expressions, such as ~verdad.tag=my_custom_tag
    * `instance`: 1 or more Epic instance such as adminsys, gnsnet or itssys (* is allowed to apply a threshold to all Epic locales)
    * `datasource`: Datasource to build your threshold on
    * `mode`:
            - expand: hosts which match will individually have the alert applied
            - avg: average of the node(s) which make up the node or nodegroup
            - sum: sum of the node(s) which make up the node or nodegroup

![Overview](images/filter_threshold_definition.png)

The threshold for your filter is a set of comparison for each state you want to configure.

- The configuration is ordered like an ACL, first match will set the state.

- You cannot use a regex to define your datasource, if you need to specify multiple, you have to list them one by one and apply the comparison to each of them.

#### Monitor HTTP VIPs

This will require a PR to be created against [epic-instance](https://github.pie.apple.com/epic/epic-instance) to add the VIP to Epic's internal polling.

Creata a file epic-instance/i/helix/conf/db/db.remotetest.http with contents:

    Include tmpl.http; var:plugin = http_get_index; var:ng = svc_http_get_index; var:uri = /; var:port = 80

Where:

| variable | description
| -- | --
var:plugin |  is the base datasource(metric) name that will be created by epic-server when the test is run
var:ng | is the name of the epic group which will when a node is associated will run this test
var:uri | GET to request
var:port |  is the port of their http service

Then any endpoint will run this test by:

	manage node add -g svc_http_get_index HOSTNAME

Where HOSTNAME must be DNS resolvable, if it is not then:

	manage node add -g svc_http_get_index HOSTNAME:IP-ADDRESS

Example:

    manage node add -g svc_http_get_index www.yahoo.com

Note:

In order for helix to not have metric name collisions it is highly suggested for the node name added by manage to be of the form /locale=LOCALE/node=HOSTNAME where LOCALE is the helix locale the add is made to ( ie: mr11 st11 nk11 etc. )

The above template is built into epic-server `conf/default/db/_templates/inc.tmpl.http` and can be overridden with a package config or a new template created for any other test type.

The template currently supports http|https; ssl enabled with var:ssl_conn = 1 but the template does not have a var:expect variable for expected text.

Epic servers http(s) polling method will:

    1) consider the remote end up if responding with a 200 OK
    2) store state and timing information for the poll

### Subscription

A subscription consists of :

* Owner (see [context](./context_ownership.html) for details about ownership)
* Escalation path (route) such as email, pagerduty, or Centralstation
* Recipient details

When a new alert matches the filter, nmSys may notify the recipients using the specified channel.

You can configure a subscription to only notify for a certain level of severity, to resend notifications, and more.

Typical nmSys users will set up multiple subscriptions, each matching different recipients and different filters.

You can only have one subscription per Context, but any number of subscriptions for a given filter.
