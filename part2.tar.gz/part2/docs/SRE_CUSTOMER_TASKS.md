title: Daily Activities
name: alert_sre_daily
---

### Acknowledging and silencing alerts

When performing maintenance, or for known issues, you might need to act or react to issues by silencing or acknowledging issues.

The difference between the two:

* silence is tied to a time period, the alert will not trigger any notification during the silencing period.

        Once silence period expires, notification process will restore for the given alert

* acknowledgment is tied to a specific state, the alert will not trigger any notification as long as the state remain the same

        Once the state changes (for a better or for a worst state, the acknowledgement flag will reset, notification process will restore for the given alert

#### Silence/Acknowledgement pre-filtering

![Overview](images/ack_silence_menu.png)


#### Silence/Acknowledgement Wizard

![Overview](images/ack_silence_action.png)


#### Remove Silence/Acknowledgement pre-filtering and wizard

![Overview](images/all_remove_ack.png)


### Manage acknowledgement and silence from the various views

The silence and acknowledgements are tied to the specific alert, you need to acknowledge per alert.
If you need to acknowledge hosts/list of alerts, multiple alerts of a filter, make sure you follow the steps below.


#### Acknowledge/Silence for a Host/node

First [search for the node](./ui_search.html#Search-node-details) and click on the hostname to land on the [node view](./ui_extra_views.html#Node-details-view).

And proceed with the [generic Silence/Acknowledgement](#Silence-Acknowledgement-pre-filtering)


#### Acknowledge/Silence multiple alerts

Proceed with the [generic Silence/Acknowledgement](#Silence-Acknowledgement-pre-filtering)


#### Acknowledge/Silence alerts in a Filter


And proceed with the [generic Silence/Acknowledgement](#Silence-Acknowledgement-pre-filtering)


#### Find Acknowledged/Silenced alerts

See [Remove Silence/Acknowledgement pre-filtering and wizard](#Silence-Acknowledgement-pre-filtering)


### Enable/Disable subscriptions



### Manage acknowledgement and silence via the nmsys-cli.py script

You will find the nmsys-cli.py script in the API tab in of the Main page [download the source](https://nmsys.isg.apple.com/nmsys/alerting/nmsys-cli.py). You can simply click the link and copy paste the content to your local computer.

The script contains a secret key which is tied to your username, so do not share it with anyone.

The script can be used to search/silence/ack any alert.


```
python nmsys-cli.py  -h
Usage: nmsys-cli.py <command> [command-options]
```

---

#### Search alerts

```
python nmsys-cli.py status --help

nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com
    # check status of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com --alert "Standard Services"
    # check status for Standard Services on nk11a00is-noname001.isg.apple.com

nmsys-cli.py status --node nk11a00is.* -S CRITICAL,WARNING
    # list status for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py status -r 1901 -S CRITICAL,WARNING -a 1
    # list all alert for the Alert 1901 that are CRITICAL or WARNING AND already acknowledged

```


#### Acknowledge alerts

```
nmsys-cli.py ack --node nk11a00is-noname001.isg.apple.com --comment="Disaster recovery on all services."
    # ack alerts of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py ack --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi"
    # ack alerts "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py ack --node nk11a00is.* -S CRITICAL,WARNING
    # ack alerts for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py ack -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING
    # ack all alerts for the filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING

```

#### Cancel acknowledgment on alerts
```
nmsys-cli.py cancel-ack --node nk11a00is-noname001.isg.apple.com --comment="Disaster recovery on all services."
    # cancel-ack alerts of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-ack --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi"
    # cancel-ack alerts "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-ack --node nk11a00is.* -S CRITICAL,WARNING
    # cancel-ack alerts for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py cancel-ack -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING
    # cancel-ack all alerts for the filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```

#### Silence alerts


```
nmsys-cli.py silence --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
    # silence for 2 days for  all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py silence --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi" -d 1h
    # silence for 1 hour alert "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py silence --node nk11a00is.* -S CRITICAL,WARNING -d 1h
    # silence for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py silence --tag ~verdad.tag=.*nmsys -S CRITICAL,WARNING -d 1h
    # silence for 1h for all hosts matching tag .*nmsys with status CRITICAL OR WARNING

 nmsys-cli.py silence -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING -d 1d
    # silence for 1 day on all alerts for the Filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```

#### Cancel silence on alerts

```
nmsys-cli.py cancel-silence --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
    # cancel-silence for 2 days for  all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-silence --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi" -d 1h
    # cancel-silence for 1 hour alert "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-silence --node nk11a00is.* -S CRITICAL,WARNING -d 1h
    # cancel-silence for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py cancel-silence --tag ~verdad.tag=.*nmsys -S CRITICAL,WARNING -d 1h
    # cancel-silence for 1h for all hosts matching tag .*nmsys with status CRITICAL OR WARNING

 nmsys-cli.py cancel-silence -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING -d 1d
    # cancel-silence for 1 day on all alerts for the Filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```
