title: Overview
name: alert_ui_overview
---

nmSys links are composed of 3 menus :

![Overview](images/main_menu.png)


- [Main](./ui_main_menu.html) `This is where you will find everything related to you or your context`

- [Search](./ui_search.html) `This is where you will search for every resource in nmSys (context agnostic)`

- {username} `This is where you will preform actions : change context / create new filters / add new groups ...)`
