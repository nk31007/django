title: Notification Manager System (nmSys) Overview
name: alerting
---

# Epic Alerting (nmSys) documentation

- [1.Endpoints](#1endpoints)
- [2.Overview](#2overview)
    - [2.1.Diagram](#21diagram)
    - [2.2.Key objects](#22key-objects)
    - [2.3.Other Objects](#23other-objects)
- [3.Details](#3details)
    - [3.1.Alert](#31alert)
    - [3.2.Filter](#32filter)
        - [3.2.1.Alert Filters](#321alert-filters)
        - [3.2.2.Custom thresholds](#322custom-thresholds)
        - [3.2.3.Monitor HTTP VIPs](#323monitor-http-vips)
    - [3.3.Subscription](#33subscription)
- [4.Context and Ownership](#4context-and-ownership)
- [5.Epic Tagging](#5epic-tagging)
    - [5.1.Custom tags from Verdad](#51custom-tags-from-verdad)
    - [5.2.Default tags from iTrac](#52default-tags-from-itrac)
    - [5.3.Default tags from Capri](#53default-tags-from-capri)
    - [5.4.Default tags from hosts discovery](#54default-tags-from-hosts-discovery)
    - [5.5.Default process discovery for process statistics (procstats)](#55default-process-discovery-for-process-statistics-procstats)
    - [5.6.Default tags from Carnival](#56default-tags-from-carnival)
    - [5.7.Default tags from Casserole](#57default-tags-from-casserole)
- [6.Clients](#6clients)
    - [6.1.Epic client package](#61epic-client-package)
        - [6.1.1.Pull Request to epic-client](#611pull-request-to-epic-client)
        - [6.1.2.Use EAPI cache directory](#612use-eapi-cache-directory)
        - [6.1.3.Use the TCP EAPI connection](#613use-the-tcp-eapi-connection)
    - [6.2.nmSys client package](#62nmsys-client-package)
        - [6.2.1.Adding New nmSys Check Scripts](#621adding-new-nmsys-check-scripts)
        - [6.2.2.Building Check Scripts](#622building-check-scripts)
        - [6.2.3.Registering Check Scripts](#623registering-check-scripts)
        - [6.2.4.Configuration File Syntax](#624configuration-file-syntax)
        - [6.2.5.Overriding Configurations](#625overriding-configurations)
        - [6.2.6.Disabling a Check](#626disabling-a-check)
        - [6.2.6.Customizing threshold](#626customizing-threshold)
        - [6.2.7.Important note about adding new checks from the nmSys client](#627important-note-about-adding-new-checks-from-the-nmsys-client)
    - [6.3.Client installation](#63client-installation)
        - [6.3.1.Within ISO](#631within-iso)
        - [6.3.2.Puppet based environment](#632puppet-based-environment)
        - [6.3.3.Other solutions](#633other-solutions)
- [7.Common checks](#7common-checks)
    - [7.1.Metric based checks](#71metric-based-checks)
        - [7.1.1.Reachable](#711reachable)
        - [7.1.2.CPU / Memory / Disk usage](#712cpu-memory-disk-usage)
        - [7.1.3.NTP](#713ntp)
    - [7.2.State based checks](#72state-based-checks)
        - [7.2.1.Load,  Memory / Disk / usage](#721load-memory-disk-usage)
        - [7.2.2.Swap / Ulimit](#722swap-ulimit)
        - [7.2.3.Filesystem / Mounts](#723filesystem-mounts)
        - [7.2.4.Mailq / Network / Puppet / Processes](#724mailq-network-puppet-processes)
- [8.Plugins](#8plugins)
    - [8.1.Remote configuration](#81remote-configuration)
    - [8.2.Plugin configurations](#82plugin-configurations)
        - [8.2.1.ApacheLog](#821apachelog)
        - [8.2.2.Apache](#822apache)
        - [8.2.3.Docker (not yet supported)](#823docker-not-yet-supported)
        - [8.2.4.Elasticsearch](#824elasticsearch)
        - [8.2.5.Haproxy](#825haproxy)
        - [8.2.6.Jenkins](#826jenkins)
        - [8.2.7.Memcached](#827memcached)
        - [8.2.8.Mongodb](#828mongodb)
        - [8.2.9.Mysql](#829mysql)
        - [8.2.10.Nginx](#8210nginx)
        - [8.2.11.NmsysClient](#8211nmsysclient)
        - [8.2.12.Nmsys](#8212nmsys)
        - [8.2.13.Parser](#8213parser)
        - [8.2.14.Postgresql](#8214postgresql)
        - [8.2.15.Puppet](#8215puppet)
        - [8.2.16.Rabbitmq](#8216rabbitmq)
        - [8.2.17.Redis](#8217redis)
- [9.nmSys UI walk-through](#9nmsys-ui-walk-through)
    - [9.1.Main menu](#91main-menu)
        - [9.1.1.Subscription sub menu](#911subscription-sub-menu)
        - [9.1.2.Notification sub menu](#912notification-sub-menu)
        - [9.1.3 API](#913-api)
    - [9.2.Search](#92search)
        - [9.2.1.Search Alerts](#921search-alerts)
        - [9.2.2.Search For existing filters/custom thresholds](#922search-for-existing-filterscustom-thresholds)
        - [9.2.3.Search notifications sent](#923search-notifications-sent)
        - [9.2.4.Search node details](#924search-node-details)
    - [9.3.Extra views](#93extra-views)
        - [9.3.1.Filter details view](#931filter-details-view)
        - [9.3.1.Node details view](#931node-details-view)
        - [9.3.2.Wizards](#932wizards)
        - [9.3.2.1.Create custom thresholds](#9321create-custom-thresholds)
        - [9.4.Subscriptions](#94subscriptions)
        - [9.4.1.Notification Routes](#941notification-routes)
        - [9.4.1.1.Email](#9411email)
        - [9.4.1.2.Pagerduty](#9412pagerduty)
        - [9.4.1.3.Centralstation](#9413centralstation)
        - [9.4.1.4.Pager](#9414pager)
        - [9.4.1.5.HTTP POST](#9415http-post)
- [10.API](#10api)
    - [10.1.Base endpoints](#101base-endpoints)
    - [10.2.Base path](#102base-path)
    - [10.3.Resources](#103resources)
    - [10.4.Allowed methods](#104allowed-methods)
    - [10.5.HTTP Status Codes](#105http-status-codes)
    - [10.6.Common Query Parameters](#106common-query-parameters)
    - [10.7.Authentication](#107authentication)
    - [10.8.Alert resource details :](#108alert-resource-details)
    - [10.9.Filter and Subscription resource details :](#109filter-and-subscription-resource-details)
- [11.GITHUB Backup Repo](#11github-backup-repo)
    - [11.1.Locations](#111locations)
    - [11.2.](#112)
- [12.Debug/Tips](#12debugtips)
    - [12.1.UNKNOWN State for custom threshold](#121unknown-state-for-custom-threshold)
    - [12.2.Advanced custom thresholds](#122advanced-custom-thresholds)
        - [12.2.1.Alert on deviation over period of time](#1221alert-on-deviation-over-period-of-time)
        - [12.2.2.Alert on the top average of multiple datasources over a period of time](#1222alert-on-the-top-average-of-multiple-datasources-over-a-period-of-time)
- [13.SRE daily activities](#13sre-daily-activities)
    - [13.1.Acknowledging and silencing alerts.](#131acknowledging-and-silencing-alerts)
        - [13.1.1 Silence/Acknowledgement pre-filtering](#1311-silenceacknowledgement-pre-filtering)
        - [13.1.1 Silence/Acknowledgement Wizard](#1311-silenceacknowledgement-wizard)
        - [13.1.2 Remove Silence/Acknowledgement pre-filtering and wizard](#1312-remove-silenceacknowledgement-pre-filtering-and-wizard)
    - [13.2.Manage acknowledgement and silence from teh various views](#132manage-acknowledgement-and-silence-from-teh-various-views)
        - [13.2.1.Acknowledge/Silence for a Host/node](#1321acknowledgesilence-for-a-hostnode)
        - [13.2.2.Acknowledge/Silence multiple alerts](#1322acknowledgesilence-multiple-alerts)
        - [13.2.3.Acknowledge/Silence alerts in a Filter](#1323acknowledgesilence-alerts-in-a-filter)
        - [13.2.4.Find Acknowledged/Silenced alerts](#1324find-acknowledgedsilenced-alerts)
    - [13.3.Enable/Disable subscriptions](#133enabledisable-subscriptions)
    - [13.4.Manage acknowledgement and silence via the nmsys-cli.py script](#134manage-acknowledgement-and-silence-via-the-nmsys-clipy-script)
        - [13.4.1.Search alerts](#1341search-alerts)
        - [13.4.2.Acknowledge alerts](#1342acknowledge-alerts)
        - [13.4.3.Cancel acknowledgment on alerts](#1343cancel-acknowledgment-on-alerts)
        - [13.4.4.Silence alerts](#1344silence-alerts)
        - [13.4.5.Cancel silence on alerts](#1345cancel-silence-on-alerts)
- [14.Support](#14support)


## 1.Endpoints

    - Production: https://nmsys.isg.apple.com

    - QA (UAT): https://nmsys.qa.isg.apple.com

***

## 2.Overview

### 2.1.Diagram

![Overview](images/overview.png)

### 2.2.Key objects

nmSys uses 3 key objects to provide escalations of your alerts:

- [Alert](#31alert) (Unique event/alert happening on a host)

- [Filter](#32filter) (A filter definition applied against the  queue of alerts)
    * Custom thresholds are a subclass of filters with extra arguments

- [Subscription](#33subscription) (Escalation definition to notify for alerts present in a filter)

### 2.3.Other Objects

- [Notification](#notification) (Historical data: result of the escalation attempt)

- [Plugin](#plugin) (Extra configuration for the nmSys client)

- [Acknowledgment](#acknowledgement) (Historical data: all acknowledgements performed)


***

## 3.Details


### 3.1.Alert

Alerts are individual message objects with the following fields:

Field | Definition
--- | ---
`alert` | name of the alert in the form `owner@name` or `source@name`
`description` | free-form description
`node` | node or hostname
`instance` | Epic instance
`locale`| Epic locale
`state` | numeric state: CRITICAL(5) WARNING(4) INFO(3) UNKNOWN(2) OK(1)
`u_ctime` | unix epoch create time (when the issue started)
`u_ptime` | unix epoch process time (when the issue was diagnosed)


The uniqueness of an object is controlled by the tuple (alert,node,instance,locale)



### 3.2.Filter

Both [Alert Filters](#alert-filters) and [Custom Threshold Filters](#custom-threshold-filters) require a name, a owner and a description (Only the owner will be allowed to edit the attributes of the filter).

The filter will always be displayed as `owner`@`filter_name` in the UI.

![Overview](images/filter_information.png)

See [context section](#4context-and-ownership) for more details about naming



#### 3.2.1.Alert Filters

The filter definition is a set of criteria that matches alerts. You must have at least one of the following filter configured:

    * `node`: node expressions, such as ~verdad.tag=my_custom_tag * See filtering details
    * `locale`: Epic locale such as nk11 or mr11
    * `instance`: Epic instance such as adminsys, gnsnet or itssys
    * `alert`: alert name such as gns-dc-external@interface_errors, nmsys@puppet,...

![Overview](images/filter_definition.png)

#### 3.2.2.Custom thresholds

The custom thresholds are just a type of filter with extra attributes.
The name (`owner`@`filter_name`) of the Filter will be used by Epic Alerting daemon as the alert name and push then into
 nmSys server alert queue (this name will be used as to filter it back from the queue)

The definition for your custom threshold is set of criteria to apply your threshold to (fields are all required):

    * `node`: 1 or more node expressions, such as ~verdad.tag=my_custom_tag
    * `instance`: 1 or more Epic instance such as adminsys, gnsnet or itssys (* is allowed to apply a threshold to all Epic locales)
    * `datasource`: Datasource to build your threshold on
    * `mode`:
            - expand: hosts which match will individually have the alert applied
            - avg: average of the node(s) which make up the node or nodegroup
            - sum: sum of the node(s) which make up the node or nodegroup



![Overview](images/filter_threshold_definition.png)


The threshold for your filter is a set of comparison for each state you want to configure.

- The configuration is ordered like an ACL, first match will set the state.

- You cannot use a regex to define your datasource, if you need to specify multiple, you have to list them one by one and apply the comparison to each of them.


#### 3.2.3.Monitor HTTP VIPs

This will require a PR to be created against [epic-instance](https://github.pie.apple.com/epic/epic-instance) to add the VIP to Epic's internal polling.

Creata a file epic-instance/i/helix/conf/db/db.remotetest.http with contents:

    Include tmpl.http; var:plugin = http_get_index; var:ng = svc_http_get_index; var:uri = /; var:port = 80

Where:

| variable | description
| -- | --
var:plugin |  is the base datasource(metric) name that will be created by epic-server when the test is run
var:ng | is the name of the epic group which will when a node is associated will run this test
var:uri | GET to request
var:port |  is the port of their http service

Then any endpoint will run this test by:

	manage node add -g svc_http_get_index HOSTNAME

Where HOSTNAME must be DNS resolvable, if it is not then:

	manage node add -g svc_http_get_index HOSTNAME:IP-ADDRESS

Example:

    manage node add -g svc_http_get_index www.yahoo.com

Note:

In order for helix to not have metric name collisions it is highly suggested for the node name added by manage to be of the form /locale=LOCALE/node=HOSTNAME where LOCALE is the helix locale the add is made to ( ie: mr11 st11 nk11 etc. )

The above template is built into epic-server `conf/default/db/_templates/inc.tmpl.http` and can be overridden with a package config or a new template created for any other test type.

The template currently supports http|https; ssl enabled with var:ssl_conn = 1 but the template does not have a var:expect variable for expected text.

Epic servers http(s) polling method will:

    1) consider the remote end up if responding with a 200 OK
    2) store state and timing information for the poll







### 3.3.Subscription

A subscription consists of :

* Owner (see [context](#4context-and-ownership) for details about ownership)
* Escalation path (route) such as email, pagerduty, or Centralstation
* Recipient details

When a new alert matches the filter, nmSys may notify the recipients using the specified channel.

You can configure a subscription to only notify for a certain level of severity, to resend notifications, and more.

Typical nmSys users will set up multiple subscriptions, each matching different recipients and different filters.

You can only have one subscription per Context, but any number of subscriptions for a given filter.

***



## 4.Context and Ownership

The context feature is used to control ownership of filters and subscriptions. The idea being that only the owner can edit filter definitions and subscriptions.

When on your main subscription page you will be able to see only the subscription set for the context
(if set to your username (default) you will see all your personal subscription as well as your group subscriptions)
See (walk-through)[#8nmsys-ui-walk-through] for more examples.


You can add new group for ownership from the UI by clicking on:

![Overview](images/apple_ds_group.png)

## 5.Epic Tagging

Epic uses various sources of truth to provide a tagging solution which suits the various SRE teams.

    ISO : Verdad
    GNS: Capri

    ALL:
        - Network discovery from the host if available
        - iTrac info from verdad if available

You can use the tags to create filters, apply custom thresholds, run searches in Epic alerting (nmSys) or in Epic search.

By default, node filters are node-name regex, when using tags, we use the tilde notation `~` internally as a special
reference to `tags` to tell the processes to expand the search to a list of nodes instead node-name regex.


e.g. for tag named `verdad.tag=mynewtag` the search / threshold definition will be `~verdad.tag=mynewtag`

Few examples :

- Search: https://epic.isg.apple.com/search/?n=~verdad.group=epic-nmsys-cluster
- nmSys alerts: https://nmsys.isg.apple.com/nmsys/alerting/search/alert/?query=n:~verdad.group=epic-nmsys-cluster
- nmSYS Filter : [Filter example](#321alert-filters)


### 5.1.Custom tags from Verdad

Epic allows you to create custom tags from Verdad via two specific keys :

- `module.epic.node.tag` which will tag the nodes like `verdad.tag=`{value}

- `module.epic.node.group` which will tag the nodes like `verdad.group=`{value}

e.g.

    ```
    -0-rfoucher@st11a00is-admin001:~ $ vd expand mr20a00is-quge05162401.isg.apple.com -T /epic.node.tag/
    item mr20a00is-quge05162401.isg.apple.com
        module.epic.node.tag = (
            sre-l2-alert3
            epic-nmsys-cluster
        )
    ```
![Overview](images/verdad_custom_tag.png)


And you can then use them in your custom threshold filters/filters :

![Overview](images/verdad_custom_tag_filter.png)



### 5.2.Default tags from iTrac

The tags are pulled from iTrac via verdad which is a requirements for this to work.

Here are the tags discovered when avaible :

    verdad.asset.config
    verdad.asset.manuf
    verdad.location.country
    verdad.localtion.dc
    verdad.location.site


### 5.3.Default tags from Capri

The tags are pulled from Capri and available only for network nodes present in Epic

    capri.id
    capri.model
    capri.priority
    capri.state
    capri.status
    capri.type
    capri.vendor


### 5.4.Default tags from hosts discovery

Epic uses LLDP discovery packets to extract network information about the closest neighbor (the switch the node is attached to).

This is not always available since as it requires LLDP to be enabled on the network node it's attached to.

Here are the tags discovered when enabled :

    network.default.local.port
    network.default.local.ip.address
    network.default.local.mac.address
    network.default.uplink.name
    network.default.uplink.port
    network.default.uplink.ip.address


### 5.5.Default process discovery for process statistics (procstats)

Epic uses pattern matching against process names to tag the hosts with the applications running on it.

See [Procstats module for details](https://github.pie.apple.com/epic/epic-client/blob/master/src/conf/eapi_module_procstat.cf)

Only few processes name patterns are being tracked by this module, if you need to add some extra pattern feel free to open a PR.

As of today processes matching:

    - "epic-"
    - "httpd"
    - "/rad/Current/sbin/rad-"
    - "WD40"
    - "CIESecurity/certd/bin/certd"

Once tagged the node will be tagged with the given process name:

    e.g. ~procstat.proc=process_name




### 5.6.Default tags from Carnival

Epic runs crawlers which goes after all carnival endpoints to and tag all hosts it can find accordingly.

If a host has been discovered it will be tag with

    carnival.app={property}_{environment}_{group}_{application}

    e.g. ~carnival.app=icloud_prod_nlams_contentedge

### 5.7.Default tags from Casserole

Epic runs crawlers which goes after all casserole endpoints to and tag all hosts it can find accordingly.

If a host has been discovered it will be tag with

    casserole.cassandra={cluster-name}_{application}

    e.g. ~casserole.cassandra=iadusrinfo-eu_iadusrinfo


## 6.Clients


### 6.1.Epic client package

The Epic client is responsible for publishing system metrics to Epic server. The client is located under `/usr/local/epic/`.

You can find the source code in [github](You can find the source code in [github](https://github.pie.apple.com/epic/epic-client).
).

If you need to publish metric to Epic server, you can either:

#### 6.1.1.Pull Request to epic-client

You can submit a pull request with your own module see [github](https://github.pie.apple.com/epic/epic-client/tree/master/src/modules/eapi) for some examples of existing modules. and [documentation](https://epic.isg.apple.com/docs/server/publish_time_series.html) for the format

#### 6.1.2.Use EAPI cache directory

The EAPI (Epic API) cache directory can be used to publish your metrics, see [documentation](https://epic.isg.apple.com/docs/server/publish_time_series.html) for the format the location of the directory is /usr/local/epic/cache/eapi/

```
location of the directory is /usr/local/epic/cache/eapi/
Create a file {appname}.{nowepoch}.{pid}
    e.g. memcached_appA.1514914370.4320
Content should look like O:varName:itime:value:node:type[:step]
    e.g.O:runTime:1514914370:0.848412036896:nk11a00is-nmsys001.isg.apple.com:GAUGE:60
```

#### 6.1.3.Use the TCP EAPI connection

You can Connect to the Epic server TCP API and publish the metrics via your own script/daemon see [documentation](https://epic.isg.apple.com/docs/server/publish_time_series.html) for the format and request a username/password for your application by creating a Radar (Component ISG Epic/New request)

```
Content should look like O:varName:itime:value:node:type[:step]
    e.g.O:runTime:1514914370:0.848412036896:nk11a00is-nmsys001.isg.apple.com:GAUGE:60
```

### 6.2.nmSys client package

nmSys Client is a long running daemon that manages passive checks and pushes metrics to Epic. The client is located under `/usr/local/nmsysclient/`.

You can find the source code in [github](https://github.pie.apple.com/epic/nmsys-client).

`(Soon will be part of the Epic client)`


#### 6.2.1.Adding New nmSys Check Scripts

A nmSys check script can be any script that runs and exits with:
- 0: OK
- 1: WARNING
- 2: CRITICAL
- 3: UNKNOWN

A check script should output all useful information to `stdout` (nmSys ignores `stderr`).

You may install a check script anywhere on your system, using any means you see fit.
After installing your script, you must [register it with the the nmSys client](#523registering-check-scripts).

#### 6.2.2.Building Check Scripts

You can use any language or library installed on your system when writing a
check script. However, before reinventing the wheel, keep in mind that any system
with the nmSys client includes:

* **Nagios libexecs** - The nmsys client RPM embeds the Nagios libexecs,
   which you can use in your checks. They are located under `/usr/local/nmsysclient/opt/nagios/`.

* **nmSys Common Checks** - nmSys's own [common checks](#62state-based-checks)
  are useful building blocks for your own scripts. They are located under `/usr/local/nmsysclient/opt/common/`.

* **nmSys other Checks** - nmSys's extra checks. These are check added over the years, feel free to improve them and reuse them.
    They are located in various directories in `/usr/local/nmsysclient/opt/`.


#### 6.2.3.Registering Check Scripts

To configure nmSys to manage your script, add a config file under `/usr/local/nmsysclient/conf.d/`.
You can add as many config files as you want. The name of your configuration
file must have the pattern `\d{2}_(application_name).ini`. For example, `03_mysupercheck.ini`.

After adding or changing configuration files, you must restart the nmSys client.

{% note info Important %}
- Do not use the prefix `00_`, as it is restricted.
- Do not edit `00_common.ini`.

Instead of editing files that you don't own, you can override their behavior as described under [Overriding Configurations](#525overriding-configurations).
{% endnote %}

#### 6.2.4.Configuration File Syntax

The configuration file follows the format:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/yourapp
    servicename: nameThatDisplaysInNmsys
    command: mysupercheck.py
    params: -c 20 -w 10
    run: 60
    occurrence: 5/5

where:

* `path`: the absolute path to your check, not including the script name
* `servicename`: name that displays in nmSys (the alert name)
* `command`: the filename of your script (excluding the path)
* `run`: the interval for running your script in seconds (default: 60); a value
   of 0 disables the check.
* `params` extra parameters for the check
* `occurrence` number of occurence for the state to change (4/5 means 4 bad occurrence out of 5 to set the state to bad - default is OK)

![Overview](images/confd_directory.png)


#### 6.2.5.Overriding Configurations

On restart, the nmSys client reads in its configuration as an ordered list of configuration files.
To modify or disable a check defined in another configuration file, create a new file that has a higher leading index number.

For example, `00_common.ini` contains a configuration block:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/yourapp
    command:  mysupercheck.py
    params: -w 5 -c 10
    run: 60

You could change this named check to use an entirely different script and interval by adding an `99_override.ini` file:

    [NmsysPlugin MyCheckUniqueName]
    path: /usr/local/bin/otherscript
    servicename: nameThatDisplaysInNmsys
    command:  mydifferentsupercheck.py
    params: -w 10 -c 20
    run: 600

You can use the following command to validate the local configuration :

![Overview](images/current_configuration.png)


You can use the following command to validate the server side configuration :

![Overview](images/server_configuration.png)


To see the full configuration `/usr/local/nmsysclient/nmsysclient.py` configuration

#### 6.2.6.Disabling a Check

To disable a check, add an override file that sets `run` to 0:

    [NmsysPlugin MyCheckUniqueName]
    run: 0


#### 6.2.6.Customizing threshold

By default the client comes with [common check](#7common-checks) although you can [override](#625overriding-configurations) the configuration, we don't advise you to do so has they are usually a good fallback for offshore to take care of your hosts.

If you need to create custom checks with specific thresholds, you can either chose to do it via [custom thresholds from Epic](#322custom-thresholds), or by adding [new checks](#621adding-new-nmsys-check-scripts) and/or re-using [existing](#622building-check-scripts).

#### 6.2.7.Important note about adding new checks from the nmSys client

Once you the new script is added, configuration set, the hosts will start reporting the states in the nmSys alert queue.
To provide escalation for these you still have to either add the pattern of your alert name to an existing filter, or create a new filter and add the proper subscription for escalation


### 6.3.Client installation

#### 6.3.1.Within ISO

For ISO, the clients are installed via puppet which takes care pulling from the ISG and/or Epic repos.

You will need to include the following classes :

    ```
	puppet.classes += (
		core::epic::client
		core::nmsys::client
	)
	```

For Epic you will need to configure the IPs and ports per locale and instance

- IP address ranges [documentation](https://pages.github.pie.apple.com/epic/docs-sre/Server/Networks.html)

- Port per instance [documentation](https://github.pie.apple.com/epic/epic-instance/blob/master/auth/instance.ini)

    (For the port we usually ask you to double check with (epic support)[#14support]

Verdad configuration example:

```
module.epic.datanode.server.ip.address = (
    17.172.6.180
    17.172.6.238
    17.172.6.249
    17.172.6.250
    17.172.6.254
    17.172.6.255
    17.172.7.3
    17.172.7.4
    17.172.7.197
    17.172.7.198
    17.172.7.199
    17.172.7.200
)
module.epic.datanode.server.port = 9521
```

For nmSys you need to set the URL endpoints:

- Production:

```
module.nmsys.url_config = "http://nmsysapi.isg.apple.com/nmsys/api/config/%s/"
module.nmsys.url_server = "http://nmsysapi.isg.apple.com/nmsys/api/node/%s/"
module.nmsys.url_update = "http://nmsysapi.isg.apple.com/nmsys/api/api_alert/nmsys/%s/%s/"
```

- QA :

```
module.nmsys.url_config = "http://nmsys.qa.isg.apple.com/nmsys/api/config/%s/"
module.nmsys.url_server = "http://nmsys.qa.isg.apple.com/nmsys/api/node/%s/"
module.nmsys.url_update = "http://nmsys.qa.isg.apple.com/nmsys/api/api_alert/nmsys/%s/%s/"
```

#### 6.3.2.Puppet based environment

If you have a custom puppet environment feel free to re-use and adapt the following manifests/templates to your needs so that it can install and configure the packages :

- Epic

    - [manifest](https://github.pie.apple.com/sre-tools/core-puppet/blob/master/modules/core/manifests/epic/client.pp)

    - [template](https://github.pie.apple.com/sre-tools/core-puppet/blob/master/modules/core/templates/epic/client/epic.cf.verb)

- nmSys

    - [manifest](https://github.pie.apple.com/sre-tools/core-puppet/blob/master/modules/core/manifests/nmsys/client.pp)

    - [template](https://github.pie.apple.com/sre-tools/core-puppet/blob/master/modules/core/templates/nmsys/client/config.ini.verb)


#### 6.3.3.Other solutions

You can always download the packages from our internal repo :

- [stable](https://epic.isg.apple.com/repo/stable/)

- [alpha](https://artifacts.apple.com/iso-yum-local/EL6/epic/alpha/x86_64/)



## 7.Common checks


The common checks serve as a fallback to provide basic host monitoring.
You can enhance this monitoring by either add your own host based checks or your custom thresholds.
The common checks are prepended with special keywords which cannot be reused :

- default@
- common@
- nmsys@


### 7.1.Metric based checks


These checks rely on the Epic client running on your hosts, they will be processed by Epic's ALERT daemon server side
and then pushed to the nmSys server's queue. These cannot be overwritten (see [github raw config](https://github.pie.apple.com/epic/epic-common/blob/master/conf/db/node/linux/db.alerts.linux))


#### 7.1.1.Reachable

- Alert name: default@reachable-eapi

    Definition:
    ```
        Host unreachable for > 5 min and not publishing stats: CRITICAL (Host is down)
        Host unreachable but publishing stats: INFO (Connectivity should be investigated)
        Host not reachable for 7 occurences out of 15 attempts but not publishing stats: WARNING (Network issue)
    ```

#### 7.1.2.CPU / Memory / Disk usage

- Alert name: common@cpu_utilization

    Definition:
    ```
        CPU Total usage is above 95%: CRITICAL
        CPU Total usage is between 90% and 95%: WARNING
        CPU Total usage below 90%: OK    
    ```
- Alert name: common@memory_utilization

    Definition:
    ```
        Remaining memory available less than 1GB and memory usage > 97%: CRITICAL
        Memory usage > 97%: WARNING
        Memory usage < 97%: OK
    ```

- Alert name: common@disk_utilization (Only monitors /, /tmp, /var, /usr if applicable)

    Definition:
    ```
        Disk usage > 95%: CRITICAL
        Disk usage between 90% and 95%: WARNING
        Disk usage below 90%: OK
    ```
#### 7.1.3.NTP

- Alert name: common@ntp_availability

    Definition:
    ```
        no ntp servers available OR ntp servers unreachable OR ntpq not responding: CRITICAL
        only 1 ntp server available OR ntpd receiving to few valid responses: WARNING
        1 or more ntp servers available AND able to reach ntp servers: OK
    ```
- Alert name: common@ntp_drift

    Definition:
    ```
        ntp drift above 3s: CRITICAL
        ntp drift between 1 and 3s: WARNING
        ntp drift within a second: OK    
    ```

### 7.2.State based checks

These checks run either from the latest Epic client package which embeds the nmSys client code, or from the nmSys client package.

They will run client (host) side and be published straight into nmSys server's alert queue.

#### 7.2.1.Load,  Memory / Disk / usage


- Alert name: nmsys@load_utilization

    Definition:
    ```
        Load above 10 (divided by  number of cores): CRITICAL
        Load above 5 (divided by number of cores): WARNING
        Load below 5: OK
    ```
    Link : [check_load.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_load.py)

- Alert name: nmsys@memory_utilization

    Definition:
    ```
        Memory usage above 99 AND amount of memory left below 512MB: CRITICAL
        Memory usage above 98 WARNING
        Memory usage below 98% OK
    ```
    Link : [check_memory_utilization.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_memory_utilization.py)

- Alert name: nmsys@disk_utilization

    Definition:
    ```
    Space left on disk < 97% OR iNodes left < 97%: CRITICAL
    Space left on disk < 94% OR iNodes left < 94%: CRITICAL
    Spave left > 94% AND iNodes left > 94%: OK
    ```

    Mount filters:
    ```
    Linux: ext[2,3,4]|xfs
    SunOs: all except nfs
    Darwin: / and /Volumes/Server

    (Except the following application mounts: ^/(blob|media|snapshot|cassandra|hadoop|apps|rrd|data|mnt)|^/dev/shm$|^devfs$)
    ```
    Link : [check_disk_local.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_disk_local.py)


#### 7.2.2.Swap / Ulimit

- Alert name: nmsys@swap

    Definition:
    ```
    Make sure the Swap usage > 1% and actively swapping
    Otherwise : OK
    ```
    Link : [check_swap.ksh](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_swap.ksh)

#### 7.2.3.Filesystem / Mounts

- Alert name: nmsys@filesystem

    Definition:
    ```
    NFS Mounts in fstab readonly when mounter as RW : CRITICAL
    Root is read only : CRITICAL
    Otherwise : OK
    ```
    Link : [check_filesystem.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_filesystem.py)

- Alert name nmsys@mounts

    Definition:
    ```
    * Missing mounts in fstab (manually mounted) : CRITICAL
    * Mounts in fstab not mounted : CRITICAL
    * Mounts are mounted multiple times : WARNING
    * Otherwise OK
    ```
    Link : [check_mounts.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_mounts.py)

#### 7.2.4.Mailq / Network / Puppet / Processes

- Alert name: nmsys@mailq

    Definition:
    ```
    Mail in queue > 20: CRITICAL
    Mail in queue > 10: WARNING
    Mail in queue < 10: OK
    ```
    Link : [check_mailq.pl](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_mailq.pl)

- Alert name: nmsys@network

    Definition:
    ```
    Test ssh connectivity via check_ssh to 127.0.0.1 CRITICAL if unable to connect
    ```
    Link : [check_network.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_network.py)

- Alert name: nmsys@puppet

    Definition:
    ```
    Puppet yaml summary reports any error : CRITICAL
    Puppet lock file older than 30minutes : CRITICAL
    Otherwise: OK
    ```
    Link : [check_puppet_run.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_puppet_run.py)

- Alert name: nmsys@processes

    Definition:
    ```
    * crond is running (at least 1 process) and not piling up number < 50
    * snmpd is not piling up if running
    * routed is not running
    * ntpd or chronyd is running
    ```
    Link : [check_running_process.py](https://github.pie.apple.com/epic/nmsys-client/blob/master/nmsysclient/opt/common/check_running_process.py)



## 8.Plugins

Plugins are specific class in the nmSys client which either run checks and/or publish specific metrics for various applications.

These can be enabled via configuration files on the hosts, or via the Plugin page in the nmSys UI.

### 8.1.Remote configuration

Plugins can be enabled via the Plugin wizard in the nmSys UI. It gives you the flexibility to configure your checks to run/Plugin to publish metrics from the UI.

![Overview](images/client_plugin.png)

Simply pick the plugin you need, configure as you would in [Plugin configurations](82plugin-configurations)

### 8.2.Plugin configurations

The plugins can be configured either by [Remote Configuration](#81remote-configuration), or by [simple ini files](#623registering-check-scripts)

Below are the available options and configuration examples for each of them.

#### 8.2.1.ApacheLog

This plugin will stat in Epic the metrics extracted from
the Apache Log file. It will count the number of occurrence
of any given match. To use it, simply Enable
this plugin by putting a configuration file in conf.d/
    [ApacheLogPlugin apachefront]
    pattern=.*\s500\s.*
    name=trend_500_pageresult

#### 8.2.2.Apache

This plugin will stat in Epic the metrics extracted from
the Apache server-status pager. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ApachePlugin apachefront]
    source=http://127.0.0.1/server-status
    name=trend_500_pageresult

Options:
    source: Url to the Apache status page
Defaults:
    source: http://127.0.0.1/server-status

Requirements:

    ExtendedStatus On
     <Location /server-status>
         SetHandler server-status
         Order deny,allow
         Deny from all
         Allow from 127.0.0.1
     </Location>

#### 8.2.3.Docker (not yet supported)

 This plugin will stat in Epic the metrics extracted from
the hDocker API. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [DockerPlugin]

#### 8.2.4.Elasticsearch

This plugin will stat in Epic the metrics extracted from
the health API call of Elasticsearch Server. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ElasticsearchPlugin myES]
    source=http://es-server.apple.com:9200


#### 8.2.5.Haproxy

This plugin will stat in Epic the metrics extracted from
the Haproxy stats API. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [HaproxyPlugin myES]
    source=http://es-server.apple.com:9200


#### 8.2.6.Jenkins

This plugin will stat in Epic the metrics extracted from
the Jenkins API. Extracting build duration and build status.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [JenkinsPlugin]
    source: https://cibuild.isg.apple.com/
    auth:true
    user: secretuser
    password: secretpass
    filter=epic-ui.*

Options:

    source: URL of the junkins API
    auth:       Auth is enabled (True|False)
    user:       Username for auth
    password:   Password for auth
    filter: Filter the project you want to trend

Defaults:

    source: https://cibuild.isg.apple.com/
    auth:   False
    user:  None
    password: None
    filter: None

#### 8.2.7.Memcached

 This plugin will stat in Epic the metrics extracted from
the Memcached stats command.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MemcachedPlugin]
    host: 127.0.0.1
    port: 11211

Options:

    host: Hostname / IP of the memcached server
    port: memcached port

Defaults:

    host: 127.0.0.1
    port:   11211



#### 8.2.8.Mongodb

This plugin will stat in Epic the metrics extracted from
the Mongodb stats command.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MongodbPlugin]
    host: 127.0.0.1
    port: 11211
    username: monitor
    password: nopass
    database: mainDB

Options:

    host: Hostname / IP of the mongodb server
    port: mongodb port
    user:       Username for auth
    password:   Password for auth
    database: Database you need extra metrics about

Defaults:

    host: 127.0.0.1
    port: 27017
    username: None
    password: None
    database: None

#### 8.2.9.Mysql

 This plugin will stat in Epic the metrics extracted from
the Mysql stats commands.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MysqlPlugin myapp]
    host: 127.0.0.1
    port: 3306
    username: monitor
    password: nopass
    type: advanced
    extra: replication

Options:

    host: Hostname / IP of the Mysql server
    port: Mysql port
    user:       Username for auth
    password:   Password for auth
    type: Type of metrics to be extracted (normal|extended) see NORMAL_METRIC_TYPES vs EXTENDED_METRIC_TYPES
    extra: Extra details based on your mysql configuration (replication|xtradb)

Defaults:

    host: 127.0.0.1
    port: 3306
    username: ***
    password: ***
    type: normal
    extra: None
Requirements:

    GRANT select, replication client, show databases, super, process ON *.* \
        TO '***'@'localhost' IDENTIFIED BY '***';
    GRANT select, replication client, show databases, super, process ON *.* \
        TO '***'@'%' IDENTIFIED BY '***’;

#### 8.2.10.Nginx

This plugin will stat in Epic the metrics extracted from
the Nginx nginx_status page or the Status page for Nginx Plus.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [NginxPlugin]
    source=http://127.0.0.1/server-status

Options:

    source: Url to the Nginx status page

Defaults:

    source: http://127.0.0.1:8080/nginx_status

Requirements:

    server {
        listen 8080 default_server backlog=1024;
        location /nginx_status {
            stub_status on;
            access_log off;
            deny all;
            allow 127.0.0.1;
        }
    }

For NginxPlus:

    server {
        listen 8080 default_server backlog=1024;
        location /status {
            root   /usr/share/nginx/html;
            access_log off;
            status;
            deny all;
            allow 127.0.0.1;
        }
    }


#### 8.2.11.NmsysClient

This plugin will stat in Epic the metrics of the nmSys client memory
and thread count footprint (mostly for debug). Can be used for other processes.
To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [NmsysClient]
    name: nmsysclient
    pid: 1200

Options:

    name: Name of the process you want to monitor
    pid: Pid of the process

Defaults:

    name: nmsysclient
    pid: self.pid()

#### 8.2.12.Nmsys

This plugin will:

    * Execute any nmSys checks and report the Status to nmSys server
    * Stat in Epic the runtime metrics (status, duration)

To use it, simply Enable this plugin by putting a configuration file in conf.d/

    [NmsysPlugin Mycheck]
    action: nagios
    servicename: my_check
    command: check_disk
    params:
    run: 240

Options:

    name: Name of the process you want to monitor
    pid: Pid of the process

Defaults:

    name: nmsysclient
    pid: self.pid()



#### 8.2.13.Parser

This plugin will stat in Epic the metrics extracted from
any Log file. It will count the number of occurence
of any given match. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ParserPlugin search]
    pattern=.*\sERROR\s.*
    name=trend_error_result

#### 8.2.14.Postgresql

This plugin will stat in Epic the metrics extracted from
the Postgres stats commands.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [PostgresqlPlugin myapp]
    host: 127.0.0.1
    port: 5432
    username: monitor
    password: nopass

Options:

    host: Hostname / IP of the Postgresql server
    port: Postgresql port
    user:       Username for auth
    password:   Password for auth

Defaults:

    host: 127.0.0.1
    port: 5432
    username: ***
    password: ***

Requirements:
    CREATE USER statsRO with password '***';
    GRANT SELECT ON pg_stat_database TO '***';


#### 8.2.15.Puppet

This plugin will stat in Epic the metrics extracted from
last_summary_run.yaml of puppet. It does not replace the
common check (check_puppet_run.py). It is mostly used to track
the catalog compilation and status based on Puppet main branch commit and changes.
If you need to track your master/dev branches of your puppet servers, simply Enable
this plugin by putting a configuration file in conf.d/

    [PuppetPlugin Master]
    puppetrun_file=/var/lib/puppet/state/last_run_summary.yaml

Options:

    puppetrun_file: Location of the last Run summary

Defaults:

    puppetrun_file: /var/lib/puppet/state/last_run_summary.yaml



#### 8.2.16.Rabbitmq

This plugin will stat in Epic the metrics extracted from
the stats API call of Rabbitmq . To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [RabbitmqPlugin]
    user: secretuser
    password: secretpass
    source: http://localhost:55672/api/overview

Requirements:

    Ensure you have a monitoring user configured

Options:

    source:     URL to the Rabbitmq Overview page
    auth:       Auth is enabled (True|False)
    user:       Username for auth
    password:   Password for auth
    proxy: List of proxy to monitor
    all: stat them all
    type: Type of metrics to be extracted (default|extended) see NORMAL_METRIC_TYPES vs EXTENDED_METRIC_TYPES

Defaults:

    source:    http://localhost:6610/stats;csv
    auth:   False
    user:  None
    password: None
    proxy: ['frontend', 'backend']
    ignore: None
    all: False
    type: default


#### 8.2.17.Redis

This plugin will stat in Epic the metrics extracted from Redis.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [RedisPlugin]
    host=127.0.0.1
    port=6379

Options:

    host: redis servert IP or DNS
    port: redis server port

Defaults:

    host: 127.0.0.1
    port 6379



## 9.nmSys UI walk-through

nmSys links are composed of 3 main menus :

![Overview](images/main_menu.png)


- Main `This is where you will find everything related to you or your context`

- Search `This is where you will search for every resource in nmSys (context agnostic)`

- {username} `This is where you will preform actions : change context / create new filters / add new groups ...)`



### 9.1.Main menu

In the Main page, the Context set (top right corner menu) will impact the results of the sub menus.

#### 9.1.1.Subscription sub menu

- Context set to your username : sub-menus will default to display `ALL` the subscriptions related to your username AND all the groups you are part of.
- Context set to a group: sub-menus will filter only on the subscription/notifications for this group name.

![Overview](images/subscription_main.png)


See [filter resource](./api_resource_filter.md#search_q-parameter) for details about the search bar and the allowed filters.



#### 9.1.2.Notification sub menu


- Context set to your username : sub-menus will default to display `ALL` the notifications related to your username AND all the groups you are part of.
- Context set to a group: sub-menus will filter only on the subscription/notifications for this group name.

![Overview](images/subscription_main.png)


#### 9.1.3 API

nmSys is built on rest APIs, to allow access you will be required to use an API key. This key is tied to your username, do not share it with anyone.

Every change is logged and tracked based on your user ID,


### 9.2.Search

#### 9.2.1.Search Alerts

![Overview](images/search_alert.png)


#### 9.2.2.Search For existing filters/custom thresholds

![Overview](images/search_filter_e.png)


#### 9.2.3.Search notifications sent

![Overview](images/search_notification.png)


#### 9.2.4.Search node details

![Overview](images/search_node.png)


### 9.3.Extra views

#### 9.3.1.Filter details view

![FilterView](images/filter_view.png)


#### 9.3.1.Node details view

![NodeView](images/node_view.png)


#### 9.3.2.Wizards

#### 9.3.2.1.Create custom thresholds

- Via the Epic dashboards / UI:

All graphs in Epic feature a specific link/button to create alerts, which will allow you to quickly pre-fill the Custom threshold wizard

![NodeView](images/alert_creation_epic_UI.png)

Simply find/build the graph you are interested and click on create alert.

- Via graph URL  :

You can simply copy paste the URL from an Epic graph in the URL

![NodeView](images/copy_epic_graph.png)


#### 9.4.Subscriptions

To subscribe to an existing filter, first do a [search on a filter](https://nmsys.isg.apple.com/nmsys/alerting/search/filter/)

The proceed to the subscription form.

If a subscription already exists for this filter under one of the group you are part of, nmSys will let you know in the header otherwise will simply create a new subscription under the chosen context.


#### 9.4.1.Notification Routes

nmSys allows you to create one notification route per subscription. The route chosen has different set of configuration but a single way to handle the escalation.

You are required to configuration a primary escalation contact which will be used by default if a specific severity contact is not specified.

- Primary :

![Primary](images/primary_contact.png)


- Severity specific contact :

![Severity](images/severity_contact.png)


- You can always chose which severity requires to be escalated :

![Severity](images/severity_escalation.png)

- Digesting

By default nmSys will try to digest your notification to reduce the noise. This means that only one notification will be sent per severity if multiple alerts occurred within the same notification time period.
Of course this behavior might not be wanted for CentralStation / Espresso tickets since the issues will be rolled into a single ticket which might imply some extra work for the SRE team in charge to separate them back.

Note that even if you disable digestion, there is a fallback for every subscription when more than 250 tickets are about to be created at the same time, nmSys will prevent creating so many notification and will digest to prevent flood of tickets during large outages.

![Severity](images/digested_notification.png)

- Duration before notification / Resend after

    * Duration before notification : Allow a delayed notification (notification status has to remain with the same status for the entire period to send a notification. Set it to a minimum of 6 minutes to bypass Epic's flapping detection

    * Resend after : Resend a notification after the given period of time. Espresso is enforced to 1day (1440 minutes)

![Severity](images/duration_resend.png)

- Callback

Set nmSys to publish a Notification summary after escalation (http API) see documentation for details about the object

![Severity](images/callback.png)

- Ratio

Only escalate when a ratio of OK vs Bad is matching (percentage of bad per filter). Can be used when wrapping up Service monitoring around multiple vip or multiple members of a vip.

![Severity](images/ratio.png)


#### 9.4.1.1.Email

Sends basic emails with both HTML and Text content, epic graph (if applicable) and extra details for your filter.

The sender will be nmsys-notification@group.apple.com

Subject will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pager Notification](images/email_notification.png)


#### 9.4.1.2.Pagerduty (Use email for now)

Send email to the pagerduty mailing service (not the HTTP API yet), uses a specific minimalist template to allow proper formating in the pagerduty UI


The sender will be nmsys-notification@group.apple.com

Subject will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pagerduty Notification](images/pagerduty_subscription.png)


#### 9.4.1.3.Centralstation

Create CentralStation ticket via the API only if it does not find an existing opened ticket for the same issue.

Title will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pager Notification](images/centralstation_subscription.png)

![Pager Notification](images/centralstation_notification.png)



#### 9.4.1.4.Pager

Send email to the pager service of your celular provider follow the specific formatting

![Pager Subscription](images/pager_subscription.png)


e.g ATT :

    {phonenumber}@txt.att.net
    {phonenumer}@mms.att.net)

![Pager Notification](images/pager_notification.png)


#### 9.4.1.5.HTTP POST

Post a JSON object with the content you would expect in an email:
```
{
   "name" : "gns-dc-external@failed_powersupply1_arista",
   "notification" : [],
   "id" : "659c51e3-81f0-4d0e-afbf-af2d41d43000",
   "content" : [
      {
         "uri" : "/nmsys/api/rest/v2/alert/ausyd2-130-09-01-map1-edg-gw1.apple.com__gns-dc-external@failed_powersupply1_arista_mr11_gnsnet/",
         "type_action" : "unack",
         "silence" : 1513037627,
         "u_ctime" : 1512328260,
         "comment" : "No Specific Message - contact user",
         "instance" : "gnsnet",
         "description" : "arista failed powersupply\\n\\n   Expr:  entStateOper.powersupply1 ! 3\\n   Value: 2 ! 3\\n\\n",
         "u_ptime" : 1512328650,
         "timestamp" : 1515441080,
         "time_ack" : 1513037628,
         "u_mtime" : 1515440100,
         "status" : "CRITICAL",
         "user" : "kbajaj",
         "alert" : "gns-dc-external@failed_powersupply1_arista",
         "node" : "ausyd2-130-09-01-map1-edg-gw1.apple.com",
         "ack" : 0,
         "ng" : "",
         "state" : 5,
         "locale" : "mr11"
      }
   ],
   "route" : "http",
   "documentation" : "",
   "description" : "arista failed powersupply\n3 = good\nNot 3 = bad\noid values\nunknown(1)\ndisabled(2)\nenabled(3) \ntesting(4)  ",
   "u_ctime" : 1515442179000,
   "stats" : {
      "ratio" : 0,
      "OK" : 4921,
      "Acknowledged" : 44,
      "CRITICAL" : 1
   },
   "subscriber" : "rfoucher"
}
```

## 10.API

nmSys provides a RESTful API to access almost any features that it provides.

### 10.1.Base endpoints

Production :

    ```http
        https://nmsys.isg.apple.com
    ```
QA:
    ```http
        https://nmsys.qa.isg.apple.com
    ```

### 10.2.Base path

The base PATH is:

```http
/nmsys/api/rest/v2/{resource}/[{id}/]?oauth_consumer_key={apikey}
```

Calls to `/nmsys//api/rest/v2/{resource}/` act on lists, while calls to `nmsys//api/rest/v2/{resource}/{id}` operate on individual objects.

### 10.3.Resources

The types of resources you can operate on are:

* `alert`
* `filter`
* `ack`
* `notification`

{% note info %}
To make API calls, you must pass an API key into requests. To get a key, select **API** in the main dashboard. If you don't have a key yet,
you can generate one from the UI. If your key is missing, nmSys responds with `401 Unauthorized`.
{% endnote %}

### 10.4.Allowed methods

* `POST`: Create a resource
* `GET`: Read an existing resource
* `PUT`: Update an existing resource
* `DELETE`: Delete an existing resource
* `PATCH`: Update multiple resources

### 10.5.HTTP Status Codes

* 200 OK : Success
     * GET - Return resource
     * PUT - Provide status or return resource
* 201 Created : Success
     * POST - Provide status or return resource
* 204 : Success
     * DELETE
* 400 Bad Request : Failure
     * PUT, POST - Return error messages, including form validation errors.
* 401 Unauthorized : Failure
     * Credential are required
* 403 Forbidden : Failure
     * You don't have privileges for this resource. Please create a request for the specific resource.
* 404 Not found : Failure
     * See the list of existing resource
* 405 Method Not Allowed : Failure
     * We don't support everything yet, please open a Radar.

### 10.6.Common Query Parameters

* `format`

Selects an alternative format.  By default, the API returns JSON. You can change
the format by setting a `format` query parameter to:

    * json
    * html (the actual HTML used by the nmSys web UI)


* `limit`

Specifies the maximum number of results to return for a list or search call. The
default is 500.

* `search_q`

Allow you to filter the result via key/value pairs. See [query parameter per resource](#Resources) for more details.

* `sort_by`

Allow you to sort the results by specific keys (to reverse order prepend the key with '-')

### 10.7.Authentication

To access the resources you must add as a get parameter your OAUTH token.

{% note info %}
`oauth_consumer_key` is required to fetch any data.
{% endnote %}


### 10.8.Alert resource details :

 See [Alert resource schema and filtering](./api_resource_alert.md)

### 10.9.Filter and Subscription resource details :

 See [Filter resource schema and filtering](./api_resource_filter.md)


## 11.GITHUB Backup Repo

### 11.1.Locations

Production
    ```
    https://github.pie.apple.com/epic/nmsys-alert-repo-production.git
    ```

QA
    ```
    https://github.pie.apple.com/epic/nmsys-alert-repo-QA.git
    ```
### 11.2.


## 12.Debug/Tips

### 12.1.UNKNOWN State for custom threshold

    Also referred as "state implicitly set to unknown (2): no rules matched"
![Overview](images/unknown_example.png)

Epic uses UNKNOWN state as a fallback when no rule matches and set the description to the above to notify of an issue which requires attention.

To debug the issue follow these simple steps :

    * In the filter definition, check your threshold and make sure that the metric exists
    * In the filter definition, make sure you don't have any gap in your comparizon
    * Make sure you have a proper default value for OK (even 1=1 is fine)
    * For the node in the alert, open Epic and makge sure the host is not Down
        (when the node is not publishing metric, the default value is NULL hence not matching  usual number ranges FYI you can add a specifif rull for ds=NULL if you want)
    * For the node in the alert, open Epic UI and visually validate that the metric is populated (you can replace a=graph to a=json to check the actual values)
    * For the node in the alert, verify that during the teimperiod the host was reachable in the latency tab
    * For the node in the alert, make sure the time is right on the host (NTP alerts) if the host is publishing with the wrong time, the metrics will be populated as is and alerting will be impacted

If the issue still exists, contact Epic SRE in order to validate :

    * Epic health of the cluster, check for any delay in the report/alert daemon
    * Check if the metric is polled :
        - Make sure you can still poll the host :
            * make sure there's no ACL issue
            * make sure there's no Community issue
            Run snmpwalk with proper community from the pollers, and check some other datasources
        - Make sure the pollers are healthy and not overloaded (latency in polling will cause NULL values)

If the issue still exists, contact Epic Admin in order to proceed with application debug.


### 12.2.Advanced custom thresholds

#### 12.2.1.Alert on deviation over period of time

For a 30% reduced change from 5 minutes ago:

	datasource	<	datasource,0.70,\*:shift=-4min

For a 30% increased change from 5 minutes ago:

	datasource	>	datasource,1.30,\*:shift=-4min


* note it's -4min ( minute 4 minutes ) for 5 minutes ago ... time shifts in 60second increments for min, so 0min is now, -4min is 5 minutes ago ( now + the 4 minutes previous )

* you can notate any minute values, these are the time notations:

| abrev | full |
| --- | --- |
| m | min |
| d | day |
| w | week |
| m | month |
| y | year |

![Overview](images/deviation_period_of_time.png)


#### 12.2.2.Alert on the top average of multiple datasources over a period of time


Find the highest average of datasource[1-3] and datasource regex for the past 10min and make sure it's below 80

    datasource1!datasource2!datasource3!datasource4!datasourceregex.\*&f=10min&order=avg:desc&limit=1 < 80


![Overview](images/top_average_period_of_time.png)




## 13.SRE daily activities



### 13.1.Acknowledging and silencing alerts.

When performing maintenance, or for known issues, you might need to act or react to issues by silencing or acknowledging issues.

The difference between the two:

* silence is tied to a time period, the alert will not trigger any notification during the silencing period.

        Once silence period expires, notification process will restore for the given alert

* acknowledgment is tied to a specific state, the alert will not trigger any notification as long as the state remain the same

        Once the state changes (for a better or for a worst state, the acknowledgement flag will reset, notification process will restore for the given alert

#### 13.1.1 Silence/Acknowledgement pre-filtering

![Overview](images/ack_silence_menu.png)


#### 13.1.1 Silence/Acknowledgement Wizard

![Overview](images/ack_silence_action.png)


#### 13.1.2 Remove Silence/Acknowledgement pre-filtering and wizard

![Overview](images/all_remove_ack.png)



### 13.2.Manage acknowledgement and silence from teh various views

The silence and acknowledgements are tied to the specific alert, you need to acknowledge per alert.
If you need to acknowledge hosts/list of alerts, multiple alerts of a filter, make sure you follow the steps below.


#### 13.2.1.Acknowledge/Silence for a Host/node

First [search for the node](#824search-node-details) and click on the hostname to land on the [node view](#831node-details-view).

And proceed with the [generic Silence/Acknowledgement](1311-silenceacknowledgement-pre-filtering)





#### 13.2.2.Acknowledge/Silence multiple alerts

Proceed with the [generic Silence/Acknowledgement](1311-silenceacknowledgement-pre-filtering)


#### 13.2.3.Acknowledge/Silence alerts in a Filter


And proceed with the [generic Silence/Acknowledgement](1311-silenceacknowledgement-pre-filtering)


#### 13.2.4.Find Acknowledged/Silenced alerts

See [Remove Silence/Acknowledgement pre-filtering and wizard](1311-silenceacknowledgement-pre-filtering)


### 13.3.Enable/Disable subscriptions





### 13.4.Manage acknowledgement and silence via the nmsys-cli.py script

You will find the nmsys-cli.py script in the API tab in of the Main page [download the source](https://nmsys.isg.apple.com/nmsys/alerting/nmsys-cli.py). You can simply click the link and copy paste the content to your local computer.

The script contains a secret key which is tied to your username, so do not share it with anyone.

The script can be used to search/silence/ack any alert.


```
python nmsys-cli.py  -h
Usage: nmsys-cli.py <command> [command-options]
```

---

#### 13.4.1.Search alerts

```
python nmsys-cli.py status --help

nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com
    # check status of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py status --node nk11a00is-noname001.isg.apple.com --alert "Standard Services"
    # check status for Standard Services on nk11a00is-noname001.isg.apple.com

nmsys-cli.py status --node nk11a00is.* -S CRITICAL,WARNING
    # list status for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py status -r 1901 -S CRITICAL,WARNING -a 1
    # list all alert for the Alert 1901 that are CRITICAL or WARNING AND already acknowledged

```


#### 13.4.2.Acknowledge alerts

```
nmsys-cli.py ack --node nk11a00is-noname001.isg.apple.com --comment="Disaster recovery on all services."
    # ack alerts of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py ack --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi"
    # ack alerts "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py ack --node nk11a00is.* -S CRITICAL,WARNING
    # ack alerts for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py ack -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING
    # ack all alerts for the filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING

```

#### 13.4.3.Cancel acknowledgment on alerts
```
nmsys-cli.py cancel-ack --node nk11a00is-noname001.isg.apple.com --comment="Disaster recovery on all services."
    # cancel-ack alerts of all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-ack --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi"
    # cancel-ack alerts "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-ack --node nk11a00is.* -S CRITICAL,WARNING
    # cancel-ack alerts for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py cancel-ack -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING
    # cancel-ack all alerts for the filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```

#### 13.4.4.Silence alerts


```
nmsys-cli.py silence --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
    # silence for 2 days for  all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py silence --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi" -d 1h
    # silence for 1 hour alert "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py silence --node nk11a00is.* -S CRITICAL,WARNING -d 1h
    # silence for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py silence --tag ~verdad.tag=.*nmsys -S CRITICAL,WARNING -d 1h
    # silence for 1h for all hosts matching tag .*nmsys with status CRITICAL OR WARNING

 nmsys-cli.py silence -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING -d 1d
    # silence for 1 day on all alerts for the Filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```
#### 13.4.5.Cancel silence on alerts

```
nmsys-cli.py cancel-silence --node nk11a00is-noname001.isg.apple.com -d 2d --comment="Disaster recovery on all services."
    # cancel-silence for 2 days for  all services for nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-silence --node nk11a00is-noname001.isg.apple.com --alert "nmsys@check_ipmi" -d 1h
    # cancel-silence for 1 hour alert "nmsys@check_ipmi" on nk11a00is-noname001.isg.apple.com

nmsys-cli.py cancel-silence --node nk11a00is.* -S CRITICAL,WARNING -d 1h
    # cancel-silence for all hosts matching regex nk11a00is.* with status CRITICAL OR WARNING

 nmsys-cli.py cancel-silence --tag ~verdad.tag=.*nmsys -S CRITICAL,WARNING -d 1h
    # cancel-silence for 1h for all hosts matching tag .*nmsys with status CRITICAL OR WARNING

 nmsys-cli.py cancel-silence -r 09302015-6811-32d5-9190-bd0258709ess -S CRITICAL,WARNING -d 1d
    # cancel-silence for 1 day on all alerts for the Filter 09302015-6811-32d5-9190-bd0258709ess that are CRITICAL or WARNING
```


## 14.Support

ISO Platform Analytics

Contact the support:

    - Email : epic-admin@group.apple.com
    - Pagerduty : epic@isga.pagerduty.com
    - HIPCHAT : hipchat://hip.apple.com/chat/room/epic-support

Contact the developers:

    - Email : epic-dev@group.apple.com
    - Pagerduty :
        Epic :epic-oncall@group.apple.com
        Alerting : nmsys-oncall@sre-oncall.pagerduty.com
    - Radar Component rdar://new/problem/component=ISG%20Epic&version=New%20Requests
