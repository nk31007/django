title: Metric based Checks
name: alert_metric_checks
---

These checks rely on the Epic client running on your hosts, they will be processed by Epic's ALERT daemon server side
and then pushed to the nmSys server's queue. These cannot be overwritten (see [github raw config](https://github.pie.apple.com/epic/epic-common/blob/master/conf/db/node/linux/db.alerts.linux))

#### Reachable

- Alert name: default@reachable-eapi

    Definition:
    ```
        Host unreachable for > 5 min and not publishing stats: CRITICAL (Host is down)
        Host unreachable but publishing stats: INFO (Connectivity should be investigated)
        Host not reachable for 7 occurences out of 15 attempts but not publishing stats: WARNING (Network issue)
    ```

#### CPU

- Alert name: common@cpu_utilization

    Definition:
    ```
        CPU Total usage is above 95%: CRITICAL
        CPU Total usage is between 90% and 95%: WARNING
        CPU Total usage below 90%: OK    
    ```

#### Memory

- Alert name: common@memory_utilization

    Definition:
    ```
        Remaining memory available less than 1GB and memory usage > 97%: CRITICAL
        Memory usage > 97%: WARNING
        Memory usage < 97%: OK
    ```

#### Disk usage

- Alert name: common@disk_utilization (Only monitors /, /tmp, /var, /usr if applicable)

    Definition:
    ```
        Disk usage > 95%: CRITICAL
        Disk usage between 90% and 95%: WARNING
        Disk usage below 90%: OK
    ```
#### NTP

- Alert name: common@ntp_availability

    Definition:
    ```
        no ntp servers available OR ntp servers unreachable OR ntpq not responding: CRITICAL
        only 1 ntp server available OR ntpd receiving to few valid responses: WARNING
        1 or more ntp servers available AND able to reach ntp servers: OK
    ```
- Alert name: common@ntp_drift

    Definition:
    ```
        ntp drift above 3s: CRITICAL
        ntp drift between 1 and 3s: WARNING
        ntp drift within a second: OK    
    ```
