title: Subscriptions
name: alert_ui_subscriptions
---

To subscribe to an existing filter, first do a [search on a filter](https://nmsys.isg.apple.com/nmsys/alerting/search/filter/)

The proceed to the subscription form.

If a subscription already exists for this filter under one of the group you are part of, nmSys will let you know in the header otherwise will simply create a new subscription under the chosen context.

#### Notification Routes

nmSys allows you to create one notification route per subscription. The route chosen has different set of configuration but a single way to handle the escalation.

You are required to configuration a primary escalation contact which will be used by default if a specific severity contact is not specified.

- Primary :

![Primary](images/primary_contact.png)


- Severity specific contact :

![Severity](images/severity_contact.png)


- You can always chose which severity requires to be escalated :

![Severity](images/severity_escalation.png)

- Digesting

By default nmSys will try to digest your notification to reduce the noise. This means that only one notification will be sent per severity if multiple alerts occurred within the same notification time period.
Of course this behavior might not be wanted for CentralStation / Espresso tickets since the issues will be rolled into a single ticket which might imply some extra work for the SRE team in charge to separate them back.

Note that even if you disable digestion, there is a fallback for every subscription when more than 250 tickets are about to be created at the same time, nmSys will prevent creating so many notification and will digest to prevent flood of tickets during large outages.

![Severity](images/digested_notification.png)

- Duration before notification / Resend after

    * Duration before notification : Allow a delayed notification (notification status has to remain with the same status for the entire period to send a notification. Set it to a minimum of 6 minutes to bypass Epic's flapping detection

    * Resend after : Resend a notification after the given period of time. Espresso is enforced to 1day (1440 minutes)

![Severity](images/duration_resend.png)

- Callback

Set nmSys to publish a Notification summary after escalation (http API) see documentation for details about the object

![Severity](images/callback.png)

- Ratio

Only escalate when a ratio of OK vs Bad is matching (percentage of bad per filter). Can be used when wrapping up Service monitoring around multiple vip or multiple members of a vip.

![Severity](images/ratio.png)


#### Email

Sends basic emails with both HTML and Text content, epic graph (if applicable) and extra details for your filter.

The sender will be nmsys-notification@group.apple.com

Subject will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pager Notification](images/email_notification.png)


#### Pagerduty (Use email for now)

Send email to the pagerduty mailing service (not the HTTP API yet), uses a specific minimalist template to allow proper formating in the pagerduty UI


The sender will be nmsys-notification@group.apple.com

Subject will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pagerduty Notification](images/pagerduty_subscription.png)


#### Centralstation

Create CentralStation ticket via the API only if it does not find an existing opened ticket for the same issue.

Title will be

- digested On {status}: {filter_name}
- digested Off {status}: {filter_name} {node_name}

![Pager Notification](images/centralstation_subscription.png)

![Pager Notification](images/centralstation_notification.png)



#### Pager

Send email to the pager service of your celular provider follow the specific formatting

![Pager Subscription](images/pager_subscription.png)


e.g ATT :

    {phonenumber}@txt.att.net
    {phonenumer}@mms.att.net)

![Pager Notification](images/pager_notification.png)


#### HTTP POST

Post a JSON object with the content you would expect in an email:
```json
{
   "name" : "gns-dc-external@failed_powersupply1_arista",
   "notification" : [],
   "id" : "659c51e3-81f0-4d0e-afbf-af2d41d43000",
   "content" : [
      {
         "uri" : "/nmsys/api/rest/v2/alert/ausyd2-130-09-01-map1-edg-gw1.apple.com__gns-dc-external@failed_powersupply1_arista_mr11_gnsnet/",
         "type_action" : "unack",
         "silence" : 1513037627,
         "u_ctime" : 1512328260,
         "comment" : "No Specific Message - contact user",
         "instance" : "gnsnet",
         "description" : "arista failed powersupply\\n\\n   Expr:  entStateOper.powersupply1 ! 3\\n   Value: 2 ! 3\\n\\n",
         "u_ptime" : 1512328650,
         "timestamp" : 1515441080,
         "time_ack" : 1513037628,
         "u_mtime" : 1515440100,
         "status" : "CRITICAL",
         "user" : "kbajaj",
         "alert" : "gns-dc-external@failed_powersupply1_arista",
         "node" : "ausyd2-130-09-01-map1-edg-gw1.apple.com",
         "ack" : 0,
         "ng" : "",
         "state" : 5,
         "locale" : "mr11"
      }
   ],
   "route" : "http",
   "documentation" : "",
   "description" : "arista failed powersupply\n3 = good\nNot 3 = bad\noid values\nunknown(1)\ndisabled(2)\nenabled(3) \ntesting(4)  ",
   "u_ctime" : 1515442179000,
   "stats" : {
      "ratio" : 0,
      "OK" : 4921,
      "Acknowledged" : 44,
      "CRITICAL" : 1
   },
   "subscriber" : "rfoucher"
}
```
