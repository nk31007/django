title: Bulk Update API
---

## Overview

nmSys provides a Bulk Update API, which is designed to update multiple alerts in
one call with reasonable performance.

The Bulk Update API is at:

```http
http://nmsysapi.isg.apple.com/nmsys/api/api_alert/{application}/{locale}/{instance}/
```
or for testing purposes:

```http
http://nmsys.qa.isg.apple.com/nmsys/api/api_alert/{application}/{locale}/{instance}/
```

* Application : Upon request we will add a new application to allow ingestion

* Locale : Location from where you are publishing (so we can help you debug)

* Instance : Epic instance you are affected to (contact us if you are unsure)



{% note info Note %}
You *must* refresh the status of ALL the alerts you are publishing at least every 30 minutes or they will be deleted from nmSys due to timeout.
{% endnote %}

## Payload Format

The payload of your API call should be a JSON string resembling:

```json
{
    "alert" : {
        "list" : [
            {
                "alert" : "name-source@alert_for_my_app",
                "description" : "Oh no I broke something (description)",
                "node" : "mr11a00is-fakenode001.isg.apple.com",
                "state" : 2,
                "u_ctime" : 1393436040
            },
            {
                "alert" : "name-source@alert_for_my_secondapp",
                "description" : "Oh no I broke something (more description)",
                "node" : "mr11a00is-othernode001.isg.apple.com",
                "state" : 1,
                "u_ctime" : 1391604660
            }
        ]
    }
}
```
If the payload includes blocks with the same combination of alert & node multiple times, then the last block wins.

### Payload Fields

#### `alert`

* Type: String
* Value: A string delimited by a `@`:
  - Left side: identifier for the source of the publication (not an actual ds group). The keywords `common`, `default`, and `nmsys` are reserved.
  - Right side : the alert name
  - Examples: `rad@cpu_usage_cluster_X`, `cassandra@max_file_handlers_cluster_its`, `isilon@quota_usage_home`
* Max Length: 150 chars


#### `description`

* Type: String
* Value: Free form field
* Max Length : 1765 chars

#### `node`

* Type: String
* Value: the node affected by the issue
* Max Length : 150 chars

#### `state`

* Type Integer
* Values :
  - 0:       'DO NOT USE'
  - 1:       'OK'
  - 2:       'UNKNOWN'
  - 3:       'INFO'
  - 4:       'WARNING'
  - 5:       'CRITICAL'
  - 6:       'DO NOT USE'
  - 7:       'DO NOT USE'
  - 8:       'DO NOT USE'
  - 9:       'DO NOT USE'
  - 10:      'AUTO-RESUME ADMINISTRATIVE'
  - 11:      'PERMANENT ADMINISTRATIVE'
  - 12:      'MAINTENANCE'
  - 13:      'DO NOT USE'
  - 14:      'DO NOT USE'
  - 15:      'DO NOT USE'

When you change the alert's state, this also clears the alert's "ack" status, but not its "ack until" status.

#### `u_ctime`

* Type: Integer
* Value: The UNIX timestamp of the actual status change of your alert
{% note info Note %}
The u_ctime is used as a time marker to trigger notification. Make sure it matches the real timestamp of the status change.
{% endnote %}
