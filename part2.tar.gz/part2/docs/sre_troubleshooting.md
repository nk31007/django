title: Troubleshooting
---

## Custom alerts aren't appearing in Epic/nmsys

1. Check if alerts were SILENCED for your host.
2. Confirm the configuration by running the commands:
`sudo /usr/local/nmsysclient/nmsysclient.py configuration && sudo /usr/local/nmsysclient/nmsysclient.py local_status`
3. Confirm that the check appears in the list from `local_status`.
4. Then trigger the auto-refresh with: `sudo /usr/local/nmsysclient/nmsysclient.py sync_remote`

## Alert is in UNKNOWN state

1. Go to alert page in nmsys.
2. Click on definition look at the datasource definition make there’s no gap.
3. If no gap look at the host in epic make sure it’s not DOWN (metrics are NULL when server is Down).
4. Search for the metric named for the given host in UNKNOWN state and check on the value, make sure it exists and has a proper value.
5. Make sure this metric is not polled, if it’s polled, that might be caused by latency in polling (metrics are not ingested fast enough causing some NULL values) - in that case valide the health of the Epic cluster impacted.
  It could also be an ACL, or an improperly configured snmp community, run SNMP walk in that case.
6. If it’s not an issue with pollers, then open a radar against Epic, there’s probably a bug in Epic server alert processing.

## UNKNOWN State for custom threshold

    Also referred as "state implicitly set to unknown (2): no rules matched"
![Overview](images/unknown_example.png)

Epic uses UNKNOWN state as a fallback when no rule matches and set the description to the above to notify of an issue which requires attention.

To debug the issue follow these simple steps :

    * In the filter definition, check your threshold and make sure that the metric exists
    * In the filter definition, make sure you don't have any gap in your comparizon
    * Make sure you have a proper default value for OK (even 1=1 is fine)
    * For the node in the alert, open Epic and makge sure the host is not Down
        (when the node is not publishing metric, the default value is NULL hence not matching  usual number ranges FYI you can add a specifif rull for ds=NULL if you want)
    * For the node in the alert, open Epic UI and visually validate that the metric is populated (you can replace a=graph to a=json to check the actual values)
    * For the node in the alert, verify that during the teimperiod the host was reachable in the latency tab
    * For the node in the alert, make sure the time is right on the host (NTP alerts) if the host is publishing with the wrong time, the metrics will be populated as is and alerting will be impacted

If the issue still exists, contact Epic SRE in order to validate :

    * Epic health of the cluster, check for any delay in the report/alert daemon
    * Check if the metric is polled :
        - Make sure you can still poll the host :
            * make sure there's no ACL issue
            * make sure there's no Community issue
            Run snmpwalk with proper community from the pollers, and check some other datasources
        - Make sure the pollers are healthy and not overloaded (latency in polling will cause NULL values)

If the issue still exists, contact Epic Admin in order to proceed with application debug.


## Advanced custom thresholds

### Alert on deviation over period of time

For a 30% reduced change from 5 minutes ago:

	datasource	<	datasource,0.70,\*:shift=-4min

For a 30% increased change from 5 minutes ago:

	datasource	>	datasource,1.30,\*:shift=-4min


* note it's -4min ( minute 4 minutes ) for 5 minutes ago ... time shifts in 60second increments for min, so 0min is now, -4min is 5 minutes ago ( now + the 4 minutes previous )

* you can notate any minute values, these are the time notations:

| abrev | full |
| --- | --- |
| m | min |
| d | day |
| w | week |
| m | month |
| y | year |

![Overview](images/deviation_period_of_time.png)

## GITHUB Backup Repo

Production
```
https://github.pie.apple.com/epic/nmsys-alert-repo-production.git
```

QA
```
https://github.pie.apple.com/epic/nmsys-alert-repo-QA.git
```


## Decommissionning process

ISO :
From verdad, decommissionning a host requires a verdad delete. Once deleted, the next night at 10PM a discovery job will set the host as deprecated and related alerts/groups will be removed from Epic. nmSys will age the alerts within 6 hours after that.

Non ISO:
Open a Radar against the Epic | GetHelp component, with your list of hosts attached, then notify the Epic SRE team either via [email](mailto:epic-sre@group.apple.com) or via #help-pie-epic on Slack. The SRE team will deprecate the hosts as time allows.
