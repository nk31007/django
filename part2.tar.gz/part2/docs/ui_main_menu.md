title: Main Menu
name: alert_ui_main_menu
---

In the Main page, the Context set (top right corner menu) will impact the results of the sub menus.

#### Subscription sub menu

- Context set to your username : sub-menus will default to display `ALL` the subscriptions related to your username AND all the groups you are part of.
- Context set to a group: sub-menus will filter only on the subscription/notifications for this group name.

![Overview](images/subscription_main.png)


See [filter resource](./api_resource_filter.html#search-q-parameter) for details about the search bar and the allowed filters.


#### Notification sub menu


- Context set to your username : sub-menus will default to display `ALL` the notifications related to your username AND all the groups you are part of.
- Context set to a group: sub-menus will filter only on the subscription/notifications for this group name.

![Overview](images/subscription_main.png)


#### API

nmSys is built on rest APIs, to allow access you will be required to use an API key. This key is tied to your username, do not share it with anyone.

Every change is logged and tracked based on your user ID.
