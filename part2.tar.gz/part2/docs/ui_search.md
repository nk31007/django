title: Search
name: alert_ui_search
---

#### Search Alerts

![Overview](images/search_alert.png)


#### Search For existing filters/custom thresholds

![Overview](images/search_filter_e.png)


#### Search notifications sent

![Overview](images/search_notification.png)


#### Search node details

![Overview](images/search_node.png)
