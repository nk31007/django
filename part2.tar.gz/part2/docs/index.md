title: Notification Manager System (nmSys) Overview
name: alerting
---

nmSys is an alerting system, integrated with Epic. It handles tens of millions
of unique [alerts](./key_objects.html#Alert) that update every minute, and sends tens of
thousands of notifications every day.

nmSys's features include:

- Filtered based escalation with multi-criteria pattern matching
- Threshold alert creation for any Epic metric
- Subscription based escalation
- Default monitoring for all hosts running nmSys-client/epic-client
- Escalation paths supported: CentralStation, Espresso, PagerDuty, Pager, Email
- Export formats: JSON, HTML, CSV, XML, PNG
- Per event escalation triage
- Modular client supporting: default alerting, user plugins, scheduling, method to publish stats to Epic

## Endpoints

- Production: https://nmsys.isg.apple.com

- QA (UAT): https://nmsys.qa.isg.apple.com

## Architecture

![Overview](images/overview.png)

## Key objects

nmSys uses 3 key objects to provide escalations of your alerts:

- [Alert](./key_objects.html#Alert) (Unique event/alert happening on a host)

- [Filter](./key_objects.html#Filter) (A filter definition applied against the  queue of alerts)
    * Custom thresholds are a subclass of filters with extra arguments

- [Subscription](./key_objects.html#Subscription) (Escalation definition to notify for alerts present in a filter)

## Other Objects

- **Notification** (Historical data: result of the escalation attempt)

- [Plugin](./plugins.html) (Extra configuration for the nmSys client)

- **Acknowledgment** (Historical data: all acknowledgements performed)
