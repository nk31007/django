### CREATE

```
#cat data
{
    "application": "filter",
    "definition": {
        "alert": "default@ping,default@reachable.*",
        "instance": ".*sys",
        "node": "~verdad.group=dcepicpoller,~verdad.group=dcepicapi"
    },
    "information": {
        "description": "Fix this in the morning",
        "gitlink": "",
        "name": "test_to_delete",
        "username": "epic-admin"
    },
    "name": "epic-admin@test_to_delete",
    "subscription": [
        {
            "email-contact": "epic-admin-alert@group.apple.com",
            "notif-ifcritical": "on",
            "notif-ifdigest": "on",
            "notification_type": "email",
            "resend-after": 1440,
            "select-duration": 1,
            "subscriber": "epic-admin"
        }
    ]
}
```

```
curl -X POST -H "Content-Type: application/json" -d @data https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/?format=json&oauth_consumer_key=yourkey
```

### RETRIEVE

```
curl -X GET https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/?format=json&oauth_consumer_key=yourkey&name=epic-admin@test_to_delete
```

### UPDATE

```
#cat data
{
    "application": "filter",
    "definition": {
        "alert": "default@ping,default@reachable.*",
        "instance": ".*sys",
        "node": "~verdad.group=dcepicpoller,~verdad.group=dcepicapi"
    },
    "information": {
        "description": "Fix this in the morning",
        "gitlink": "",
        "name": "test_to_delete",
        "username": "epic-admin"
    },
    "pk": "dc27332f-839d-4e50-8b8a-1656280cb57d",
    "name": "epic-admin@test_to_delete",
    "subscription": [
        {
            "email-contact": "epic-admin-alert@group.apple.com",
            "notif-ifcritical": "on",
            "notif-ifdigest": "on",
            "notification_type": "email",
            "resend-after": 1440,
            "select-duration": 1,
            "subscriber": "epic-admin"
        }
    ]
}
```

* Don't forget to add the key in the URL

```
curl -X PUT  -H "Content-Type: application/json" -d @data  https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/dc27332f-839d-4e50-8b8a-1656280cb57d/?format=json&oauth_consumer_key=yourkey
```

### DELETE

```
curl -X DELETE https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/dc27332f-839d-4e50-8b8a-1656280cb57d/?format=json&oauth_consumer_key=yourkey
```

### ADD A SUBSCRIPTION

```
#cat data
{
    "application": "filter",
    "definition": {
        "alert": "default@ping,default@reachable.*",
        "instance": ".*sys",
        "node": "~verdad.group=dcepicpoller,~verdad.group=dcepicapi"
    },
    "information": {
        "description": "Fix this in the morning",
        "gitlink": "",
        "name": "test_to_delete",
        "username": "epic-admin"
    },
    "pk": "dc27332f-839d-4e50-8b8a-1656280cb57d",
    "name": "epic-admin@test_to_delete",
    "subscription": [
        {
            "email-contact": "epic-admin-alert@group.apple.com",
            "notif-ifcritical": "on",
            "notif-ifdigest": "on",
            "notification_type": "email",
            "resend-after": 1440,
            "select-duration": 1,
            "subscriber": "epic-admin"
        },
        {
            "email-contact": "rfoucher@apple.com",
            "notif-ifcritical": "on",
            "notif-ifdigest": "on",
            "notification_type": "email",
            "resend-after": 1440,
            "select-duration": 1,
            "subscriber": "rfoucher"
        }
    ]
}
```

* Don't forget to add the key in the URL

```
curl -X PUT  -H "Content-Type: application/json" -d @data  https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/dc27332f-839d-4e50-8b8a-1656280cb57d/?format=json&oauth_consumer_key=yourkey
```

### REMOVE A SUBSCRIPTION

```
#cat data
{
    "application": "filter",
    "definition": {
        "alert": "default@ping,default@reachable.*",
        "instance": ".*sys",
        "node": "~verdad.group=dcepicpoller,~verdad.group=dcepicapi"
    },
    "information": {
        "description": "Fix this in the morning",
        "gitlink": "",
        "name": "test_to_delete",
        "username": "epic-admin"
    },
    "pk": "dc27332f-839d-4e50-8b8a-1656280cb57d",
    "name": "epic-admin@test_to_delete",
    "subscription": [
        {
            "email-contact": "rfoucher@apple.com",
            "notif-ifcritical": "on",
            "notif-ifdigest": "on",
            "notification_type": "email",
            "resend-after": 1440,
            "select-duration": 1,
            "subscriber": "rfoucher"
        }
    ]
}
```

* Don't forget to add the key in the URL

```
curl -X PUT  -H "Content-Type: application/json" -d @data  https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/dc27332f-839d-4e50-8b8a-1656280cb57d/?format=json&oauth_consumer_key=yourkey
```

### RETRIEVE ALL SUBSCRIPTION FOR A GIVEN USER

```
curl -X GET https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/?format=json&oauth_consumer_key=yourkey&subscription.subscriber=rfoucher
```

### RETRIEVE ALL SUBSCRIPTION FOR A GIVEN ROUTE

```
curl -X GET https://nmsys.isg.apple.com/nmsys/api/rest/v2/filter/?format=json&oauth_consumer_key=yourkey&subscription.notification_type=centralstation
```
