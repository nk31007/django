title: Extra Views
name: alert_ui_extra
---

#### Filter details view

![FilterView](images/filter_view.png)

#### Node details view

![NodeView](images/node_view.png)

#### Wizards

##### Create custom thresholds

- Via the Epic dashboards / UI:

All graphs in Epic feature a specific link/button to create alerts, which will allow you to quickly pre-fill the Custom threshold wizard

![NodeView](images/alert_creation_epic_UI.png)

Simply find/build the graph you are interested and click on create alert.

- Via graph URL  :

You can simply copy paste the URL from an Epic graph in the URL

![NodeView](images/copy_epic_graph.png)
