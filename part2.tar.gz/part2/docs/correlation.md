title: Correlation feature 
name: correlation
---

### Correlation overall details:


Correlation is the mechanism for identifying the relationships between alerts, with the goal of reducing cascading alert volume when key nodes fail. As such, the correlation API is tailored for use by nmSys.

(*Note: for now the only identified patterns are imported from Capri which means only GNS owned devices will have there alerts correlated.)

### Correlation in the UI

A correlation tab is present in the UI to relate events on demand 

![Tab](images/correlationtab.png)

The tab will eventually show correlated alerts when the correlation framework finds relations between the alerts.



### Correlation in the Notification

This feature is an opt-in option to enable it you will need to select correlation on notification in your subscription:


![Option](images/correlationoption.png)


Once the option is enabled, when a notification is sent, nmSys will try to find related alerts and embed them in the notification :

![Notification](images/correlationnotification2.png)
