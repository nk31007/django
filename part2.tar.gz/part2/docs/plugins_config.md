title: Plugins Configurations
name: alert_plugin_configs
---

The plugins can be configured either by [Remote Configuration](./plugins.html#Remote-configuration), or by [simple ini files](../client/nmsys_client.html#Configuration-File-Syntax)

Below are the available options and configuration examples for each of them.

#### ApacheLog

This plugin will stat in Epic the metrics extracted from
the Apache Log file. It will count the number of occurrence
of any given match. To use it, simply Enable
this plugin by putting a configuration file in conf.d/
    [ApacheLogPlugin apachefront]
    pattern=.*\s500\s.*
    name=trend_500_pageresult

#### Apache

This plugin will stat in Epic the metrics extracted from
the Apache server-status pager. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ApachePlugin apachefront]
    source=http://127.0.0.1/server-status
    name=trend_500_pageresult

- Options:
  source: Url to the Apache status page
- Defaults:
  source: http://127.0.0.1/server-status

Requirements:

    ExtendedStatus On
     <Location /server-status>
         SetHandler server-status
         Order deny,allow
         Deny from all
         Allow from 127.0.0.1
     </Location>

#### Docker (not yet supported)

 This plugin will stat in Epic the metrics extracted from
the hDocker API. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [DockerPlugin]

#### Elasticsearch

This plugin will stat in Epic the metrics extracted from
the health API call of Elasticsearch Server. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ElasticsearchPlugin myES]
    source=http://es-server.apple.com:9200

#### Haproxy

This plugin will stat in Epic the metrics extracted from
the Haproxy stats API. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [HaproxyPlugin myES]
    source=http://es-server.apple.com:9200

#### Jenkins

This plugin will stat in Epic the metrics extracted from
the Jenkins API. Extracting build duration and build status.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [JenkinsPlugin]
    source: https://cibuild.isg.apple.com/
    auth:true
    user: secretuser
    password: secretpass
    filter=epic-ui.*

Options:

    source: URL of the junkins API
    auth:       Auth is enabled (True|False)
    user:       Username for auth
    password:   Password for auth
    filter: Filter the project you want to trend

Defaults:

    source: https://cibuild.isg.apple.com/
    auth:   False
    user:  None
    password: None
    filter: None

#### Memcached

 This plugin will stat in Epic the metrics extracted from
the Memcached stats command.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MemcachedPlugin]
    host: 127.0.0.1
    port: 11211

Options:

    host: Hostname / IP of the memcached server
    port: memcached port

Defaults:

    host: 127.0.0.1
    port:   11211

#### Mongodb

This plugin will stat in Epic the metrics extracted from
the Mongodb stats command.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MongodbPlugin]
    host: 127.0.0.1
    port: 11211
    username: monitor
    password: nopass
    database: mainDB

Options:

    host: Hostname / IP of the mongodb server
    port: mongodb port
    user:       Username for auth
    password:   Password for auth
    database: Database you need extra metrics about

Defaults:

    host: 127.0.0.1
    port: 27017
    username: None
    password: None
    database: None

#### Mysql

 This plugin will stat in Epic the metrics extracted from
the Mysql stats commands.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [MysqlPlugin myapp]
    host: 127.0.0.1
    port: 3306
    username: monitor
    password: nopass
    type: advanced
    extra: replication

Options:

    host: Hostname / IP of the Mysql server
    port: Mysql port
    user:       Username for auth
    password:   Password for auth
    type: Type of metrics to be extracted (normal|extended) see NORMAL_METRIC_TYPES vs EXTENDED_METRIC_TYPES
    extra: Extra details based on your mysql configuration (replication|xtradb)

Defaults:

    host: 127.0.0.1
    port: 3306
    username: ***
    password: ***
    type: normal
    extra: None
Requirements:

    GRANT select, replication client, show databases, super, process ON *.* \
        TO '***'@'localhost' IDENTIFIED BY '***';
    GRANT select, replication client, show databases, super, process ON *.* \
        TO '***'@'%' IDENTIFIED BY '***’;

#### Nginx

This plugin will stat in Epic the metrics extracted from
the Nginx nginx_status page or the Status page for Nginx Plus.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [NginxPlugin]
    source=http://127.0.0.1/server-status

Options:

    source: Url to the Nginx status page

Defaults:

    source: http://127.0.0.1:8080/nginx_status

Requirements:

    server {
        listen 8080 default_server backlog=1024;
        location /nginx_status {
            stub_status on;
            access_log off;
            deny all;
            allow 127.0.0.1;
        }
    }

For NginxPlus:

    server {
        listen 8080 default_server backlog=1024;
        location /status {
            root   /usr/share/nginx/html;
            access_log off;
            status;
            deny all;
            allow 127.0.0.1;
        }
    }

#### NmsysClient

This plugin will stat in Epic the metrics of the nmSys client memory
and thread count footprint (mostly for debug). Can be used for other processes.
To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [NmsysClient]
    name: nmsysclient
    pid: 1200

Options:

    name: Name of the process you want to monitor
    pid: Pid of the process

Defaults:

    name: nmsysclient
    pid: self.pid()

#### Nmsys

This plugin will:

    * Execute any nmSys checks and report the Status to nmSys server
    * Stat in Epic the runtime metrics (status, duration)

To use it, simply Enable this plugin by putting a configuration file in conf.d/

    [NmsysPlugin Mycheck]
    action: nagios
    servicename: my_check
    command: check_disk
    params:
    run: 240

Options:

    name: Name of the process you want to monitor
    pid: Pid of the process

Defaults:

    name: nmsysclient
    pid: self.pid()

#### Parser

This plugin will stat in Epic the metrics extracted from
any Log file. It will count the number of occurence
of any given match. To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [ParserPlugin search]
    pattern=.*\sERROR\s.*
    name=trend_error_result

#### Postgresql

This plugin will stat in Epic the metrics extracted from
the Postgres stats commands.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [PostgresqlPlugin myapp]
    host: 127.0.0.1
    port: 5432
    username: monitor
    password: nopass

Options:

    host: Hostname / IP of the Postgresql server
    port: Postgresql port
    user:       Username for auth
    password:   Password for auth

Defaults:

    host: 127.0.0.1
    port: 5432
    username: ***
    password: ***

Requirements:
    CREATE USER statsRO with password '***';
    GRANT SELECT ON pg_stat_database TO '***';

#### Puppet

This plugin will stat in Epic the metrics extracted from
last_summary_run.yaml of puppet. It does not replace the
common check (check_puppet_run.py). It is mostly used to track
the catalog compilation and status based on Puppet main branch commit and changes.
If you need to track your master/dev branches of your puppet servers, simply Enable
this plugin by putting a configuration file in conf.d/

    [PuppetPlugin Master]
    puppetrun_file=/var/lib/puppet/state/last_run_summary.yaml

Options:

    puppetrun_file: Location of the last Run summary

Defaults:

    puppetrun_file: /var/lib/puppet/state/last_run_summary.yaml

#### Rabbitmq

This plugin will stat in Epic the metrics extracted from
the stats API call of Rabbitmq . To use it, simply Enable
this plugin by putting a configuration file in conf.d/

    [RabbitmqPlugin]
    user: secretuser
    password: secretpass
    source: http://localhost:55672/api/overview

Requirements:

    Ensure you have a monitoring user configured

Options:

    source:     URL to the Rabbitmq Overview page
    auth:       Auth is enabled (True|False)
    user:       Username for auth
    password:   Password for auth
    proxy: List of proxy to monitor
    all: stat them all
    type: Type of metrics to be extracted (default|extended) see NORMAL_METRIC_TYPES vs EXTENDED_METRIC_TYPES

Defaults:

    source:    http://localhost:6610/stats;csv
    auth:   False
    user:  None
    password: None
    proxy: ['frontend', 'backend']
    ignore: None
    all: False
    type: default

#### Redis

This plugin will stat in Epic the metrics extracted from Redis.
To use it, simply Enable this plugin by putting a configuration
file in conf.d/

    [RedisPlugin]
    host=127.0.0.1
    port=6379

Options:

    host: redis servert IP or DNS
    port: redis server port

Defaults:

    host: 127.0.0.1
    port 6379
